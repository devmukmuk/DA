"""Picture fingerprints, and the resized copies they find (design: docs/da-docs/SIMILAR-DESIGN.md).

A fingerprint is a 256-bit difference hash of the photo turned upright, made grey and shrunk to 17x16: is each pixel
brighter than the one to its right. Resizing and re-saving barely change it (an original and its 800x600 export:
0-1 bits); a different picture changes about half. It is kept in the index's `pictures` table by SHA-256, so a
rename or move doesn't redo it.
"""

from __future__ import annotations

import sqlite3
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

RESIZED_BITS = 6                  # two fingerprints this close are the same picture
SHAPE_TOLERANCE = 0.02            # width/height within 2%: the same shape
SMALLER = 0.9                     # a resized copy has under 90% of the original's pixels
FLAT = 24                         # a fingerprint with fewer than 24 bits set (or unset) is a plain picture: no match
BANDS = 8                         # 8 x 32 bits: two fingerprints within 6 bits share at least one band exactly
PICTURE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".tif", ".tiff", ".bmp", ".webp"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS pictures (
    sha256 TEXT PRIMARY KEY,
    fingerprint TEXT,
    width INTEGER,
    height INTEGER,
    made_at TEXT
);
"""


@dataclass(frozen=True)
class Print:
    """One picture's fingerprint and its full size, upright."""

    fingerprint: int
    width: int
    height: int


def picture_print(path: Path) -> Print | None:
    """Return a photo's fingerprint and upright size, or None when it can't be read."""
    import numpy as np  # pylint: disable=import-outside-toplevel
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    try:
        from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

        register_heif_opener()
    except ImportError:
        pass
    try:
        with Image.open(path) as img:
            width, height = img.size
            orientation = img.getexif().get(0x0112, 1)
            if orientation in (5, 6, 7, 8):
                width, height = height, width
            if img.format == "JPEG":
                img.draft("L", (256, 256))                      # decode at reduced size: much faster
            small = ImageOps.exif_transpose(img).convert("L").resize((17, 16), Image.LANCZOS)
        a = np.asarray(small, dtype=np.int16)
        bits = (a[:, 1:] > a[:, :-1]).flatten()
        value = 0
        for bit in bits:
            value = (value << 1) | int(bit)
        return Print(value, width, height)
    except Exception:  # pylint: disable=broad-except
        return None


def distance(a: int, b: int) -> int:
    """Return how many bits two fingerprints differ in."""
    return (a ^ b).bit_count()


def connect(db_path: Path) -> sqlite3.Connection:
    """Open the index with the pictures table there."""
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    return conn


def ensure(db_path: Path, files: Iterable[tuple[str, str]], progress: Callable[[int, int], None] | None = None,
           workers: int = 6) -> dict[str, Print]:
    """Return the fingerprint of each (path, sha256), working out (in threads) and keeping the ones not known yet."""
    files = [(p, s) for p, s in files if s and Path(p).suffix.lower() in PICTURE_EXTENSIONS]
    with connect(db_path) as conn:
        known = {s: Print(int(f, 16), w or 0, h or 0)
                 for s, f, w, h in conn.execute("SELECT sha256, fingerprint, width, height FROM pictures")
                 if f}
    todo = list({s: p for p, s in files if s not in known}.items())
    if todo:
        now = datetime.now().isoformat(timespec="seconds")
        done = 0
        with ThreadPoolExecutor(max_workers=workers) as pool, connect(db_path) as conn:
            for (sha, _path), made in zip(todo, pool.map(lambda item: picture_print(Path(item[1])), todo)):
                done += 1
                if made is not None:
                    known[sha] = made
                    conn.execute("INSERT OR REPLACE INTO pictures VALUES (?, ?, ?, ?, ?)",
                                 (sha, f"{made.fingerprint:064x}", made.width, made.height, now))
                if progress and (done % 200 == 0 or done == len(todo)):
                    progress(done, len(todo))
    return {s: known[s] for _p, s in files if s in known}


def _bands(value: int) -> list[tuple[int, int]]:
    return [(i, (value >> (32 * i)) & 0xFFFFFFFF) for i in range(BANDS)]


def same_shape(a: Print, b: Print) -> bool:
    """Return whether two pictures have the same shape (width/height within 2%)."""
    if not (a.width and a.height and b.width and b.height):
        return False
    return abs(a.width / a.height - b.width / b.height) <= SHAPE_TOLERANCE * (b.width / b.height)


def resized_copies(rows: list[dict[str, Any]], prints: dict[str, Print]) -> list[dict[str, Any]]:
    """Return each resized copy among rows (path, sha256, area) with the largest picture it's a copy of.

    Same picture (fingerprints within 6 bits), the same shape, and under 90% of the pixels. The kept one is the
    biggest; when two are as big, a filed one before one in intake. Exact copies (same SHA-256) aren't this step's.
    """
    by_sha: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in rows:
        if r["sha256"] in prints and FLAT <= prints[r["sha256"]].fingerprint.bit_count() <= 256 - FLAT:
            by_sha[r["sha256"]].append(r)
    shas = list(by_sha)
    buckets: dict[tuple[int, int], list[str]] = defaultdict(list)
    for sha in shas:
        for band in _bands(prints[sha].fingerprint):
            buckets[band].append(sha)
    parent = {s: s for s in shas}

    def root(s: str) -> str:
        while parent[s] != s:
            parent[s] = parent[parent[s]]
            s = parent[s]
        return s

    for members in buckets.values():
        if len(members) < 2 or len(members) > 500:            # a band shared by hundreds: a plain picture, skip
            continue
        for i, a in enumerate(members):
            for b in members[i + 1:]:
                pa, pb = prints[a], prints[b]
                if distance(pa.fingerprint, pb.fingerprint) <= RESIZED_BITS and same_shape(pa, pb):
                    parent[root(a)] = root(b)
    groups: dict[str, list[str]] = defaultdict(list)
    for sha in shas:
        groups[root(sha)].append(sha)
    out = []
    for members in groups.values():
        if len(members) < 2:
            continue
        rank = lambda s: (prints[s].width * prints[s].height,                     # noqa: E731
                          any(r["area"] != "intake" for r in by_sha[s]), -min(len(r["path"]) for r in by_sha[s]))
        best = max(members, key=rank)
        kept = sorted(by_sha[best], key=lambda r: (r["area"] == "intake", r["path"]))[0]
        big = prints[best].width * prints[best].height
        for sha in members:
            p = prints[sha]
            if sha == best or p.width * p.height >= SMALLER * big:
                continue
            if distance(p.fingerprint, prints[best].fingerprint) > RESIZED_BITS * 2:
                continue                                       # joined through others, too far from the kept one                                       # as big: an edit, not a resize (phase 2)
            for r in by_sha[sha]:
                out.append({**r, "kept": kept["path"], "kept_sha256": best, "size": f"{p.width} x {p.height}",
                            "kept_size": f"{prints[best].width} x {prints[best].height}",
                            "bits": distance(p.fingerprint, prints[best].fingerprint)})
    return sorted(out, key=lambda r: r["path"])
