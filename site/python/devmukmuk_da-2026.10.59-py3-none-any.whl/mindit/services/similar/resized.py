"""Plan setting resized copies aside: the smaller copy goes to holding, the largest picture stays (decided 2026-10-19)."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Callable

from mindit.services.similar.fingerprints import PICTURE_EXTENSIONS, ensure, resized_copies

NOTE = "a resized copy of "                    # + the kept picture's path: history, --duplicates and da picasa read it


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def kept_of(note: str | None) -> str | None:
    """Return the kept picture a resized copy's log note names, or None."""
    return note[len(NOTE):] if note and note.startswith(NOTE) else None


def plan_resized(db: Any, layout: Any, prefix: str | None = None, *, areas: tuple[str, ...] = ("intake",),
                 progress: Callable[[str], None] | None = None) -> list[dict[str, Any]]:
    """Plan moving resized copies into holding\\resized: those in `areas` (and under prefix), against every photo.

    Intake pictures with no SHA-256 yet are hashed first (and remembered in the index); fingerprints are kept by hash.
    """
    db.initialize(log=False)
    with db.connect() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT path, sha256, area, size_bytes FROM files WHERE area IN ('photos', 'intake')")]
    rows = [r for r in rows if Path(r["path"]).suffix.lower() in PICTURE_EXTENSIONS]
    missing = [r for r in rows if not r["sha256"] and r["area"] == "intake"]
    if missing:
        if progress:
            progress(f"fingerprinting: hashing {len(missing):,} intake pictures first")
        updates = []
        for r in missing:
            try:
                r["sha256"] = _sha256(Path(r["path"]))
                updates.append((r["sha256"], r["path"]))
            except OSError:
                continue
        with db.connect() as conn:
            conn.executemany("UPDATE files SET sha256 = ?, hash_status = 'computed' WHERE path = ?", updates)
    rows = [r for r in rows if r["sha256"]]
    prints = ensure(db.db_path, [(r["path"], r["sha256"]) for r in rows],
                    progress=(lambda d, n: progress(f"fingerprints: {d:,} of {n:,} new")) if progress else None)
    holding = layout.holding_root / "resized"
    plan = []
    for r in resized_copies(rows, prints):
        if r["area"] not in areas or (prefix and not r["path"].startswith(prefix)):
            continue
        src = Path(r["path"])
        try:
            mtime = src.stat().st_mtime
        except OSError:
            continue
        plan.append({"class": "resized_copy", "source": r["path"],
                     "destination": str(holding / src.relative_to(layout.data_root)),
                     "size_bytes": r["size_bytes"], "sha256": r["sha256"], "kept": r["kept"], "source_mtime": mtime,
                     "note": f"{NOTE}{r['kept']}", "pixels": r["size"], "kept_pixels": r["kept_size"],
                     "bits": r["bits"]})
    return plan


def give_details(plan: list[dict[str, Any]]) -> int:
    """Give each kept picture what only its resized copy had (Picasa faces, your tags); return how many gained some."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    gained = 0
    for p in plan:
        src, kept = Path(p["source"]), Path(p["kept"])
        if not Path(f"{src}.meta.json").exists() or not kept.exists():
            continue
        copy, keep = SidecarService.load(src), SidecarService.load(kept)
        changed = False
        if isinstance(copy.get("picasa"), dict) and not isinstance(keep.get("picasa"), dict):
            keep["picasa"] = copy["picasa"]                     # boxes are fractions: the same on the bigger picture
            changed = True
        mine = (copy.get("user") or {}).get("tags") or [] if isinstance(copy.get("user"), dict) else []
        if mine:
            user = keep.get("user") if isinstance(keep.get("user"), dict) else {}
            tags = list(user.get("tags") or [])
            new = [t for t in mine if t not in tags]
            if new:
                user["tags"] = tags + new
                keep["user"] = user
                changed = True
        if changed:
            SidecarService.save(kept, keep)
            gained += 1
    return gained
