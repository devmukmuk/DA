"""The copies of a photo DA set aside: exact ones (same SHA-256) and resized ones (same picture, smaller)."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any

from mindit.services.similar.resized import NOTE


def copies_of(pictures: list[tuple[Path, str]], data_root: Path, db_path: Path) -> dict[str, list[dict[str, Any]]]:
    """Return, for each (photo, sha256), the copies in _duplicates-holding still there: kind, path, bytes."""
    from mindit.services.contactsheet.contact_sheet import held_copies  # pylint: disable=import-outside-toplevel

    key = lambda p: os.path.normcase(str(Path(p).resolve()))           # noqa: E731
    wanted = {key(p): (p, sha) for p, sha in pictures}
    out: dict[str, list[dict[str, Any]]] = {k: [] for k in wanted}
    holding = data_root / "_duplicates-holding"
    if not holding.is_dir():
        return out
    held = held_copies(holding)
    for k, (photo, sha) in wanted.items():
        for copy in held.get(sha, []) if sha else []:
            if key(copy.path) != k:
                out[k].append({"kind": "exact copy", "path": copy.path, "size_bytes": copy.size_bytes})
    if Path(db_path).exists():
        from mindit.services.history.events import connect, follow  # pylint: disable=import-outside-toplevel

        with connect(db_path) as conn:
            try:
                rows = conn.execute("SELECT destination, note FROM events WHERE note LIKE ? AND undone_at IS NULL",
                                    (NOTE + "%",)).fetchall()
            except sqlite3.Error:
                rows = []
            for destination, note in rows:
                kept = key(follow(conn, note[len(NOTE):]))
                if kept in out and destination and Path(destination).is_file():
                    out[kept].append({"kind": "resized copy", "path": Path(destination),
                                      "size_bytes": Path(destination).stat().st_size, "pixels": _pixels(destination)})
    return out


def _pixels(path: str) -> str:
    try:
        from PIL import Image  # pylint: disable=import-outside-toplevel

        with Image.open(path) as img:
            return f"{img.width} x {img.height}"
    except Exception:  # pylint: disable=broad-except
        return ""


def describe(copy: dict[str, Any]) -> str:
    """Return 'resized copy in holding (800 x 600)' or 'exact copy in holding'."""
    return f"{copy['kind']} in holding" + (f" ({copy['pixels']})" if copy.get("pixels") else "")
