# src/mindit/config/computer.py

"""This PC's own settings: %LOCALAPPDATA%\\DA\\da-computer.yaml (docs/da-docs/COMPUTER-CONFIG-DESIGN.md).

An archive's da-archive.yaml goes wherever the archive goes; this file holds what is true only on this PC.
Today that is the `watch:` section (`da watch`): the folders to watch, the archives to match them against and
where the report goes. DA never needs the file: a command that reads a missing section says how to make it.

    computer: HOMEPC          # optional: a copy brought from another PC is refused instead of misread
    watch:
      report: D:\\archives
      sources:
        - E:\\pictures
      archives:               # an archive, a folder holding archives, or `registry` (every connected
        - D:\\archives         #   archive in archives.json); no list = registry
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from mindit.config.archive import known_archives, registry_path, this_computer

FILE = "da-computer.yaml"
OLD_WATCH_FILE = "watch-status.yaml"         # the standalone watch-status script's settings (2026-11-22)
SECTIONS = ("computer", "watch")
WATCH_KEYS = ("report", "sources", "archives", "cache")


class ComputerSettingsError(RuntimeError):
    """da-computer.yaml can't be used (and why)."""


def computer_path() -> Path:
    """Return this PC's settings file, beside archives.json."""
    return registry_path().parent / FILE


def read_computer(path: Path | None = None) -> dict[str, Any]:
    """Return da-computer.yaml as a dict ({} when there is none), refusing one made for another PC."""
    import yaml  # pylint: disable=import-outside-toplevel

    path = path or computer_path()
    if not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8-sig")) or {}
    except (OSError, yaml.YAMLError) as exc:
        raise ComputerSettingsError(f"{path} can't be read: {exc}") from exc
    if not isinstance(data, dict):
        raise ComputerSettingsError(f"{path}: expected settings (key: value), found {type(data).__name__}")
    unknown = sorted(set(data) - set(SECTIONS))
    if unknown:
        raise ComputerSettingsError(f"{path}: unknown setting(s) {', '.join(unknown)} (known: {', '.join(SECTIONS)})")
    pc = str(data.get("computer") or "").strip()
    if pc and pc.upper() != this_computer():
        raise ComputerSettingsError(f"{path} is for {pc.upper()}, and this is {this_computer()}. Fix `computer:`, "
                                    "or delete the file and run `da watch --init` here.")
    return data


@dataclass
class WatchSettings:
    """The watch: section, with archives listed as folders (registry entries expanded)."""

    path: Path
    sources: list[Path]
    archive_roots: list[Path]
    report: Path
    cache: Path | None = None
    missing: list[str] = field(default_factory=list)       # listed archive folders not connected now


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (str, Path)):
        return [str(value)]
    return [str(v) for v in value if v]


def watch_from(data: dict[str, Any], path: Path) -> WatchSettings:
    """Return the watch settings in a parsed watch: section (or an old watch-status.yaml)."""
    if not isinstance(data, dict):
        raise ComputerSettingsError(f"{path}: `watch:` should hold report:, sources: and archives:")
    unknown = sorted(set(data) - set(WATCH_KEYS) - {"computer"})
    if unknown:
        raise ComputerSettingsError(f"{path}: unknown watch setting(s) {', '.join(unknown)} "
                                    f"(known: {', '.join(WATCH_KEYS)})")
    sources = [Path(s) for s in _as_list(data.get("sources"))]
    if not sources:
        raise ComputerSettingsError(f"{path}: no `sources:` to watch")
    roots: list[Path] = []
    for entry in _as_list(data.get("archives")) or ["registry"]:
        roots += known_archives() if entry.strip().lower() == "registry" else [Path(entry)]
    report = data.get("report")
    cache = data.get("cache")
    return WatchSettings(path, sources, roots, Path(str(report)) if report else (roots[0] if roots else path.parent),
                         Path(str(cache)) if cache else None)


def old_watch_path() -> Path:
    """Return the standalone watch-status script's settings file (read until da watch --init moves it)."""
    return registry_path().parent / OLD_WATCH_FILE


def watch_settings(path: Path | None = None) -> WatchSettings | None:
    """Return this PC's watch settings: da-computer.yaml's watch: section, else an old watch-status.yaml."""
    import yaml  # pylint: disable=import-outside-toplevel

    path = path or computer_path()
    data = read_computer(path)
    if data.get("watch") is not None:
        return watch_from(data["watch"], path)
    old = old_watch_path()
    if path == computer_path() and old.is_file():
        try:
            old_data = yaml.safe_load(old.read_text(encoding="utf-8-sig")) or {}
        except (OSError, yaml.YAMLError) as exc:
            raise ComputerSettingsError(f"{old} can't be read: {exc}") from exc
        pc = str(old_data.get("computer") or "").strip() if isinstance(old_data, dict) else ""
        if pc and pc.upper() != this_computer():
            raise ComputerSettingsError(f"{old} is for {pc.upper()}, and this is {this_computer()}.")
        return watch_from(old_data, old)
    return None


def watch_section(report: Path, sources: list[Path], roots: list[Path], copies: list[Path], note: str = "") -> str:
    """Return a watch: section as YAML text (paths in single quotes; comments say what each part is)."""
    def quoted(p: Path | str) -> str:
        return "'" + str(p).replace("'", "''") + "'"

    lines = ["# da watch: the folders whose photos, videos and documents should end up in an archive, and the",
             "# archives to look for them in (an archive, a folder holding archives, or `registry` = every",
             "# connected archive DA knows on this PC).",
             "watch:",
             f"  report: {quoted(report)}        # WATCH-STATUS.md, watch-status.csv, watch-actions.csv",
             "  sources:" + (f"            # {note}" if note else "")]
    lines += [f"    - {quoted(s)}" for s in sources] or ["    - 'E:\\pictures'      # change me"]
    lines += ["  archives:"]
    lines += [f"    - {quoted(r)}" for r in roots] or ["    - registry"]
    lines += [f"    # - {quoted(c)}      # same name as one above: a backup copy?" for c in copies]
    return "\n".join(lines) + "\n"


def add_watch_section(text: str, path: Path | None = None) -> Path:
    """Write the watch: section into da-computer.yaml (made when missing; refused when it has one)."""
    path = path or computer_path()
    data = read_computer(path)
    if data.get("watch") is not None:
        raise ComputerSettingsError(f"{path} already has a watch: section; edit it there.")
    if path.is_file():
        old = path.read_text(encoding="utf-8-sig")
        new = old.rstrip("\n") + "\n\n" + text
    else:
        new = (f"# Settings for this PC ({this_computer()}) only; each archive's own settings are in its "
               "da-archive.yaml.\n\n"
               f"computer: {this_computer()}\n\n" + text)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(new, encoding="utf-8")
    tmp.replace(path)
    if read_computer(path).get("watch") is None:                 # verified re-read
        raise ComputerSettingsError(f"{path}: the watch: section didn't read back")
    return path
