# src/mindit/services/naming/moves.py

"""`da move`: put chosen filed files in a folder of their own inside their year (2017\\medical).

The folder is kept in each file's sidecar (user.folder), and the folder pattern puts a file with one there in
place of its last level (`folders.expected_folder`), so `da run`, validate and `da rename` keep it there.
`--clear` takes the folder off (the file goes back to its date folder). Names never change; raw files and
Live Photo videos follow their photo. Every move is logged (class `folder_move`) so `da intake undo` puts the
files back and their sidecars' folder as it was.
"""

from __future__ import annotations

import copy
import csv
import os
import re
from collections import Counter
from pathlib import Path
from typing import Any, Callable, Iterable

from mindit.services.naming.rename import NamePlan, _add_rows, _row, apply_names
from mindit.services.naming.rename import undo_rows as undo_names

LOG_CLASS = "folder_move"
MARKED = "marked"                     # log result: already in its folder; only the sidecar was changed
NOT_FILED = "not filed yet - file it with da run first"
HELD = "a copy set aside in _duplicates-holding; it stays there (da history --duplicates)"
NO_DATE = "no sure date - set one with da date set, then move it"
NO_SIDECAR = "no sidecar - run da validate on this folder first"
BY_TEMPLATE = "filed by its document template's folder"
_WAS = re.compile(r"was: (.*)$")


def folder_name(text: str) -> str:
    """Return the folder name to use for --new, or raise ValueError for one that can't be a single folder."""
    from mindit.services.naming.folders import _level  # pylint: disable=import-outside-toplevel

    if re.search(r"[\\/]", text or ""):
        raise ValueError("--new is one folder name (it goes inside the year folder), e.g. --new medical")
    name = _level(text or "")
    if not name:
        raise ValueError("--new needs a folder name, e.g. --new medical")
    return name


def _inside(path: Path, root: Path | None) -> bool:
    if root is None:
        return False
    return os.path.normcase(os.path.abspath(path)).startswith(os.path.normcase(os.path.abspath(root)) + os.sep)


def _with_folder(metadata: dict[str, Any], folder: str) -> dict[str, Any]:
    data = copy.deepcopy(metadata)
    user = data.get("user") if isinstance(data.get("user"), dict) else {}
    if folder:
        user["folder"] = folder
    else:
        user.pop("folder", None)
    data["user"] = user
    return data


def plan_moves(paths: Iterable[Path], folder: str, *, photos_root: Path | None, documents_root: Path | None,
               kind: str | None = None, progress: Callable[[int, int], None] | None = None) -> NamePlan:
    """Work out where each file goes with `folder` as its own folder ('' = back to its date folder); change nothing."""
    from mindit.services.naming.folders import chosen_folder, expected_folder, in_place  # pylint: disable=import-outside-toplevel
    from mindit.services.naming.rename import _providers  # pylint: disable=import-outside-toplevel
    from mindit.services.photoit.photoit_workflows import _load_metadata_json  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import companions, is_live_photo_part  # pylint: disable=import-outside-toplevel

    files = [Path(p) for p in paths if Path(p).exists() and not str(p).endswith(".meta.json")]
    following = {os.path.normcase(str(c)) for p in files for c in companions(p) if c.exists()}
    provider_for = _providers(documents_root)
    plan = NamePlan()
    planned: list[tuple[Path, list[Path], Path, str]] = []
    for i, path in enumerate(sorted(files, key=lambda p: str(p).lower()), 1):
        if progress:
            progress(i, len(files))
        if os.path.normcase(str(path)) in following:
            continue                                                  # it goes with its photo
        if not (_inside(path, photos_root) or _inside(path, documents_root)):
            held = any(part.lower() == "_duplicates-holding" for part in path.parts)
            label = "held copy" if held else "not filed"
            plan.rows.append(_row(path, "", "", label, HELD if held else NOT_FILED))
            plan.counts[label] += 1
            continue
        this_kind, provider = provider_for(path)
        if kind and this_kind != kind:
            continue
        if this_kind == "video" and is_live_photo_part(path):
            continue
        root = documents_root if this_kind == "document" else photos_root
        sidecar = Path(f"{path}.meta.json")
        if not sidecar.exists():
            plan.rows.append(_row(path, "", "", "no sidecar", NO_SIDECAR))
            plan.counts["no sidecar"] += 1
            continue
        capture = provider.capture_date(path)
        if not capture.certain:
            plan.rows.append(_row(path, "", "", "no date", NO_DATE))
            plan.counts["no date"] += 1
            continue
        metadata = _load_metadata_json(sidecar) or {}
        template = metadata.get("template") if isinstance(metadata.get("template"), dict) else {}
        if this_kind == "document" and template.get("folder"):
            plan.rows.append(_row(path, "", "", "template", BY_TEMPLATE))
            plan.counts["template"] += 1
            continue
        wanted, _missing = expected_folder(path, root, capture.value, _with_folder(metadata, folder), this_kind)
        target = path.parent if in_place(path, wanted) else wanted
        was = chosen_folder(metadata)
        note = f"folder: {folder or '(date folder)'}; was: {was}"
        others = [c for c in companions(path) if c.exists()]
        planned.append((path, others, target / path.name, note if was != folder else ""))
    _add_rows(plan, planned)
    return plan


def _mark(path: Path, folder: str) -> None:
    """Keep (or with '' take off) the file's own folder in its sidecar."""
    from mindit.services.sidecar.sidecar_service import SidecarService  # pylint: disable=import-outside-toplevel

    SidecarService.save(path, _with_folder(SidecarService.load(path), folder))


def apply_moves(plan: NamePlan, folder: str, log_path: Path, db_path: Path | None = None,
                progress: Callable[[int, int], None] | None = None, roots: Iterable[Path] = ()) -> Counter:
    """Move the planned files, keep the folder in their sidecars, and log it all so `da intake undo` reverses it."""
    from mindit.services.dbit.intake_service import LOG_FIELDS  # pylint: disable=import-outside-toplevel

    notes = {r["path"]: r["notes"] for r in plan.rows if r["action"] in ("move", "unchanged")}
    stats = apply_names(plan, log_path, db_path, progress=progress, roots=roots, log_class=LOG_CLASS, notes=notes)
    with log_path.open(encoding="utf-8", newline="") as f:
        moved = [r for r in csv.DictReader(f) if r["result"] == "moved" and not r["kept"]]
    for r in moved:
        _mark(Path(r["destination"]), folder)
    marked = [r for r in plan.rows if r["action"] == "unchanged" and r["notes"]]   # in place; only its folder changes
    with log_path.open("a", newline="", encoding="utf-8") as f:
        log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        for r in marked:
            _mark(Path(r["path"]), folder)
            log.writerow({**{k: "" for k in LOG_FIELDS}, "result": MARKED, "class": LOG_CLASS, "source": r["path"],
                          "destination": r["path"], "note": r["notes"]})
            stats[MARKED] += 1
    return stats


def undo_rows(db_path: Path | None, rows: list[dict[str, str]]) -> None:
    """After `da intake undo` puts moved files back, give their sidecars the folder they had before."""
    for r in rows:
        if r.get("kept"):
            continue                                                  # a raw/video that followed: no folder of its own
        match = _WAS.search(r.get("note") or "")
        if match is not None and Path(r["source"]).exists():
            _mark(Path(r["source"]), match.group(1).strip())
    moved = [r for r in rows if r["result"] == "moved"]
    if moved:
        undo_names(db_path, moved)


def marked_rows(log_path: Path) -> list[dict[str, str]]:
    """Return the log's rows for files only marked (not moved), for undo."""
    with log_path.open(encoding="utf-8", newline="") as f:
        return [r for r in csv.DictReader(f) if r["result"] == MARKED and r["class"] == LOG_CLASS]
