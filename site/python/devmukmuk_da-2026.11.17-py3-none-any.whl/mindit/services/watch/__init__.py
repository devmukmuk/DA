# src/mindit/services/watch/__init__.py

"""`da watch`: where every watched source folder is in the DA workflow."""
