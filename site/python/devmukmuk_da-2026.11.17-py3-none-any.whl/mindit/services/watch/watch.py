# src/mindit/services/watch/watch.py

"""`da watch`: where is every watched source folder in the DA workflow?

Reads this PC's watch settings (the `watch:` section of %LOCALAPPDATA%\\DA\\da-computer.yaml: the source folders,
the archives to match them against, where the report goes), then for every source folder and sub-folder counts
photos, videos and documents by extension and says where each file is now: filed in an archive's organized
folders, waiting in review (no sure date), still in intake, set aside as a copy (_duplicates-holding), or not in
any archive yet. Files are matched by content (SHA-256), so a renamed or moved copy still counts.

Read-only on the sources and the archives. Hashes are cached (path, size, modified time) in
%LOCALAPPDATA%\\DA\\watch-hashes.sqlite so later runs are quick. A source file is only hashed when an archive
holds a file of the same size; a file whose size matches nothing in any archive can't be there.

Writes, in the report folder: WATCH-STATUS.md (page 1: a three-column checklist of every action to print and
tick off; then the summary, the Actions with the command for each folder that has work left, and the folder
tree), watch-status.csv (every folder, a column per extension), watch-actions.csv (every action: ID, folder,
command) and watch-action-ids.csv (each action's ID, kept from run to run and never reused). Before
overwriting, the previous WATCH-STATUS.md, its PDF and the two report CSVs are copied to
watch-status-history\\<date>_<time>\\, so every report is kept.

A folder to import goes to the archive the import plan (`da imports`, imports.yaml) gives it, else the one
taking the year in its name (when several do, the one already holding most of its files), else the one
holding most of its files, else the biggest. Archives are named in full, so two archives of the same years
(jane-archive-200x, sam-archive-200x) stay apart.
"""
from __future__ import annotations

import collections
import csv
import hashlib
import html
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

from mindit.services.validateit.validateit_file_types import (DOCUMENT_ONLY_EXTENSIONS, PHOTO_EXTENSIONS,
                                                             RAW_EXTENSIONS, VIDEO_EXTENSIONS)

KINDS = ("photo", "video", "doc")

SKIP_DIRS = {"system volume information", "$recycle.bin"}
ARCHIVE_AREAS = ("intake", "photos", "documents", "_duplicates-holding")

# Where a file is, best first. A file in two places counts at the better one.
STATES = ("filed", "set aside", "review", "intake", "not in archive", "unchecked")
RANK = {s: i for i, s in enumerate(STATES)}
DONE = {"filed", "set aside"}

HASH_CACHE = "watch-hashes.sqlite"
OLD_CACHE = Path(r"C:\Scripts\watch-status\cache\watch-status-hashes.sqlite")   # the standalone script's
OLD_WATCH = Path(r"E:\archives\watch-folders.txt")                            # its first list format


class WatchProblem(RuntimeError):
    """da watch can't run (and why)."""


def kind_of(ext: str) -> str:
    """Return photo / video / doc / other for an extension (DA's own lists; a scanner's .jpg counts as a photo)."""
    if ext in PHOTO_EXTENSIONS or ext in RAW_EXTENSIONS:
        return "photo"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    if ext in DOCUMENT_ONLY_EXTENSIONS:
        return "doc"
    return "other"


def skip_dir(name: str) -> bool:
    """Return True for folders never counted (hidden ones, the recycle bin)."""
    return name.startswith(".") or name.lower() in SKIP_DIRS


def ext_of(name: str) -> str:
    """Return ".mp4" for "clip.MP4", and for a file named just ".MP4" too (splitext gives it no extension)."""
    return os.path.splitext("x" + name)[1].lower()


# What `da import` leaves behind (workflow/importer.py JUNK, dbit/mac_files.py): not photos, whatever the name.
JUNK = {"thumbs.db", "desktop.ini", ".ds_store"}
APPLE_DOUBLE = b"\x00\x05\x16\x07"   # a Mac's hidden "._name" metadata file, left beside what it copied


def is_apple_double(path: str, size: int) -> bool:
    """Return True for a "._name.jpg" a Mac left: AppleDouble metadata (by its header), not a picture."""
    if size > 1 << 20:
        return False
    try:
        with open(path, "rb") as f:
            return f.read(4) == APPLE_DOUBLE
    except OSError:
        return False


def not_a_file_to_count(name: str, path: str, size: int) -> bool:
    """Return True for junk `da import` leaves behind."""
    low = name.lower()
    return low in JUNK or (low.startswith("._") and is_apple_double(path, size))


def read_watch(path: Path) -> tuple[list[Path], list[Path]]:
    """Return the sources and archives of an old watch-folders.txt ("## source folders" / "## archives" lists)."""
    sources: list[Path] = []
    archives: list[Path] = []
    section = None
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("<!--"):
            continue
        if line.startswith("#"):
            head = line.lstrip("#").strip().lower()
            section = "sources" if head.startswith("source") else "archives" if head.startswith("archive") else None
            continue
        line = line.lstrip("-* ").strip().strip('"')
        if section == "sources":
            sources.append(Path(line))
        elif section == "archives":
            archives.append(Path(line))
    return sources, archives


def init_roots(archives: list[Path]) -> tuple[list[Path], list[Path]]:
    """Return what a new watch: section lists: a folder holding 2+ archives once, other archives by themselves;
    and the archives left out because one of the same name came first (a backup copy of another)."""
    names: set[str] = set()
    kept: list[Path] = []
    copies: list[Path] = []
    for a in archives:
        (copies if a.name.lower() in names else kept).append(a)
        names.add(a.name.lower())
    parents = collections.Counter(os.path.normcase(str(a.parent)) for a in kept)
    roots: list[Path] = []
    for a in kept:
        pick = a.parent if parents[os.path.normcase(str(a.parent))] >= 2 else a
        if pick not in roots:
            roots.append(pick)
    return roots, copies


def find_archives(roots: list[Path]) -> list[Path]:
    found: list[Path] = []
    for root in roots:
        if (root / "da-archive.yaml").is_file():
            found.append(root)
            continue
        if root.is_dir():
            found += sorted(p for p in root.iterdir() if p.is_dir() and (p / "da-archive.yaml").is_file())
    return found


# ---------------------------------------------------------------- hash cache

class HashCache:
    def __init__(self, path: Path | None):
        self.db = None
        if path:
            path.parent.mkdir(parents=True, exist_ok=True)
            self.db = sqlite3.connect(path)
            self.db.execute("create table if not exists h (path text primary key, size int, mtime real, sha text)")
        self.hashed = 0
        self.hashed_bytes = 0
        self.pending: list[tuple] = []

    def get(self, path: str, size: int, mtime: float) -> str | None:
        if not self.db:
            return None
        row = self.db.execute("select size, mtime, sha from h where path = ?", (path.lower(),)).fetchone()
        if row and row[0] == size and abs(row[1] - mtime) < 1:
            return row[2]
        return None

    def put(self, path: str, size: int, mtime: float, sha: str) -> None:
        if self.db:
            self.pending.append((path.lower(), size, mtime, sha))
            if len(self.pending) >= 500:
                self.flush()

    def flush(self) -> None:
        if self.db and self.pending:
            self.db.executemany("insert or replace into h values (?, ?, ?, ?)", self.pending)
            self.db.commit()
            self.pending.clear()

    def sha(self, path: str, size: int, mtime: float) -> str | None:
        got = self.get(path, size, mtime)
        if got:
            return got
        h = hashlib.sha256()
        try:
            with open(path, "rb") as f:
                while chunk := f.read(4 << 20):
                    h.update(chunk)
        except OSError:
            return None
        self.hashed += 1
        self.hashed_bytes += size
        digest = h.hexdigest()
        self.put(path, size, mtime, digest)
        return digest


# ---------------------------------------------------------------- archives

@dataclass
class ArchiveFiles:
    """Everything known about the archives' files."""

    # sha -> (state, archive name, archive folder, folder inside the archive)
    by_sha: dict[str, tuple[str, str, str, str]] = field(default_factory=dict)
    by_path: dict[str, str] = field(default_factory=dict)   # any path a file had in an archive (lower) -> sha
    sizes: set[int] = field(default_factory=set)
    counts: dict[str, collections.Counter] = field(default_factory=dict)
    no_sha: int = 0
    # source files still in intake or review: (state, archive folder, group folder) -> Counter of kinds
    left: dict[tuple[str, str, str], collections.Counter] = field(
        default_factory=lambda: collections.defaultdict(collections.Counter))
    names: dict[str, str] = field(default_factory=dict)      # archive folder -> its name in the report


def archive_state(rel_lower: str) -> str:
    if rel_lower.startswith("intake\\"):
        return "intake"
    if rel_lower.startswith("_duplicates-holding\\"):
        return "set aside"
    if "\\organized\\review\\" in "\\" + rel_lower:
        return "review"
    return "filed"


def group_folder(state: str, rel_dir: str) -> str:
    """The archive folder to act on: intake\\photos\\from-K-2023 (one import), or the review folder
    photos\\organized\\review\\from-E-2010\\2010 Bridal."""
    parts = Path(rel_dir).parts
    return str(Path(*parts[:3])) if state == "intake" else str(Path(*parts[:5]))


def archive_names(archives: list[Path]) -> dict[str, str]:
    """Return each archive's name (da-archive.yaml's, else its folder's) by folder; a name two archives share
    gets its drive or parent folder added, so a copy never counts as the other."""
    from mindit.services.workflow.split import archive_name  # pylint: disable=import-outside-toplevel

    names = {str(a): archive_name(a) for a in archives}
    seen = collections.Counter(v.lower() for v in names.values())
    for a in archives:
        if seen[names[str(a)].lower()] > 1:
            names[str(a)] = f"{names[str(a)]} ({a.parent})"
    return names


def load_archives(archives: list[Path], cache: HashCache, log) -> ArchiveFiles:
    """Read every archive's files: index rows and sidecars give hashes; the rest are hashed (and cached)."""
    out = ArchiveFiles(names=archive_names(archives))
    for arch in archives:
        name = out.names[str(arch)]
        index: dict[str, tuple[int, str]] = {}
        db_path = arch / ".da" / "da.sqlite"
        if db_path.is_file():
            # Read it all at once and let go: while this read is open, a running `da` can't save to the index
            # (DA #510: a `da run` failed with "database is locked").
            rows = []
            try:
                con = sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True, timeout=30)
                try:
                    # An index only `da history` has used has no files table yet (linds-archive-201x).
                    if con.execute("select 1 from sqlite_master where type = 'table' and name = 'files'").fetchone():
                        rows = con.execute("select path, size_bytes, sha256, source_path from files "
                                           "where sha256 is not null").fetchall()
                finally:
                    con.close()
            except sqlite3.Error as e:
                log(f"  {arch.name}: index not read ({e}); using sidecars and hashing")
            for p, size, sha, src in rows:
                index[p.lower()] = (size, sha)
                if src:
                    out.by_path.setdefault(src.lower(), sha)   # the intake path it was filed from
        counts = collections.Counter()
        t = time.time()
        for area in ARCHIVE_AREAS:
            top = arch / area
            if not top.is_dir():
                continue
            for dp, dns, fns in os.walk(top):
                dns[:] = [d for d in dns if not skip_dir(d)]
                for fn in fns:
                    low = fn.lower()
                    if low.endswith(".meta.json") or low.startswith("_contact-sheet"):
                        continue
                    if low.startswith("._") and is_apple_double(os.path.join(dp, fn), 0):
                        continue
                    ext = ext_of(low)
                    if kind_of(ext) == "other":
                        continue
                    full = os.path.join(dp, fn)
                    try:
                        st = os.stat(full)
                    except OSError:
                        continue
                    sha = None
                    hit = index.get(full.lower())
                    if hit and hit[0] == st.st_size:
                        sha = hit[1]
                    if not sha:
                        try:
                            with open(full + ".meta.json", encoding="utf-8") as f:
                                meta = json.load(f).get("file", {})
                            if meta.get("size_bytes") == st.st_size:
                                sha = meta.get("sha256")
                                if sha and meta.get("source_path"):
                                    out.by_path.setdefault(meta["source_path"].lower(), sha)
                        except (OSError, ValueError):
                            pass
                    if not sha:
                        sha = cache.sha(full, st.st_size, st.st_mtime)
                    if not sha:
                        out.no_sha += 1
                        continue
                    rel_dir = os.path.relpath(dp, arch)
                    state = archive_state(os.path.join(rel_dir, fn).lower())
                    counts[state] += 1
                    out.sizes.add(st.st_size)
                    out.by_path[full.lower()] = sha
                    prev = out.by_sha.get(sha)
                    if prev is None or RANK[state] < RANK[prev[0]]:
                        out.by_sha[sha] = (state, name, str(arch), rel_dir)
        cache.flush()
        counts["emptied"] = load_emptied(arch, out)
        out.counts[name] = counts
        log(f"  {name}: {sum(v for k, v in counts.items() if k != 'emptied'):,} files ({', '.join(f'{k} {v:,}' for k, v in counts.most_common())}) in {time.time() - t:.0f} s")
    return out


def load_emptied(arch: Path, out: ArchiveFiles) -> int:
    """Copies `da holding --empty` sent to the Recycle Bin still count as set aside: their original is kept
    (a re-saved JPG of a filed HEIC, a resized copy...). Read from output\\runs\\*-holding\\holding-check.csv
    (path, sha256, original) for the copies holding-emptied.csv says were recycled. Also links the intake
    path each copy came from to its hash, so `da import` plans without a hash still resolve."""
    found = 0
    for check in sorted((arch / "output" / "runs").glob("*-holding/holding-check.csv")):
        emptied: set[str] = set()
        try:
            with open(check.with_name("holding-emptied.csv"), encoding="utf-8-sig", newline="") as fh:
                emptied = {r["path"].lower() for r in csv.DictReader(fh) if r.get("result") == "recycled"}
        except OSError:
            continue
        try:
            with open(check, encoding="utf-8-sig", newline="") as fh:
                rows = list(csv.DictReader(fh))
        except OSError:
            continue
        for r in rows:
            path, sha = r.get("path", ""), r.get("sha256", "")
            if not sha or path.lower() not in emptied or os.path.exists(path):
                continue
            found += 1
            if r.get("size_bytes", "").isdigit():
                out.sizes.add(int(r["size_bytes"]))      # so a source file of this size gets checked
            rel = os.path.relpath(path, arch)
            parts = Path(rel).parts                       # _duplicates-holding\<date>\[class\]intake\...
            if "intake" in parts:
                intake = os.path.join(str(arch), *parts[parts.index("intake"):])
                out.by_path.setdefault(intake.lower(), sha)
            out.by_path.setdefault(path.lower(), sha)
            if sha not in out.by_sha:
                out.by_sha[sha] = ("set aside", out.names.get(str(arch), arch.name), str(arch), os.path.dirname(rel))
    return found


# ---------------------------------------------------------------- import plans

def load_plans(archives: list[Path], arch: ArchiveFiles) -> dict[str, tuple[int, str]]:
    """source path (lower) -> (size, sha) from every `da import` plan. The plan's own hash when it has one,
    else the hash of the file it was copied to (destination) or already matched (archived_copy)."""
    plans: dict[str, tuple[int, str]] = {}
    for arch_dir in archives:
        for f in sorted((arch_dir / "output" / "runs").glob("*-import/import-plan.csv")):
            try:
                with open(f, encoding="utf-8-sig", newline="") as fh:
                    for r in csv.DictReader(fh):
                        if not r.get("size_bytes", "").isdigit():
                            continue
                        sha = (r.get("sha256")
                               or arch.by_path.get((r.get("destination") or "").lower())
                               or arch.by_path.get((r.get("archived_copy") or "").lower()))
                        if sha:
                            plans[r["source"].lower()] = (int(r["size_bytes"]), sha)
            except OSError:
                pass
    return plans


# ---------------------------------------------------------------- sources

@dataclass
class Tally:
    ext: collections.Counter = field(default_factory=collections.Counter)      # ".jpg" -> n (media only)
    kind: collections.Counter = field(default_factory=collections.Counter)     # photo/video/doc/other
    state: collections.Counter = field(default_factory=collections.Counter)    # STATES -> n
    state_kind: collections.Counter = field(default_factory=collections.Counter)  # (state, kind) -> n
    where: collections.Counter = field(default_factory=collections.Counter)    # archive short name -> n
    bytes: int = 0

    def add(self, other: "Tally") -> None:
        self.ext.update(other.ext)
        self.kind.update(other.kind)
        self.state.update(other.state)
        self.state_kind.update(other.state_kind)
        self.where.update(other.where)
        self.bytes += other.bytes

    @property
    def media(self) -> int:
        return sum(self.kind[k] for k in KINDS)

    @property
    def done(self) -> int:
        return sum(self.state[s] for s in DONE)

    def pct(self) -> float | None:
        return 100.0 * self.done / self.media if self.media else None

    def stage(self) -> str:
        m = self.media
        if not m:
            return "no media"
        if self.done == m:
            return "done"
        if self.state["not in archive"] + self.state["unchecked"] == m:
            return "not started" if not self.state["unchecked"] else "not started?"
        if self.state["not in archive"]:
            return "import"            # some files still to bring in (da import)
        if self.state["intake"]:
            return "run"               # imported, waiting for da run
        if self.state["review"]:
            return "review"            # filed except files with no sure date
        return "hash"                  # only unchecked files left: run without --no-hash


@dataclass
class Folder:
    path: Path
    depth: int
    own: Tally = field(default_factory=Tally)
    total: Tally = field(default_factory=Tally)
    children: list["Folder"] = field(default_factory=list)


def scan_source(root: Path, arch: ArchiveFiles, plans, cache: HashCache, hashing: bool, progress) -> Folder:
    def walk(path: Path, depth: int) -> Folder:
        node = Folder(path, depth)
        try:
            entries = sorted(os.scandir(path), key=lambda e: e.name.lower())
        except OSError:
            return node
        for e in entries:
            try:
                is_dir = e.is_dir(follow_symlinks=False)
            except OSError:
                continue
            if is_dir:
                # An archive inside a source (E:\library\library-astronomy) is where files go, not one to file.
                if not skip_dir(e.name) and not os.path.isfile(os.path.join(e.path, "da-archive.yaml")):
                    node.children.append(walk(Path(e.path), depth + 1))
                continue
            ext = ext_of(e.name)
            kind = kind_of(ext)
            if kind != "other" and e.name.startswith("._"):
                try:
                    if not_a_file_to_count(e.name, e.path, e.stat().st_size):
                        kind = "other"            # a Mac's ._ metadata file: da import leaves it, so don't count it
                except OSError:
                    pass
            t = node.own
            t.kind[kind] += 1
            if kind == "other":
                continue
            try:
                st = e.stat()
            except OSError:
                continue
            t.ext[ext] += 1
            t.bytes += st.st_size
            state, where = "not in archive", None
            if st.st_size in arch.sizes:
                sha = None
                plan = plans.get(e.path.lower())
                if plan and plan[0] == st.st_size:
                    sha = plan[1]
                if not sha:
                    sha = cache.get(e.path, st.st_size, st.st_mtime)
                if not sha and hashing:
                    sha = cache.sha(e.path, st.st_size, st.st_mtime)
                if sha:
                    hit = arch.by_sha.get(sha)
                    if hit:
                        state, where, arch_dir, rel_dir = hit
                        if state in ("intake", "review"):
                            arch.left[(state, arch_dir, group_folder(state, rel_dir))][kind] += 1
                else:
                    state = "unchecked"
            t.state[state] += 1
            t.state_kind[(state, kind)] += 1
            if where:
                t.where[where] += 1
            progress()
        node.total.add(node.own)
        for c in node.children:
            node.total.add(c.total)
        return node

    return walk(root, 0)


def flatten(node: Folder):
    yield node
    for c in node.children:
        yield from flatten(c)


# ---------------------------------------------------------------- output

def n(v: int) -> str:
    return f"{v:,}" if v else ""


def gb(b: int) -> str:
    return f"{b / 1e9:.1f} GB" if b >= 1e8 else f"{b / 1e6:.0f} MB" if b else ""


def pct_text(t: Tally) -> str:
    p = t.pct()
    if p is None:
        return ""
    return "100%" if t.done == t.media else f"{min(p, 99.9):.1f}%" if p >= 99 else f"{p:.0f}%"


def exts_text(t: Tally, limit: int = 6) -> str:
    top = t.ext.most_common()
    text = ", ".join(f"{e.lstrip('.')} {c:,}" for e, c in top[:limit])
    return text + (f", +{len(top) - limit} more" if len(top) > limit else "")


def where_text(t: Tally) -> str:
    return ", ".join(f"{a} {c:,}" for a, c in t.where.most_common())


def bar(t: Tally, width: int = 10) -> str:
    p = t.pct()
    if p is None:
        return ""
    full = int(round(p / 100 * width))
    return "#" * full + "." * (width - full)


def label(f: Folder, root: Path) -> str:
    if f.depth == 0:
        return str(f.path)
    return "  " * f.depth + f.path.name


STAGE_MARK = {"done": "[x]", "review": "[~]", "run": "[ ]", "import": "[ ]", "hash": "[?]",
              "not started": "[ ]", "not started?": "[?]", "no media": ""}


@dataclass
class Action:
    step: str        # import / run / pair-movies / review / hash
    where: str       # the folder to act on
    files: int
    what: str        # what's there
    command: str     # one line, runs as is from any folder in PowerShell
    note: str = ""   # what to do around it (preview first...)
    label: str = ""  # short name for the printed checklist
    id: str = ""     # I7, R2...: the same from run to run (watch-action-ids.csv)


STEP_PREFIX = {"import": "I", "run": "R", "pair-movies": "P", "review": "V", "hash": "H"}
STEP_TITLES = {"import": "Import: not in any archive yet", "run": "Run: imported, waiting in intake",
               "pair-movies": "Pair movies: videos in intake", "review": "Review: filed, no sure date",
               "hash": "Hash: not checked yet"}
STEP_SHORT = {"import": "Import", "run": "Run", "pair-movies": "Pair movies", "review": "Review", "hash": "Hash"}
YEAR = re.compile(r"(?<!\d)((?:19|20)\d\d)(?!\d)")


def kinds_text(c: collections.Counter) -> str:
    return ", ".join(f"{c[k]:,} {k}{'s' if c[k] != 1 else ''}" for k in KINDS if c[k])


def import_folders(node: Folder, depth: int, rows: list[tuple[Folder, int, bool]]) -> None:
    """The folders that still hold files no archive has: the deepest such folder down to `depth`."""
    if not node.total.state["not in archive"]:
        return
    kids = [c for c in node.children if c.total.state["not in archive"]]
    if node.depth >= depth or not kids:
        rows.append((node, node.total.state["not in archive"], False))
        return
    if node.own.state["not in archive"]:
        rows.append((node, node.own.state["not in archive"], True))   # files directly in it
    for c in kids:
        import_folders(c, depth, rows)


def find_plan(archives: list[Path]) -> Path | None:
    """Return the import plan (`da imports`, imports.yaml) beside one of the archives, if there is one."""
    from mindit.services.workflow.imports import PLAN  # pylint: disable=import-outside-toplevel

    for a in archives:
        if (a.parent / PLAN).is_file():
            return a.parent / PLAN
    return None


def planned_archives(plan_file: Path | None, archives: list[Path], arch: ArchiveFiles) -> list[tuple[Path, Path, list[str]]]:
    """Return (source, archive, excluded patterns) from the import plan, deepest source first; [] without one."""
    from mindit.services.workflow.imports import PlanProblem, read_plan  # pylint: disable=import-outside-toplevel

    plan_file = plan_file or find_plan(archives)
    if plan_file is None or not plan_file.is_file():
        return []
    try:
        plan = read_plan(plan_file)
    except PlanProblem:
        return []
    by_name: dict[str, Path] = {}
    for a in archives:
        by_name.setdefault(arch.names.get(str(a), a.name).lower(), a)
        by_name.setdefault(a.name.lower(), a)
    found = [(s.source, by_name[s.archive.lower()], s.exclude) for s in plan if s.archive.lower() in by_name]
    return sorted(found, key=lambda x: -len(x[0].parts))


def _under(folder: Path, top: Path) -> bool:
    f, t = os.path.normcase(str(folder)).rstrip("\\/"), os.path.normcase(str(top)).rstrip("\\/")
    return f == t or f.startswith(t + os.sep)


def _excluded(folder: Path, patterns: list[str]) -> bool:
    import fnmatch  # pylint: disable=import-outside-toplevel

    levels = [folder, *folder.parents]
    return any(fnmatch.fnmatch(os.path.normcase(str(level)), os.path.normcase(p)) for p in patterns for level in levels)


def import_archive(f: Folder, archives: list[Path], arch: ArchiveFiles,
                   planned: list[tuple[Path, Path, list[str]]] | None = None) -> tuple[Path | None, str]:
    """Return the archive to import a folder into, and why: the import plan's; else the one taking a year in its
    path (deepest first; when several take it, the one already holding most of its files); else the one holding
    most of its files; else the one with the most filed files."""
    from mindit.services.workflow.split import archive_years  # pylint: disable=import-outside-toplevel

    for source, target, exclude in planned or []:
        if _under(f.path, source) and not _excluded(f.path, exclude):
            return target, "the import plan (imports.yaml)"
    by_name = {arch.names.get(str(a), a.name): a for a in archives}
    holding = [by_name[name] for name, _ in f.total.where.most_common() if name in by_name]
    for part in reversed(f.path.parts):
        m = YEAR.search(part)
        if not m:
            continue
        year = int(m.group(1))
        fits = [a for a in archives if (span := archive_years(a)) and span[0] <= year <= span[1]]
        if len(fits) == 1:
            return fits[0], f"{year} in the folder name"
        if fits:
            for a in holding:
                if a in fits:
                    return a, f"{year} in the folder name; most of its other files are there"
            others = ", ".join(arch.names.get(str(a), a.name) for a in fits[1:])
            return fits[0], f"{year} in the folder name - {others} take{'s' if len(fits) == 2 else ''} {year} too: check"
    if holding:
        return holding[0], "where its other files are"
    if archives:
        best = max(archives, key=lambda a: arch.counts.get(arch.names.get(str(a), a.name), collections.Counter())["filed"])
        return best, "the biggest archive"
    return None, ""


def short_label(path: str, keep: int = 16) -> str:
    """The folder's own name, with its parent's when the name alone is short (2012 -> Old Laptop Pictures\\2012)."""
    parts = Path(path).parts
    if len(parts) >= 2 and len(parts[-1]) < keep:
        return "\\".join(p.rstrip("\\") for p in parts[-2:])
    return parts[-1] if parts else path


def actions(roots: list[Folder], arch: ArchiveFiles, depth: int, archives: list[Path],
            planned: list[tuple[Path, Path, list[str]]] | None = None) -> list[Action]:
    """Return what's left to do, biggest first per step: import, run, pair-movies, review, hash."""
    def name_of(folder: Path | str) -> str:
        return arch.names.get(str(folder), Path(folder).name)

    acts: list[Action] = []
    for r in roots:
        rows: list[tuple[Folder, int, bool]] = []
        import_folders(r, depth, rows)
        for f, count, own_only in sorted(rows, key=lambda x: -x[1]):
            tally = f.own if own_only else f.total
            kinds = collections.Counter({k: tally.state_kind[("not in archive", k)] for k in KINDS})
            what = ("files directly in this folder: " if own_only else "") + kinds_text(kinds)
            target, why = import_archive(f, archives, arch, planned)
            into = f' --archive "{target}"' if target else ""
            note = "copies straight away; without --apply --yes it only shows the plan" + (
                f". {name_of(target)}: {why}; da split moves other years" if target else "")
            acts.append(Action("import", str(f.path), count, what, f'da import "{f.path}"{into} --apply --yes', note,
                               (f"{name_of(target)}: " if target else "") + short_label(str(f.path))))
    for (state, arch_dir, folder), kinds in sorted(arch.left.items(), key=lambda x: -sum(x[1].values())):
        total = sum(kinds.values())
        name = f"{name_of(arch_dir)}: {Path(folder).name}"
        if state == "intake":
            if kinds["video"] < total:   # a folder of only videos already had its run: they wait for their photo
                acts.append(Action("run", f"{arch_dir}\\{folder}", total, kinds_text(kinds),
                                   f'da run "{arch_dir}\\{folder}" --yes', "without --yes it asks before moving files",
                                   name))
            if kinds["video"]:
                acts.append(Action("pair-movies", f"{arch_dir}\\{folder}", kinds["video"],
                                   "videos left in intake: Live Photo halves go beside their filed photo",
                                   f'da pair-movies "{arch_dir}\\{folder}" --apply',
                                   "moves straight away; without --apply it only shows what would move", name))
        else:
            acts.append(Action("review", f"{arch_dir}\\{folder}", total, kinds_text(kinds) + " with no sure date",
                               f'da review --archive "{arch_dir}"', "or the dashboard's Dates page",
                               f"{name_of(arch_dir)}: {short_label(folder, keep=8)}"))
    unchecked = sum(r.total.state["unchecked"] for r in roots)
    if unchecked:
        acts.append(Action("hash", "", unchecked, "files an archive may hold (same size), not hashed yet",
                           "da watch", "without --no-hash", "hash the unchecked files"))
    return acts


# ---------------------------------------------------------------- action IDs

ID_FIELDS = ["id", "step", "folder", "first_seen", "last_seen"]


def assign_ids(acts: list[Action], path: Path, when: str, full_run: bool, save: bool) -> list[dict]:
    """Give each action its ID from watch-action-ids.csv, adding new ones (I = import, R = run, P = pair-movies,
    V = review, H = hash; numbers are never reused). Returns the actions of the last full run that are gone
    now (finished), or [] after a --source run. Only full runs move last_seen."""
    rows: list[dict] = []
    try:
        with open(path, encoding="utf-8-sig", newline="") as fh:
            rows = [r for r in csv.DictReader(fh) if r.get("id")]
    except OSError:
        pass
    known = {(r["step"], r["folder"].lower()): r for r in rows}
    top: collections.Counter = collections.Counter()
    for r in rows:
        num = r["id"][1:]
        if num.isdigit():
            top[r["id"][0]] = max(top[r["id"][0]], int(num))
    previous = max((r["last_seen"] for r in rows if r.get("last_seen")), default="")
    seen = set()
    for a in acts:
        key = (a.step, a.where.lower())
        seen.add(key)
        row = known.get(key)
        if row is None:
            prefix = STEP_PREFIX.get(a.step, "X")
            top[prefix] += 1
            row = {"id": f"{prefix}{top[prefix]}", "step": a.step, "folder": a.where, "first_seen": when,
                   "last_seen": ""}
            rows.append(row)
            known[key] = row
        if full_run:
            row["last_seen"] = when
        a.id = row["id"]
    finished = [] if not (full_run and previous) else [
        r for r in rows if r.get("last_seen") == previous and (r["step"], r["folder"].lower()) not in seen]
    if save:
        with open(path, "w", encoding="utf-8-sig", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=ID_FIELDS, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)
    return finished


def id_key(action_id: str) -> tuple[str, int]:
    num = action_id[1:]
    return (action_id[:1], int(num) if num.isdigit() else 0)


# ---------------------------------------------------------------- actions out

ACTION_FIELDS = ["id", "step", "folder", "files", "what", "command", "note"]


def write_actions_csv(path: Path, acts: list[Action]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(ACTION_FIELDS)
        for a in acts:
            w.writerow([a.id, a.step, a.where, a.files, a.what, a.command, a.note])


CHECKLIST_CSS = """<style>
.wa-sheet { break-after: page; font-size: 7.5pt; line-height: 1.18; }
.wa-head { font-size: 9pt; border-bottom: 1.5px solid #000; padding-bottom: 2pt; margin-bottom: 4pt; }
.wa-head b { font-size: 11pt; }
.wa-cols { column-count: 3; column-gap: 12pt; column-rule: 1px solid #ccc; }
.wa-step { font-weight: bold; border-bottom: 1px solid #888; margin: 0 0 2pt; padding-top: 3pt; break-after: avoid; }
.wa-item { break-inside: avoid; position: relative; padding: 1.2pt 0 1.2pt 12pt; }
.wa-box { position: absolute; left: 0; top: 2pt; width: 7pt; height: 7pt; border: 1px solid #000; }
.wa-line { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.wa-id { font-weight: bold; display: inline-block; min-width: 2.6em; }
.wa-sub { color: #444; font-size: 6.8pt; }
.wa-foot { font-size: 7pt; color: #444; margin-top: 4pt; border-top: 1px solid #ccc; padding-top: 2pt; }
</style>"""


def checklist_html(acts: list[Action], when: str, finished: list[dict]) -> list[str]:
    """Page 1: every action in three columns with a box to tick, to print once and check off."""
    esc = html.escape
    two_lines = len(acts) <= 105          # the "what" line too while it still fits on one page
    total = sum(a.files for a in acts)
    out = [CHECKLIST_CSS, "", '<div class="wa-sheet">',
           f'<div class="wa-head"><b>Watch checklist</b> &nbsp;·&nbsp; made {esc(when)} &nbsp;·&nbsp; '
           f'{len(acts):,} actions, {total:,} files. Tick each one when it&rsquo;s done. IDs stay the same from '
           f'run to run, so this sheet still works after the next report.</div>',
           '<div class="wa-cols">']
    for step in STEP_TITLES:
        rows = [a for a in acts if a.step == step]
        if not rows:
            continue
        out.append(f'<div class="wa-step">{esc(STEP_SHORT[step])} ({len(rows):,} · {sum(a.files for a in rows):,} files)</div>')
        for a in rows:
            line = (f'<div class="wa-line"><span class="wa-id">{esc(a.id)}</span>{esc(a.label)}'
                    + ("" if two_lines else f' <span class="wa-sub">{a.files:,}</span>') + "</div>")
            brief = f"{a.files:,} videos" if a.step == "pair-movies" else a.what
            sub = f'<div class="wa-line wa-sub">{esc(brief)}</div>' if two_lines else ""
            out.append(f'<div class="wa-item"><span class="wa-box"></span>{line}{sub}</div>')
    out.append("</div>")
    foot = "Commands: <code>da watch --cmd I7</code> copies an action&rsquo;s command to the clipboard (several IDs: one per line)."
    if finished:
        foot += " Finished since the last report: " + esc(", ".join(sorted((r["id"] for r in finished), key=id_key))) + "."
    out.append(f'<div class="wa-foot">{foot}</div>')
    out.append("</div>")
    out.append("")
    return out


def actions_markdown(acts: list[Action], finished: list[dict], limit: int = 40) -> list[str]:
    out = ["## Actions", ""]
    if finished:
        out.append("**Finished since the last report:** "
                   + ", ".join(f"{r['id']} ({md_text(r['folder']) or r['step']})"
                               for r in sorted(finished, key=lambda r: id_key(r["id"]))))
        out.append("")
    if not acts:
        return out + ["Nothing left: every photo, video and document in the watch folders is filed.", ""]
    out.append("What's left, biggest first. Rebuilt on every run, so finished work drops off; an action keeps its ID "
               "from run to run. Every row is in `watch-actions.csv`. The commands change files straight away "
               "(`--apply --yes`); each note says how to preview instead.")
    out.append("")
    out.append("**Copying a command:** a PDF breaks long commands across lines, so don't copy them from the PDF. "
               "Run `da watch --cmd I7` (or several: `da watch --cmd I7 R2`): it prints them and puts them "
               "on the clipboard, one command per line. Each is a single `da ...` with the archive in it (a full "
               "path, or `--archive`), so it runs from any folder in PowerShell or Command Prompt.")
    out.append("")
    for step, title in STEP_TITLES.items():
        rows = [a for a in acts if a.step == step]
        if not rows:
            continue
        out.append(f"### {title} ({sum(a.files for a in rows):,} files)")
        out.append("")
        out.append("| ✓ | ID | Folder | Files | What | Command |")
        out.append("|---|---|---|--:|---|---|")
        for a in rows[:limit]:
            what = md_text(a.what) + (f" *({md_text(a.note)})*" if a.note else "")
            out.append(f"| [ ] | **{a.id}** | {md_text(a.where)} | {a.files:,} | {what} | `{md_text(a.command)}` |")
        if len(rows) > limit:
            out.append(f"| | | *{len(rows) - limit:,} more in watch-actions.csv* | {sum(a.files for a in rows[limit:]):,} | | |")
        out.append("")
    return out


def md_text(s: str) -> str:
    return s.replace("|", "/")


def console_actions(acts: list[Action], limit: int = 12) -> None:
    if not acts:
        return
    print("Next actions (biggest first; all in WATCH-STATUS.md and watch-actions.csv; "
          "`da watch --cmd <ID>` copies a command):")
    for a in sorted((a for a in acts if a.step != "hash"), key=lambda a: -a.files)[:limit]:
        print(f"  {a.id:<5} {a.step:<11} {a.files:>8,}  {a.where}")
        print(f"  {'':<5} {'':<11} {'':>8}  {a.command}" + (f"   # {a.note}" if a.note else ""))
    for a in acts:
        if a.step == "hash":
            print(f"  {a.id:<5} {a.step:<11} {a.files:>8,}  {a.command}   # {a.note}")
    print()


def copy_commands(csv_path: Path, ids: list[str]) -> int:
    """--cmd: print the commands for these action IDs from the last report and put them on the clipboard."""
    try:
        with open(csv_path, encoding="utf-8-sig", newline="") as fh:
            rows = {r["id"].upper(): r for r in csv.DictReader(fh) if r.get("id")}
    except OSError:
        print(f"No {csv_path}: run da watch first.", file=sys.stderr)
        return 1
    wanted = [i.strip().upper() for arg in ids for i in arg.replace(",", " ").split() if i.strip()]
    missing = [i for i in wanted if i not in rows]
    if missing:
        print(f"Not in {csv_path.name} (finished, or not made yet): {', '.join(missing)}", file=sys.stderr)
        return 1
    for i in wanted:
        r = rows[i]
        print(f"# {i}  {r['step']}  {r['folder']}  ({int(r['files']):,} files)"
              + (f"  - {r['note']}" if r.get("note") else ""))
    print()
    lines = [rows[i]["command"] for i in wanted]
    for line in lines:
        print(line)
    print()
    try:
        # via an environment variable, so any path survives (clip.exe needs a byte-order mark that then gets pasted)
        subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                        "Set-Clipboard -Value $env:WATCH_STATUS_CLIP"], check=True, capture_output=True,
                       env={**os.environ, "WATCH_STATUS_CLIP": "\r\n".join(lines)}, timeout=30)
        print(f"Copied {len(lines)} command{'s' if len(lines) != 1 else ''} to the clipboard"
              + (" (one per line; pasting runs each one when you press Enter)." if len(lines) > 1 else "."))
    except (OSError, subprocess.SubprocessError):
        print("(Couldn't reach the clipboard; copy the lines above.)")
    return 0


def console(roots: list[Folder], depth: int) -> None:
    head = f"{'Folder':<58} {'Photos':>8} {'Videos':>7} {'Docs':>6} {'Filed':>8} {'Review':>7} {'Intake':>7} {'Not in':>8} {'Done':>6}  {'':10}  Next"
    print(head)
    print("-" * len(head))
    for root in roots:
        for f in flatten(root):
            if f.depth > depth or not f.total.media:
                continue
            t = f.total
            name = label(f, root.path)
            if len(name) > 58:
                name = name[:55] + "..."
            missing = t.state["not in archive"] + t.state["unchecked"]
            print(f"{name:<58} {n(t.kind['photo']):>8} {n(t.kind['video']):>7} {n(t.kind['doc']):>6} "
                  f"{n(t.state['filed'] + t.state['set aside']):>8} {n(t.state['review']):>7} {n(t.state['intake']):>7} "
                  f"{n(missing):>8} {pct_text(t):>6}  {bar(t):10}  {t.stage()}")
        print()


def markdown(roots: list[Folder], depth: int, meta: dict, acts: list[Action], finished: list[dict]) -> str:
    out = checklist_html(acts, meta["when"], finished) if acts else []
    out += ["# Watch folders: where every source folder is in the DA workflow", ""]
    out.append(f"*Made {meta['when']} by `da watch` from `{meta['watch']}`. Read-only; rerun it to refresh. "
               f"Files are matched by content (SHA-256), so renamed copies count.*")
    out.append("")
    out.append("**Steps:** `da import <folder>` (preview, then `--apply`) → `da run intake\\...` → date the review files → done. "
               "**Next** says which step each folder is waiting on: **import** (files not in any archive), **run** (in intake), "
               "**review** (filed except files with no sure date), **done**. *Done* counts filed files and copies set aside "
               "in `_duplicates-holding`, including copies `da holding --empty` has since recycled (their original is kept).")
    out.append("")
    out.append("## Archives")
    out.append("")
    out.append("| Archive | Filed | Review | Intake | Set aside | Emptied from holding |")
    out.append("|---|--:|--:|--:|--:|--:|")
    for name, c in meta["archives"].items():
        out.append(f"| {name} | {n(c['filed'])} | {n(c['review'])} | {n(c['intake'])} | {n(c['set aside'])} | "
                   f"{n(c['emptied'])} |")
    out.append("")
    out.append("## Sources")
    out.append("")
    out.append("| Source | Photos | Videos | Docs | Done | Review | Intake | Not in an archive | Unchecked | Next |")
    out.append("|---|--:|--:|--:|--:|--:|--:|--:|--:|---|")
    for r in roots:
        t = r.total
        out.append(f"| `{r.path}` | {n(t.kind['photo'])} | {n(t.kind['video'])} | {n(t.kind['doc'])} | "
                   f"{n(t.done)} ({pct_text(t)}) | {n(t.state['review'])} | {n(t.state['intake'])} | "
                   f"{n(t.state['not in archive'])} | {n(t.state['unchecked'])} | {t.stage()} |")
    out.append("")
    out += actions_markdown(acts, finished)
    for r in roots:
        out.append(f"## {r.path}")
        out.append("")
        if not r.total.media:
            out.append("No photos, videos or documents (or the drive isn't connected).")
            out.append("")
            continue
        out.append("| | Folder | Photos | Videos | Docs | Done | Review | Intake | Not in | Next | In archive | Types |")
        out.append("|---|---|--:|--:|--:|--:|--:|--:|--:|---|---|---|")
        for f in flatten(r):
            if f.depth > depth or not f.total.media:
                continue
            t = f.total
            rel = "." if f.depth == 0 else str(f.path.relative_to(r.path))
            missing = t.state["not in archive"] + t.state["unchecked"]
            out.append(f"| {STAGE_MARK.get(t.stage(), '')} | {'&nbsp;' * 2 * max(f.depth - 1, 0)}{rel.replace('|', '/')} | "
                       f"{n(t.kind['photo'])} | {n(t.kind['video'])} | {n(t.kind['doc'])} | {pct_text(t)} | "
                       f"{n(t.state['review'])} | {n(t.state['intake'])} | {n(missing)} | {t.stage()} | {where_text(t)} | {exts_text(t)} |")
        out.append("")
    out.append(f"*Folders shown to depth {depth}; `watch-status.csv` has every folder. "
               f"[x] done, [~] only review left, [ ] work left, [?] some files not checked (run without --no-hash).*")
    out.append("")
    return "\n".join(out)


def write_csv(path: Path, roots: list[Folder]) -> int:
    rows = 0
    all_exts = sorted({e for r in roots for f in flatten(r) for e in f.own.ext})
    with open(path, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["source", "folder", "depth", "own_media", "photos", "videos", "docs", "other_files", "bytes",
                    "filed", "set_aside", "review", "intake", "not_in_archive", "unchecked", "pct_done", "next",
                    "in_archive"] + [f"ext{e}" for e in all_exts])
        for r in roots:
            for f in flatten(r):
                t = f.total
                p = t.pct()
                w.writerow([str(r.path), str(f.path), f.depth, f.own.media, t.kind["photo"], t.kind["video"],
                            t.kind["doc"], t.kind["other"], t.bytes, t.state["filed"], t.state["set aside"],
                            t.state["review"], t.state["intake"], t.state["not in archive"], t.state["unchecked"],
                            "" if p is None else f"{p:.1f}", t.stage(), where_text(t)]
                           + [t.ext.get(e, 0) or "" for e in all_exts])
                rows += 1
    return rows


# ---------------------------------------------------------------- main

HISTORY_DIR = "watch-status-history"
REPORT_FILES = ("WATCH-STATUS.md", "watch-status.csv", "watch-actions.csv")


def file_previous(out_dir: Path) -> Path | None:
    """Copy the last report into watch-status-history\\<its date>_<time>\\ before it's overwritten.

    The folder is named from WATCH-STATUS.md's modified time. WATCH-STATUS.pdf goes with it only when it
    was made from that .md (not older than it); a PDF left over from an earlier report was filed then.
    Copies, never moves; a run whose folder already exists is skipped. Returns the folder, or None."""
    md = out_dir / "WATCH-STATUS.md"
    if not md.is_file():
        return None
    made = md.stat().st_mtime
    dest = out_dir / HISTORY_DIR / datetime.fromtimestamp(made).strftime("%Y-%m-%d_%H%M")
    if (dest / md.name).exists():
        return None
    dest.mkdir(parents=True, exist_ok=True)
    for name in REPORT_FILES:
        if (out_dir / name).is_file():
            shutil.copy2(out_dir / name, dest / name)
    pdf = out_dir / "WATCH-STATUS.pdf"
    if pdf.is_file() and pdf.stat().st_mtime >= made:
        try:
            shutil.copy2(pdf, dest / pdf.name)
        except OSError as e:  # open in a viewer that locks it
            print(f"  couldn't file {pdf.name}: {e}", file=sys.stderr)
    return dest


def default_cache() -> Path:
    """Return the hash cache, copied once from the standalone script's cache when there is one."""
    from mindit.config.archive import registry_path  # pylint: disable=import-outside-toplevel

    path = registry_path().parent / HASH_CACHE
    if not path.exists() and OLD_CACHE.is_file() and os.environ.get("DA_WATCH_NO_OLD_CACHE") is None:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(OLD_CACHE, path)
        except OSError:
            pass
    return path


@dataclass
class WatchResult:
    """What a run wrote (for the command's log line)."""

    report: Path | None = None
    folders: int = 0
    actions: int = 0
    media: int = 0
    done: int = 0
    not_in_archive: int = 0


def run_watch(sources: list[Path], archive_roots: list[Path], out_dir: Path, *, settings_path: Path,
              cache_path: Path | None = None, depth: int = 2, hashing: bool = True, to_stdout: bool = False,
              full_run: bool = True, plan_file: Path | None = None,
              say: Callable[[str], None] | None = None) -> WatchResult:
    """Scan the sources against the archives and write the report (or print it, `to_stdout`)."""
    def log(msg: str) -> None:
        if say:
            say(msg)
        else:
            print(msg, file=sys.stderr if to_stdout else sys.stdout, flush=True)

    for root in archive_roots:
        if not root.is_dir():
            log(f"{root}: not connected, its archives skipped")
    archives = find_archives(archive_roots)
    if not archives:
        raise WatchProblem("No DA archives (folders with da-archive.yaml) under: "
                           f"{', '.join(map(str, archive_roots)) or '(none listed)'} - check `archives:` in {settings_path}")
    if not to_stdout and not out_dir.is_dir():
        raise WatchProblem(f"The report folder isn't there: {out_dir} (`report:` in {settings_path})")

    cache = HashCache(cache_path or default_cache())
    started = time.time()

    log(f"Archives ({len(archives)}):")
    arch = load_archives(archives, cache, log)
    if arch.no_sha:
        log(f"  {arch.no_sha:,} archive files couldn't be read")
    plans = load_plans(archives, arch)
    log(f"  {len(plans):,} source hashes from `da import` plans")
    planned = planned_archives(plan_file, archives, arch)

    roots: list[Folder] = []
    for src in sources:
        if not src.is_dir():
            log(f"{src}: not connected, skipped")
            roots.append(Folder(src, 0))
            continue
        count = [0, time.time()]

        def progress() -> None:
            count[0] += 1
            if time.time() - count[1] > 15:
                count[1] = time.time()
                log(f"  ... {count[0]:,} files, {cache.hashed:,} hashed ({cache.hashed_bytes / 1e9:.1f} GB)")

        t = time.time()
        before = cache.hashed
        log(f"{src}: scanning")
        roots.append(scan_source(src, arch, plans, cache, hashing, progress))
        cache.flush()
        log(f"  {roots[-1].total.media:,} photos/videos/docs in {time.time() - t:.0f} s ({cache.hashed - before:,} hashed)")

    now = datetime.now()
    meta = {"when": now.strftime("%Y-%m-%d %H:%M"), "watch": str(settings_path),
            "archives": {arch.names[str(a)]: arch.counts.get(arch.names[str(a)], collections.Counter())
                         for a in archives}}
    acts = actions(roots, arch, depth, archives, planned)
    finished = assign_ids(acts, out_dir / "watch-action-ids.csv", now.strftime("%Y-%m-%d %H:%M:%S"),
                          full_run=full_run, save=not to_stdout)
    report = markdown(roots, depth, meta, acts, finished)
    total = Tally()
    for r in roots:
        total.add(r.total)
    result = WatchResult(None, 0, len(acts), total.media, total.done, total.state["not in archive"])
    if to_stdout:
        print(report)
        return result

    print()
    console(roots, depth)
    console_actions(acts)
    md_path = out_dir / "WATCH-STATUS.md"
    csv_path = out_dir / "watch-status.csv"
    filed = file_previous(out_dir)
    md_path.write_text(report, encoding="utf-8")
    result.folders = write_csv(csv_path, roots)
    result.report = md_path
    write_actions_csv(out_dir / "watch-actions.csv", acts)
    print(f"All sources: {total.media:,} photos/videos/docs, {total.done:,} done ({pct_text(total)}), "
          f"{total.state['review']:,} in review, {total.state['intake']:,} in intake, "
          f"{total.state['not in archive']:,} not in an archive"
          + (f", {total.state['unchecked']:,} unchecked" if total.state["unchecked"] else ""))
    print(f"Wrote {md_path}, {csv_path} ({result.folders:,} folders) and watch-actions.csv ({len(acts):,} actions) "
          f"in {time.time() - started:.0f} s")
    if filed:
        print(f"The previous report is kept in {filed}")
    if finished:
        print(f"Finished since the last report: {', '.join(sorted((r['id'] for r in finished), key=id_key))}")
    return result
