# src/mindit/services/workflow/checks.py

"""The checks between workflow steps: is a set-aside plan safe, does a preview look right, did filing work."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable


def sha256_file(path: Path) -> str:
    """Return a file's sha256, reading it in chunks."""
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------- set-aside plan

def check_plan(plan_csv: Path, sample: int = 40, seed: int = 0) -> dict[str, Any]:
    """Re-hash a random sample of a set-aside plan and confirm every kept copy still exists.

    `ok` is True only when every sampled file is byte-identical to its kept copy and no kept file is missing.
    """
    with Path(plan_csv).open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    result: dict[str, Any] = {"rows": len(rows), "by_class": dict(Counter(r["class"] for r in rows))}
    if not rows:
        return {**result, "sampled": 0, "identical": 0, "mismatched": [], "kept_missing": 0, "ok": True}

    missing = [r["kept"] for r in rows if not Path(r["kept"]).exists()]
    kept_missing = len(missing)
    picked = random.Random(seed).sample(rows, min(sample, len(rows)))
    identical, mismatched = 0, []
    for r in picked:
        try:
            if r["class"] in ("resized_copy", "resaved_copy"):     # the same picture: compare the pixels again
                from mindit.services.similar.fingerprints import (  # pylint: disable=import-outside-toplevel
                    RESAVED_PIXELS, RESIZED_PIXELS, pixel_difference,
                )

                diff = pixel_difference(Path(r["source"]), Path(r["kept"]))
                limit = RESIZED_PIXELS if r["class"] == "resized_copy" else RESAVED_PIXELS
                same = diff is not None and diff <= limit
            else:
                same = sha256_file(Path(r["source"])) == sha256_file(Path(r["kept"])) == r["sha256"]
        except OSError:
            same = False
        if same:
            identical += 1
        else:
            mismatched.append(r["source"])
    return {
        **result,
        "sampled": len(picked),
        "identical": identical,
        "mismatched": mismatched,
        "kept_missing": kept_missing,
        "kept_missing_example": missing[0] if missing else None,
        "ok": not mismatched and kept_missing == 0,
    }


# --------------------------------------------------------------------------- validate preview

def load_report(report_path: Path) -> dict[str, Any]:
    """Load a validate JSON report."""
    return json.loads(Path(report_path).read_text(encoding="utf-8"))


def check_report(report: dict[str, Any]) -> dict[str, Any]:
    """Summarize a validate report's plan and flag what needs a look before filing.

    Warnings: midnight names (a date with no time), two files planned for one name, a planned name that
    already exists (usually an identical copy that wasn't set aside), and years before 1990 or in the future.
    """
    actions = report.get("repair_actions", [])
    moves = [a for a in actions if a["action_type"] == "move_file"]
    renames = [a for a in actions if a["action_type"] == "rename_file"]     # filed already, a new name in place
    targets = Counter((a.get("target_path") or "").lower() for a in moves + renames)
    years = Counter(_year_of(a.get("target_path") or "") for a in moves + renames)
    problems = report.get("problem_summary", {})
    summary = {
        "target_folder": report.get("target_folder"),
        "mode": report.get("mode"),
        "moves": len(moves),
        "renames": len(renames),
        "raw_companions": sum(1 for a in actions if a["action_type"] == "move_raw_companion"),
        "midnight_names": sum(1 for a in moves if "_000000_" in os.path.basename(a.get("target_path") or "")),
        "same_target_twice": sum(1 for n in targets.values() if n > 1),
        # Only a planned (not yet executed) move can collide; after a repair the target is where it went.
        "target_exists": sum(1 for a in moves + renames if not a.get("executed") and a.get("target_path")
                             and Path(a["target_path"]).exists()),
        "uncertain_dates": problems.get("capture_date_uncertain", 0),
        "name_date_differs_from_exif": problems.get("name_date_differs_from_exif", 0),
        "duplicates_in_folder": (report.get("duplicates") or {}).get("duplicate_file_count", 0),
        "years": dict(sorted(years.items())),
        "problems": problems,
    }
    this_year = int(report.get("checked_at", "2100")[:4] or 2100)
    odd_years = {y: n for y, n in years.items() if y.isdigit() and (int(y) < 1990 or int(y) > this_year)}
    warnings = []
    if summary["same_target_twice"]:
        warnings.append(f"{summary['same_target_twice']} names are planned for two different files")
    if summary["target_exists"]:
        warnings.append(f"{summary['target_exists']} planned names already exist (run the duplicate step again?)")
    if summary["midnight_names"]:
        warnings.append(f"{summary['midnight_names']} photos would be named at midnight (no time known)")
    if odd_years:
        warnings.append(f"unusual years: {odd_years}")
    summary["clock_jumps"] = clock_jumps(report)
    for jump in summary["clock_jumps"][:5]:
        warnings.append(f"{jump['outside']} photos in {jump['folder']} are dated {', '.join(jump['outside_years'])}, while "
                        f"{jump['filed']} beside them are {', '.join(jump['filed_years'])} - a camera clock that was reset? "
                        f"Fix them with da date shift (they stay in intake until then)")
    summary["warnings"] = warnings
    return summary


_TAKEN = re.compile(r"^Taken (\d{4})-")


def clock_jumps(report: dict[str, Any], least: int = 5) -> list[dict[str, Any]]:
    """Return the folders where some photos are filed and others are dated outside the archive's years (a reset clock)."""
    outside: dict[str, Counter] = defaultdict(Counter)
    for problem in report.get("problems", []):
        m = _TAKEN.match(problem.get("message") or "") if problem.get("code") == "outside_archive_years" else None
        if m and problem.get("file_path"):
            outside[str(Path(problem["file_path"]).parent)][m.group(1)] += 1
    filed: dict[str, Counter] = defaultdict(Counter)
    for action in report.get("repair_actions", []):
        if action["action_type"] == "move_file" and action.get("source_path") and action.get("target_path"):
            folder = str(Path(action["source_path"]).parent)
            if folder in outside:
                filed[folder][_year_of(action["target_path"])] += 1
    jumps = [{"folder": folder, "outside": sum(years.values()), "outside_years": sorted(years),
              "filed": sum(filed[folder].values()), "filed_years": sorted(filed[folder])}
             for folder, years in outside.items() if sum(years.values()) >= least and filed.get(folder)]
    return sorted(jumps, key=lambda j: -j["outside"])


def _year_of(target: str) -> str:
    """Return the year folder a file goes in (2024\\2024-07, or a template's Payroll\\Acme\\2024), else '?'."""
    for part in reversed(Path(target).parent.parts):
        if re.fullmatch(r"\d{4}", part):
            return part
    return "?"


# --------------------------------------------------------------------------- after filing

QUICK_SAMPLE = 100                       # a quick verify re-reads every Nth file in full (and at least a few)


def verify_report(report: dict[str, Any], progress: Callable[[str], None] | None = None,
                  full: bool = False) -> dict[str, Any]:
    """Re-check every executed move in a repair report: at its target, gone from its source, unchanged.

    Unchanged: full re-reads every file and compares its hash with the sidecar's. Quick (the default)
    compares size and date with what the sidecar recorded, and re-hashes a sample (1 in QUICK_SAMPLE, at
    least 20) plus any file whose size or date differ: filing renames files on one drive, which can't
    change what's in them, so reading hundreds of GB again finds nothing new.
    """
    c: Counter = Counter()
    problems: list[str] = []
    moves = [a for a in report.get("repair_actions", [])
             if a["action_type"] in ("move_file", "rename_file", "move_raw_companion") and a.get("executed")]
    every = 1 if full else max(1, min(QUICK_SAMPLE, len(moves) // 20 or 1))
    for i, a in enumerate(moves):
        c["moved"] += 1
        if progress and c["moved"] % 1000 == 0:
            progress(f"{c['moved']:,} / {len(moves):,} checked")
        target = Path(a["target_path"])
        if Path(a["source_path"]).exists():
            c["source_still_there"] += 1
            problems.append(f"still at source: {a['source_path']}")
        if not target.exists():
            c["missing_at_target"] += 1
            problems.append(f"missing: {target}")
            continue
        recorded, size, modified = _recorded(target)
        if not recorded:
            c["no_hash_recorded"] += 1
            continue
        if i % every:                                        # not in the sample: size and date must match
            stat = target.stat()
            if size is not None and stat.st_size == size and (modified is None or stat.st_mtime == modified):
                c["size_ok"] += 1
                continue
        if recorded == sha256_file(target):
            c["hash_ok"] += 1
        else:
            c["hash_mismatch"] += 1
            problems.append(f"hash differs from sidecar: {target}")
    c["ok"] = int(c["source_still_there"] == c["missing_at_target"] == c["hash_mismatch"] == 0)
    return {**dict(c), "ok": bool(c["ok"]), "full": full, "problems": problems[:50]}


def _recorded(path: Path) -> tuple[str | None, int | None, float | None]:
    """Return the hash, size and modified time the sidecar recorded for a file."""
    try:
        meta = json.loads(Path(f"{path}.meta.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None, None, None
    quarantine = meta.get("quarantine") or {}
    sha = quarantine.get("hash_sha256") or (meta.get("file") or {}).get("sha256")
    size = quarantine.get("file_size")
    modified = quarantine.get("file_modified_at")
    return (sha, size if isinstance(size, int) else None,
            float(modified) if isinstance(modified, (int, float)) else None)


def _recorded_hash(path: Path) -> str | None:
    return _recorded(path)[0]
