"""The index follows the archive: point the paths stored in it at the folder the archive is opened from now.

The index (`.da\\da.sqlite`) and the run records (`output\\runs`) store full paths that begin with the archive's folder
as it was when they were written. That folder changes without a single file moving: DESKTOP's D:\\ shared as
\\\\DESKTOP\\photos and mapped as A:\\ (Python resolves a mapped drive to its UNC path), a copy on another drive, another
letter on another PC. `follow` notices when the folder the archive is opened from isn't the one the index remembers
and swaps the old root for the new one in every text column of the index (one transaction) and in the run records,
then remembers the new root. Only values that begin with the old root change; a source outside the archive
(`files.source_path` = E:\\pictures\\...) and free-text messages stay as they are.

An index made before this has no remembered root: `old_roots` works it out from `files.path` (the part before the
archive's folder name, else before one of its top folders: photos, documents, intake, ...).
"""

from __future__ import annotations

import os
import shutil
import sqlite3
from collections import Counter
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path, PureWindowsPath
from typing import Callable, Iterator

from mindit.services.dbit.dbit_service import BUSY_TIMEOUT

ROOT_TABLE = "archive_root"
# Folders at an archive's top: a path's root is what comes before one of them (when the archive's folder was renamed).
TOP_FOLDERS = {"photos", "documents", "intake", "output", "logs", "_duplicates-holding", "metadata", "exports",
               "review", ".da"}
UNIQUE_PATH_TABLES = {"files", "event_sources"}   # path is UNIQUE there: a row already at the new place gives way


@dataclass
class RepointResult:
    """What `repoint` changed."""
    old: list[str]
    new: str
    rows: Counter = field(default_factory=Counter)       # "table.column" -> rows changed
    run_files: int = 0
    backup: Path | None = None

    @property
    def total(self) -> int:
        return sum(self.rows.values())


def _norm(path: str) -> str:
    return os.path.normcase(str(path).rstrip("\\/"))


def same_root(a: str | Path, b: str | Path) -> bool:
    return _norm(str(a)) == _norm(str(b))


@contextmanager
def _connect(db_path: Path) -> Iterator[sqlite3.Connection]:
    """Open the index; commit when the block ends well, and always close (an open file can't be moved on Windows)."""
    conn = sqlite3.connect(db_path, timeout=BUSY_TIMEOUT)
    try:
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()


# --------------------------------------------------------------------------- the remembered root

def stored_root(conn: sqlite3.Connection) -> str | None:
    """Return the folder the index was last used from, or None (an index made before this)."""
    try:
        row = conn.execute(f"SELECT path FROM {ROOT_TABLE} WHERE id = 1").fetchone()
    except sqlite3.OperationalError:
        return None
    return row[0] if row else None


def remember_root(conn: sqlite3.Connection, root: Path | str) -> None:
    conn.execute(f"CREATE TABLE IF NOT EXISTS {ROOT_TABLE} (id INTEGER PRIMARY KEY CHECK (id = 1), path TEXT NOT NULL, "
                 "computer TEXT, at TEXT)")
    conn.execute(f"INSERT OR REPLACE INTO {ROOT_TABLE} (id, path, computer, at) VALUES (1, ?, ?, ?)",
                 (str(root), os.environ.get("COMPUTERNAME", ""), datetime.now().isoformat(timespec="seconds")))


def _root_of(path: str, name: str) -> str | None:
    """Return the archive root a stored path begins with (before the archive's folder name or a top folder)."""
    parts = PureWindowsPath(path).parts
    for i in range(len(parts) - 1, 0, -1):         # the last folder named like the archive
        if parts[i].lower() == name.lower():
            return str(PureWindowsPath(*parts[:i + 1]))
    for i in range(1, len(parts)):                 # else the folder above the first top folder
        if parts[i].lower() in TOP_FOLDERS:
            return str(PureWindowsPath(*parts[:i])) if i > 1 else None
    return None


def old_roots(conn: sqlite3.Connection, root: Path) -> Counter:
    """Return the roots other than `root` that files.path rows begin with, and how many rows each."""
    found: Counter = Counter()
    try:
        rows = conn.execute("SELECT path FROM files").fetchall()
    except sqlite3.OperationalError:              # no files table (never indexed)
        return found
    here = _norm(str(root)) + os.sep
    for (path,) in rows:
        if not path or os.path.normcase(path).startswith(here):
            continue
        other = _root_of(path, root.name)
        if other and not same_root(other, root):
            found[other] += 1
    return found


def roots_to_move(db_path: Path, root: Path) -> list[str]:
    """Return the old roots this index's paths should be moved from to `root` (empty: already pointing here)."""
    if not db_path.exists():
        return []
    with _connect(db_path) as conn:
        remembered = stored_root(conn)
        if remembered and same_root(remembered, root):
            return []
        found = old_roots(conn, root)
    roots = [r for r, _ in found.most_common()]
    if remembered and not same_root(remembered, root) and remembered not in roots:
        roots.insert(0, remembered)
    return roots


# --------------------------------------------------------------------------- swapping

def _text_columns(conn: sqlite3.Connection) -> list[tuple[str, str]]:
    out = []
    for (table,) in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"):
        if table == ROOT_TABLE:
            continue
        for _cid, column, kind, *_ in conn.execute(f'PRAGMA table_info("{table}")'):
            if (kind or "").upper() in ("TEXT", "") or "CHAR" in (kind or "").upper():
                out.append((table, column))
    return out


def _like_prefix(text: str) -> str:
    return text.replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%"


def _swap_sql(table: str, column: str, *, count: bool) -> str:
    where = (f'"{column}" LIKE :pattern ESCAPE \'!\' AND (length("{column}") = :n '
             f'OR substr("{column}", :n + 1, 1) IN (\'\\\', \'/\'))')
    if count:
        return f'SELECT count(*) FROM "{table}" WHERE {where}'
    verb = "UPDATE OR REPLACE" if table in UNIQUE_PATH_TABLES and column == "path" else "UPDATE"
    return f'{verb} "{table}" SET "{column}" = :new || substr("{column}", :n + 1) WHERE {where}'


def count_index(db_path: Path, old: str) -> Counter:
    """Return the rows (per table.column) whose value begins with the old root."""
    counts: Counter = Counter()
    old = str(old).rstrip("\\/")
    with _connect(db_path) as conn:
        for table, column in _text_columns(conn):
            n = conn.execute(_swap_sql(table, column, count=True), {"pattern": _like_prefix(old), "n": len(old)}).fetchone()[0]
            if n:
                counts[f"{table}.{column}"] = n
    return counts


def repoint_index(db_path: Path, olds: list[str], new: Path) -> Counter:
    """Swap each old root for new at the start of every text value in the index (one transaction); remember new."""
    changed: Counter = Counter()
    with _connect(db_path) as conn:
        conn.execute("BEGIN IMMEDIATE")
        try:
            for old in olds:
                old = str(old).rstrip("\\/")
                for table, column in _text_columns(conn):
                    cur = conn.execute(_swap_sql(table, column, count=False),
                                       {"pattern": _like_prefix(old), "n": len(old), "new": str(new).rstrip("\\/")})
                    if cur.rowcount > 0:
                        changed[f"{table}.{column}"] += cur.rowcount
            remember_root(conn, new)
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
    return changed


def repoint(root: Path, olds: list[str], *, db_path: Path | None = None, output_root: Path | None = None,
            backup: bool = False, say: Callable[[str], None] | None = None) -> RepointResult:
    """Point the index, the run records and this PC's list of archives at root (from each of olds)."""
    from mindit.services.workflow.archive_move import rewrite_runs  # pylint: disable=import-outside-toplevel

    say = say or (lambda _m: None)
    db_path = db_path or root / ".da" / "da.sqlite"
    output_root = output_root or root / "output"
    result = RepointResult(old=list(olds), new=str(root))
    if backup and db_path.exists():
        result.backup = db_path.with_name(f"{db_path.name}.bak-{datetime.now():%Y%m%d-%H%M%S}")
        say(f"Copying the index to {result.backup.name} first ...")
        shutil.copy2(db_path, result.backup)
    if db_path.exists():
        result.rows = repoint_index(db_path, olds, root)
    for old in olds:
        result.run_files += rewrite_runs(output_root, Path(old), root)
        _move_registry_entry(old, root)
    return result


def _move_registry_entry(old: str, new: Path) -> None:
    """Point this PC's archives.json line for the old place at the new one.

    When the new place is on the list already, the old line goes only if no archive is at the old place any more
    (one there may be another copy, e.g. a backup, and stays on the list).
    """
    from mindit.config.archive import is_archive, read_registry, write_registry  # pylint: disable=import-outside-toplevel

    entries = read_registry()
    olds = [e for e in entries if same_root(e["path"], old)]
    if not olds:
        return
    if not any(same_root(e["path"], new) for e in entries):
        olds[0]["path"] = str(new)
    elif not is_archive(Path(old)):
        entries = [e for e in entries if not same_root(e["path"], old)]
    else:
        return
    write_registry(entries)


def follow(root: Path, say: Callable[[str], None] | None = None) -> RepointResult | None:
    """When the archive is opened from a new folder, point its index there; return what changed (None: nothing)."""
    db_path = root / ".da" / "da.sqlite"
    olds = roots_to_move(db_path, root)
    if not olds:
        if db_path.exists():
            with _connect(db_path) as conn:
                if stored_root(conn) is None:
                    remember_root(conn, root)
        return None
    say = say or (lambda _m: None)
    say(f"This archive's index was last used from {olds[0]}; it's at {root} now. Pointing the index there ...")
    result = repoint(root, olds, say=say)
    say(f"  {result.total:,} index values and {result.run_files:,} run records now point at {root}.")
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("archive_repoint", f"index repointed: {', '.join(olds)} -> {root} ({result.total} values, "
                                 f"{result.run_files} run records)", path=str(root))
    return result
