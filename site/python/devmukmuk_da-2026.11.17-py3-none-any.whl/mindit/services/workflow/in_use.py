"""One PC at a time: the note (`.da\\in-use.json`) a PC leaves while it changes an archive.

Several PCs can reach one copy of an archive (a shared drive; `home: [DESKTOP, LAPTOP]`). SQLite over a network
share isn't safe with writers on two machines, so a command that changes the archive takes this note first and
another PC stops instead of changing it at the same time. The note is made with O_EXCL (works over SMB), kept fresh
by a background thread while the command runs, and removed when it ends. A note nobody has refreshed for STALE_AFTER
(the PC crashed, lost power or the network) is taken over. The same PC never stops itself (as before this note).
"""

from __future__ import annotations

import atexit
import json
import os
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

NOTE = "in-use.json"
REFRESH_EVERY = timedelta(minutes=5)
STALE_AFTER = timedelta(minutes=30)

_held: dict[str, threading.Event] = {}          # note path -> stop event of its refresher (this process)


class InUse(Exception):
    """Another PC is changing the archive."""

    def __init__(self, holder: dict[str, Any]) -> None:
        super().__init__(describe(holder))
        self.holder = holder


def note_path(root: Path) -> Path:
    return Path(root) / ".da" / NOTE


def _computer() -> str:
    from mindit.config.archive import this_computer  # pylint: disable=import-outside-toplevel

    return this_computer()


def _now() -> datetime:
    return datetime.now()


def holder(root: Path) -> dict[str, Any] | None:
    """Return who holds the archive now (computer, pid, command, started, refreshed), or None."""
    try:
        data = json.loads(note_path(root).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return None
    except (OSError, ValueError):
        return {}                                 # half-written or unreadable: treated as stale below


def describe(info: dict[str, Any]) -> str:
    since = str(info.get("started") or "?").replace("T", " ")
    return (f"{info.get('computer') or 'Another PC'} is changing this archive (da {info.get('command') or '?'}, "
            f"since {since})")


def _stale(info: dict[str, Any]) -> bool:
    try:
        refreshed = datetime.fromisoformat(str(info.get("refreshed") or info.get("started")))
    except ValueError:
        return True
    return _now() - refreshed > STALE_AFTER


def _write_new(path: Path, info: dict[str, Any]) -> bool:
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        return False
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2)
    return True


def acquire(root: Path, command: str) -> dict[str, Any] | None:
    """Take the archive for this PC; return the stale note taken over (None: it was free or this PC's own).

    Raises InUse when another PC holds it. A no-op for an archive with no .da folder yet.
    """
    path = note_path(root)
    if not path.parent.is_dir() or str(path) in _held:
        return None
    here = _computer()
    info = {"computer": here, "pid": os.getpid(), "command": command,
            "started": _now().isoformat(timespec="seconds"), "refreshed": _now().isoformat(timespec="seconds")}
    taken_over = None
    if not _write_new(path, info):
        current = holder(root)
        if current is not None:
            if current.get("computer") and str(current["computer"]).upper() != here and not _stale(current):
                raise InUse(current)
            if current.get("computer") and str(current["computer"]).upper() != here:
                taken_over = current
        path.write_text(json.dumps(info, indent=2), encoding="utf-8")
    stop = threading.Event()
    _held[str(path)] = stop
    threading.Thread(target=_refresh, args=(path, info, stop), daemon=True, name="da-in-use").start()
    atexit.register(release, root)
    return taken_over


def _refresh(path: Path, info: dict[str, Any], stop: threading.Event) -> None:
    while not stop.wait(REFRESH_EVERY.total_seconds()):
        try:
            current = json.loads(path.read_text(encoding="utf-8"))
            if current.get("computer") != info["computer"] or current.get("pid") != info["pid"]:
                return                            # cleared by hand, or taken over: stop touching it
            current["refreshed"] = _now().isoformat(timespec="seconds")
            path.write_text(json.dumps(current, indent=2), encoding="utf-8")
        except (OSError, ValueError):
            pass


def release(root: Path) -> None:
    """Remove this process's note (another PC's or process's is left alone)."""
    path = note_path(root)
    stop = _held.pop(str(path), None)
    if stop is None:
        return
    stop.set()
    current = holder(root)
    if current and current.get("computer") == _computer() and current.get("pid") == os.getpid():
        try:
            path.unlink()
        except OSError:
            pass


def clear(root: Path) -> None:
    """Remove the note whoever made it (da archives unlock)."""
    try:
        note_path(root).unlink()
    except FileNotFoundError:
        pass
