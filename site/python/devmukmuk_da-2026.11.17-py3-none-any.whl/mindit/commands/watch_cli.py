# src/mindit/commands/watch_cli.py

"""`da watch`: where every watched source folder is in the DA workflow (services/watch/watch.py)."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.markup import escape

console = Console()


def watch(
    ids: list[str] = typer.Argument(None, help="With --cmd: the action IDs (I7 R2 ...).", show_default=False),
    init: bool = typer.Option(False, "--init", help="Write this PC's watch settings (the watch: section of "
                                                    "da-computer.yaml) from DA's list of archives, then stop."),
    source: list[Path] = typer.Option(None, "--source", help="Only this source folder (repeat for more); still "
                                                             "matched against every archive."),
    depth: int = typer.Option(2, "--depth", help="Folder depth on screen and in WATCH-STATUS.md (the .csv has all)."),
    no_hash: bool = typer.Option(False, "--no-hash", help="Hash nothing new: size-matched files count as unchecked."),
    to_stdout: bool = typer.Option(False, "--stdout", help="Print the markdown report; write nothing."),
    cmd: bool = typer.Option(False, "--cmd", help="Print the commands of the action IDs given (da watch --cmd I7 R2) "
                                                  "from the last report and copy them to the clipboard; no scan."),
    settings: Path = typer.Option(None, "--settings", help="Another settings file (da-computer.yaml or an old "
                                                           "watch-status.yaml) instead of this PC's."),
    out: Path = typer.Option(None, "--out", help="Folder for the report (default: the settings' report:)."),
    cache: Path = typer.Option(None, "--cache", help="Hash cache (default: %LOCALAPPDATA%\\DA\\watch-hashes.sqlite)."),
) -> None:
    """Where every watched source folder is: filed, in review, in intake, set aside, or not in any archive yet."""
    from mindit.config import computer  # pylint: disable=import-outside-toplevel
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.watch import watch as wt  # pylint: disable=import-outside-toplevel

    if init:
        raise typer.Exit(_init(settings))
    try:
        found = computer.watch_settings(settings)
    except computer.ComputerSettingsError as exc:
        console.print(f"[yellow]{escape(str(exc))}[/yellow]")
        raise typer.Exit(1) from exc
    if found is None:
        console.print(f"No watch settings on this PC yet ({escape(str(settings or computer.computer_path()))}). "
                      "Make them: da watch --init, then add the folders to watch.")
        raise typer.Exit(1)
    out_dir = out or found.report
    if cmd or ids:
        if not ids:
            raise typer.BadParameter("Give the action IDs: da watch --cmd I7 R2")
        raise typer.Exit(wt.copy_commands(out_dir / "watch-actions.csv", list(ids)))
    if found.path.name == computer.OLD_WATCH_FILE:
        console.print(f"Using {escape(str(found.path))}; da watch --init moves it into "
                      f"{escape(str(computer.computer_path()))}.")
    try:
        result = wt.run_watch(list(source) if source else found.sources, found.archive_roots, out_dir,
                              settings_path=found.path, cache_path=cache or found.cache, depth=depth,
                              hashing=not no_hash, to_stdout=to_stdout, full_run=not source)
    except wt.WatchProblem as exc:
        console.print(f"[yellow]{escape(str(exc))}[/yellow]")
        raise typer.Exit(1) from exc
    if result.report:
        console.print(f"Printable PDF (page 1 is the checklist): open {escape(str(result.report))} in a Markdown "
                      "viewer, or md2pdf it.")
        log_event("watch", f"da watch: {result.media:,} files, {result.done:,} done, {result.actions:,} actions",
                  path=result.report, folders=result.folders, media=result.media, done=result.done,
                  not_in_archive=result.not_in_archive, actions=result.actions)


def _init(settings: Path | None) -> int:
    """Write the watch: section: an old watch-status.yaml's values, else DA's archives + old watch-folders.txt."""
    import yaml  # pylint: disable=import-outside-toplevel

    from mindit.config import computer  # pylint: disable=import-outside-toplevel
    from mindit.config.archive import known_archives  # pylint: disable=import-outside-toplevel
    from mindit.services.watch import watch as wt  # pylint: disable=import-outside-toplevel

    target = settings or computer.computer_path()
    old = computer.old_watch_path()
    try:
        if computer.read_computer(target).get("watch") is not None:
            console.print(f"{escape(str(target))} already has a watch: section; edit it there.")
            return 1
        note = ""
        if old.is_file():
            raw = yaml.safe_load(old.read_text(encoding="utf-8-sig")) or {}
            moved = computer.watch_from(raw, old)                       # checks it before it moves
            listed = [Path(str(a)) for a in (raw.get("archives") or [])] or [Path("registry")]
            text = computer.watch_section(moved.report, moved.sources, listed, [], f"from {old.name}")
            if raw.get("cache"):
                text = text.rstrip("\n") + f"\n  cache: '{raw['cache']}'\n"
        else:
            sources = wt.read_watch(wt.OLD_WATCH)[0] if wt.OLD_WATCH.is_file() else []
            roots, copies = wt.init_roots(known_archives())
            note = f"from {wt.OLD_WATCH}" if sources else ""
            report = roots[0] if roots else target.parent
            text = computer.watch_section(report, sources, roots, copies, note)
        path = computer.add_watch_section(text, target)
    except (computer.ComputerSettingsError, OSError, yaml.YAMLError) as exc:
        console.print(f"[yellow]{escape(str(exc))}[/yellow]")
        return 1
    if old.is_file() and target == computer.computer_path():
        done = old.with_name(old.name + ".moved")
        old.replace(done)
        console.print(f"Moved the settings of {escape(str(old))} in (the old file is now {escape(done.name)}).")
    console.print(f"Wrote the watch: section of {escape(str(path))}. Check the sources and archives, then: da watch")
    return 0
