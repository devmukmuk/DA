"""DA (Digital Archive) app cli command."""
# src/mindit/cli.py

from __future__ import annotations

import sqlite3
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Callable
import typer
from rich.console import Console
from rich.markup import escape
console = Console()



from mindit.config.archive import away_from_home, away_message, no_home_message, this_computer, yaml_details
from mindit.config.cli import app as config_app
from mindit.config.settings import (
    load_settings,
    get_archive_root,
    is_profile_chosen,
    get_config_root,
    get_config_path,
    get_data_root_path,
    resolve_config_relative_path,
    resolve_data_path,
    resolve_packit_output_path,
    resolve_packit_qr_path,
    resolve_packit_reports_path,
    resolve_packit_rooms_path,
    resolve_photoit_organized_path,
    resolve_photoit_output_path,
    resolve_photoit_quarantine_path,
    resolve_photoit_intake_path,
    resolve_scanit_organized_path,
    resolve_scanit_output_path,
    resolve_scanit_quarantine_path,
    resolve_scanit_intake_path,
)

from mindit.core.logging import (
    configure_logging,
    get_context_logger,
    log_command,
    log_command_start,
)

from mindit import __app_name__, __version__
from mindit.providers.cli import app as storage_app
from mindit.commands.validateit.cli import app as validateit_app
from mindit.commands.validateit.cli import validate_folder
from mindit.commands.dbit_cli import app as dbit_app
from mindit.commands.sidecar_cli import app as sidecar_cli_app
from mindit.commands.findit_cli import app as findit_cli_app
from mindit.commands.intake_cli import app as intake_app
from mindit.commands.location_cli import app as location_app
from mindit.commands.facial_cli import facial_app
from mindit.commands.date_cli import app as date_app
from mindit.commands.scans_cli import cameras_app, review as review_command
from mindit.commands.watch_cli import watch as watch_command
from mindit.commands import family_cli
from mindit.commands.template_cli import app as template_app
from mindit.commands import workflow_cli





# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def _is_pathlike_key(key: str) -> bool:
    return key.endswith(("_root", "_dir", "_path", "_file")) or key in {
        "data_root",
        "intake",
        "documents",
        "photos",
        "metadata",
        "exports",
        "logs",
        "output",
        "camera_inbox",
        "archive_dir",
    }


def _flatten_dict(data: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    flat: dict[str, Any] = {}

    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            flat.update(_flatten_dict(value, full_key))
        else:
            flat[full_key] = value

    return flat


def _section_name(dot_key: str) -> str:
    parts = dot_key.split(".")

    if parts[0] == "paths":
        return "Paths"
    if parts[0] == "logs":
        return "Logs"
    if parts[0] == "providers":
        return f"Providers / {parts[1]}"
    if parts[0] == "modules":
        return parts[1].capitalize()

    return parts[0].capitalize()


def _field_name(dot_key: str) -> str:
    parts = dot_key.split(".")

    if parts[0] in {"paths", "logs"}:
        return ".".join(parts[1:])

    if parts[0] == "providers":
        return ".".join(parts[2:])

    if parts[0] == "modules":
        return ".".join(parts[2:])

    return ".".join(parts[1:])


_SPECIAL_RESOLVERS: dict[str, Callable[[Any], str]] = {
    # shared paths
    "paths.data_root": lambda settings: str(get_data_root_path(settings)),
    "paths.intake": lambda settings: str(resolve_data_path(settings.paths.intake, settings)),
    "paths.documents": lambda settings: str(resolve_data_path(settings.paths.documents, settings)),
    "paths.photos": lambda settings: str(resolve_data_path(settings.paths.photos, settings)),
    "paths.metadata": lambda settings: str(resolve_data_path(settings.paths.metadata, settings)),
    "paths.exports": lambda settings: str(resolve_data_path(settings.paths.exports, settings)),
    "paths.logs": lambda settings: str(resolve_data_path(settings.paths.logs, settings)),
    "paths.output": lambda settings: str(resolve_data_path(settings.paths.output, settings)),
    "paths.camera_inbox": lambda settings: str(resolve_data_path(settings.paths.camera_inbox, settings)),

    # logs
    "logs.root": lambda settings: str(resolve_data_path(settings.logs.root, settings)),
    "logs.archive_dir": lambda settings: str(resolve_data_path(settings.logs.archive_dir, settings)),

    # provider files
    "providers.google_drive.credentials_file": lambda settings: str(
        resolve_config_relative_path(settings.providers.google_drive.credentials_file)
    ),
    "providers.google_drive.service_account_file": lambda settings: str(
        resolve_config_relative_path(settings.providers.google_drive.service_account_file)
    ),
    "providers.google_drive.token_file": lambda settings: str(
        resolve_config_relative_path(settings.providers.google_drive.token_file)
    ),

    # packit
    "modules.packit.rooms_root": lambda settings: str(resolve_packit_rooms_path(settings)),
    "modules.packit.reports_root": lambda settings: str(resolve_packit_reports_path(settings)),
    "modules.packit.qr_root": lambda settings: str(resolve_packit_qr_path(settings)),
    "modules.packit.output_root": lambda settings: str(resolve_packit_output_path(settings)),

    # scanit
    "modules.scanit.intake_root": lambda settings: str(resolve_scanit_intake_path(settings)),
    "modules.scanit.organized_root": lambda settings: str(resolve_scanit_organized_path(settings)),
    "modules.scanit.quarantine_root": lambda settings: str(resolve_scanit_quarantine_path(settings)),
    "modules.scanit.output_root": lambda settings: str(resolve_scanit_output_path(settings)),

    # photoit
    "modules.photoit.intake_root": lambda settings: str(resolve_photoit_intake_path(settings)),
    "modules.photoit.organized_root": lambda settings: str(resolve_photoit_organized_path(settings)),
    "modules.photoit.quarantine_root": lambda settings: str(resolve_photoit_quarantine_path(settings)),
    "modules.photoit.output_root": lambda settings: str(resolve_photoit_output_path(settings)),
}


def _resolve_config_value(key: str, value: Any, settings: Any) -> str:
    if not isinstance(value, str):
        return str(value)

    special_resolver = _SPECIAL_RESOLVERS.get(key)
    if special_resolver is not None:
        return special_resolver(settings)

    # generic config-relative files
    if key.endswith("_file"):
        return str(resolve_config_relative_path(value))

    # generic data-relative paths
    if _is_pathlike_key(key.split(".")[-1]):
        return str(resolve_data_path(value, settings))

    return str(value)


app = typer.Typer(
    help="DA (Digital Archive): validate, de-duplicate and file photos and documents. "
         "Run `da` on its own for the menu.",
    no_args_is_help=False,
    pretty_exceptions_enable=False,
)

app.add_typer(config_app, name="config")
app.add_typer(storage_app, name="storage")
try:                                    # the household inventory needs Google's libraries (an extra)
    from mindit.commands.packit.cli import app as packit_app  # pylint: disable=wrong-import-position
    from mindit.commands.qrcode.cli import app as qrcode_app  # pylint: disable=wrong-import-position
except ImportError:
    packit_app = typer.Typer(help="Household inventory (needs Google's libraries: the 'google' extra).")
    qrcode_app = typer.Typer(help="QR labels for the household inventory (needs Google's libraries: the 'google' extra).")
app.add_typer(packit_app, name="packit")
app.add_typer(qrcode_app, name="qrcode")
app.add_typer(validateit_app, name="validateit")
app.add_typer(dbit_app, name="db")
app.add_typer(sidecar_cli_app, name="sidecar")
app.add_typer(findit_cli_app, name="findit")
app.add_typer(intake_app, name="intake")
app.add_typer(location_app, name="location")
app.add_typer(facial_app, name="facial")
app.add_typer(date_app, name="date")
app.add_typer(template_app, name="template")
app.add_typer(cameras_app, name="cameras")

# The archive's main job, so it is a top-level command too: `da validate <folder>`.
app.command("validate")(validate_folder)

# The whole workflow, for running it yourself on any archive.
app.command("setup")(workflow_cli.setup)
app.command("run")(workflow_cli.run)
app.command("status")(workflow_cli.status)
archives_app = typer.Typer(help="The archives on this PC: list, open, move, delete.", invoke_without_command=True,
                            no_args_is_help=False)
archives_app.callback()(workflow_cli.archives)
archives_app.command("delete")(workflow_cli.archives_delete)
archives_app.command("move")(workflow_cli.archives_move)
archives_app.command("home")(workflow_cli.archives_home)
archives_app.command("repoint")(workflow_cli.archives_repoint)
archives_app.command("unlock")(workflow_cli.archives_unlock)
archives_app.command("details", hidden=True)(workflow_cli.archives_details)
app.add_typer(archives_app, name="archives")
app.command("guide")(workflow_cli.guide)
app.command("contact-sheets")(workflow_cli.contact_sheets)
app.command("pair-movies")(workflow_cli.pair_movies)
app.command("picasa")(workflow_cli.picasa)
app.command("similar")(workflow_cli.similar)
app.command("edits")(workflow_cli.edits)
app.command("convert")(workflow_cli.convert)
app.command("holding")(workflow_cli.holding)
app.command("heic-to-jpg")(workflow_cli.heic_to_jpg)
app.command("tag")(workflow_cli.tag)
app.command("rename")(workflow_cli.rename)
app.command("move")(workflow_cli.move)
app.command("find")(workflow_cli.find)
app.command("share")(workflow_cli.share)
app.command("history")(workflow_cli.history)
app.command("ocr")(workflow_cli.ocr)
app.command("split")(workflow_cli.split)
app.command("report")(workflow_cli.report)
app.command("family")(family_cli.family)
app.command("dashboard")(workflow_cli.dashboard)
app.command("merge")(workflow_cli.merge)
app.command("import")(workflow_cli.import_files)
app.command("backup")(workflow_cli.backup)
app.command("imports")(workflow_cli.imports)
app.command("watch")(watch_command)
app.command("review")(review_command)
app.command("install")(workflow_cli.install)
app.command("update")(workflow_cli.update)
app.command("check")(workflow_cli.check)
app.command("verify")(workflow_cli.verify)


@app.command("menu")
def menu() -> None:
    """The interactive menu (same as running `da` on its own)."""
    from mindit.commands.menu import run_menu  # pylint: disable=import-outside-toplevel

    run_menu()



# Commands that work on an archive's files; outside an archive they stop instead of using an old profile.
ARCHIVE_COMMANDS = {"run", "import", "status", "validate", "validateit", "db", "intake", "findit", "sidecar", "pair-movies", "tag", "location", "split", "report", "dashboard", "merge", "date", "rename", "move", "find", "share", "history", "picasa", "similar", "edits", "convert", "facial", "template", "cameras", "review"}

# Commands that only look at an archive, so they run on a PC that isn't its home (da archives home);
# every other command changes it. A flag listed here turns that command into one that changes it.
LOOK_ONLY = {"status", "find", "history", "report", "share", "dashboard", "family", "guide", "archives",
             "version", "about", "install", "update", "menu", "backup", "imports", "watch", "cameras", "review",
             "setup"}                                  # a new archive; `da setup` on another one only adds folders
CHANGING_FLAGS = {"find": {"--move"}, "report": {"--refresh"}, "family": {"--update"},
                  "cameras": {"--detect", "set", "add"}, "review": {"--guess", "--file"}}


# Commands that don't point an archive's index at where it's opened from (da archives repoint shows it first).
NO_FOLLOW = {"archives", "setup", "install", "update", "guide", "version", "about"}


def open_archive(root: Path, command: str, *, changing: bool) -> None:
    """Before a command: take the archive for this PC when it changes it, and point its index here if it moved.

    Another PC changing it stops a changing command (one PC at a time on a shared drive). The index follows the
    archive only on a home PC (or one with no home), and only when no other PC holds it; elsewhere DA just looks.
    """
    from mindit.services.workflow import in_use, repoint  # pylint: disable=import-outside-toplevel

    at_home = away_from_home(root) is None
    if changing and at_home:
        try:
            taken = in_use.acquire(root, command)
        except in_use.InUse as busy:
            console.print(f"[yellow]{escape(str(busy))}. One PC at a time changes an archive; wait for it to finish, "
                          "or, if that PC stopped without finishing: da archives unlock[/yellow]")
            raise typer.Exit(1) from None
        except OSError:
            taken = None                               # a read-only copy: the command says what it can't do
        if taken:
            console.print(f"[yellow]Took over from {escape(in_use.describe(taken))}: it hasn't been heard from in "
                          f"{int(in_use.STALE_AFTER.total_seconds() // 60)} minutes.[/yellow]")
    if not at_home:
        return
    holder = in_use.holder(root)
    if holder and not changing and str(holder.get("computer") or "").upper() not in ("", this_computer()):
        return                                         # another PC is working in it: don't rewrite its index now
    try:
        repoint.follow(root, say=lambda m: console.print(f"[cyan]{escape(m)}[/cyan]"))
    except (OSError, sqlite3.Error) as exc:
        console.print(f"[yellow]Couldn't point the index at {escape(str(root))}: {escape(str(exc))}[/yellow]")


def changes_archive(command: str | None, args: list[str]) -> bool:
    """Return True when `da <command> <args>` would change the archive it works in."""
    if command is None or command in ("--help", "-h"):
        return False
    if command not in LOOK_ONLY:
        return True
    flags = CHANGING_FLAGS.get(command, set())
    return any(arg.split("=", 1)[0] in flags for arg in args)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    config_dir: str | None = typer.Option(
        None,
        "--config-dir",
        help="Use an old-style profile config folder instead of an archive.",
    ),
    archive: str | None = typer.Option(
        None,
        "--archive",
        help="The archive folder (holding da-archive.yaml). Default: the current folder or one above it.",
    ),
    feedback: bool | None = typer.Option(
        None,
        "--feedback/--no-feedback",
        help="Chime when the command starts and ends (works after any command too). Default: da-archive.yaml's "
             "feedback.enabled, which chimes after commands that took a minute or more.",
    ),
) -> None:
    """
    Initialize DA before running any subcommand.

    Notes:
        - The actual config root bootstrap happens earlier in __main__.py.
        - This option exists here so it appears in CLI help output.
    """
    asking_for_help = any(arg in ("--help", "-h") for arg in sys.argv[1:])
    if (ctx.invoked_subcommand in ARCHIVE_COMMANDS and get_archive_root() is None
            and not is_profile_chosen() and not asking_for_help):
        console.print("[yellow]Not inside an archive.[/yellow] Run this inside an archive folder "
                      r"(cd D:\jane-archive-202x), add --archive <folder>,")
        console.print("double-click the archive's Open DA.cmd, or run `da` to pick one. "
                      "Archives on this PC: da archives")
        raise typer.Exit(1)
    root = get_archive_root()
    changing = changes_archive(ctx.invoked_subcommand, sys.argv[1:])
    if root is not None and not asking_for_help and changing:
        home = away_from_home(root)
        if home:
            console.print(f"[yellow]{escape(away_message(home, f'`da {ctx.invoked_subcommand}`'))}[/yellow]")
            raise typer.Exit(1)
        if not yaml_details(root).get("home"):         # an archive made before homes: say so, don't stop
            console.print(f"[yellow]{escape(no_home_message())}[/yellow]")
    if root is not None and not asking_for_help and ctx.invoked_subcommand not in NO_FOLLOW:
        open_archive(root, ctx.invoked_subcommand or "menu", changing=changing)

    settings = load_settings()
    # A relative log folder ("logs") belongs to the archive's data root, not wherever DA was started.
    configure_logging(settings.logs.model_copy(update={"root": str(resolve_data_path(settings.logs.root, settings))}))
    if not asking_for_help:
        root = get_archive_root()
        log_command_start(sys.argv[1:], str(root) if root else None)

    # store settings in context for subcommands to access without reloading
    ctx.obj = settings

    if ctx.invoked_subcommand is None:          # `da` on its own: the interactive menu
        from mindit.commands.menu import run_menu  # pylint: disable=import-outside-toplevel

        run_menu()

    # logger = get_context_logger(
    #     __name__,
    #     app="mindit",
    #     command="cli",
    #     profile=settings.profile,
    # )

    # logger.info(
    #     "CLI initialized",
    #     extra={
    #         "event": "mindit.cli.init",
    #         "status": "ok",
    #         "profile": settings.profile,
    #         "config_root": str(get_config_root()),
    #         "config_path": str(get_config_path()),
    #         "config_dir_option": config_dir,
    #         "invoked_subcommand": ctx.invoked_subcommand,
    #         "version": __version__,
    #     },
    # )


@app.command("version")
def version() -> None:
    """ Show the current DA version. """
    print(f"{__app_name__} v{__version__}")



@app.command("about")
def about(
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="Show full flat path dump.",
    )
) -> None:
    """
    Show basic application information and resolved paths.
    """
    settings = load_settings()

    logger = get_context_logger(
        __name__,
        app="mindit",
        command="about",
        profile=settings.profile,
    )

    with log_command(logger, "mindit.about"):
        print(f"[bold]{__app_name__} v{__version__}[/bold]")
        print(f"config_root = {get_config_root()}")
        print(f"config      = {get_config_path()}")

        flat = _flatten_dict(settings.model_dump())

        if verbose:
            print("\n[bold]Raw Path-Like Config[/bold]")
            for key, value in flat.items():
                if _is_pathlike_key(key.split(".")[-1]):
                    print(f"{key:45} = {value}")

            print("\n[bold]Resolved Path-Like Config[/bold]")
            for key, value in flat.items():
                if _is_pathlike_key(key.split(".")[-1]):
                    resolved = _resolve_config_value(key, value, settings)
                    print(f"{key:45} = {resolved}")

            return

        grouped: dict[str, list[tuple[str, Any, str]]] = defaultdict(list)

        for key, value in flat.items():
            if not _is_pathlike_key(key.split(".")[-1]):
                continue

            section = _section_name(key)
            field = _field_name(key)
            resolved = _resolve_config_value(key, value, settings)
            grouped[section].append((field, value, resolved))

        for section, items in grouped.items():
            print(f"\n[bold]{section}[/bold]")
            for field, raw, resolved in sorted(items):
                print(f"{field:20} {str(raw):30} -> {resolved}")


def run() -> None:
    """
    Run the DA CLI with top-level error logging.
    """
    bootstrap_logger = get_context_logger(__name__, app="mindit", command="run")

    try:
        app()
    except Exception:  # pylint: disable=broad-except
        bootstrap_logger.exception(
            "Unhandled CLI error",
            extra={
                "event": "mindit.cli.crash",
                "status": "error",
            },
        )
        raise
