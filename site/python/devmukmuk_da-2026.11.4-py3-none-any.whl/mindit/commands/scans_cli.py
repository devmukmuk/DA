﻿# src/mindit/commands/scans_cli.py

"""`da cameras` (cameras.json: every camera and scanner, its owner, type, date rule and years) and `da review` (photos
waiting in photos\\organized\\review for a date). Design: docs/da-docs/SCANS-DESIGN.md."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.markup import escape
from rich.prompt import Confirm
from rich.table import Table

console = Console()

cameras_app = typer.Typer(help="Every camera and scanner this archive has seen (cameras.json): type, owner, how to "
                               "read its dates, the years it was used.", invoke_without_command=True)


def _listed():
    from mindit.config.settings import get_cameras_file  # pylint: disable=import-outside-toplevel
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    try:
        return cams.read(get_cameras_file())
    except cams.CamerasError as error:
        console.print(f"[red]{escape(str(error))}[/red]")
        raise typer.Exit(1) from error


def show(listed) -> None:
    """Print the cameras as a table."""
    if not listed.rows:
        console.print(f"No cameras listed yet in {listed.path}. Run: da cameras --detect")
        return
    table = Table(title=f"Cameras ({listed.path})")
    for col in ("#", "camera", "type", "owner", "dates", "years", "photos", "first - last"):
        table.add_column(col, justify="right" if col in ("#", "photos") else "left")
    for n, row in enumerate(listed.rows, 1):
        span = " - ".join(x for x in (row.get("first") or "", row.get("last") or "") if x)
        table.add_row(str(n), escape(row["name"]), row.get("type") or "", escape(row.get("owner") or ""),
                      row.get("date") or "", row.get("years") or "", f"{int(row.get('found') or 0):,}", span)
    console.print(table)
    console.print("Change one: da cameras set \"<camera>\" --owner jane --type film --date none --years 1985-1986")


@cameras_app.callback()
def cameras(
    ctx: typer.Context,
    detect: bool = typer.Option(False, "--detect", help="Add the cameras the index's sidecars name, and count them "
                                                        "(no photo is opened)."),
    open_it: bool = typer.Option(False, "--open", help="Open cameras.json (in Notepad)."),
) -> None:
    """List the cameras (and with --detect, find new ones first)."""
    if ctx.invoked_subcommand is None:
        list_cameras(detect, open_it)


def list_cameras(detect: bool = False, open_it: bool = False) -> None:
    """Show the cameras; with detect, add the ones the index's sidecars name first."""
    from mindit.config.settings import load_settings, resolve_database_path  # pylint: disable=import-outside-toplevel
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    listed = _listed()
    if detect:
        sidecars = cams.index_sidecars(resolve_database_path())
        if not sidecars:
            console.print("The index lists no sidecars yet: run 1 Autorun (or da run) first.")
            raise typer.Exit(1)
        console.print(f"Reading the camera details of {len(sidecars):,} sidecars ...")
        found = cams.detect(listed, sidecars, old_owners=dict(load_settings().cameras or {}),
                            progress=lambda n: console.print(f"  {n:,} ...", end="\r"))
        path = listed.save()
        console.print(f"{found.seen:,} pictures with a camera; {len(found.added)} new: "
                      + (", ".join(found.added[:8]) + (" ..." if len(found.added) > 8 else "") if found.added else "none"))
        log_event("cameras", f"cameras found: {len(listed.rows)} ({len(found.added)} new)", path=str(path),
                  cameras=len(listed.rows), new=len(found.added), pictures=found.seen)
    show(listed)
    if open_it:
        import subprocess  # pylint: disable=import-outside-toplevel

        if not listed.path.exists():
            listed.save()
        subprocess.Popen(["notepad.exe", str(listed.path)])  # pylint: disable=consider-using-with


def _set(name: str, kind: str | None, owner: str | None, date: str | None, years: str | None, note: str | None,
         adding: bool) -> None:
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    listed = _listed()
    if not adding and listed.find(name) is None:
        console.print(f"No camera called {escape(name)!r} in {listed.path}. Add a film camera with: "
                      f"da cameras add \"{escape(name)}\" --type film")
        raise typer.Exit(1)
    try:
        row = listed.set(name, type=kind, owner=owner, date=date, years=years, note=note)
        if adding and not row.get("type"):
            row["type"] = "film"
        if adding and not row.get("date"):
            row["date"] = "none" if row["type"] == "film" else "exif"
    except cams.CamerasError as error:
        raise typer.BadParameter(str(error)) from error
    path = listed.save()
    console.print(f"{escape(row['name'])}: " + ", ".join(f"{k} {escape(str(row[k]))}" for k in cams.FAMILY_FIELDS
                                                       if row.get(k)))
    log_event("cameras", f"camera {'added' if adding else 'changed'}: {row['name']}", path=str(path))
    if owner:
        console.print("Run da tag to update the owner: tags.")


@cameras_app.command("set")
def set_camera(
    name: str = typer.Argument(..., help="The camera, as da cameras lists it."),
    kind: str = typer.Option(None, "--type", help="camera, phone, film or scanner."),
    owner: str = typer.Option(None, "--owner", help="Who it belonged to (owner: tags)."),
    date: str = typer.Option(None, "--date", help="exif (trust its clock), scanned (its date is when it scanned), "
                                                  "none, or shift +1y (its clock was off)."),
    years: str = typer.Option(None, "--years", help="When it was used: 1985-1986."),
    note: str = typer.Option(None, "--note", help="Anything to remember about it."),
) -> None:
    """Change a camera's type, owner, date rule, years or note ('' takes one off)."""
    _set(name, kind, owner, date, years, note, adding=False)


@cameras_app.command("add")
def add_camera(
    name: str = typer.Argument(..., help="A name for it: 'Pentax K1000'."),
    kind: str = typer.Option("film", "--type", help="film (default), camera, phone or scanner."),
    owner: str = typer.Option(None, "--owner", help="Who it belonged to."),
    date: str = typer.Option(None, "--date", help="exif, scanned, none or shift +1y (film: none)."),
    years: str = typer.Option(None, "--years", help="When it was used: 1985-1986."),
    note: str = typer.Option(None, "--note", help="Anything to remember about it."),
) -> None:
    """Add a camera DA can't see in the photos: a film camera whose prints come in as scans."""
    _set(name, kind, owner, date, years, note, adding=True)


# --------------------------------------------------------------------------- da review

def review(
    folder: str = typer.Argument(None, help="One review folder (as listed), or all of them."),
    guess: bool = typer.Option(False, "--guess", help="Work out each photo's guesses and keep them in its sidecar."),
    file: bool = typer.Option(False, "--file", help="File the photos that have a date now (as Autorun would)."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before filing."),
) -> None:
    """Photos waiting for a date in photos\\organized\\review: by folder, with the best guess for each."""
    from mindit.config.settings import resolve_database_path, resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.scans import review as rv  # pylint: disable=import-outside-toplevel

    organized = resolve_photoit_organized_path()
    root = rv.review_root(organized)
    if root is None:
        console.print("This archive has no review folder: add `review_folder: review` to da-archive.yaml.")
        raise typer.Exit(1)
    if file:
        _file(yes)
        return
    folders = rv.waiting(resolve_database_path(), organized)
    if folder:
        folders = [w for w in folders if w.folder.lower() == folder.strip("\\/").lower()]
    if not folders:
        console.print(f"Nothing waiting in {root}" + (" (or the index is behind: menu 5 Refresh index)." if not folder else "."))
        return
    total = sum(len(w.photos) for w in folders)
    console.print(f"{total:,} photos waiting for a date in {root}, in {len(folders):,} folders:")
    table = Table()
    for col in ("photos", "folder", "best guess", "from"):
        table.add_column(col, justify="right" if col == "photos" else "left")
    kept = 0
    for w in folders[:40 if not folder else None]:
        first = Path(w.photos[0]["path"])
        found = rv.guesses(first)
        best = found[0] if found else None
        table.add_row(f"{len(w.photos):,}", escape(w.folder or "(top)"), best.label if best else "-",
                      escape(best.source) if best else "")
        if guess:
            for photo in w.photos:
                rv.keep_guesses(Path(photo["path"]), rv.guesses(Path(photo["path"])))
                kept += 1
    console.print(table)
    if len(folders) > 40 and not folder:
        console.print(f"... and {len(folders) - 40:,} more folders (da review \"<folder>\" for one).")
    if guess:
        from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

        console.print(f"Guesses kept on {kept:,} photos (sidecar `guesses`).")
        log_event("review", f"review guesses on {kept} photos", path=str(root), photos=kept)
    console.print("Date them: the dashboard's Dates page (menu V), or da date set \"<folder>\" --date 1987-03.")


def _file(yes: bool) -> None:
    from mindit.config.settings import resolve_database_path  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.run_workflow import _file_reviewed  # pylint: disable=import-outside-toplevel
    from mindit.core.progress import NullProgressReporter  # pylint: disable=import-outside-toplevel

    layout = default_layout()
    run_dir = layout.run_dir("review")
    folders = _file_reviewed(layout, run_dir, None, lambda name, data: None, console.print,
                             (lambda q: True) if yes else (lambda q: Confirm.ask(q, default=True)), NullProgressReporter())
    if not folders:
        console.print("No photo in review has a date yet.")
        return
    ArchiveIndexService(DbitService(resolve_database_path())).build(default_areas())
    console.print(f"Filed into {len(folders):,} folders. Record: {run_dir}")
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("review", f"filed dated photos from review into {len(folders)} folders", path=str(run_dir),
              folders=len(folders))
