# src/mindit/commands/date_cli.py

"""`da date`: dates you know better than the camera - see which photos have none, set one, shift a camera's clock."""

from __future__ import annotations

import os
from collections import defaultdict
from pathlib import Path

import typer
from rich.console import Console

from mindit.config.settings import resolve_database_path

app = typer.Typer(help="Dates you know better: list photos with no sure date, set one by hand, shift a camera's clock.",
                  no_args_is_help=True)
console = Console()


def media_under(targets: list[Path]) -> list[Path]:
    """Return the photos, videos and documents named, and those in the folders named (raw files and Live Photo videos follow their photo)."""
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import DOCUMENT_EXTENSIONS, PHOTO_EXTENSIONS, VIDEO_EXTENSIONS, is_live_photo_part  # pylint: disable=import-outside-toplevel

    return [p for p in files_under(targets, photos_only=False)
            if p.suffix.lower() in PHOTO_EXTENSIONS | DOCUMENT_EXTENSIONS
            or (p.suffix.lower() in VIDEO_EXTENSIONS and not is_live_photo_part(p))]


def undated_by_folder(folder: Path, progress=None) -> dict[Path, list[Path]]:
    """Return the photos and documents under folder with no sure date, grouped by the folder they're in."""
    from mindit.services.validateit.capture_date import resolve_capture_date  # pylint: disable=import-outside-toplevel

    found: dict[Path, list[Path]] = defaultdict(list)
    for i, path in enumerate(media_under([folder]), 1):
        if progress and i % 500 == 0:
            progress(i)
        try:
            if not resolve_capture_date(path).certain:
                found[path.parent].append(path)
        except OSError:
            found[path.parent].append(path)
    return dict(sorted(found.items()))


def _check(targets: list[Path]) -> list[Path]:
    missing = [t for t in targets if not t.exists()]
    if missing:
        raise typer.BadParameter(f"not found: {missing[0]}")
    files = media_under(targets)
    if not files:
        console.print("No photos or documents there.")
        raise typer.Exit(0)
    return files


def _done(result, what: str) -> None:
    from mindit.services.dates.user_dates import update_index  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel

    rows = update_index(resolve_database_path(), result.changed)
    n = len(result.changed)
    console.print(f"{what} on {n:,} file{'s' if n != 1 else ''} (index updated: {rows:,}).")
    for path, why in result.skipped[:5]:
        console.print(f"  skipped {path.name}: {why}")
    if len(result.skipped) > 5:
        console.print(f"  ... and {len(result.skipped) - 5:,} more skipped")
    waiting = [str(default_layout().intake_root.resolve()) + os.sep]
    review = _review_root()
    if review is not None:
        waiting.append(str(review.resolve()) + os.sep)              # waiting in review: Autorun files them too
    in_intake = [p for p in result.changed if str(Path(p).resolve()).startswith(tuple(waiting))]
    filed = sorted({str(Path(p).parent) for p in result.changed if p not in in_intake})
    if in_intake:
        console.print("Next: 1 Autorun in the menu (or da run) files them by these dates.")
    if filed:
        console.print("Already filed: to rename and move them to match, run")
        for folder in filed[:5]:
            console.print(f'  da validate "{folder}" --mode repair')


def _review_root() -> Path | None:
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.scans.review import review_root  # pylint: disable=import-outside-toplevel

    try:
        return review_root(resolve_photoit_organized_path())
    except Exception:  # pylint: disable=broad-except
        return None


@app.command("list")
def list_undated(
    folder: Path = typer.Argument(None, help="Where to look (default: this archive's intake and review folder)."),
) -> None:
    """List the photos and documents with no sure date, folder by folder."""
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel

    folders = [folder] if folder else [default_layout().intake_root, _review_root()]
    folders = [f for f in folders if f is not None and f.exists()]
    console.print("Looking for photos and documents with no sure date in " + " and ".join(str(f) for f in folders) + " ...")
    found: dict[Path, list[Path]] = {}
    for where in folders:
        found.update(undated_by_folder(where, progress=lambda n: console.print(f"  {n:,} files ...", end="\r")))
    if not found:
        console.print("Every photo and document there has a sure date.")
        return
    total = sum(len(v) for v in found.values())
    console.print(f"{total:,} with no sure date, in {len(found):,} folder{'s' if len(found) != 1 else ''}:")
    for where, files in list(found.items())[:30]:
        console.print(f"  {len(files):>6,}  {where}   (e.g. {files[0].name})")
    if len(found) > 30:
        console.print(f"  ... and {len(found) - 30:,} more folders")
    console.print('Give a folder its date:  da date set "<folder>" --date 1998-07')


@app.command("set")
def set_date(
    targets: list[Path] = typer.Argument(..., help="Photos or folders."),
    date: str = typer.Option(..., "--date", "-d", help="1990s, 1998, 1998-07, 1998-07-04 or 1998-07-04 14:30."),
) -> None:
    """Give photos a date by hand (it wins over the camera and the file name)."""
    from mindit.services.dates.user_dates import DateError, parse_when, set_dates  # pylint: disable=import-outside-toplevel

    try:
        when, precision = parse_when(date)
    except DateError as error:
        raise typer.BadParameter(str(error)) from error
    files = _check(targets)
    if precision == "decade":
        console.print("Only a decade: noted, but they wait in review until they have a month.")
    elif precision == "year":
        console.print(f"Only a year: DA files photos under {when:%Y}-01 (January), but scanned prints wait in review "
                      "for a month. A month is better if you know it.")
    _done(set_dates(files, when, precision, date), f"Date set to {date.strip()}")


@app.command("shift")
def shift_date(
    targets: list[Path] = typer.Argument(..., help="Photos or folders."),
    by: str = typer.Option(..., "--by", help="How far the camera's clock was off: +1h, -30m, +2d, -1y, +3mo."),
) -> None:
    """Move photos' dates by a fixed amount (a camera whose clock was wrong, or a time zone)."""
    from mindit.services.dates.user_dates import DateError, parse_shift, shift_dates  # pylint: disable=import-outside-toplevel

    try:
        shift = parse_shift(by)
    except DateError as error:
        raise typer.BadParameter(str(error)) from error
    files = _check(targets)
    _done(shift_dates(files, shift), f"Dates shifted {shift.text}")


@app.command("clear")
def clear_date(
    targets: list[Path] = typer.Argument(..., help="Photos or folders."),
) -> None:
    """Take dates set by hand off again; each file's own date counts again."""
    from mindit.services.dates.user_dates import clear_dates  # pylint: disable=import-outside-toplevel

    _done(clear_dates(_check(targets)), "Dates set by hand taken off")
