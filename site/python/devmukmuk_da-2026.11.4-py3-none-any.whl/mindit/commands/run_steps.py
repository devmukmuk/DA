﻿# src/mindit/commands/run_steps.py

"""Process intake's steps (1-12) and choosing them: the menu's P Pre-run setup, kept in da-archive.yaml `run:`.

1-7 file what's in intake (1 index, 2 hash, 3 duplicates, 4 preview, 5 check, 6 file, 7 refresh); 3 and 7 can be left
out, the others are always done. After filing, each on only the folders just filed: 8 Camera owners (ask who used
cameras DA hasn't seen), 9 Tags (automatic tags), 10 Places (look up GPS photos' places, internet), 11 Location folders
(group a month's GPS photos into folders you name), 12 Faces (da facial scan + suggest on them; you confirm on the
dashboard's People page). Owners come before tags so one tagging pass gets the owner: tags right. 8 and 11 need a
person: with --yes (bypass) or no terminal they say what's waiting instead.
"""

from __future__ import annotations

import functools
import os
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Iterator

import typer
from rich.console import Console
from rich.prompt import Prompt

from mindit.services.scans.cameras import owners as camera_owners

console = Console()


@dataclass(frozen=True)
class Step:
    """One step of Process intake."""

    number: int
    name: str
    title: str
    what: str
    always: bool = False


CORE = (
    Step(1, "index", "Index", "what the archive and this folder hold now", always=True),
    Step(2, "hash", "Hash", "fingerprint the files that could be copies", always=True),
    Step(3, "duplicates", "Duplicates", "set exact, resized and re-saved copies aside (off: copies are filed too)"),
    Step(4, "preview", "Preview", "plan every name and folder (nothing moves)", always=True),
    Step(5, "check", "Check", "show the plan and its warnings", always=True),
    Step(6, "file", "File", "move the files into organized and check each one", always=True),
    Step(7, "refresh", "Refresh index", "index again at the end (off: the next run catches up)"),
)
STEPS = (
    Step(8, "owners", "Camera owners", "ask who used cameras DA hasn't seen yet"),
    Step(9, "tags", "Tags", "automatic tags for the photos just filed"),
    Step(10, "places", "Places", "look up the places of GPS photos (internet, about one a second)"),
    Step(11, "groups", "Location folders", "group each month's GPS photos into folders you name"),
    Step(12, "faces", "Faces", "find the faces in the photos just filed and suggest names (da facial)"),
)
ALL = CORE + STEPS
TOTAL = 12
DEFAULT = ("tags",)
BYPASS = "bypass"


def step_names(words: list[str] | None) -> list[str]:
    """Return the step names in words like 'places,groups' or '10 11' (numbers or names); unknown ones stop."""
    names = []
    for word in re.split(r"[,\s]+", " ".join(words or [])):
        if not word:
            continue
        found = next((s for s in ALL if word.lower() in (s.name, str(s.number), s.title.lower())), None)
        if found is None or found.always:
            raise typer.BadParameter(f"{word!r} isn't a step DA can switch" + (" (it's always done)" if found else "")
                                     + ": " + ", ".join(f"{s.number} {s.name}" for s in ALL if not s.always))
        names.append(found.name)
    return names


def chosen(saved: list[str] | None, skip: list[str] | None = None, also: list[str] | None = None) -> list[str]:
    """Return the steps after filing to run, in order: the saved choice (or the default), minus --skip, plus --with."""
    on = set(saved if saved is not None else DEFAULT)
    on -= set(step_names(skip))
    on |= set(step_names(also))
    return [s.name for s in STEPS if s.name in on]


def left_out(saved: list[str] | None, skip: list[str] | None = None, also: list[str] | None = None) -> list[str]:
    """Return the steps 1-7 not to do (3 duplicates, 7 refresh): the saved run: skip, plus --skip, minus --with."""
    off = set(saved or []) | set(step_names(skip))
    off -= set(step_names(also))
    return [s.name for s in CORE if s.name in off]


def summary(after: list[str], skip: list[str], yes: bool) -> str:
    """Return one line like 'Run includes steps: 1,2,3,4,5,6,7,9,bypass' (the menu's header)."""
    on = [str(s.number) for s in CORE if s.name not in skip] + [str(s.number) for s in STEPS if s.name in after]
    return "Run includes steps: " + ",".join(on + ([BYPASS] if yes else []))


def setup(after: list[str], skip: list[str], yes: bool, keys: Iterator[str] | None = None
          ) -> tuple[list[str], list[str], bool] | None:
    """Show every step ticked or not and let the user switch them; return (after filing, left out, bypass), or None.

    In a Windows terminal: up/down arrows move, the spacebar switches, Enter keeps it, Esc or q goes back.
    Otherwise (input piped in) a typed number, or `bypass`, switches one.
    """
    on = {s.name for s in CORE if s.name not in skip} | set(after) | ({BYPASS} if yes else set())
    if keys is None and _arrow_keys():
        keys = _windows_keys()
    done = _by_keys(on, keys) if keys is not None else _by_lines(on)
    if done is None:
        return None
    return [s.name for s in STEPS if s.name in done], [s.name for s in CORE if s.name not in done], BYPASS in done


_ROWS = ALL + (Step(0, BYPASS, "Bypass yes", "don't ask before each change (8 and 11 then only say what's waiting)"),)
_HEADINGS = {1: "File what's in intake:", 8: "After filing (on the folders just filed):", 0: "Questions:"}


def _rows(on: set[str], at: int | None, note: str = "") -> str:
    lines = ["  [bold]Pre-run setup[/bold]: what 1 Autorun does each time"
             + ("   [dim]up/down: move   space: switch   Enter: keep   Esc: back[/dim]" if at is not None else "")]
    for i, s in enumerate(_ROWS):
        if s.number in _HEADINGS and s.name in (CORE[0].name, STEPS[0].name, BYPASS):
            lines.append("  " + _HEADINGS[s.number])
        mark = "[dim]\\[*][/dim]" if s.always else "[green]\\[x][/green]" if s.name in on else "\\[ ]"
        number = f"{s.number:>2}" if s.number else "  "
        line = f"{mark} {number}  {s.title:<17} {'[dim](always)[/dim] ' if s.always else ''}{s.what}"
        lines.append(f"  [reverse]>[/reverse] {line}" if i == at else f"    {line}")
    if note:
        lines.append(f"  [yellow]{note}[/yellow]")
    return "\n".join(lines)


def _by_keys(on: set[str], keys: Iterator[str]) -> set[str] | None:
    """The arrow-key list, drawn again in place after each key."""
    from rich.live import Live  # pylint: disable=import-outside-toplevel
    from rich.text import Text  # pylint: disable=import-outside-toplevel

    at = 0
    with Live(Text.from_markup(_rows(on, at)), console=console, auto_refresh=False) as live:
        for key in keys:
            note = ""
            if key == "up":
                at = (at - 1) % len(_ROWS)
            elif key == "down":
                at = (at + 1) % len(_ROWS)
            elif key == "space":
                if _ROWS[at].always:
                    note = f"{_ROWS[at].number} {_ROWS[at].title} is always done: filing needs it."
                else:
                    on ^= {_ROWS[at].name}
            elif key == "enter":
                live.update(Text.from_markup(_rows(on, None)), refresh=True)
                return on
            elif key == "back":
                return None
            live.update(Text.from_markup(_rows(on, at, note)), refresh=True)
    return None


def _by_lines(on: set[str]) -> set[str] | None:
    """The typed list (no arrow keys): a number or `bypass` switches one, Enter keeps it, q goes back."""
    while True:
        console.print("\n" + _rows(on, None))
        try:
            answer = Prompt.ask("  Type a number (or bypass) to switch it; Enter = keep, q = back",
                                default="", show_default=False).strip().lower()
        except (EOFError, KeyboardInterrupt):
            return None
        if not answer:
            return on
        if answer in ("q", "back"):
            return None
        try:
            for word in re.split(r"[,\s]+", answer):
                on ^= {BYPASS} if word in (BYPASS, "yes") else set(step_names([word]))
        except typer.BadParameter as exc:
            console.print(f"  [yellow]{exc}[/yellow]")


def _arrow_keys() -> bool:
    return os.name == "nt" and sys.stdin.isatty() and sys.stdout.isatty()


def _windows_keys() -> Iterator[str]:
    """Yield up / down / space / enter / back as keys are pressed in the Windows console."""
    import msvcrt  # pylint: disable=import-outside-toplevel,import-error

    while True:
        key = msvcrt.getwch()
        if key in ("\x00", "\xe0"):                     # an arrow or other special key: its code comes next
            yield {"H": "up", "P": "down"}.get(msvcrt.getwch(), "")
        elif key == " ":
            yield "space"
        elif key in ("\r", "\n"):
            yield "enter"
        elif key in ("\x1b", "q", "Q", "\x03"):
            yield "back"


def after_filing(folders: list[Path], steps: list[str], *, interactive: bool, say: Callable[[str], None],
                 yes: bool = False) -> dict[str, Any]:
    """Run the chosen steps 8-11 on the folders just filed; return what each did (for the run's summary).

    yes (--yes, or Bypass yes): step 11 files groups under their location.untitled names without asking.
    """
    done: dict[str, Any] = {}
    folders = sorted({Path(f) for f in folders if Path(f).is_dir()})
    for s in STEPS:
        label = f"{s.number}/{TOTAL} {s.title}"
        if s.name not in steps:
            say(f"{label}: skipped")
            done[s.name] = "skipped"
            continue
        if not folders:
            say(f"{label}: nothing was filed")
            done[s.name] = "nothing filed"
            continue
        step = functools.partial(_groups, yes=yes) if s.name == "groups" else _STEP[s.name]
        try:
            done[s.name] = step(folders, interactive, lambda m, label=label: say(f"{label}: {m}"))
        except typer.Exit:
            done[s.name] = "stopped"
        except Exception as exc:  # pylint: disable=broad-except
            say(f"{label}: [red]didn't finish: {exc}[/red]")
            done[s.name] = f"error: {exc}"
    return done


def _owners(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.commands.workflow_cli import _save_owners  # pylint: disable=import-outside-toplevel
    from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging import tags as tg  # pylint: disable=import-outside-toplevel

    seen = tg.cameras_seen(tg.files_under(folders, photos_only=True), camera_owners())
    missing = [cam for cam in seen if not cam.owner]
    if not missing:
        say(f"all {len(seen):,} cameras' owners are known" if seen else "no camera details in these photos")
        return {"cameras": len(seen), "new": 0}
    if not interactive:
        say(f"{len(missing):,} cameras with no owner yet: " + ", ".join(c.key for c in missing[:4])
            + (" ..." if len(missing) > 4 else "") + " - name them: da tag --cameras")
        return {"cameras": len(seen), "new": len(missing), "asked": False}
    say("who used each camera? Type a name, or press Enter to skip.")
    names = {}
    for cam in missing:
        years = tg.camera_years(cam)
        try:
            answer = Prompt.ask(f"    {cam.key}  ({cam.photos:,} photos{', ' + years if years else ''})",
                                default="", show_default=False).strip()
        except (EOFError, KeyboardInterrupt):
            break
        if answer:
            names[cam.key] = answer
    if names:
        _save_owners(names)
    return {"cameras": len(seen), "new": len(missing), "named": len(names)}


def _tags(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.config.settings import load_settings, resolve_database_path  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging import tags as tg  # pylint: disable=import-outside-toplevel

    photos = tg.files_under(folders, photos_only=True)
    result = tg.tag_photos(photos, camera_owners())          # owners saved in step 8 count already
    rows = tg.update_index(resolve_database_path(), result.changed)
    say(f"{result.files:,} photos tagged (camera details read from {result.read:,}; index updated: {rows:,})")
    return {"photos": result.files, "read": result.read}


def _places(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.commands.location_cli import lookup  # pylint: disable=import-outside-toplevel

    say("looking up the places of the GPS photos just filed ...")
    lookup(targets=folders, force=False, offline=False, yes=True)       # you switched this step on: no second ask
    return {"folders": len(folders)}


def _months(folders: list[Path], without_gps: bool = False) -> list[str]:
    from mindit.services.location import places as pl  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel

    months = set()
    for folder in folders:
        month = re.search(r"(\d{4}-\d{2})", folder.name)
        if not month or month.group(1) in months:
            continue
        for photo in files_under([folder], photos_only=True):
            if Path(f"{photo}.meta.json").exists() and (without_gps or pl.position(SidecarService.load(photo))):
                months.add(month.group(1))
                break
    return sorted(months)


def _groups(folders: list[Path], interactive: bool, say: Callable[[str], None], yes: bool = False) -> dict[str, Any]:
    from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

    settings = load_settings().location
    which = "photos" if settings.without_gps else "GPS photos"
    months = _months(folders, settings.without_gps)
    if not months:
        say(f"no {which} filed, nothing to group")
        return {"months": 0}
    named = yes and bool(settings.untitled)          # not asked: each group gets its location.untitled name
    if not interactive and not named:
        say(f"{len(months):,} months with {which} to put in location folders: "
            + ", ".join(months[:6]) + (" ..." if len(months) > 6 else "") + f" - da location group {months[0]}")
        return {"months": len(months), "asked": False}
    from mindit.commands.location_cli import group  # pylint: disable=import-outside-toplevel

    for month in months:
        say(f"{month}")
        try:
            group(month=Path(month), title=None, hours=6.0, km=2.0, yes=named, skip_title=named and not interactive,
                  set_title=None)
        except typer.Exit:
            continue
    return {"months": len(months), **({"named": settings.untitled} if named and not interactive else {})}


def _faces(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.config.settings import resolve_database_path  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import scan as sc  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import suggest as sg  # pylint: disable=import-outside-toplevel
    from mindit.services.faces.engine import EngineError, FaceEngine  # pylint: disable=import-outside-toplevel

    db_path = resolve_database_path()
    rows = sc.photos(db_path, [str(f.resolve()) for f in folders])
    try:
        engine = FaceEngine(say=say)
    except EngineError as exc:
        say(f"[yellow]{exc}[/yellow]")
        return {"error": str(exc)}
    result = sc.scan(db_path, rows, engine)
    counts = sg.suggest(db_path)
    say(f"{result.photos:,} photos looked at, {result.faces:,} faces ({result.picasa_names:,} with Picasa's names); "
        f"suggested: {counts['probably']:,} probably, {counts['maybe']:,} maybe - confirm them: da dashboard, People")
    return {"photos": result.photos, "faces": result.faces, **counts}


_STEP: dict[str, Callable[[list[Path], bool, Callable[[str], None]], Any]] = {
    "owners": _owners, "tags": _tags, "places": _places, "groups": _groups, "faces": _faces}


def save_choice(archive_file: Path, steps: list[str], skip: list[str] | None = None, yes: bool = False) -> Path:
    """Write `run:` (after_filing; skip and bypass when set) into da-archive.yaml (a text edit), check it; the backup."""
    import shutil  # pylint: disable=import-outside-toplevel

    import yaml  # pylint: disable=import-outside-toplevel

    skip = list(skip or [])
    text = archive_file.read_text(encoding="utf-8")
    block = ("run:\n  # What 1 Autorun does (menu P Pre-run setup). After filing: owners, tags, places, groups, faces.\n"
             f"  after_filing: [{', '.join(steps)}]\n"
             + ("  # Steps left out (duplicates, refresh); da run leaves them out too.\n"
                f"  skip: [{', '.join(skip)}]\n" if skip else "")
             + ("  # The menu's Autorun doesn't ask before each change (da run still asks, unless --yes).\n"
                "  bypass: true\n" if yes else ""))
    lines = text.splitlines(keepends=True)
    start = next((i for i, line in enumerate(lines) if re.match(r"^run:\s*(#.*)?$", line)), None)
    if start is None:
        new = text + ("" if text.endswith("\n") else "\n") + "\n" + block
    else:
        end = start + 1
        while end < len(lines) and (lines[end].startswith((" ", "\t")) or not lines[end].strip()):
            end += 1
        new = "".join(lines[:start]) + block + ("\n" if end < len(lines) else "") + "".join(lines[end:])
    backup = archive_file.with_name(archive_file.name + ".bak")
    shutil.copy2(archive_file, backup)
    archive_file.write_text(new, encoding="utf-8")
    try:
        run = (yaml.safe_load(archive_file.read_text(encoding="utf-8")) or {}).get("run") or {}
        assert run.get("after_filing") == steps and (run.get("skip") or []) == skip and bool(run.get("bypass")) == yes
    except Exception as exc:  # pylint: disable=broad-except
        shutil.copy2(backup, archive_file)
        raise RuntimeError(f"Couldn't save the steps in {archive_file.name} (put back as it was): {exc}") from exc
    return backup
