# src/mindit/services/workflow/imports.py

"""`da imports`: how far each drive or folder being brought in has got, as a table and a page (imports.html).

The plan is `imports.yaml` beside the archives (W:\\archives\\imports.yaml): each source and the archive that takes
it, made by `da imports --init <drives>` and edited by hand. Nothing here copies or moves anything; it reads:

- each archive's `da import` records (output\\runs\\<ts>-import\\import-plan.csv and import-log.csv), taking the
  rows under each source (so one import of several year folders counts for each of them);
- each archive's index, to see where every copy is now: still in intake (waiting to be filed, needing a date, or
  for another decade's archive), filed, set aside as a copy, or gone on (split elsewhere, or undone).

The page is rewritten after every `da import`, `da run` and `da split` when a plan exists (`refresh_quietly`), and
reloads itself every minute while open. Design: docs/da-docs/IMPORTS-DESIGN.md.
"""

from __future__ import annotations

import csv
import fnmatch
import html
import os
import re
import sqlite3
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

PLAN = "imports.yaml"
PAGE = "imports.html"
_YEAR = re.compile(r"^(\d{4})$")
_RUN = re.compile(r"^(\d{8}-\d{6})-(import|run|split)$")
STATUSES = ("not found", "not started", "previewed", "nothing new", "copied", "filing", "needs dates", "done")
TO_IMPORT = ("not started", "previewed")            # what `da import --plan` brings in

PLAN_HEADER = """\
# The drives and folders to bring in with `da import`, and the archive each goes to.
# `da imports` shows how far each has got (and writes imports.html beside this file).
# exclude: folders inside the source to leave out (* and ? work), e.g. the year folders imported on their own.
"""


class PlanProblem(RuntimeError):
    """The plan can't be read or made (and why)."""


# --------------------------------------------------------------------------- the plan

@dataclass
class Source:
    """One planned source: a drive or folder, the archive it goes to, and folders in it to leave out."""

    source: Path
    archive: str
    exclude: list[str] = field(default_factory=list)
    note: str = ""

    def excluded_folders(self) -> list[Path]:
        """Return the folders the exclude patterns name now."""
        found: list[Path] = []
        for pattern in self.exclude:
            parent = Path(pattern).parent
            if parent.is_dir():
                found += sorted(p for p in parent.iterdir()
                                if p.is_dir() and fnmatch.fnmatch(p.name.lower(), Path(pattern).name.lower()))
        return found


def plan_path(archive: Path | None, archives: list[Path]) -> Path | None:
    """Return where the plan lives: beside the current archive, else beside the first archive on this PC."""
    root = archive or (archives[0] if archives else None)
    return Path(root).parent / PLAN if root else None


def read_plan(path: Path) -> list[Source]:
    """Return the plan's sources."""
    import yaml  # pylint: disable=import-outside-toplevel

    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError) as exc:
        raise PlanProblem(f"{path} can't be read: {exc}") from exc
    sources = []
    for entry in data.get("sources") or []:
        if not isinstance(entry, dict) or not entry.get("source") or not entry.get("archive"):
            raise PlanProblem(f"{path}: every entry needs source: and archive: ({entry!r})")
        exclude = entry.get("exclude") or []
        sources.append(Source(Path(str(entry["source"])), str(entry["archive"]),
                              [str(e) for e in (exclude if isinstance(exclude, list) else [exclude])],
                              str(entry.get("note") or "")))
    return sources


def make_plan(roots: list[Path], archives: dict[str, tuple[int, int] | None]) -> list[Source]:
    """Return a plan for these drives: a year folder (2019) to the archive for its year, the rest to the newest."""
    newest = max(archives, key=lambda name: (archives[name] or (0, 0))[1]) if archives else ""
    sources: list[Source] = []
    for root in roots:
        years = sorted((p for p in Path(root).iterdir() if p.is_dir() and _YEAR.match(p.name)), key=lambda p: p.name)
        placed = []
        for folder in years:
            year = int(folder.name)
            home = next((name for name, span in archives.items() if span and span[0] <= year <= span[1]), "")
            if home:
                sources.append(Source(folder, home))
                placed.append(folder)
        rest = Source(Path(root), newest, [str(f) for f in placed],        # a year no archive takes stays in
                      "the rest (not the year folders above)" if placed else "")
        sources.append(rest)
    return sources


def write_plan(path: Path, sources: list[Source]) -> Path:
    """Write the plan as YAML."""
    import yaml  # pylint: disable=import-outside-toplevel

    entries = []
    for s in sources:
        entry: dict[str, Any] = {"source": str(s.source), "archive": s.archive}
        if s.exclude:
            entry["exclude"] = s.exclude
        if s.note:
            entry["note"] = s.note
        entries.append(entry)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(PLAN_HEADER + yaml.safe_dump({"sources": entries}, sort_keys=False, allow_unicode=True),
                    encoding="utf-8")
    return path


# --------------------------------------------------------------------------- what the archives say

@dataclass
class ArchiveRecords:
    """One archive's import records and index, read once."""

    root: Path
    name: str
    years: tuple[int, int] | None
    plans: list[tuple[str, list[dict[str, str]]]] = field(default_factory=list)   # (run time, rows), oldest first
    copies: list[tuple[str, dict[str, str]]] = field(default_factory=list)        # (run time, log row)
    runs: list[str] = field(default_factory=list)                                 # da run times
    by_path: dict[str, tuple[str, str | None, bool]] = field(default_factory=dict)  # path -> area, captured, sidecar
    by_source: dict[str, tuple[str, str]] = field(default_factory=dict)          # source_path -> area, path


def _key(path: str | Path) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def _csv(path: Path) -> list[dict[str, str]]:
    try:
        with path.open(encoding="utf-8", newline="") as f:
            return list(csv.DictReader(f))
    except (OSError, csv.Error):
        return []


def read_archive(root: Path) -> ArchiveRecords:
    """Read an archive's import records, run times and index."""
    from mindit.services.workflow.split import archive_name, archive_years  # pylint: disable=import-outside-toplevel

    records = ArchiveRecords(Path(root), archive_name(root), archive_years(root))
    runs = Path(root) / "output" / "runs"
    for folder in sorted(runs.iterdir()) if runs.is_dir() else []:
        match = _RUN.match(folder.name)
        if not match:
            continue
        when, kind = match.groups()
        if kind == "run":
            records.runs.append(when)
        elif kind == "import":
            plan = _csv(folder / "import-plan.csv")
            if plan:
                records.plans.append((when, plan))
            records.copies += [(when, r) for r in _csv(folder / "import-log.csv") if r.get("result") == "copied"]
    db = Path(root) / ".da" / "da.sqlite"
    if db.exists():
        try:
            with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as conn:
                for path, area, captured, sidecar, source in conn.execute(
                        "SELECT path, area, captured_at, sidecar_path, source_path FROM files"):
                    records.by_path[_key(path)] = (area or "", captured, bool(sidecar))
                    if source:
                        records.by_source[_key(source)] = (area or "", path)
        except sqlite3.Error:
            pass
    return records


# --------------------------------------------------------------------------- each source's progress

@dataclass
class Progress:
    """How far one source has got."""

    source: Source
    exists: bool = True
    status: str = "not started"
    seen: int = 0                  # files the last look at the source counted (junk left out)
    new: int = 0
    archived: int = 0
    duplicates: int = 0
    other: int = 0
    copied: int = 0
    filed: int = 0
    set_aside: int = 0
    to_file: int = 0               # in intake, not run yet
    needs_date: int = 0
    other_decade: int = 0
    moved_on: int = 0              # split to another archive, or undone
    last_look: str = ""
    last_copy: str = ""
    last_run: str = ""

    @property
    def waiting(self) -> int:
        """Return how many copies are in intake for Autorun or Split (those needing a date are counted apart)."""
        return self.to_file + self.other_decade

    @property
    def handled(self) -> int:
        """Return how many copies have left intake (filed, set aside, or moved on)."""
        return self.filed + self.set_aside + self.moved_on


def _under(path: str, source: Source, excluded: list[str]) -> bool:
    key = _key(path)
    top = _key(source.source).rstrip("\\/") + os.sep
    return key.startswith(top) and not any(key.startswith(e) for e in excluded)


def _stamp(when: str) -> str:
    return datetime.strptime(when, "%Y%m%d-%H%M%S").strftime("%Y-%m-%d %H:%M") if when else ""


def progress_of(source: Source, archives: dict[str, ArchiveRecords]) -> Progress:
    """Work out how far one source has got, from every archive's records."""
    p = Progress(source, exists=source.source.is_dir())
    excluded = [_key(f).rstrip("\\/") + os.sep for f in source.excluded_folders()]
    home = archives.get(source.archive)

    looks = [(when, [r for r in rows if _under(r.get("source", ""), source, excluded)])
             for rec in archives.values() for when, rows in rec.plans]
    looks = [(when, rows) for when, rows in looks if rows]
    if looks:
        when, rows = max(looks, key=lambda item: item[0])
        actions = Counter(r.get("action") for r in rows)
        p.last_look, p.seen = when, len(rows)
        p.new, p.archived, p.duplicates, p.other = (actions["copy"], actions["archived"], actions["duplicate"],
                                                    actions["other"])

    copies: dict[str, str] = {}
    for rec in archives.values():
        for when, row in rec.copies:
            if _under(row.get("source", ""), source, excluded):
                copies[_key(row["destination"])] = when
                p.last_copy = max(p.last_copy, when)
    p.copied = len(copies)
    for destination in copies:
        _place(destination, p, archives)
    if home is not None and home.runs:
        p.last_run = home.runs[-1]

    if not p.exists and not copies:
        p.status = "not found"
    elif not copies:
        p.status = "nothing new" if looks and p.new == 0 else ("previewed" if looks else "not started")
    elif p.to_file or p.other_decade:
        p.status = "filing" if p.handled else "copied"
    elif p.needs_date:
        p.status = "needs dates"
    else:
        p.status = "done"
    return p


def _place(destination: str, p: Progress, archives: dict[str, ArchiveRecords]) -> None:
    """Count where one copy is now."""
    for rec in archives.values():
        found = rec.by_path.get(destination)
        if found is not None:
            area, captured, has_sidecar = found
            if area == "intake":
                _waiting(captured, has_sidecar, rec, p)
                return
    for rec in archives.values():
        moved = rec.by_source.get(destination)
        if moved is not None:
            area, path = moved
            if area in ("photos", "documents"):
                p.filed += 1
            elif area == "holding":
                p.set_aside += 1
            elif area == "intake":
                _waiting(*rec.by_path.get(_key(path), ("intake", None, False))[1:], rec, p)
            else:
                p.moved_on += 1
            return
    if os.path.exists(destination):
        p.to_file += 1                                   # copied since the index was last refreshed
    else:
        p.moved_on += 1


def _waiting(captured: str | None, has_sidecar: bool, rec: ArchiveRecords, p: Progress) -> None:
    if not has_sidecar:
        p.to_file += 1                                   # not through da run yet
        return
    year = int(captured[:4]) if captured and captured[:4].isdigit() else None
    if year is None:
        p.needs_date += 1
    elif rec.years and not rec.years[0] <= year <= rec.years[1]:
        p.other_decade += 1
    else:
        p.to_file += 1


def gather(plan: list[Source], archive_roots: Iterable[Path]) -> list[Progress]:
    """Return every planned source's progress."""
    archives = {}
    for root in archive_roots:
        rec = read_archive(root)
        archives[rec.name] = rec
    return [progress_of(source, archives) for source in plan]


# --------------------------------------------------------------------------- the page

_COLORS = {"not found": "#b91c1c", "not started": "#6b7280", "previewed": "#2563eb", "nothing new": "#15803d",
           "copied": "#7c3aed", "filing": "#d97706", "needs dates": "#ca8a04", "done": "#15803d"}

PAGE_CSS = """
:root { --bg:#fff; --fg:#1f2328; --muted:#6b7280; --line:#e5e7eb; --card:#f6f8fa; --bar:#15803d; }
@media (prefers-color-scheme: dark) { :root { --bg:#0d1117; --fg:#e6edf3; --muted:#8b949e; --line:#30363d;
  --card:#161b22; --bar:#3fb950; } }
body { margin:0; background:var(--bg); color:var(--fg); font:15px/1.5 "Segoe UI", system-ui, sans-serif; }
main { max-width:1400px; margin:0 auto; padding:20px 16px 40px; }
h1 { font-size:26px; margin:0 0 4px; } .muted { color:var(--muted); font-size:13px; }
.tiles { display:flex; flex-wrap:wrap; gap:12px; margin:18px 0; }
.tile { background:var(--card); border:1px solid var(--line); border-radius:8px; padding:10px 14px; min-width:130px; }
.tile b { display:block; font-size:24px; } .tile span { color:var(--muted); font-size:13px; }
.bar { height:12px; background:var(--line); border-radius:6px; overflow:hidden; margin:6px 0 18px; }
.bar div { height:100%; background:var(--bar); }
.wrap { overflow-x:auto; } table { border-collapse:collapse; width:100%; font-size:14px; }
th, td { border-bottom:1px solid var(--line); padding:6px 8px; text-align:right; white-space:nowrap; }
th { position:sticky; top:0; background:var(--bg); font-weight:600; }
td.l, th.l { text-align:left; }
h2 { font-size:19px; margin:28px 0 6px; } h2 .muted { font-weight:400; margin-left:8px; }
.next { background:var(--card); border:1px solid var(--line); border-radius:8px; padding:8px 12px; margin:6px 0 4px; }
.next code { font-family:Consolas, monospace; font-size:13px; white-space:normal; word-break:break-all; }
th, td { padding:4px 8px; }
.pill { display:inline-block; padding:1px 8px; border-radius:10px; color:#fff; font-size:12px; font-weight:600; }
.zero { color:var(--muted); }
"""


def _n(value: int) -> str:
    return '<span class="zero">0</span>' if not value else f"{value:,}"


def next_step(archive: str, rows: list[Progress]) -> str:
    """Return what to do next in one archive: file what's waiting first, then bring in what's left."""
    if any(r.to_file for r in rows):
        return f"Open DA in {archive} and choose 1 Autorun (files are waiting in intake)."
    if any(r.other_decade for r in rows):
        return f"In {archive}, choose S Split: some files belong to another decade's archive."
    todo = [r for r in rows if r.status in TO_IMPORT]
    if todo:
        return (f"In {archive}: da import --plan --apply   ({len(todo)} folder{'s' if len(todo) != 1 else ''}"
                " not brought in yet)")
    if any(r.needs_date for r in rows):
        return f"In {archive}, choose D Fix dates: some files have no date."
    missing = [r for r in rows if r.status == "not found"]
    if missing:
        return "Plug in the drive for " + ", ".join(str(r.source.source) for r in missing) + "."
    return "Nothing to do: everything planned for this archive is in."


def _summary(rows: list[Progress]) -> dict[str, int]:
    return {"done": sum(1 for r in rows if r.status in ("done", "nothing new")), "sources": len(rows),
            "new": sum(r.new for r in rows), "copied": sum(r.copied for r in rows),
            "filed": sum(r.filed for r in rows), "set_aside": sum(r.set_aside for r in rows),
            "waiting": sum(r.waiting for r in rows), "needs_date": sum(r.needs_date for r in rows),
            "handled": sum(r.handled for r in rows)}


def _row(r: Progress) -> str:
    look = (f"Last look: {r.seen:,} files - {r.new:,} new, {r.archived:,} already in an archive, "
            f"{r.duplicates:,} repeats, {r.other:,} not photos or papers")
    wait = f"{r.to_file:,} to file (Autorun), {r.other_decade:,} for another decade (S Split)"
    last = max(r.last_look, r.last_copy, r.last_run if r.copied else "")
    return (f"<tr><td class=l>{html.escape(str(r.source.source))}"
            + (f' <span class="muted">{html.escape(r.source.note)}</span>' if r.source.note else "")
            + f'</td><td class=l><span class="pill" style="background:{_COLORS[r.status]}">{r.status}</span></td>'
            f'<td title="{html.escape(look)}">{_n(r.new)}</td><td>{_n(r.copied)}</td><td>{_n(r.filed)}</td>'
            f'<td>{_n(r.set_aside)}</td><td title="{html.escape(wait)}">{_n(r.waiting)}</td><td>{_n(r.needs_date)}</td>'
            f"<td class=l>{_stamp(last)}</td></tr>")


def _rows(group: list[Progress]) -> str:
    """Return a section's rows: each folder that has started, then one folded line for those that haven't."""
    waiting = [r for r in group if r.status == "not started"]
    shown = "".join(_row(r) for r in group if r.status != "not started")
    if not waiting:
        return shown
    names = [r.source.source.name or str(r.source.source) for r in waiting]
    label = f"{len(waiting)} folder{'s' if len(waiting) != 1 else ''} not started: " + (
        f"{names[0]} &hellip; {names[-1]}" if len(names) > 3 else ", ".join(html.escape(n) for n in names))
    every = "".join(f"<div>{html.escape(str(r.source.source))}</div>" for r in waiting)
    return shown + (f'<tr><td class=l colspan=9><details><summary class="muted">{label}</summary>{every}</details>'
                    "</td></tr>")


def _tiles(s: dict[str, int]) -> str:
    tiles = [(f"{s['done']} / {s['sources']}", "folders done"), (f"{s['new']:,}", "new, at the last look"),
             (f"{s['copied']:,}", "copied"), (f"{s['filed']:,}", "filed"), (f"{s['set_aside']:,}", "set aside (copies)"),
             (f"{s['waiting']:,}", "waiting in intake"), (f"{s['needs_date']:,}", "need a date")]
    return "".join(f"<div class=tile><b>{v}</b><span>{label}</span></div>" for v, label in tiles)


def _bar(s: dict[str, int]) -> str:
    pct = round(100 * s["handled"] / s["copied"]) if s["copied"] else 0
    return (f'<div class="muted">{pct}% of the copies have left intake (filed, set aside or moved on)</div>'
            f'<div class="bar"><div style="width:{pct}%"></div></div>')


def render_page(rows: list[Progress], plan: Path, now: datetime | None = None) -> str:
    """Return the progress page: totals, then a section per archive with its next step (reloads every minute)."""
    now = now or datetime.now()
    by_archive: dict[str, list[Progress]] = {}
    for r in rows:
        by_archive.setdefault(r.source.archive, []).append(r)
    head = ("<tr><th class=l>Folder</th><th class=l>Status</th><th>New</th><th>Copied</th><th>Filed</th>"
            "<th>Set aside</th><th>Waiting</th><th>Need date</th><th class=l>Last activity</th></tr>")
    sections = []
    for archive, group in by_archive.items():
        s = _summary(group)
        sections.append(
            f"<section><h2>{html.escape(archive)} <span class=muted>{s['done']} of {s['sources']} folders done"
            f" &middot; {s['copied']:,} copied &middot; {s['filed']:,} filed &middot; {s['waiting']:,} waiting</span></h2>"
            f'<div class="next"><b>Next:</b> <code>{html.escape(next_step(archive, group))}</code></div>'
            f"{_bar(s)}<div class=wrap><table>{head}{_rows(group)}</table></div></section>")
    total = _summary(rows)
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="60"><title>DA Imports</title><style>{PAGE_CSS}</style></head>
<body><main>
<h1>DA Imports</h1>
<div class="muted">Updated {now:%Y-%m-%d %H:%M} &middot; plan: {html.escape(str(plan))} &middot; reloads every minute;
rewritten after each da import, da run and da split (or type <code>da imports</code>)</div>
<div class="tiles">{_tiles(total)}</div>
{_bar(total)}
{"".join(sections)}
<p class="muted">New: files not in any archive yet, at the last look (a preview or an import; hover for the rest).
Copied: brought into intake. Then where each copy is now: Filed; Set aside (a copy of one already filed, kept in
_duplicates-holding); Waiting in intake (hover: to file with Autorun, or for another decade with S Split);
Need date (D Fix dates).</p>
</main></body></html>
"""


def write_page(rows: list[Progress], plan: Path) -> Path:
    """Write imports.html beside the plan (replacing it whole)."""
    page = plan.with_name(PAGE)
    temp = page.with_name(PAGE + ".tmp")
    temp.write_text(render_page(rows, plan), encoding="utf-8")
    os.replace(temp, page)
    return page


def refresh_quietly(archive: Path | None = None) -> Path | None:
    """Rewrite imports.html when there's a plan (after an import, a run or a split); never fails the command."""
    try:
        from mindit.config.archive import known_archives  # pylint: disable=import-outside-toplevel
        from mindit.config.settings import get_archive_root  # pylint: disable=import-outside-toplevel

        archives = known_archives()
        plan = plan_path(archive or get_archive_root(), archives)
        if plan is None or not plan.exists():
            return None
        return write_page(gather(read_plan(plan), archives), plan)
    except Exception:  # pylint: disable=broad-except
        return None
