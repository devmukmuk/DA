# src/mindit/services/workflow/backup.py

"""`da backup`: keep a copy of every archive on this PC in one backup folder, usually on a USB drive.

`da backup --setup E:\\DA-backup` remembers the folder (%LOCALAPPDATA%\\DA\\backup.json), marks it as this PC's
backup (DA-backup.json, with an id both files hold) and puts a "Back up archives" shortcut on the desktop. `da backup`
then mirrors each archive into <folder>\\<archive name> with robocopy (/MIR: new and changed files are copied, files
gone from the archive are removed from the copy). It stops before copying anything when:

- the folder isn't there (the drive isn't plugged in);
- the folder isn't the one set up (another drive got the same letter): its mark is missing or holds another id;
- an archive has far fewer files than at its last backup (half or less), which looks like a mistake, not tidying.

The thumbnail and face caches (.da\\thumbs, .da\\faces) are left out: DA makes them again. Design:
docs/da-docs/BACKUP-DESIGN.md.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

CONFIG = "backup.json"
MARK = "DA-backup.json"
SHORTCUT = "Back up archives.cmd"
SHRINK = 0.5                                     # an archive with half its last backup's files or fewer: stop
CACHES = (Path(".da") / "thumbs", Path(".da") / "faces")

SHORTCUT_TEMPLATE = """\
@echo off
rem Backs up every DA archive on this PC to {target}. Made by `da backup --setup`.
title DA - Back up archives
set "DA_EXE="
for /f "delims=" %%i in ('where $PATH:da.cmd 2^>nul') do if not defined DA_EXE set "DA_EXE=%%i"
for /f "delims=" %%i in ('where $PATH:DA.exe 2^>nul') do if not defined DA_EXE set "DA_EXE=%%i"
if not defined DA_EXE if exist "C:\\Scripts\\DA\\da.cmd" set "DA_EXE=C:\\Scripts\\DA\\da.cmd"
if not defined DA_EXE if exist "C:\\Scripts\\DA\\DA.exe" set "DA_EXE=C:\\Scripts\\DA\\DA.exe"
if not defined DA_EXE (
  echo DA is not installed on this PC. See "Getting started" at https://da.gamenightbymike.com
  pause
  exit /b 1
)
call "%DA_EXE%" backup
echo.
pause
"""


class BackupProblem(RuntimeError):
    """Why a backup can't start (and what to do)."""


@dataclass
class Copied:
    """One archive's backup."""

    archive: Path
    destination: Path
    files: int = 0
    ok: bool = False
    note: str = ""


@dataclass
class BackupResult:
    """What a backup did."""

    target: Path
    archives: list[Copied] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """Return whether every archive was backed up."""
        return bool(self.archives) and all(a.ok for a in self.archives)


# --------------------------------------------------------------------------- where the backup goes

def config_path() -> Path:
    """Return this PC's backup settings file (beside archives.json)."""
    from mindit.config.archive import registry_path  # pylint: disable=import-outside-toplevel

    return registry_path().with_name(CONFIG)


def read_config() -> dict:
    """Return this PC's backup settings ({} when `da backup --setup` hasn't been run)."""
    try:
        data = json.loads(config_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(temp, path)


def desktop() -> Path:
    """Return the desktop folder (DA_DESKTOP in tests)."""
    if os.environ.get("DA_DESKTOP"):
        return Path(os.environ["DA_DESKTOP"])
    if sys.platform == "win32":
        import ctypes  # pylint: disable=import-outside-toplevel

        buffer = ctypes.create_unicode_buffer(260)
        if ctypes.windll.shell32.SHGetFolderPathW(None, 0x10, None, 0, buffer) == 0:   # CSIDL_DESKTOPDIRECTORY
            return Path(buffer.value)
    return Path.home() / "Desktop"


def setup_backup(target: Path) -> Path:
    """Make target this PC's backup folder (marking it), and put the shortcut on the desktop; return the shortcut."""
    from mindit.config.archive import this_computer  # pylint: disable=import-outside-toplevel

    target = Path(target).resolve()
    if target.parent == target:
        raise BackupProblem(f"Give a folder on the drive, not the whole drive: e.g. {target}DA-backup")
    target.mkdir(parents=True, exist_ok=True)
    mark = _read_mark(target)
    backup_id = mark.get("id") or uuid.uuid4().hex                  # a folder set up before keeps its id
    if not mark:
        _write_json(target / MARK, {"id": backup_id, "made": datetime.now().isoformat(timespec="seconds"),
                                    "computer": this_computer(), "note": "DA's backup of this PC's archives. "
                                    "`da backup` copies into this folder; leave this file here."})
    config = read_config()
    _write_json(config_path(), {**config, "to": str(target), "id": backup_id})
    shortcut = desktop() / SHORTCUT
    shortcut.parent.mkdir(parents=True, exist_ok=True)
    shortcut.write_text(SHORTCUT_TEMPLATE.format(target=target), encoding="utf-8")
    return shortcut


def _read_mark(target: Path) -> dict:
    try:
        data = json.loads((target / MARK).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def check_target(config: dict) -> Path:
    """Return the backup folder, or say why a backup can't go there now."""
    if not config.get("to"):
        raise BackupProblem("No backup folder yet. Plug in the backup drive and run once: "
                            "da backup --setup E:\\DA-backup (the drive's letter and a folder name).")
    target = Path(config["to"])
    if not target.is_dir():
        raise BackupProblem(f"The backup drive isn't there ({target}). Plug it in and try again.")
    if _read_mark(target).get("id") != config.get("id"):
        raise BackupProblem(f"{target} isn't this PC's backup folder (its {MARK} is missing or from another "
                            "backup), so nothing was copied. Is another drive using that letter? "
                            f"To make it the backup: da backup --setup {target}")
    return target


# --------------------------------------------------------------------------- copying

def count_files(folder: Path) -> int:
    """Return how many files an archive holds (the caches left out)."""
    skip = {os.path.normcase(str(folder / c)) for c in CACHES}
    total = 0
    for dirpath, dirnames, filenames in os.walk(folder):
        dirnames[:] = [d for d in dirnames if os.path.normcase(os.path.join(dirpath, d)) not in skip]
        total += len(filenames)
    return total


def robocopy(source: Path, destination: Path) -> tuple[int, str]:
    """Mirror source into destination; return robocopy's exit code (below 8 = done) and its last lines."""
    command = ["robocopy", str(source), str(destination), "/MIR", "/R:1", "/W:1", "/FFT", "/XJ", "/DCOPY:T",
               "/NFL", "/NDL", "/NP", "/XD", *(str(source / c) for c in CACHES)]
    done = subprocess.run(command, capture_output=True, text=True, errors="replace", check=False)
    return done.returncode, "\n".join(done.stdout.strip().splitlines()[-8:])


def run_backup(archives: list[Path], config: dict | None = None,
               say: Callable[[str], None] | None = None) -> BackupResult:
    """Back up each archive into the backup folder (see the module docstring for when it stops)."""
    from mindit.core.logging import log_to_archive  # pylint: disable=import-outside-toplevel

    say = say or (lambda _m: None)
    config = read_config() if config is None else config
    target = check_target(config)
    result = BackupResult(target)
    last = dict(config.get("files") or {})
    inside = os.path.normcase(str(target.resolve()))
    for archive in archives:
        archive = Path(archive).resolve()
        if os.path.normcase(str(archive)).startswith(inside):
            continue                                                 # a copy in the backup itself
        copy = Copied(archive, target / archive.name)
        result.archives.append(copy)
        copy.files = count_files(archive)
        before = int(last.get(archive.name) or 0)
        if before >= 100 and copy.files <= before * SHRINK:
            copy.note = (f"has {copy.files:,} files, {before:,} at the last backup: not copied, so the backup "
                         "keeps them. If that's right, ask for help before backing up again.")
            say(f"{archive.name}: {copy.note}")
            continue
        say(f"{archive.name}: {copy.files:,} files -> {copy.destination} ...")
        code, tail = robocopy(archive, copy.destination)
        copy.ok = code < 8
        copy.note = "" if copy.ok else f"robocopy stopped (code {code}):\n{tail}"
        if copy.ok:
            last[archive.name] = copy.files
            log_to_archive(archive, "backup", f"backed up to {copy.destination}", path=str(copy.destination),
                           files=copy.files)
        say(f"{archive.name}: " + ("done" if copy.ok else copy.note))
    _write_json(config_path(), {**config, "files": last, "last": datetime.now().isoformat(timespec="seconds")})
    return result
