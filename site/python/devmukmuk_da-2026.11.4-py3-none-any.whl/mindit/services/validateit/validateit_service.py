# src/mindit/services/validateit/validateit_service.py

from __future__ import annotations

import os
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from mindit.core.long_paths import TOO_LONG, too_long
from mindit.services.dates.user_dates import read_user_date
from mindit.services.validateit.validateit_models import (
    RepairAction,
    RepairActionType,
    ValidationMode,
    ValidationProblem,
    ValidationProblemCode,
    ValidationSeverity,
    ValidationState,
)
from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider
from mindit.services.validateit.validateit_repair_providers import (
    RepairProviderRegistry,
)
from mindit.services.validateit.validateit_sidecars import write_validation_block
from mindit.services.validateit.capture_date import describe as describe_capture_date
from mindit.services.validateit.capture_date import name_and_exif_taken
from mindit.services.validateit.quarantine_hash_service import (
    compute_sha256,
    ensure_file_hash,
    record_file_hash,
    stored_or_computed_sha256,
)
from mindit.services.sidecar import SidecarService
from mindit.models.quarantine_state import (
    DUPLICATE_STATUS_DUPLICATE,
    DUPLICATE_STATUS_PRIMARY,
    DUPLICATE_STATUS_UNIQUE,
)
from mindit.core.progress import NullProgressReporter, ProgressReporter
from mindit.services.contactsheet.contact_sheet import (
    SHEET_NAME,
    SheetResult,
    folders_with_sheets,
    is_sheet,
    refresh_sheets,
)

from mindit.services.validateit.validateit_file_types import (
    PHOTO_FOLDER_NAMES,
    MediaClassifier,
    MediaKind,
    is_in_named_folder,
    companions,
)


def _companion_label(path: Path) -> str:
    """Return what kind of companion file this is, for repair descriptions."""
    suffix = path.suffix.lower()
    return "Live Photo video" if suffix in (".mov", ".mp4") else "Voice note" if suffix == ".wav" else "Raw file"


IGNORED_FILE_NAMES = {
    "sync.ffs_db",
    "desktop.ini",
    "thumbs.db",
    ".ds_store",
}

# ValidateIt's own holding area for cleaned-up files; never validated or re-quarantined.
QUARANTINE_FOLDER_NAME = ".validateit-quarantine"

IGNORED_EXTENSIONS = {
    ".tmp",
    ".bak",
}


class ValidateItService:
    def __init__(
        self,
        repair_provider_registry: RepairProviderRegistry | None = None,
        media_classifier: MediaClassifier | None = None,
        contact_sheets: bool = True,
    ) -> None:
        self.repair_provider_registry = repair_provider_registry or RepairProviderRegistry()
        self.media_classifier = media_classifier or MediaClassifier()
        # Remake any contact sheet under the folder whose photos changed (they're never created here).
        self.contact_sheets = contact_sheets
        self.last_contact_sheets: SheetResult | None = None
        self._media_kinds: dict[Path, MediaKind | None] = {}
        self._file_hashes: dict[Path, str] = {}
        self._archive_years: tuple[int, int] | None | bool = False   # False = not read yet
        self._hash_skipped = 0

    def validate_folder(
        self,
        target_folder: Path,
        mode: ValidationMode,
        recursive: bool = True,
        progress: ProgressReporter | None = None,
        only: set[Path] | None = None,
    ) -> ValidationState:
        """Check every file under target_folder (with only: just those files and their sidecars) and plan repairs."""
        checked_at = datetime.now().isoformat(timespec="seconds")
        progress_reporter = progress or NullProgressReporter()

        state = ValidationState(
            target_folder=str(target_folder),
            checked_at=checked_at,
            mode=mode,
        )

        if not target_folder.exists() or not target_folder.is_dir():
            self._add_problem(
                state,
                code=ValidationProblemCode.EMPTY_FOLDER_REVIEW_REQUIRED,
                severity=ValidationSeverity.ERROR,
                message="Target folder does not exist or is not a directory.",
                file_path=target_folder,
                repairable=False,
            )
            return state

        paths = self._iter_files(target_folder, recursive=recursive)
        if only is not None:                     # `da run --template`: only the documents a template matched
            wanted = {os.path.normcase(str(Path(p).resolve())) for p in only}
            paths = [p for p in paths if os.path.normcase(str(p.resolve())).removesuffix(".meta.json") in wanted]
        self._file_hashes = {}
        self._hash_skipped = 0
        self._media_kinds = {}

        progress_reporter.start(
            label="Validating files",
            total=len(paths),
        )

        try:
            for path in paths:
                self._validate_path(path, state)

                progress_reporter.advance(
                    current_item=str(path),
                )

            self._detect_duplicates(state, progress=progress_reporter)

            progress_reporter.start(
                label="Validating folders",
                total=None,
            )
            self._validate_empty_folders(target_folder, state)

            self._build_repair_plan(state, progress=progress_reporter)

            if mode == ValidationMode.REPAIR:
                self._repair_safe_problems(state, progress=progress_reporter)

        finally:
            progress_reporter.finish()

        if self.contact_sheets:
            from mindit import __version__  # pylint: disable=import-outside-toplevel

            self.last_contact_sheets = refresh_sheets(folders_with_sheets(target_folder), create=False,
                                                      version=__version__)
        return state

    def apply_repairs(self, state: ValidationState, progress: ProgressReporter | None = None) -> ValidationState:
        """Carry out a preview's plan (the same as a repair run, without checking every file again).

        Use the service that made the preview, right after it: each move still checks its file is there and
        its target is free, so a file changed or moved in between is left alone.
        """
        progress_reporter = progress or NullProgressReporter()
        state.mode = ValidationMode.REPAIR
        try:
            self._repair_safe_problems(state, progress=progress_reporter)
        finally:
            progress_reporter.finish()
        return state

    def summarize(self, state: ValidationState) -> dict[str, int]:
        counts = Counter(problem.code.value for problem in state.problems)
        return dict(sorted(counts.items(), key=lambda item: item[0]))

    def _iter_files(self, target_folder: Path, recursive: bool) -> list[Path]:
        paths = target_folder.rglob("*") if recursive else target_folder.glob("*")

        return [
            path
            for path in paths
            if path.is_file() and not self._in_quarantine(path, target_folder) and not is_sheet(path)
        ]

    def _iter_folders_bottom_up(self, target_folder: Path) -> list[Path]:
        return sorted(
            [
                path
                for path in target_folder.rglob("*")
                if path.is_dir() and not self._in_quarantine(path, target_folder)
            ],
            key=lambda path: len(path.parts),
            reverse=True,
        )

    @staticmethod
    def _in_quarantine(path: Path, target_folder: Path) -> bool:
        """Return True for paths inside ValidateIt's own quarantine folder."""
        return QUARANTINE_FOLDER_NAME in path.relative_to(target_folder).parts

    def _is_truly_empty_folder(self, folder: Path) -> bool:
        return not self._has_content(folder) and not self._is_kept_folder(folder)

    @staticmethod
    def _has_content(folder: Path) -> bool:
        """Return True when folder holds anything besides a contact sheet (which shows nothing then)."""
        return any(not is_sheet(entry) for entry in folder.iterdir())

    @staticmethod
    def _rmdir(folder: Path) -> None:
        (folder / SHEET_NAME).unlink(missing_ok=True)
        folder.rmdir()

    def _is_kept_folder(self, folder: Path) -> bool:
        """Return True for an archive's configured intake folders, which stay even when empty."""
        return folder.resolve() in self.media_classifier.intake_folders

    def _validate_empty_folders(self, target_folder: Path, state: ValidationState) -> None:
        for folder in self._iter_folders_bottom_up(target_folder):
            if folder.resolve() == target_folder.resolve():
                continue

            if self._is_truly_empty_folder(folder):
                state.review_folders.append(str(folder))

                self._add_problem(
                    state,
                    code=ValidationProblemCode.EMPTY_FOLDER,
                    severity=ValidationSeverity.INFO,
                    message="Folder is truly empty and can be removed.",
                    file_path=folder,
                    repairable=True,
                )

                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.REMOVE_EMPTY_FOLDER,
                        problem_code=ValidationProblemCode.EMPTY_FOLDER,
                        description="Remove truly empty folder.",
                        source_path=str(folder),
                        target_path=None,
                        safe_auto=True,
                    )
                )

    def _remove_all_empty_folders(
        self,
        target_folder: Path,
        state: ValidationState,
    ) -> None:
        target_root = target_folder.resolve()

        while True:
            removed_any = False

            folders = self._iter_folders_bottom_up(target_root)

            for folder in folders:
                folder = folder.resolve()

                if folder == target_root:
                    continue

                if not folder.exists() or not folder.is_dir():
                    continue

                if self._has_content(folder) or self._is_kept_folder(folder):
                    continue

                self._rmdir(folder)
                state.removed_folders.append(str(folder))
                removed_any = True

                self._mark_remove_empty_folder_action_executed(folder, state)
                self._mark_empty_folder_problem_repaired(folder, state)

            if not removed_any:
                break

    def _mark_remove_empty_folder_action_executed(
        self,
        folder: Path,
        state: ValidationState,
    ) -> None:
        for action in state.repair_actions:
            if (
                action.action_type == RepairActionType.REMOVE_EMPTY_FOLDER
                and action.source_path
                and Path(action.source_path).resolve() == folder.resolve()
            ):
                action.executed = True
                return

        state.repair_actions.append(
            RepairAction(
                action_type=RepairActionType.REMOVE_EMPTY_FOLDER,
                problem_code=ValidationProblemCode.EMPTY_FOLDER_AFTER_REPAIR,
                description="Remove folder that became empty during repair.",
                source_path=str(folder),
                target_path=None,
                safe_auto=True,
                executed=True,
            )
        )

    def _mark_empty_folder_problem_repaired(
        self,
        folder: Path,
        state: ValidationState,
    ) -> None:
        for problem in state.problems:
            if (
                problem.code
                in {
                    ValidationProblemCode.EMPTY_FOLDER,
                    ValidationProblemCode.NESTED_EMPTY_FOLDERS,
                    ValidationProblemCode.EMPTY_FOLDER_AFTER_REPAIR,
                }
                and problem.file_path
                and Path(problem.file_path).resolve() == folder.resolve()
            ):
                problem.repaired = True
                return

        self._add_problem(
            state,
            code=ValidationProblemCode.EMPTY_FOLDER_AFTER_REPAIR,
            severity=ValidationSeverity.INFO,
            message="Folder became empty during repair and was removed.",
            file_path=folder,
            repairable=True,
        )

        state.problems[-1].repaired = True

    def _remove_folder_if_empty(
        self,
        folder: Path,
        target_folder: Path,
        state: ValidationState,
    ) -> bool:
        if folder.resolve() == target_folder.resolve():
            return False

        if not folder.exists() or not folder.is_dir():
            return False

        if self._has_content(folder) or self._is_kept_folder(folder):
            return False

        self._rmdir(folder)
        state.removed_folders.append(str(folder))
        return True

    def _execute_remove_empty_folder_actions(
        self,
        state: ValidationState,
    ) -> None:
        target_folder = Path(state.target_folder).resolve()

        actions = [
            action
            for action in state.repair_actions
            if action.action_type == RepairActionType.REMOVE_EMPTY_FOLDER
            and action.source_path
        ]

        actions = sorted(
            actions,
            key=lambda action: len(Path(action.source_path or "").parts),
            reverse=True,
        )

        for action in actions:
            folder = Path(action.source_path).resolve()

            removed = self._remove_folder_if_empty(
                folder=folder,
                target_folder=target_folder,
                state=state,
            )

            if removed:
                action.executed = True

                for problem in state.problems:
                    if (
                        problem.code
                        in {
                            ValidationProblemCode.EMPTY_FOLDER,
                            ValidationProblemCode.NESTED_EMPTY_FOLDERS,
                            ValidationProblemCode.EMPTY_FOLDER_AFTER_REPAIR,
                        }
                        and problem.file_path
                        and Path(problem.file_path).resolve() == folder
                    ):
                        problem.repaired = True

    def _is_ignored_file(self, path: Path) -> bool:
        return (
            path.name.lower() in IGNORED_FILE_NAMES
            or path.suffix.lower() in IGNORED_EXTENSIONS
        )

    def _validate_path(self, path: Path, state: ValidationState) -> None:
        if self._is_sidecar(path):
            self._validate_sidecar_file(path, state)
            return

        self._validate_regular_file(path, state)

    def _validate_regular_file(self, path: Path, state: ValidationState) -> None:
        if self._is_ignored_file(path):
            self._add_problem(
                state,
                code=ValidationProblemCode.IGNORED_FILE_PRESENT,
                severity=ValidationSeverity.INFO,
                message="Ignored/system file present. Candidate for cleanup.",
                file_path=path,
                repairable=True,
            )
            return

        self._ensure_sidecar(path, state)
        self._check_folder_type_mismatch(path, state)
        # Hash first so provider naming can reuse the fresh sidecar hash instead of re-hashing.
        self._check_hash(path, state)
        self._check_provider_expectations(path, state)

    def _check_provider_expectations(self, path: Path, state: ValidationState) -> None:
        provider = self._provider_for(path)

        if provider is None:
            return

        capture_date = getattr(provider, "capture_date", None)
        if capture_date is not None:
            capture = capture_date(path)
            if not capture.certain:
                # A guessed date would file the photo/document in the wrong place, so don't
                # plan a rename or move at all; a person has to confirm the date first.
                self._add_problem(
                    state,
                    code=ValidationProblemCode.CAPTURE_DATE_UNCERTAIN,
                    severity=ValidationSeverity.WARNING,
                    message=(
                        f"Capture date uncertain: {describe_capture_date(capture)}. "
                        "Not renamed or moved."
                    ),
                    file_path=path,
                    sidecar_path=self._sidecar_path_for_file(path),
                    repairable=False,
                )
                review = getattr(provider, "review_folder", None)
                if review is not None and review(path) is not None:
                    # A photo with no sure date in intake goes to photos\organized\review (expected_folder), named as it is.
                    self._add_problem(
                        state,
                        code=ValidationProblemCode.WRONG_FOLDER_LOCATION,
                        severity=ValidationSeverity.WARNING,
                        message="No sure date: to the review folder, to be dated.",
                        file_path=path,
                        sidecar_path=self._sidecar_path_for_file(path),
                        repairable=False,
                    )
                return

            years = self._years_range()
            if years and not years[0] <= capture.value.year <= years[1]:
                # This archive only takes years[0]-years[1]; the file belongs in another archive.
                self._add_problem(
                    state,
                    code=ValidationProblemCode.OUTSIDE_ARCHIVE_YEARS,
                    severity=ValidationSeverity.WARNING,
                    message=(
                        f"Taken {capture.value:%Y-%m-%d}, outside this archive's years "
                        f"{years[0]}-{years[1]}. Not renamed or moved."
                    ),
                    file_path=path,
                    sidecar_path=self._sidecar_path_for_file(path),
                    repairable=False,
                )
                return

        if getattr(provider, "media_kind", None) == MediaKind.PHOTO and not read_user_date(path):
            differs = name_and_exif_taken(path)          # (a date set by hand is meant to differ)
            if differs is not None:
                named, taken = differs
                # Review only: a camera clock or time zone can make EXIF the wrong one.
                self._add_problem(
                    state,
                    code=ValidationProblemCode.NAME_DATE_DIFFERS_FROM_EXIF,
                    severity=ValidationSeverity.WARNING,
                    message=(
                        f"Name says {named:%Y-%m-%d %H:%M:%S}, but EXIF date taken is "
                        f"{taken:%Y-%m-%d %H:%M:%S}."
                    ),
                    file_path=path,
                    sidecar_path=self._sidecar_path_for_file(path),
                    repairable=False,
                )

        expected_name = provider.expected_name(path)
        if expected_name and expected_name != path.name:
            self._add_problem(
                state,
                code=ValidationProblemCode.WRONG_NAME,
                severity=ValidationSeverity.WARNING,
                message=f"File name does not match {provider.name} expected name.",
                file_path=path,
                sidecar_path=self._sidecar_path_for_file(path),
                repairable=False,
            )

        expected_folder = provider.expected_folder(path)
        if expected_folder and expected_folder != path.parent:
            self._add_problem(
                state,
                code=ValidationProblemCode.WRONG_FOLDER_LOCATION,
                severity=ValidationSeverity.WARNING,
                message=f"File is not in the {provider.name} expected folder.",
                file_path=path,
                sidecar_path=self._sidecar_path_for_file(path),
                repairable=False,
            )

    def _years_range(self) -> tuple[int, int] | None:
        """Return the active archive's (first, last) capture year, or None when it takes any year."""
        if self._archive_years is False:
            from mindit.config.settings import get_archive_root, load_settings  # pylint: disable=import-outside-toplevel

            years = load_settings().archive.years if get_archive_root() else None
            self._archive_years = tuple(int(y) for y in years.split("-")) if years else None
        return self._archive_years  # type: ignore[return-value]

    def _check_hash(self, path: Path, state: ValidationState) -> None:
        sidecar_path = self._sidecar_path_for_file(path)

        # _ensure_sidecar already created any missing sidecar; this only triggers when
        # that failed (e.g. a permissions error), and a later pass picks the hash up.
        if not sidecar_path.exists():
            self._hash_skipped += 1
            return

        quarantine = SidecarService.get_block(path, "quarantine")
        stat = path.stat()
        existing_hash = quarantine.get("hash_sha256")

        if not existing_hash:
            code = ValidationProblemCode.HASH_MISSING
            severity = ValidationSeverity.INFO
            message = "File has no recorded hash; computed one."
        elif (
            quarantine.get("file_size") != stat.st_size
            or quarantine.get("file_modified_at") != stat.st_mtime
        ):
            code = ValidationProblemCode.HASH_STALE
            severity = ValidationSeverity.WARNING
            message = "File changed since its last recorded hash; recomputed."
        else:
            self._file_hashes[path] = existing_hash
            return

        # Computed and written back in both PREVIEW and REPAIR -- hashing is read-only
        # with respect to the file itself, so it doesn't need to wait for REPAIR like the
        # move/rename/delete-style repairs below do.
        hash_state = ensure_file_hash(str(path), str(sidecar_path))
        self._file_hashes[path] = hash_state.hash_sha256

        self._add_problem(
            state,
            code=code,
            severity=severity,
            message=message,
            file_path=path,
            sidecar_path=sidecar_path,
            repairable=True,
        )
        state.problems[-1].repaired = True

    def _detect_duplicates(
        self, state: ValidationState, progress: ProgressReporter | None = None
    ) -> None:
        """Group hashed files by sha256 and record unique/primary/duplicate status."""
        progress_reporter = progress or NullProgressReporter()
        progress_reporter.start(
            label="Detecting duplicates",
            total=len(self._file_hashes),
        )

        state.hash_summary = self._build_hash_summary(state)

        groups: dict[str, list[Path]] = defaultdict(list)
        for path, sha256 in self._file_hashes.items():
            groups[sha256].append(path)

        for sha256, paths in sorted(groups.items(), key=lambda item: str(min(item[1], key=str))):
            primary, *duplicates = sorted(paths, key=str)
            group_id = f"sha256:{sha256}" if duplicates else None

            self._write_duplicate_status(
                primary,
                {
                    "duplicate_status": (
                        DUPLICATE_STATUS_PRIMARY if duplicates else DUPLICATE_STATUS_UNIQUE
                    ),
                    "duplicate_group_id": group_id,
                    "duplicate_of": None,
                    "duplicate_paths": [str(path) for path in duplicates],
                },
            )
            progress_reporter.advance(current_item=str(primary))

            if not duplicates:
                continue

            state.duplicate_groups.append(
                {
                    "group_id": group_id,
                    "primary": str(primary),
                    "duplicates": [str(path) for path in duplicates],
                }
            )

            self._add_problem(
                state,
                code=ValidationProblemCode.DUPLICATE_PRIMARY,
                severity=ValidationSeverity.INFO,
                message=f"Primary copy of {len(duplicates)} duplicate file(s).",
                file_path=primary,
                sidecar_path=self._sidecar_path_for_file(primary),
            )

            for duplicate in duplicates:
                self._write_duplicate_status(
                    duplicate,
                    {
                        "duplicate_status": DUPLICATE_STATUS_DUPLICATE,
                        "duplicate_group_id": group_id,
                        "duplicate_of": str(primary),
                        "duplicate_paths": [],
                    },
                )
                self._add_problem(
                    state,
                    code=ValidationProblemCode.DUPLICATE_FILE,
                    severity=ValidationSeverity.WARNING,
                    message=f"Same content as {primary}. Review before removing.",
                    file_path=duplicate,
                    sidecar_path=self._sidecar_path_for_file(duplicate),
                )
                progress_reporter.advance(current_item=str(duplicate))

    def _build_hash_summary(self, state: ValidationState) -> dict[str, int]:
        """Count hashes computed, recomputed, reused, and skipped for lack of a sidecar."""
        counts = Counter(problem.code for problem in state.problems)
        computed = counts[ValidationProblemCode.HASH_MISSING] + sum(
            1
            for problem in state.problems
            if problem.code == ValidationProblemCode.FILE_MISSING_SIDECAR and problem.repaired
        )
        recomputed = counts[ValidationProblemCode.HASH_STALE]

        return {
            "hashed": len(self._file_hashes),
            "computed": computed,
            "recomputed": recomputed,
            "reused": len(self._file_hashes) - computed - recomputed,
            "skipped_no_sidecar": self._hash_skipped,
        }

    def _write_duplicate_status(self, path: Path, status: dict) -> None:
        """Write duplicate fields to the quarantine block only when they changed."""
        quarantine = SidecarService.get_block(path, "quarantine")

        if all(quarantine.get(key) == value for key, value in status.items()):
            return

        SidecarService.update_quarantine_block(path, status)

    def _rename_file_pair(self, source_path: Path, target_path: Path) -> Path | None:
        """Move a file and its sidecar together; None when an identical file is already there."""
        target_path.parent.mkdir(parents=True, exist_ok=True)

        if target_path.exists() and os.path.samefile(source_path, target_path):
            # Case-only rename (IMG.JPG -> img.jpg) on a case-insensitive drive.
            final_target = target_path
        elif target_path.exists() and self._same_content(source_path, target_path):
            return None
        else:
            final_target = self._unique_path(target_path)

        source_sidecar = self._sidecar_path_for_file(source_path)
        if too_long(final_target, self._sidecar_path_for_file(final_target)):
            raise OSError(TOO_LONG)
        source_path.rename(final_target)

        if source_sidecar.exists():
            # _unique_path only hands out names whose sidecar slot is free too.
            source_sidecar.rename(self._sidecar_path_for_file(final_target))

        return final_target

    def _report_move_failed(
        self, state: ValidationState, source_path: Path, target_path: Path, error: OSError
    ) -> RepairAction:
        """Record a move that Windows refused (a path too long, a file in use); the file stays where it is."""
        self._add_problem(
            state,
            code=ValidationProblemCode.MOVE_FAILED,
            severity=ValidationSeverity.WARNING,
            message=f"Couldn't move to {target_path}: {error}",
            file_path=source_path,
            sidecar_path=self._sidecar_path_for_file(source_path),
            repairable=False,
        )
        return RepairAction(
            action_type=RepairActionType.REVIEW_REQUIRED,
            problem_code=ValidationProblemCode.MOVE_FAILED,
            description=f"Not moved: {error}",
            source_path=str(source_path),
            target_path=str(target_path),
            safe_auto=False,
        )

    def _same_content(self, first: Path, second: Path) -> bool:
        """Return True when two files are byte-for-byte identical (by size, then sha256)."""
        if first.stat().st_size != second.stat().st_size:
            return False
        return stored_or_computed_sha256(first) == stored_or_computed_sha256(second)

    def _report_identical_target(
        self, state: ValidationState, source_path: Path, target_path: Path
    ) -> RepairAction:
        """Record a move/rename skipped because an identical copy already sits at the target."""
        self._add_problem(
            state,
            code=ValidationProblemCode.DUPLICATE_FILE,
            severity=ValidationSeverity.WARNING,
            message=f"Identical copy already exists at {target_path}; left in place for review.",
            file_path=source_path,
            sidecar_path=self._sidecar_path_for_file(source_path),
        )
        return RepairAction(
            action_type=RepairActionType.REVIEW_REQUIRED,
            problem_code=ValidationProblemCode.DUPLICATE_FILE,
            description="Identical file already at the target. Review before deleting this copy.",
            source_path=str(source_path),
            target_path=str(target_path),
            safe_auto=False,
        )

    def _execute_move_actions(self, state: ValidationState) -> None:
        review_actions: list[RepairAction] = []

        for action in state.repair_actions:
            if action.action_type != RepairActionType.MOVE_FILE:
                continue

            if not action.source_path or not action.target_path:
                continue

            source_path = Path(action.source_path)
            target_path = Path(action.target_path)

            if not source_path.exists():
                continue

            try:
                final_target = self._rename_file_pair(source_path, target_path)
            except OSError as error:                       # one file can't stop the rest
                review_actions.append(self._report_move_failed(state, source_path, target_path, error))
                continue

            if final_target is None:
                review_actions.append(self._report_identical_target(state, source_path, target_path))
                continue

            action.target_path = str(final_target)
            action.executed = True
            review_actions.extend(
                self._move_raw_companions(state, source_path, final_target)
            )

            for problem in state.problems:
                if (
                    problem.file_path == action.source_path
                    and problem.code
                    in {
                        ValidationProblemCode.WRONG_FOLDER_LOCATION,
                        ValidationProblemCode.WRONG_NAME,
                    }
                ):
                    problem.repaired = True

        state.repair_actions.extend(review_actions)

    def _execute_rename_actions(self, state: ValidationState) -> None:
        review_actions: list[RepairAction] = []

        for action in state.repair_actions:
            if action.action_type != RepairActionType.RENAME_FILE:
                continue

            if not action.source_path or not action.target_path:
                continue

            source_path = Path(action.source_path)
            target_path = Path(action.target_path)

            if not source_path.exists():
                continue

            try:
                final_target = self._rename_file_pair(source_path, target_path)
            except OSError as error:                       # one file can't stop the rest
                review_actions.append(self._report_move_failed(state, source_path, target_path, error))
                continue

            if final_target is None:
                review_actions.append(self._report_identical_target(state, source_path, target_path))
                continue

            action.target_path = str(final_target)
            action.executed = True
            review_actions.extend(
                self._move_raw_companions(state, source_path, final_target)
            )

            for problem in state.problems:
                if (
                    problem.code == ValidationProblemCode.WRONG_NAME
                    and problem.file_path == action.source_path
                ):
                    problem.repaired = True

        state.repair_actions.extend(review_actions)

    def _validate_sidecar_file(self, sidecar_path: Path, state: ValidationState) -> None:
        file_path = self._file_path_for_sidecar(sidecar_path)

        if not file_path.exists():
            self._add_problem(
                state,
                code=ValidationProblemCode.SIDECAR_MISSING_FILE,
                severity=ValidationSeverity.WARNING,
                message="Sidecar exists but paired file is missing.",
                file_path=file_path,
                sidecar_path=sidecar_path,
                repairable=False,
            )

    def _ensure_sidecar(self, path: Path, state: ValidationState) -> None:
        """Create a missing sidecar (in any mode) with the file's hash, computed once."""
        sidecar_path = self._sidecar_path_for_file(path)

        if sidecar_path.exists():
            return

        # Sidecar creation never touches the file itself, so like hashing it runs in
        # PREVIEW too: every file leaves validate with a sidecar holding its sha256, which
        # _check_hash, provider naming, and duplicate detection then reuse.
        try:
            sha256 = compute_sha256(path)
            provider = self._provider_for(path)

            if provider is not None:
                provider.create_or_refresh_sidecar(path, sha256=sha256)
            else:
                SidecarService.normalize_file(path)

            record_file_hash(path, sha256)
        except OSError as exc:
            self._add_problem(
                state,
                code=ValidationProblemCode.FILE_MISSING_SIDECAR,
                severity=ValidationSeverity.WARNING,
                message=f"File is missing its sidecar and one could not be created: {exc}",
                file_path=path,
                sidecar_path=sidecar_path,
                repairable=True,
            )
            return

        state.sidecars_created.append(str(sidecar_path))
        self._add_problem(
            state,
            code=ValidationProblemCode.FILE_MISSING_SIDECAR,
            severity=ValidationSeverity.INFO,
            message="File was missing its sidecar; created one and recorded its hash.",
            file_path=path,
            sidecar_path=sidecar_path,
            repairable=True,
        )
        state.problems[-1].repaired = True

    def _media_kind(self, path: Path) -> MediaKind | None:
        """Return the file's photo/document kind, decided once per run."""
        if path not in self._media_kinds:
            self._media_kinds[path] = self.media_classifier.kind(path)
        return self._media_kinds[path]

    def _provider_for(self, path: Path):
        """Return the repair provider matching the file's photo/document kind."""
        return self.repair_provider_registry.provider_for(path, kind=self._media_kind(path))

    def _check_folder_type_mismatch(self, path: Path, state: ValidationState) -> None:
        kind = self._media_kind(path)

        if kind == MediaKind.DOCUMENT and is_in_named_folder(path, PHOTO_FOLDER_NAMES):
            self._add_problem(
                state,
                code=ValidationProblemCode.DOCUMENT_IN_PHOTOS_FOLDER,
                severity=ValidationSeverity.WARNING,
                message="A document among the photos: it is filed with the documents (once it has a date).",
                file_path=path,
                sidecar_path=self._sidecar_path_for_file(path),
                repairable=False,
            )

        if kind == MediaKind.PHOTO and self.media_classifier.is_document_location(path):
            self._add_problem(
                state,
                code=ValidationProblemCode.PHOTO_IN_DOCUMENTS_FOLDER,
                severity=ValidationSeverity.WARNING,
                message="Photo appears to be in a documents folder.",
                file_path=path,
                sidecar_path=self._sidecar_path_for_file(path),
                repairable=False,
            )

    def _write_validation_sidecars(self, state: ValidationState) -> None:
        problems_by_sidecar: dict[Path, list[ValidationProblem]] = defaultdict(list)

        for problem in state.problems:
            # A folder has no sidecar: writing one would leave "<folder>.meta.json" beside it.
            if problem.code in (ValidationProblemCode.IGNORED_FILE_PRESENT, ValidationProblemCode.EMPTY_FOLDER):
                continue

            sidecar_path = self._problem_sidecar_path(problem)

            if sidecar_path is None:
                continue

            problems_by_sidecar[sidecar_path].append(problem)

        for sidecar_path, problems in problems_by_sidecar.items():
            write_problems = problems

            # FILE_MISSING_SIDECAR is resolved by the time a sidecar exists to write into.
            write_problems = [
                problem
                for problem in problems
                if problem.code != ValidationProblemCode.FILE_MISSING_SIDECAR
            ]

            write_result = write_validation_block(
                sidecar_path=sidecar_path,
                state=state,
                problems=write_problems,
            )

            # 🔑 track result
            if write_result == "created":
                state.sidecars_created.append(str(sidecar_path))

            elif write_result == "updated":
                state.sidecars_updated.append(str(sidecar_path))

            elif write_result == "skipped":
                state.sidecars_skipped.append(str(sidecar_path))

    def _problem_sidecar_path(self, problem: ValidationProblem) -> Path | None:
        if problem.sidecar_path:
            return Path(problem.sidecar_path)

        if problem.file_path:
            return self._sidecar_path_for_file(Path(problem.file_path))

        return None

    def _add_problem(
        self,
        state: ValidationState,
        code: ValidationProblemCode,
        severity: ValidationSeverity,
        message: str,
        file_path: Path | None = None,
        sidecar_path: Path | None = None,
        repairable: bool = False,
    ) -> None:
        state.problems.append(
            ValidationProblem(
                code=code,
                severity=severity,
                message=message,
                file_path=str(file_path) if file_path else None,
                sidecar_path=str(sidecar_path) if sidecar_path else None,
                repairable=repairable,
            )
        )

    def _is_sidecar(self, path: Path) -> bool:
        return path.name.endswith(".meta.json")

    def _sidecar_path_for_file(self, path: Path) -> Path:
        return Path(f"{path}.meta.json")

    def _file_path_for_sidecar(self, sidecar_path: Path) -> Path:
        return Path(str(sidecar_path).removesuffix(".meta.json"))

    def _repair_safe_problems(self, state: ValidationState, progress: ProgressReporter | None = None) -> None:
        progress_reporter = progress or NullProgressReporter()
        progress_reporter.start(
            label="Repairing safe problems",
            total=len(state.repair_actions),
        )

        for problem in state.problems:

            if problem.code != ValidationProblemCode.FILE_MISSING_SIDECAR or problem.repaired:
                continue

            progress_reporter.advance(
                current_item=problem.file_path,
            )

            if not problem.file_path:
                continue

            file_path = Path(problem.file_path)
            provider = self._provider_for(file_path)

            if provider and provider.create_or_refresh_sidecar(file_path):
                problem.repaired = True

                for action in state.repair_actions:
                    if (
                        action.action_type == RepairActionType.CREATE_SIDECAR
                        and action.source_path == problem.file_path
                    ):
                        action.executed = True

        self._write_validation_sidecars(state)

        for action in state.repair_actions:
            progress_reporter.advance(
                current_item=action.source_path,
            )
            
            if action.action_type == RepairActionType.CLEANUP_IGNORED_FILE:
                if not action.source_path or not action.target_path:
                    continue

                src = Path(action.source_path)
                dst = Path(action.target_path)

                if not src.exists():
                    continue

                dst.parent.mkdir(parents=True, exist_ok=True)
                dst = self._unique_path(dst)

                src.rename(dst)
                action.target_path = str(dst)
                action.executed = True

                src_sidecar = self._sidecar_path_for_file(src)

                if src_sidecar.exists():
                    src_sidecar.rename(self._sidecar_path_for_file(dst))

        for problem in state.problems:
            if problem.code == ValidationProblemCode.IGNORED_FILE_PRESENT:
                problem.repaired = True
        
        # the order matters - we want to move/rename files before removing empty folders, to maximize automatic repairs and minimize manual review
        self._execute_move_actions(state)
        self._execute_rename_actions(state)

        #self._validate_empty_folders(Path(state.target_folder), state)
        self._remove_all_empty_folders(
            target_folder=Path(state.target_folder),
            state=state,
        )

    def _build_quarantine_path(self, file_path: str, state: ValidationState) -> Path:
        original = Path(file_path)
        target_root = Path(state.target_folder).resolve()

        quarantine_root = target_root / QUARANTINE_FOLDER_NAME / "ignored-files"

        return quarantine_root / original.name

    def _unique_path(self, path: Path) -> Path:
        """Return path, or "name (N).ext" when it or its sidecar is already taken."""

        def taken(candidate: Path) -> bool:
            return candidate.exists() or self._sidecar_path_for_file(candidate).exists()

        if not taken(path):
            return path

        # The counter goes before the extension so the file keeps its type (never photo.jpg.2).
        counter = 2
        while True:
            candidate = path.with_name(f"{path.stem} ({counter}){path.suffix}")
            if not taken(candidate):
                return candidate
            counter += 1

    def _build_repair_plan(self, state: ValidationState, progress: ProgressReporter | None = None) -> None:
        progress_reporter = progress or NullProgressReporter()

        progress_reporter.start(
            label="Building repair plan",
            total=len(state.problems),
        )
        
        for problem in state.problems:
            progress_reporter.advance(
                current_item=problem.file_path or problem.sidecar_path,
            )
            
            if problem.code == ValidationProblemCode.FILE_MISSING_SIDECAR:
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.CREATE_SIDECAR,
                        problem_code=problem.code,
                        description="Create missing meta.json sidecar.",
                        source_path=problem.file_path,
                        target_path=problem.sidecar_path,
                        safe_auto=True,
                        executed=problem.repaired,
                    )
                )

                continue

            if problem.code == ValidationProblemCode.IGNORED_FILE_PRESENT:
                if problem.file_path is None:
                    continue

                quarantine_path = self._build_quarantine_path(problem.file_path, state)

                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.CLEANUP_IGNORED_FILE,
                        problem_code=problem.code,
                        description="Move ignored/system file to quarantine.",
                        source_path=problem.file_path,
                        target_path=str(quarantine_path),
                        safe_auto=True,
                    )
                )
                continue

            if problem.code in {
                ValidationProblemCode.HASH_MISSING,
                ValidationProblemCode.HASH_STALE,
            }:
                # Already resolved in _check_hash during the main validation pass.
                continue

            if problem.code == ValidationProblemCode.DUPLICATE_PRIMARY:
                continue

            if problem.code == ValidationProblemCode.CAPTURE_DATE_UNCERTAIN:
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.REVIEW_REQUIRED,
                        problem_code=problem.code,
                        description="Confirm the capture date (e.g. put it in the file name) before filing.",
                        source_path=problem.file_path,
                        target_path=None,
                        safe_auto=False,
                    )
                )
                continue

            if problem.code == ValidationProblemCode.OUTSIDE_ARCHIVE_YEARS:
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.REVIEW_REQUIRED,
                        problem_code=problem.code,
                        description="Taken outside this archive's years; move it to the archive for those years.",
                        source_path=problem.file_path,
                        target_path=None,
                        safe_auto=False,
                    )
                )
                continue

            if problem.code == ValidationProblemCode.NAME_DATE_DIFFERS_FROM_EXIF:
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.REVIEW_REQUIRED,
                        problem_code=problem.code,
                        description="Check which date is right; rename the file if its name is wrong.",
                        source_path=problem.file_path,
                        target_path=None,
                        safe_auto=False,
                    )
                )
                continue

            if problem.code == ValidationProblemCode.DUPLICATE_FILE:
                # Never auto-removed; duplicates always need a human decision.
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.REVIEW_REQUIRED,
                        problem_code=problem.code,
                        description="Duplicate file. Review before removing; ValidateIt never removes duplicates.",
                        source_path=problem.file_path,
                        target_path=None,
                        safe_auto=False,
                    )
                )
                continue

            if problem.code == ValidationProblemCode.SIDECAR_MISSING_FILE:
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.REVIEW_REQUIRED,
                        problem_code=problem.code,
                        description="Sidecar has no paired file. Review before delete, move, or quarantine.",
                        source_path=problem.sidecar_path,
                        target_path=None,
                        safe_auto=False,
                    )
                )
                continue

            if not problem.file_path:
                continue

            source = Path(problem.file_path)
            provider = self._provider_for(source)

            if provider is None:
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.REVIEW_REQUIRED,
                        problem_code=problem.code,
                        description="No repair provider available. Review manually.",
                        source_path=problem.file_path,
                        target_path=None,
                        safe_auto=False,
                    )
                )
                continue

            if problem.code == ValidationProblemCode.WRONG_FOLDER_LOCATION:
                expected_folder = provider.expected_folder(source)
                expected_name = provider.expected_name(source) or source.name

                if expected_folder and expected_folder != source.parent:
                    target_path = expected_folder / expected_name

                    state.repair_actions.append(
                        RepairAction(
                            action_type=RepairActionType.MOVE_FILE,
                            problem_code=problem.code,
                            description=f"Move/rename file using {provider.name} repair provider.",
                            source_path=str(source),
                            target_path=str(target_path),
                            safe_auto=False,
                        )
                    )
                    continue

            if problem.code == ValidationProblemCode.WRONG_NAME:
                expected_name = provider.expected_name(source)

                if expected_name and expected_name != source.name:
                    target_path = source.with_name(expected_name)

                    state.repair_actions.append(
                        RepairAction(
                            action_type=RepairActionType.RENAME_FILE,
                            problem_code=problem.code,
                            description=f"Rename file using {provider.name} repair provider.",
                            source_path=str(source),
                            target_path=str(target_path),
                            safe_auto=False,
                        )
                    )
                    continue

            state.repair_actions.append(
                RepairAction(
                    action_type=RepairActionType.REVIEW_REQUIRED,
                    problem_code=problem.code,
                    description=f"{provider.name} provider could not produce a repair target. Review manually.",
                    source_path=problem.file_path,
                    target_path=None,
                    safe_auto=False,
                )
            )

        self._plan_raw_companions(state)

    def _plan_raw_companions(self, state: ValidationState) -> None:
        """Plan each raw file (IMG_0574.CR2) to follow the photo of the same name; a move wins over a rename."""
        photo_actions: dict[str, RepairAction] = {}
        for action_type in (RepairActionType.MOVE_FILE, RepairActionType.RENAME_FILE):
            for action in state.repair_actions:
                if action.action_type == action_type and action.source_path and action.target_path:
                    photo_actions.setdefault(action.source_path, action)

        for source, action in photo_actions.items():
            for raw in companions(Path(source)):
                state.repair_actions.append(
                    RepairAction(
                        action_type=RepairActionType.MOVE_RAW_COMPANION,
                        problem_code=action.problem_code,
                        description=f"{_companion_label(raw)} follows {Path(source).name}.",
                        source_path=str(raw),
                        target_path=str(Path(action.target_path).with_suffix(raw.suffix.lower())),
                        safe_auto=False,
                    )
                )

    def _move_raw_companions(
        self, state: ValidationState, photo_source: Path, photo_target: Path
    ) -> list[RepairAction]:
        """Move the raw files named like photo_source next to photo_target, under its name."""
        planned = {
            action.source_path: action
            for action in state.repair_actions
            if action.action_type == RepairActionType.MOVE_RAW_COMPANION
        }
        extra: list[RepairAction] = []

        for raw in companions(photo_source):
            target = photo_target.with_suffix(raw.suffix.lower())
            action = planned.get(str(raw))
            if action is None:
                action = RepairAction(
                    action_type=RepairActionType.MOVE_RAW_COMPANION,
                    problem_code=ValidationProblemCode.WRONG_NAME,
                    description=f"{_companion_label(raw)} follows {photo_source.name}.",
                    source_path=str(raw),
                    target_path=str(target),
                    safe_auto=False,
                )
                extra.append(action)

            try:
                final_target = self._rename_file_pair(raw, target)
            except OSError as error:                       # one file can't stop the rest
                extra.append(self._report_move_failed(state, raw, target, error))
                continue
            if final_target is None:
                extra.append(self._report_identical_target(state, raw, target))
                continue

            action.target_path = str(final_target)
            action.executed = True
            self._record_raw_source(raw, final_target)

        return extra

    def _record_raw_source(self, raw_source: Path, raw_target: Path) -> None:
        """Record where a moved raw file came from, as the photo provider does for photos."""
        if not self._sidecar_path_for_file(raw_target).exists():
            return
        block = dict(SidecarService.load(raw_target).get("file") or {})
        if not block.get("source_path"):
            block["source_path"] = str(raw_source)
        block["current_path"] = str(raw_target)
        block["file_name"] = raw_target.name
        SidecarService.update_block(raw_target, "file", block)
