# src/mindit/services/validateit/validateit_file_types.py

"""Canonical photo/document extension sets and photo-vs-document classification."""

from __future__ import annotations

import os
import re
from enum import StrEnum
from pathlib import Path


PHOTO_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".heic",
    ".heif",
    ".tif",
    ".tiff",
    ".bmp",
    ".gif",
}

# Image formats a scanner produces; these are photos or scanned documents depending on context.
SCAN_IMAGE_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".tif",
    ".tiff",
    ".bmp",
}

DOCUMENT_ONLY_EXTENSIONS = {
    ".pdf",
    ".doc",
    ".docx",
    ".txt",
    ".md",
    ".xls",
    ".xlsx",
    ".csv",
}

DOCUMENT_EXTENSIONS = DOCUMENT_ONLY_EXTENSIONS | SCAN_IMAGE_EXTENSIONS

AMBIGUOUS_EXTENSIONS = PHOTO_EXTENSIONS & DOCUMENT_EXTENSIONS

# Camera raw formats. A raw file isn't filed on its own: it follows the photo with the same name,
# so IMG_0574.CR2 goes wherever IMG_0574.jpg goes and takes its new name (photo_..._1f40.cr2).
RAW_EXTENSIONS = {
    ".cr2",
    ".cr3",
    ".crw",
    ".nef",
    ".nrw",
    ".arw",
    ".srf",
    ".sr2",
    ".dng",
    ".raf",
    ".orf",
    ".rw2",
    ".pef",
    ".srw",
    ".x3f",
    ".3fr",
    ".iiq",
}


RAW_PARTNER_EXTENSIONS = {".jpg", ".jpeg", ".heic", ".heif", ".tif", ".tiff", ".png"}


def raw_partner(raw: Path) -> Path | None:
    """Return the photo beside a raw file that shares its name (IMG_0574.JPG for IMG_0574.CR2), or None."""
    for ext in sorted(RAW_PARTNER_EXTENSIONS):
        for variant in (ext.upper(), ext):
            candidate = raw.with_suffix(variant)
            if candidate.is_file():
                return candidate
    return None


def is_lone_raw(path: Path) -> bool:
    """Return whether a camera raw file has no photo of the same name beside it (so it is filed as a photo itself)."""
    return path.suffix.lower() in RAW_EXTENSIONS and raw_partner(path) is None


def raw_companions(photo: Path) -> list[Path]:
    """Return the raw files beside photo that share its name (IMG_0574.CR2 for IMG_0574.jpg)."""
    if photo.suffix.lower() in RAW_EXTENSIONS:
        return []

    found: list[Path] = []
    for ext in sorted(RAW_EXTENSIONS):
        for variant in (ext.upper(), ext):  # cameras write upper case; a case-insensitive drive finds either
            candidate = photo.with_suffix(variant)
            if candidate.is_file() and not any(os.path.samefile(candidate, f) for f in found):
                found.append(candidate)
    return found


PAIRED_MOTION_EXTENSIONS = {
    ".mov",
    ".mp4",
}

# Videos are filed like photos (by the date recorded inside them), except a Live Photo's video, which
# follows its photo (see motion_companions) or waits for `da pair-movies`.
VIDEO_EXTENSIONS = {".mov", ".mp4", ".m4v", ".3gp", ".3g2", ".avi", ".mpg", ".mpeg", ".mts", ".m2ts", ".wmv",
                    ".mkv", ".webm"}

# A Live Photo is a still (IMG_1234.HEIC or .JPG) plus a short video. The iPhone names them alike
# (IMG_1234.MOV); backup apps add markers: <id>-photo.HEIC + <id>-video-paired.MOV, an edited
# <id>-photo-full.jpg + <id>-video-paired-full.mov, or IMG_1234~video-paired.MOV.
LIVE_PHOTO_STILL_EXTENSIONS = {".heic", ".heif", ".jpg", ".jpeg"}
_STILL_MARK = re.compile(r"^(?P<base>.+?)[-~]photo(?P<full>-full)?$", re.IGNORECASE)
_VIDEO_MARK = re.compile(r"^(?P<base>.+?)[-~]video-paired(?P<full>-full)?$", re.IGNORECASE)
_PLAIN_VIDEO_MARK = re.compile(r"[-~]video$", re.IGNORECASE)   # <id>-video.MOV: an ordinary video


def live_photo_key(path: Path) -> tuple[str, str] | None:
    """Return (name, variant) shared by the two halves of a Live Photo, or None for anything else."""
    suffix, stem = path.suffix.lower(), path.stem
    if suffix in LIVE_PHOTO_STILL_EXTENSIONS:
        m = _STILL_MARK.match(stem)
    elif suffix in PAIRED_MOTION_EXTENSIONS:
        if _PLAIN_VIDEO_MARK.search(stem):
            return None
        m = _VIDEO_MARK.match(stem)
    else:
        return None
    if m:
        return m.group("base").lower(), "full" if m.group("full") else ""
    return stem.lower(), ""


def _video_stems(stem: str) -> list[str]:
    m = _STILL_MARK.match(stem)
    if m:
        sep = stem[len(m.group("base"))]
        return [f"{m.group('base')}{sep}video-paired{m.group('full') or ''}"]
    return [stem, f"{stem}~video-paired"]


def motion_companions(photo: Path) -> list[Path]:
    """Return the Live Photo video beside photo (IMG_1234.MOV for IMG_1234.HEIC, and backup-app names)."""
    if photo.suffix.lower() not in LIVE_PHOTO_STILL_EXTENSIONS:
        return []
    found: list[Path] = []
    for stem in _video_stems(photo.stem):
        for ext in sorted(PAIRED_MOTION_EXTENSIONS):
            for variant in (ext.upper(), ext):
                candidate = photo.with_name(stem + variant)
                if candidate.is_file() and not any(os.path.samefile(candidate, f) for f in found):
                    found.append(candidate)
    return found


def still_for_video(video: Path) -> Path | None:
    """Return the Live Photo still beside a video (IMG_1234.HEIC for IMG_1234.MOV, and backup-app names), or None."""
    key = live_photo_key(video)
    if key is None:
        return None
    base, variant = key
    full = "-full" if variant else ""
    stems = [f"{base}-photo{full}", f"{base}~photo{full}"] + ([base] if not variant else [])
    for stem in stems:
        for ext in sorted(LIVE_PHOTO_STILL_EXTENSIONS):
            for spelled in (ext, ext.upper()):
                candidate = video.with_name(stem + spelled)
                if candidate.is_file():
                    return candidate
    return None


def is_live_photo_part(video: Path) -> bool:
    """Return True for the video half of a Live Photo: its still is beside it, or the video says so itself."""
    if video.suffix.lower() not in PAIRED_MOTION_EXTENSIONS:
        return False
    if still_for_video(video) is not None:
        return True
    from mindit.services.video.video_info import is_live_photo_video, read_video_info  # pylint: disable=import-outside-toplevel

    return is_live_photo_video(read_video_info(video))


# A voice note some cameras record with a photo (Samsung's elder 010.wav for elder 010.jpg): it follows the photo.
VOICE_NOTE_EXTENSIONS = {".wav"}


def voice_companions(photo: Path) -> list[Path]:
    """Return the voice notes beside photo that share its name (IMG_0010.WAV for IMG_0010.JPG)."""
    if photo.suffix.lower() in VOICE_NOTE_EXTENSIONS | RAW_EXTENSIONS | VIDEO_EXTENSIONS:
        return []
    found: list[Path] = []
    for ext in sorted(VOICE_NOTE_EXTENSIONS):
        for variant in (ext.upper(), ext):
            candidate = photo.with_suffix(variant)
            if candidate.is_file() and not any(os.path.samefile(candidate, f) for f in found):
                found.append(candidate)
    return found


def companions(photo: Path) -> list[Path]:
    """Return the files that travel with photo: its camera raw files, its Live Photo video and its voice note."""
    return raw_companions(photo) + motion_companions(photo) + voice_companions(photo)

DOCUMENT_FOLDER_NAMES = {"documents"}
PHOTO_FOLDER_NAMES = {"photos"}


class MediaKind(StrEnum):
    PHOTO = "photo"
    DOCUMENT = "document"
    VIDEO = "video"


_MODULE_KINDS = {
    "photoit": MediaKind.PHOTO,
    "scanit": MediaKind.DOCUMENT,
}


def is_in_named_folder(path: Path, names: set[str]) -> bool:
    """Return True when any parent folder of path has one of the given names."""
    return any(part.lower() in names for part in path.parent.parts)


class MediaClassifier:
    """Decide whether a file is a photo or a document, resolving ambiguous image formats."""

    def __init__(
        self,
        force_kind: MediaKind | None = None,
        document_roots: list[Path] | None = None,
        intake_folders: dict[Path, MediaKind] | None = None,
        default_kind: MediaKind | None = None,
    ) -> None:
        self.force_kind = force_kind
        self.default_kind = default_kind      # outside the intake folders: this, ignoring sidecar and location
        self._document_roots = document_roots
        self._intake_folders = intake_folders

    def kind(self, path: Path) -> MediaKind | None:
        """Return the file's media kind, or None for files that are neither."""
        suffix = path.suffix.lower()

        if suffix in VIDEO_EXTENSIONS:                 # a Live Photo's video goes with its photo, not alone
            return None if is_live_photo_part(path) else MediaKind.VIDEO
        if suffix in RAW_EXTENSIONS:                   # a raw with its JPG follows it; a raw on its own is a photo
            return MediaKind.PHOTO if raw_partner(path) is None else None
        if suffix not in PHOTO_EXTENSIONS and suffix not in DOCUMENT_EXTENSIONS:
            return None
        if suffix not in DOCUMENT_EXTENSIONS:
            return MediaKind.PHOTO
        if suffix not in PHOTO_EXTENSIONS:
            return MediaKind.DOCUMENT

        # Ambiguous image format: explicit override, then the intake folder it was put in,
        # then the sidecar's recorded module, then location, then photo (the historical default).
        if self.force_kind is not None:
            return self.force_kind

        intake_kind = self.intake_kind(path)
        if intake_kind is not None:
            return intake_kind
        if self.default_kind is not None:
            return self.default_kind

        recorded = self._sidecar_kind(path)
        if recorded is not None:
            return recorded

        if self.is_document_location(path):
            return MediaKind.DOCUMENT

        return MediaKind.PHOTO

    def is_document_location(self, path: Path) -> bool:
        """Return True when path sits in a documents folder or a configured documents root."""
        if is_in_named_folder(path, DOCUMENT_FOLDER_NAMES):
            return True
        if self.intake_kind(path) == MediaKind.DOCUMENT:
            return True

        resolved = path.resolve()
        return any(resolved.is_relative_to(root) for root in self.document_roots)

    def intake_kind(self, path: Path) -> MediaKind | None:
        """Return the kind configured for the intake folder path is in (intake/scans: document), or None."""
        resolved = path.resolve()
        for folder, kind in self.intake_folders.items():
            if resolved.is_relative_to(folder):
                return kind
        return None

    @property
    def intake_folders(self) -> dict[Path, MediaKind]:
        """Return configured intake folders and their kinds, loading settings once."""
        if self._intake_folders is None:
            self._intake_folders = _configured_intake_folders()
        return self._intake_folders

    @property
    def document_roots(self) -> list[Path]:
        """Return configured document roots, loading settings once."""
        if self._document_roots is None:
            self._document_roots = _configured_document_roots()
        return self._document_roots

    @staticmethod
    def _sidecar_kind(path: Path) -> MediaKind | None:
        from mindit.services.sidecar import SidecarService

        if not SidecarService.sidecar_path_for(path).exists():
            return None

        classification = SidecarService.get_block(path, "classification")
        return _MODULE_KINDS.get(str(classification.get("module") or "").lower())


def _configured_document_roots() -> list[Path]:
    """Return the configured documents root, or nothing when settings can't be loaded."""
    try:
        from mindit.config.settings import get_documents_path

        return [get_documents_path().resolve()]
    except Exception:  # pylint: disable=broad-except
        return []


def _configured_intake_folders() -> dict[Path, MediaKind]:
    """Return the configured intake folders, or nothing when settings can't be loaded."""
    try:
        from mindit.config.settings import get_intake_folders

        # scanphoto: scanned prints are photos (only their dates are read differently: services/scans)
        return {folder: MediaKind.PHOTO if kind == "scanphoto" else MediaKind(kind)
                for folder, kind in get_intake_folders().items()}
    except Exception:  # pylint: disable=broad-except
        return {}
