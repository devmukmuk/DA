﻿# src/mindit/services/scans/cameras.py

"""cameras.json: every camera and scanner an archive has seen, and what the family knows about each.

    {"schema": 1, "cameras": [
      {"name": "Gcmc RODFS70", "type": "scanner", "owner": "jane", "date": "scanned", "years": "2022-2023",
       "make": "GCMC", "model": "RODFS70", "serial": null, "found": 3769, "first": "2022-07-28", "last": "2022-07-28"}]}

type: camera / phone / film / scanner. date: exif (trust its clock), scanned (its date is when it scanned), shift +1y
(its clock was off by that much), none. years: when it was used. `da cameras --detect` adds new ones and keeps found /
first / last / make / model / serial current; type, owner, date, years and note are the family's and never changed.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

SCHEMA = 1
TYPES = ("camera", "phone", "film", "scanner")
DATE_RULES = ("exif", "scanned", "none")             # and "shift +1y" / "shift -2h"
FAMILY_FIELDS = ("type", "owner", "date", "years", "note")
FOUND_FIELDS = ("make", "model", "serial", "found", "first", "last")
# A model that names a scanner: a film or flatbed scanner, an all-in-one printer's scanner.
_LOOKS_LIKE_A_SCANNER = re.compile(r"scan|rodfs|\bpsc ?\d|\bpstc|\bphotosmart|perfection|officejet|deskjet|"
                                   r"\bmfc-|\bdcp-|pixma", re.IGNORECASE)
_SHIFT = re.compile(r"^shift\s+([+-]\s*\d+\s*[a-z]+)$", re.IGNORECASE)
_YEARS = re.compile(r"^\s*(\d{4})\s*(?:-\s*(\d{4}))?\s*$")


class CamerasError(ValueError):
    """A cameras.json DA can't use, or a value it can't take."""


def _key(name: str) -> str:
    return re.sub(r"\s+", " ", str(name or "").strip().lower())


def name_of(info: dict[str, Any] | None) -> str | None:
    """Return the camera's name as cameras.json lists it ('Nikon D70', 'Gcmc RODFS70') from a sidecar camera block."""
    from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel

    return camera_name(info or {})


def looks_like_a_scanner(info: dict[str, Any] | None) -> bool:
    """Return whether a camera block's make and model name a scanner."""
    text = f"{(info or {}).get('make') or ''} {(info or {}).get('model') or ''}"
    return bool(text.strip()) and _LOOKS_LIKE_A_SCANNER.search(text) is not None


def parse_years(text: str | None) -> tuple[int, int] | None:
    """Return (first, last) from '1985-1986' or '1985', or None for ''."""
    if not text or not str(text).strip():
        return None
    m = _YEARS.match(str(text))
    if not m:
        raise CamerasError(f"{text!r}: write the years as 1985-1986 or 1985.")
    first, last = int(m.group(1)), int(m.group(2) or m.group(1))
    if first > last:
        raise CamerasError(f"{text!r}: the first year comes first.")
    return first, last


def check_rule(rule: str) -> str:
    """Return the date rule as kept, or raise CamerasError."""
    rule = " ".join(str(rule or "").split()).lower()
    if rule in DATE_RULES:
        return rule
    m = _SHIFT.match(rule)
    if m:
        from mindit.services.dates.user_dates import DateError, parse_shift  # pylint: disable=import-outside-toplevel

        try:
            return f"shift {parse_shift(m.group(1).replace(' ', '')).text}"
        except DateError as error:
            raise CamerasError(str(error)) from error
    raise CamerasError(f"{rule!r}: the date rule is exif, scanned, none or shift +1y.")


@dataclass
class Cameras:
    """The cameras of one cameras.json, by name."""

    path: Path
    rows: list[dict[str, Any]] = field(default_factory=list)

    def find(self, name: str | None) -> dict[str, Any] | None:
        """Return the row named name (any case and spacing), or None."""
        key = _key(name or "")
        return next((r for r in self.rows if _key(r.get("name", "")) == key), None) if key else None

    def of(self, info: dict[str, Any] | None) -> dict[str, Any] | None:
        """Return the row for a sidecar camera block: its body (name #serial) first, then its model."""
        name = name_of(info)
        if not name:
            return None
        serial = (info or {}).get("body_serial")
        return (self.find(f"{name} #{serial}") if serial else None) or self.find(name)

    def kind(self, info: dict[str, Any] | None) -> str:
        """Return the camera's type (a model that names a scanner is one until it's listed otherwise)."""
        row = self.of(info)
        if row and row.get("type"):
            return str(row["type"])
        return "scanner" if looks_like_a_scanner(info) else "camera"

    def rule(self, info: dict[str, Any] | None) -> str:
        """Return how to read this camera's dates: exif, scanned, none or 'shift +1y'."""
        row = self.of(info)
        if row and row.get("date"):
            return str(row["date"])
        return "scanned" if self.kind(info) == "scanner" else "exif"

    def owners(self) -> dict[str, str]:
        """Return name -> owner for the cameras that have one (as da-archive.yaml's cameras: list)."""
        return {r["name"]: r["owner"] for r in self.rows if r.get("name") and r.get("owner")}

    def set(self, name: str, **values: Any) -> dict[str, Any]:
        """Change (or add) a camera's family fields; return its row."""
        row = self.find(name)
        if row is None:
            row = {"name": " ".join(name.split())}
            self.rows.append(row)
        for key, value in values.items():
            if value is None:
                continue
            if key not in FAMILY_FIELDS:
                raise CamerasError(f"{key} isn't something to set on a camera ({', '.join(FAMILY_FIELDS)}).")
            value = str(value).strip()
            if key == "type" and value and value not in TYPES:
                raise CamerasError(f"{value!r}: the type is {', '.join(TYPES)}.")
            if key == "date" and value:
                value = check_rule(value)
            if key == "years" and value:
                first, last = parse_years(value)  # type: ignore[misc]
                value = f"{first}-{last}" if first != last else str(first)
            if value:
                row[key] = value
            else:
                row.pop(key, None)
        return row

    def save(self) -> Path:
        """Write the file (.tmp then replace), sorted: the most photos first, then by name."""
        self.rows.sort(key=lambda r: (-int(r.get("found") or 0), _key(r.get("name", ""))))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps({"schema": SCHEMA, "cameras": self.rows}, indent=2, ensure_ascii=False) + "\n",
                       encoding="utf-8")
        os.replace(tmp, self.path)
        _CACHE.pop(str(self.path), None)
        return self.path


def read(path: Path) -> Cameras:
    """Return the cameras in path (none when it isn't there); a file DA can't read raises CamerasError."""
    path = Path(path)
    if not path.exists():
        return Cameras(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as error:
        raise CamerasError(f"{path} can't be read ({error}). Fix it, or rename it and run da cameras --detect.") from error
    rows = data.get("cameras") if isinstance(data, dict) else None
    if not isinstance(rows, list):
        raise CamerasError(f"{path} has no cameras list.")
    return Cameras(path, [r for r in rows if isinstance(r, dict) and r.get("name")])


_CACHE: dict[str, tuple[tuple[int, int], Cameras]] = {}


def current(path: Path | None = None) -> Cameras:
    """Return this archive's cameras (cached until the file changes); an unreadable file counts as empty."""
    if path is None:
        try:
            from mindit.config.settings import get_cameras_file  # pylint: disable=import-outside-toplevel

            path = get_cameras_file()
        except Exception:  # pylint: disable=broad-except
            return Cameras(Path("cameras.json"))
    try:
        stat = path.stat()
        stamp = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        return Cameras(path)
    cached = _CACHE.get(str(path))
    if cached and cached[0] == stamp:
        return cached[1]
    try:
        found = read(path)
    except CamerasError:
        found = Cameras(path)
    _CACHE[str(path)] = (stamp, found)
    return found


def owners(settings: Any | None = None) -> dict[str, str]:
    """Return every camera owner: da-archive.yaml's cameras: list, with cameras.json's owners over it."""
    try:
        from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

        old = dict((settings or load_settings()).cameras or {})
    except Exception:  # pylint: disable=broad-except
        old = {}
    return {**old, **current().owners()}


# --------------------------------------------------------------------------- detect

@dataclass
class Detected:
    """What `da cameras --detect` found."""

    added: list[str] = field(default_factory=list)
    seen: int = 0                       # pictures with a camera
    sidecars: int = 0


def _day(value: Any) -> str | None:
    m = re.match(r"(\d{4})[:-](\d{2})[:-](\d{2})", str(value or ""))
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m and m.group(1) != "0000" else None


def detect(cameras: Cameras, sidecars: Iterable[Path], *, old_owners: dict[str, str] | None = None,
           progress: Callable[[int], None] | None = None) -> Detected:
    """Count each camera in the sidecars (no photo opened); add new ones; keep found/first/last/make/model current."""
    result = Detected()
    counts: dict[str, dict[str, Any]] = {}
    for n, side in enumerate(sidecars, 1):
        try:
            data = json.loads(Path(side).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        result.sidecars += 1
        info = data.get("camera") if isinstance(data.get("camera"), dict) else None
        name = name_of(info)
        if not name:
            continue
        result.seen += 1
        entry = counts.setdefault(name, {"make": info.get("make"), "model": info.get("model"), "found": 0,
                                         "first": None, "last": None, "serials": set()})
        entry["found"] += 1
        if info.get("body_serial"):
            entry["serials"].add(str(info["body_serial"]))
        day = _day(info.get("date_taken"))
        if day:
            entry["first"] = min(filter(None, (entry["first"], day)))
            entry["last"] = max(filter(None, (entry["last"], day)))
        if progress and n % 2000 == 0:
            progress(n)
    old_owners = {_key(k): v for k, v in (old_owners or {}).items() if v}
    for name, entry in counts.items():
        row = cameras.find(name)
        if row is None:
            row = {"name": name}
            cameras.rows.append(row)
            result.added.append(name)
            info = {"make": entry["make"], "model": entry["model"]}
            row["type"] = "scanner" if looks_like_a_scanner(info) else "camera"
            row["date"] = "scanned" if row["type"] == "scanner" else "exif"
            if old_owners.get(_key(name)):
                row["owner"] = old_owners[_key(name)]       # da-archive.yaml's cameras: list moves over
        row.update({"make": entry["make"], "model": entry["model"], "found": entry["found"],
                    "first": entry["first"], "last": entry["last"]})
        row["serial"] = ", ".join(sorted(entry["serials"])) or None
    return result


def index_sidecars(db_path: Path) -> list[Path]:
    """Return every sidecar the archive's index knows (filed, intake and review)."""
    if not Path(db_path).exists():
        return []
    with sqlite3.connect(db_path) as conn:
        try:
            rows = conn.execute("SELECT sidecar_path FROM files WHERE sidecar_path IS NOT NULL AND sidecar_path != '' "
                                "AND area IN ('photos', 'intake')").fetchall()
        except sqlite3.Error:
            return []
    return [Path(r[0]) for r in rows]
