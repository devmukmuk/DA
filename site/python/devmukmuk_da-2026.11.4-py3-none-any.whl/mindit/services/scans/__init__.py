"""Scanned prints and photos with no date: cameras.json, scan dates, the review folder (docs/da-docs/SCANS-DESIGN.md)."""
