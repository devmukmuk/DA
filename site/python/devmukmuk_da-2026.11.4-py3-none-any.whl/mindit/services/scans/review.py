﻿# src/mindit/services/scans/review.py

"""The review folder: photos with no sure date wait in photos\\organized\\review\\<the folders they came in through>.

Autorun moves an undated photo there from intake (`review_place`), named as it is; once someone dates it (da date
set, the dashboard's Dates page), the next Autorun or `da review --file` files it like any other. `waiting()` lists
what's there by folder, with each photo's guesses (`guesses()`): its name and folders, the camera it was taken with,
before its scan date.
"""

from __future__ import annotations

import json
import os
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

GUESS_BLOCK = "guesses"


def review_root(organized: Path, settings: Any | None = None) -> Path | None:
    """Return the archive's review folder (photos\\organized\\<review_folder>), or None when it has none."""
    try:
        from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

        name = (settings or load_settings()).review_folder
    except Exception:  # pylint: disable=broad-except
        return None
    return Path(organized) / name if name and str(name).strip() else None


def in_review(path: Path, organized: Path) -> bool:
    """Return whether path is in the review folder."""
    root = review_root(organized)
    return root is not None and Path(os.path.abspath(path)).is_relative_to(os.path.abspath(root))


def review_place(path: Path, organized: Path) -> Path | None:
    """Return the review folder an undated photo in intake moves to, or None (not in intake, or no review folder)."""
    root = review_root(organized)
    if root is None:
        return None
    try:
        from mindit.config.settings import get_intake_path  # pylint: disable=import-outside-toplevel

        intake = Path(os.path.abspath(get_intake_path()))
    except Exception:  # pylint: disable=broad-except
        return None
    here = Path(os.path.abspath(path))
    if not here.is_relative_to(intake):
        return None                                       # filed already, or in review: stays where it is
    parts = here.parent.relative_to(intake).parts[1:]     # under intake\<kind>
    return root.joinpath(*parts) if parts else root


# --------------------------------------------------------------------------- what's waiting

@dataclass
class Guess:
    """A date a photo may be from: its first and last day, how sure, and where it came from."""

    start: str                       # 1987-03-01
    end: str                         # 1987-03-31
    label: str                       # 1987-03, 1985-1986, before 2022-07
    source: str                      # folder: 06-15 Party, camera: Pentax K1000, scanned

    def as_dict(self) -> dict[str, str]:
        return {"start": self.start, "end": self.end, "label": self.label, "source": self.source}


@dataclass
class Waiting:
    """One review folder: its photos (index rows), most first."""

    folder: str                      # relative to the review folder
    photos: list[dict[str, Any]] = field(default_factory=list)
    dated: int = 0                   # dated already (filed by the next Autorun)


def _month_end(year: int, month: int) -> str:
    import calendar  # pylint: disable=import-outside-toplevel

    return f"{year:04d}-{month:02d}-{calendar.monthrange(year, month)[1]:02d}"


def guesses(path: Path, data: dict[str, Any] | None = None, now: datetime | None = None) -> list[Guess]:
    """Return what DA can guess about when a photo was taken, best first (never applied without a person)."""
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel
    from mindit.services.scans import scan_dates as sd  # pylint: disable=import-outside-toplevel

    now = now or datetime.now()
    data = sd.load(path) if data is None else data
    found: list[Guess] = []
    named = sd.date_in(Path(path).stem, now) or sd.date_in(
        Path(str((data.get("origin") or {}).get("file_name") or "")).stem, now)
    folder = sd.folder_date(sd.came_through(path, data), now, sd.skip_words())
    for hit, where in ((named, "name"), (folder, "folder")):
        if hit is None:
            continue
        y, m = hit.value.year, hit.value.month
        if hit.precision == "year":
            found.append(Guess(f"{y}-01-01", f"{y}-12-31", str(y), f"{where}: {hit.where}"))
        else:
            label = f"{y}-{m:02d}" + (f"-{hit.value.day:02d}" if hit.precision == "day" else "")
            found.append(Guess(f"{y}-{m:02d}-01", _month_end(y, m), label, f"{where}: {hit.where}"))
    taken_with = data.get("taken_with") if isinstance(data.get("taken_with"), dict) else {}
    row = cams.current().find(taken_with.get("camera")) if taken_with.get("camera") else None
    years = cams.parse_years(row.get("years")) if row and row.get("years") else None
    if years:
        found.append(Guess(f"{years[0]}-01-01", f"{years[1]}-12-31",
                           f"{years[0]}-{years[1]}" if years[0] != years[1] else str(years[0]),
                           f"camera: {row['name']}"))
    scanned = sd.scanned_at(path, data) if sd.why_a_scan(path, data) else None
    if scanned:
        found.append(Guess("1826-01-01", scanned[:10], f"before {scanned[:7]}", "scanned"))
    unique: list[Guess] = []
    for g in found:
        if all(g.label != u.label for u in unique):
            unique.append(g)
    return unique


def best_month(found: list[Guess]) -> str:
    """Return the month to start the page's picker at (the best guess's first month), or '' with no real guess
    (only 'before its scan'): the page keeps the month last chosen."""
    for g in found:
        if g.start[:4] != "1826":
            return g.start[:7]
    return ""


def waiting(db_path: Path, organized: Path) -> list[Waiting]:
    """Return the review folders and their photos (from the index), the biggest folder first."""
    root = review_root(organized)
    if root is None or not Path(db_path).exists():
        return []
    prefix = os.path.abspath(root).rstrip("\\/") + os.sep
    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT rowid AS id, path, sidecar_path, captured_at, tags, camera FROM files "
                            "WHERE area = 'photos' AND substr(path, 1, ?) = ? ORDER BY path",
                            (len(prefix), prefix)).fetchall()
    folders: dict[str, Waiting] = {}
    for row in rows:
        path = Path(row["path"])
        if not path.exists():
            continue
        rel = os.path.relpath(path.parent, root)
        bucket = folders.setdefault("" if rel == "." else rel, Waiting("" if rel == "." else rel))
        bucket.photos.append(dict(row))
    return sorted(folders.values(), key=lambda w: (-len(w.photos), w.folder.lower()))


def photo_facts(path: Path, data: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return what's known about a photo for the page: date and its source, people, place, camera, tags, guesses."""
    from mindit.services.scans import scan_dates as sd  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import all_tags  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.capture_date import resolve_capture_date  # pylint: disable=import-outside-toplevel

    data = sd.load(path) if data is None else data
    capture = resolve_capture_date(path)
    user = data.get("user") if isinstance(data.get("user"), dict) else {}
    faces = data.get("faces") if isinstance(data.get("faces"), dict) else {}
    people = sorted({str(f.get("name")) for f in faces.get("faces") or [] if isinstance(f, dict) and f.get("name")})
    picasa = data.get("picasa") if isinstance(data.get("picasa"), dict) else {}
    people += sorted({str(f.get("name")) for f in picasa.get("faces") or []
                      if isinstance(f, dict) and f.get("name") and str(f.get("name")) not in people})
    location = data.get("location") if isinstance(data.get("location"), dict) else {}
    camera = data.get("camera") if isinstance(data.get("camera"), dict) else {}
    taken_with = data.get("taken_with") if isinstance(data.get("taken_with"), dict) else {}
    found = guesses(path, data)
    shown = {"decade": 3, "year": 4, "month": 7}.get(str(user.get("date_precision") or ""), 10)
    return {
        "date": (user["captured_at"][:shown] + ("0s" if shown == 3 else "")) if user.get("captured_at") else "",
        "precision": user.get("date_precision") or "",
        "date_source": capture.source.value,
        "certain": capture.certain,
        "people": people,
        "place": location.get("place") or location.get("city") or location.get("title") or "",
        "camera": camera_name(camera) or "",
        "taken_with": taken_with.get("camera") or "",
        "tags": [t for t in all_tags(data) if not t.startswith(("folder:", "maker:", "camera:"))][:12],
        "guesses": [g.as_dict() for g in found],
        "start": best_month(found),
        "scan": sd.why_a_scan(path, data) or "",
    }


def keep_guesses(path: Path, found: list[Guess]) -> None:
    """Write a photo's guesses into its sidecar's `guesses` block (da review --guess)."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    SidecarService.update_block(path, GUESS_BLOCK, {"guesses": [g.as_dict() for g in found],
                                                    "made_at": datetime.now().isoformat(timespec="seconds")})


def dated(path: Path) -> bool:
    """Return whether a photo in review has a sure date now (so the next Autorun files it)."""
    from mindit.services.validateit.capture_date import resolve_capture_date  # pylint: disable=import-outside-toplevel

    return resolve_capture_date(path).certain


def read_json(path: Path) -> dict[str, Any]:
    """Return a JSON file's contents, or {}."""
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
