# src/mindit/services/dashboard/page.py

"""The dashboard's one HTML page (kept in Python so the exe and the wheel carry it without data files)."""

PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DA Dashboard</title>
<style>
:root {
  --bg: #f5f6f8; --card: #ffffff; --ink: #1d2330; --muted: #667085; --line: #e3e6eb;
  --accent: #2563eb; --accent-soft: #dbe7fe; --warn: #b45309; --warn-soft: #fef3c7; --ok: #15803d; --bad: #b91c1c;
}
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    --bg: #12151b; --card: #1b2029; --ink: #e6e9ef; --muted: #98a2b3; --line: #2b313c;
    --accent: #6ea0ff; --accent-soft: #1e2d4d; --warn: #f5b454; --warn-soft: #3a2c12; --ok: #4ade80; --bad: #f87171;
  }
}
* { box-sizing: border-box; }
[hidden] { display: none !important; }
body { margin: 0; background: var(--bg); color: var(--ink);
       font: 15px/1.45 "Segoe UI", system-ui, -apple-system, sans-serif; }
header { padding: 18px 16px 6px; max-width: 1180px; margin: 0 auto; display: flex; flex-wrap: wrap;
         gap: 6px 16px; align-items: baseline; }
header h1 { margin: 0; font-size: 22px; }
header .sub { color: var(--muted); font-size: 13px; overflow-wrap: anywhere; }
header .right { margin-left: auto; color: var(--muted); font-size: 13px; }
main { max-width: 1180px; margin: 0 auto; padding: 10px 16px 32px; display: grid; gap: 14px;
       grid-template-columns: repeat(auto-fit, minmax(min(330px, 100%), 1fr)); }
.card { background: var(--card); border: 1px solid var(--line); border-radius: 10px; padding: 14px 16px; min-width: 0; }
.card.wide { grid-column: 1 / -1; }
.card h2 { margin: 0 0 10px; font-size: 13px; text-transform: uppercase; letter-spacing: .06em; color: var(--muted); }
.big { font-size: 30px; font-weight: 600; line-height: 1.1; }
.note { color: var(--muted); font-size: 13px; }
.stats { display: flex; flex-wrap: wrap; gap: 8px 22px; margin-top: 6px; }
.stats div span { display: block; font-size: 12px; color: var(--muted); }
.stats div b { font-size: 18px; }
.bars { display: grid; gap: 5px; }
.bar { display: grid; grid-template-columns: minmax(80px, 40%) 1fr auto; gap: 8px; align-items: center; font-size: 13px; }
.bar .name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bar .track { height: 9px; background: var(--accent-soft); border-radius: 5px; overflow: hidden; }
.bar .fill { height: 100%; background: var(--accent); border-radius: 5px; }
.bar .n { font-variant-numeric: tabular-nums; color: var(--muted); }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
td, th { text-align: left; padding: 5px 6px; border-bottom: 1px solid var(--line); vertical-align: top;
         overflow-wrap: anywhere; }
th { color: var(--muted); font-weight: 600; }
td.n { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
td.when { white-space: nowrap; color: var(--muted); }
.working { background: var(--warn-soft); color: var(--warn); border-radius: 8px; padding: 8px 10px; margin-bottom: 6px; }
.status-ok { color: var(--ok); } .status-bad { color: var(--bad); }
button { font: inherit; font-size: 13px; padding: 5px 12px; border-radius: 6px; border: 1px solid var(--line);
         background: var(--card); color: var(--ink); cursor: pointer; }
button:hover { border-color: var(--accent); }
.scroll { max-height: 330px; overflow: auto; }
.error { color: var(--bad); }
@media (max-width: 520px) { main { grid-template-columns: minmax(0, 1fr); } .big { font-size: 26px; }
  td.when { white-space: normal; } }

.pics-bar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 10px; }
.pics-bar select { font: inherit; padding: 4px 6px; border: 1px solid var(--line); border-radius: 6px;
                   background: var(--card); color: var(--ink); max-width: 100%; }
.pics { display: grid; gap: 8px; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); }
.pic { position: relative; aspect-ratio: 4 / 3; border-radius: 6px; overflow: hidden; cursor: pointer;
       background: var(--accent-soft); border: 1px solid var(--line); padding: 0; color: var(--ink); }
.pic img { width: 100%; height: 100%; object-fit: cover; display: block; }
.pic .kind { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
             font-size: 13px; color: var(--muted); text-align: center; padding: 6px; overflow-wrap: anywhere; }
.pic .cap { position: absolute; left: 0; right: 0; bottom: 0; font-size: 11px; padding: 2px 5px;
            background: rgba(0, 0, 0, .55); color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.pic:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; }
#viewer { position: fixed; inset: 0; background: rgba(0, 0, 0, .86); display: none; z-index: 10;
          flex-direction: column; align-items: center; justify-content: center; padding: 12px; gap: 10px; }
#viewer.open { display: flex; }
#viewer .stage { flex: 1; min-height: 0; width: 100%; display: flex; align-items: center; justify-content: center; }
#viewer .stage img, #viewer .stage video { max-width: 100%; max-height: 100%; object-fit: contain; }
#viewer .stage iframe { width: min(1000px, 100%); height: 100%; border: 0; background: #fff; }
#viewer .tools { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; justify-content: center; color: #fff; }
#viewer .tools button { font: inherit; padding: 6px 12px; border-radius: 6px; border: 1px solid #ffffff55;
                        background: #ffffff1a; color: #fff; cursor: pointer; }
#viewer .tools button:disabled { opacity: .45; cursor: default; }
#viewer .said { color: #fff; font-size: 13px; min-height: 1.2em; }

.chips { display: flex; flex-wrap: wrap; gap: 6px; }
.chip { font-size: 13px; padding: 3px 10px; border-radius: 999px; border: 1px solid var(--line); background: var(--card);
        color: var(--ink); cursor: pointer; }
.chip b { font-weight: 600; } .chip span { color: var(--muted); }
.person { border-top: 1px solid var(--line); padding: 10px 0; }
.person h3 { margin: 0 0 6px; font-size: 15px; display: flex; flex-wrap: wrap; gap: 6px 12px; align-items: baseline; }
.person h3 .note { font-weight: 400; }
.faces { display: grid; gap: 6px; grid-template-columns: repeat(auto-fill, minmax(84px, 1fr)); margin: 6px 0 8px; }
.face { position: relative; aspect-ratio: 1; border-radius: 6px; overflow: hidden; border: 3px solid var(--ok);
        padding: 0; background: var(--accent-soft); cursor: pointer; }
.face img { width: 100%; height: 100%; object-fit: cover; display: block; }
.face .lvl { position: absolute; left: 0; right: 0; bottom: 0; font-size: 10px; background: rgba(0, 0, 0, .55);
             color: #fff; padding: 1px 3px; }
.face.off { border-color: var(--bad); opacity: .45; }
.face.off::after { content: "\2715"; position: absolute; top: 2px; right: 5px; color: var(--bad); font-weight: 700; }
.face:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; }
.acts { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.acts input { font: inherit; font-size: 13px; padding: 4px 8px; border: 1px solid var(--line); border-radius: 6px;
              background: var(--card); color: var(--ink); min-width: 0; width: min(240px, 100%); }
button.primary { background: var(--accent); border-color: var(--accent); color: #fff; }

.dgrid { --tile: 150px; display: grid; gap: 10px; grid-template-columns: repeat(auto-fill, minmax(var(--tile), 1fr));
         margin: 10px 0; }
.dtile { position: relative; padding: 0; border: 3px solid transparent; border-radius: 8px; background: var(--card);
         color: var(--ink); text-align: left; cursor: pointer; overflow: hidden; font-size: 12px; line-height: 1.3; }
.dtile .ph { aspect-ratio: 4 / 3; background: var(--accent-soft); display: block; width: 100%; }
.dtile .ph img { width: 100%; height: 100%; object-fit: contain; display: block; }
.dtile .facts { padding: 4px 6px 6px; display: grid; gap: 1px; }
.dtile .facts span { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dtile .facts .when { font-weight: 600; } .dtile .facts .dated { color: var(--ok); }
.dtile.sel { border-color: var(--accent); background: var(--accent-soft); }
.dtile.sel::after { content: "\2713"; position: absolute; top: 4px; left: 6px; background: var(--accent); color: #fff;
                    border-radius: 50%; width: 22px; height: 22px; text-align: center; font-weight: 700; line-height: 22px; }
.dtile:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; }
.picker { position: sticky; bottom: 0; background: var(--card); border-top: 1px solid var(--line); padding: 10px 0 4px;
          display: grid; gap: 8px; }
.picker .row { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
.picker .step { font-size: 18px; font-weight: 700; min-width: 48px; padding: 8px 10px; }
.picker .lbl { color: var(--muted); font-size: 13px; }
.picker .now { font-size: 26px; font-weight: 700; font-variant-numeric: tabular-nums; min-width: 130px; text-align: center;
               border-style: dashed; }
.picker .src { color: var(--muted); font-size: 13px; }
.picker .big { font-size: 16px; padding: 8px 18px; }
.editbox { border: 1px solid var(--line); border-radius: 8px; padding: 10px; display: grid; gap: 8px; margin-top: 6px; }
.editbox label { display: grid; gap: 3px; font-size: 13px; color: var(--muted); }
.editbox input, .editbox select { font: inherit; padding: 5px 8px; border: 1px solid var(--line); border-radius: 6px;
                                  background: var(--card); color: var(--ink); }
</style>
</head>
<body>
<header>
  <h1 id="name">DA</h1>
  <span class="sub" id="where"></span>
  <span class="right"><span id="updated">Loading...</span> &nbsp; <span id="offline" class="error"></span></span>
</header>
<main>
  <section class="card">
    <h2>Filed</h2>
    <div class="big" id="filed">-</div>
    <div class="stats" id="filed-stats"></div>
    <p class="note" id="index-note"></p>
  </section>
  <section class="card">
    <h2>Waiting in intake</h2>
    <div class="big" id="intake">-</div>
    <div class="bars" id="intake-bars" style="margin-top:10px"></div>
  </section>
  <section class="card">
    <h2>Needs review</h2>
    <div id="review"></div>
  </section>
  <section class="card">
    <h2>Happening now</h2>
    <div id="working"></div>
  </section>
  <section class="card">
    <h2>Latest runs</h2>
    <div class="scroll"><table id="runs"></table></div>
  </section>
  <section class="card">
    <h2>Activity</h2>
    <div class="scroll"><table id="activity"></table></div>
  </section>
  <section class="card wide">
    <h2>In the archive <button id="recount" style="float:right">Recount</button></h2>
    <div id="details-note" class="note"></div>
    <div style="display:grid;gap:18px;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr));margin-top:8px">
      <div><b>By year</b><div class="bars scroll" id="years" style="margin-top:6px"></div></div>
      <div><b>Cameras</b><div class="bars" id="cameras" style="margin-top:6px"></div></div>
      <div><b>Places</b><div class="bars" id="places" style="margin-top:6px"></div></div>
    </div>
  </section>
  <section class="card wide" id="people-card">
    <h2>People <button id="people-load" style="float:right">Show</button></h2>
    <div id="people-note" class="note">Faces DA found (da facial scan) and the names it suggests - nothing is named until
      you confirm it here. Click a face to untick it.</div>
    <div id="people" hidden>
      <div style="margin:10px 0 4px"><b>Everyone</b> <span class="note">(click a name to rename it)</span></div>
      <div class="chips" id="everyone"></div>
      <div style="margin:14px 0 0"><b>Waiting for you</b> <span class="note" id="waiting-note"></span></div>
      <div id="waiting"></div>
      <div style="margin:14px 0 0"><b>Who is this?</b> <span class="note" id="groups-note"></span></div>
      <div id="groups"></div>
      <datalist id="known-names"></datalist>
    </div>
    <div class="said note" id="people-said"></div>
  </section>
  <section class="card wide" id="dates-card">
    <h2>Dates <button id="dates-load" style="float:right">Show</button></h2>
    <div id="dates-note" class="note">Photos waiting for a date (the review folder). Pick one or more, choose the month
      with Older and Newer, then Set. The next Autorun files them.</div>
    <div id="dates" hidden>
      <div class="pics-bar">
        <label for="dates-folder" class="note">Folder</label>
        <select id="dates-folder"></select>
        <button id="dates-smaller" title="Smaller pictures">&#8722;</button>
        <button id="dates-bigger" title="Bigger pictures">+</button>
        <button id="dates-all" title="Select all (Ctrl+A)">Select all</button>
        <button id="dates-none">Select none</button>
        <button id="dates-file" title="File the dated ones now, as Autorun would">File dated photos</button>
        <span class="note" id="dates-undo-note"></span>
        <button id="dates-undo" hidden>Undo</button>
      </div>
      <div class="dgrid" id="dates-grid"></div>
      <div class="picker">
        <div class="row">
          <span class="lbl" id="dates-count">Nothing selected</span>
        </div>
        <div class="row">
          <button class="step" id="d-yy" title="A year older (Shift + left arrow)">&#8722;&#8722;</button>
          <button class="step" id="d-m" title="A month older (left arrow)">&#8722;</button>
          <span class="lbl">Older</span>
          <button class="now" id="d-now" title="Click to type the month">----</button>
          <span class="lbl">Newer</span>
          <button class="step" id="d-p" title="A month newer (right arrow)">+</button>
          <button class="step" id="d-pp" title="A year newer (Shift + right arrow)">++</button>
          <button class="primary big" id="d-set" title="Give the selected photos this month (Enter)">Set</button>
          <button class="big" id="d-edit" title="One photo: its date, camera, people, tags">Edit</button>
        </div>
        <div class="row"><span class="src" id="d-src"></span></div>
        <div class="row chips" id="d-guesses"></div>
      </div>
      <div class="editbox" id="d-editbox" hidden>
          <b id="d-edit-name"></b>
          <label>Date (1987-03-14, 1987-03, 1987, 1980s)<input id="e-date" autocomplete="off"></label>
          <label>Taken with (a camera in cameras.json)<select id="e-camera"></select></label>
          <label>People in it (commas between)<input id="e-people" autocomplete="off"></label>
          <label>Add tags (commas between)<input id="e-tags" autocomplete="off"></label>
          <div class="acts"><button class="primary" id="e-save">Save</button><button id="e-cancel">Cancel</button></div>
      </div>
    </div>
    <div class="said note" id="dates-said"></div>
  </section>
  <section class="card wide">
    <h2>Pictures</h2>
    <div class="pics-bar">
      <label for="pick-folder" class="note">Show</label>
      <select id="pick-folder"><option value="">Latest filed</option></select>
      <span class="note" id="pics-note"></span>
    </div>
    <div class="pics" id="pics"></div>
  </section>
</main>
<div id="viewer" role="dialog" aria-modal="true" aria-label="Picture">
  <div class="stage" id="stage"></div>
  <div class="tools">
    <span id="viewer-name"></span>
    <button id="v-prev" title="Previous (left arrow)">&#8592;</button>
    <button id="v-next" title="Next (right arrow)">&#8594;</button>
    <button id="v-desktop">Set as desktop</button>
    <button id="v-folder">Open its folder</button>
    <button id="v-share" title="Email it to a share list (da share)">Share</button>
    <button id="v-close" title="Close (Esc)">Close</button>
  </div>
  <div class="said" id="viewer-said"></div>
</div>
<script>
(function () {
  "use strict";
  var REFRESH_SECONDS = 10;
  function $(id) { return document.getElementById(id); }
  function fmt(n) { return (n || 0).toLocaleString(); }
  function el(tag, text, cls) {
    var e = document.createElement(tag);
    if (text !== undefined && text !== null) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
  function bars(node, rows, empty) {
    clear(node);
    if (!rows || !rows.length) { node.appendChild(el("div", empty || "Nothing yet.", "note")); return; }
    var top = Math.max.apply(null, rows.map(function (r) { return r[1]; })) || 1;
    rows.forEach(function (r) {
      var row = el("div", null, "bar"), track = el("div", null, "track"), fill = el("div", null, "fill");
      var name = el("span", r[0], "name"); name.title = r[0];
      fill.style.width = Math.max(2, Math.round(100 * r[1] / top)) + "%";
      track.appendChild(fill);
      row.appendChild(name); row.appendChild(track); row.appendChild(el("span", fmt(r[1]), "n"));
      node.appendChild(row);
    });
  }
  function table(node, head, rows) {
    clear(node);
    if (!rows.length) { var tr = el("tr"); tr.appendChild(el("td", "Nothing yet.", "note")); node.appendChild(tr); return; }
    var h = el("tr");
    head.forEach(function (t) { h.appendChild(el("th", t)); });
    node.appendChild(h);
    rows.forEach(function (cells) {
      var tr = el("tr");
      cells.forEach(function (c) { tr.appendChild(el("td", c[0], c[1])); });
      node.appendChild(tr);
    });
  }
  var KINDS = { photo: "photos", document: "documents", video: "videos", raw: "raw files", other: "other" };

  function show(s) {
    var a = s.archive, c = s.counts;
    document.title = "DA - " + a.name;
    $("name").textContent = "DA - " + a.name;
    $("where").textContent = a.folder + "   years: " + a.years + (a.version ? "   DA " + a.version : "");
    $("updated").textContent = "Updated " + s.updated.slice(11);

    var filed = c.filed || {}, total = 0;
    Object.keys(filed).forEach(function (k) { total += filed[k]; });
    $("filed").textContent = fmt(total) + " files";
    var stats = clear($("filed-stats"));
    ["photo", "document", "video", "raw", "other"].forEach(function (k) {
      if (!filed[k]) return;
      var d = el("div"); d.appendChild(el("span", KINDS[k])); d.appendChild(el("b", fmt(filed[k]))); stats.appendChild(d);
    });
    var size = el("div"); size.appendChild(el("span", "size")); size.appendChild(el("b", c.gigabytes + " GB"));
    stats.appendChild(size);
    $("index-note").textContent = c.error ? c.error : !c.indexed
      ? "Not indexed yet: choose 1 Process intake (or 5 Refresh index) in the menu."
      : "From the index, last refreshed " + (c.index_built || "?").replace("T", " ").slice(0, 16)
        + ". Menu 5 refreshes it.";

    $("intake").textContent = fmt(c.intake) + " files";
    bars($("intake-bars"), (c.intake_folders || []).slice(0, 12), c.indexed ? "Nothing waiting." : "Not indexed yet.");

    var rv = clear($("review"));
    if (!s.review.run) rv.appendChild(el("p", "No run yet.", "note"));
    else if (!s.review.rows.length) rv.appendChild(el("p", "Nothing left to review from the last run.", "note"));
    else {
      bars(rv, s.review.rows);
      rv.appendChild(el("p", "From the last run (" + (s.review.folder || "") + "). Menu 3 lists the files.", "note"));
    }

    var w = clear($("working"));
    if (!s.activity.working.length) w.appendChild(el("p", "Nothing running.", "note"));
    s.activity.working.forEach(function (j) {
      w.appendChild(el("div", j.command + " - started " + j.since + " (" + j.minutes + " min ago)", "working"));
    });

    table($("runs"), ["When", "What", ""], s.runs.map(function (r) {
      return [[r.when, "when"], [r.kind], [r.detail, "note"]];
    }));
    table($("activity"), ["When", "What"], s.activity.recent.map(function (e) {
      var cls = e.level === "ERROR" ? "status-bad" : (e.status === "ok" ? "" : "");
      return [[e.when, "when"], [e.message, cls]];
    }));

    var d = s.details, note = $("details-note");
    $("recount").disabled = !!s.counting;
    if (s.counting && !d) note.textContent = "Counting years, cameras and places (a minute on a very big archive) ...";
    else if (d && d.error) note.textContent = d.error;
    else if (d) {
      note.textContent = (s.counting ? "Recounting ... " : "Counted " + d.made_at + ". ") + d.places_sentence;
      bars($("years"), d.years || []);
      bars($("cameras"), d.cameras || [], "No camera details yet (da tag).");
      bars($("places"), d.places || [], "No places yet (da location lookup).");
    }
  }

  function refresh() {
    fetch("/api/status", { cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (s) { $("offline").textContent = ""; show(s); })
      .catch(function () { $("offline").textContent = "DA dashboard stopped (start it again with da dashboard)"; });
  }
  $("recount").addEventListener("click", function () {
    fetch("/api/recount", { cache: "no-store" }).then(refresh);
  });
  refresh();
  setInterval(refresh, REFRESH_SECONDS * 1000);

  // ----------------------------------------------------------------- pictures
  var TOKEN = "__DA_TOKEN__", shown = [], at = -1;
  function loadFolders() {
    fetch("/api/folders", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (rows) {
      var pick = $("pick-folder");
      rows.forEach(function (f) {
        var o = el("option", (f.area === "documents" ? "Documents " : "") + (f.folder || "(top)") + "  (" + fmt(f.count) + ")");
        o.value = f.area + "|" + f.folder;
        pick.appendChild(o);
      });
    });
  }
  function loadPictures() {
    var v = $("pick-folder").value, q = "";
    if (v) { var i = v.indexOf("|"); q = "?area=" + encodeURIComponent(v.slice(0, i)) + "&folder=" + encodeURIComponent(v.slice(i + 1)); }
    fetch("/api/pictures" + q, { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (rows) {
      shown = rows;
      var grid = clear($("pics"));
      $("pics-note").textContent = rows.length ? fmt(rows.length) + (v ? " in this folder" : " filed most recently") : "";
      if (!rows.length) { grid.appendChild(el("p", "Nothing filed yet.", "note")); return; }
      rows.forEach(function (p, n) {
        var b = el("button", null, "pic");
        b.title = p.name + (p.when ? "  " + p.when : "");
        b.appendChild(el("span", p.kind === "video" ? "\u25B6 video" : p.kind === "document" ? "document" : "", "kind"));
        if (p.kind !== "video") {
          var img = el("img"); img.loading = "lazy"; img.alt = p.name; img.src = "/thumb/" + p.id;
          img.onerror = function () { img.remove(); };
          b.appendChild(img);
        }
        b.appendChild(el("span", p.name, "cap"));
        b.addEventListener("click", function () { openAt(n); });
        grid.appendChild(b);
      });
    });
  }
  function openAt(n) {
    if (n < 0 || n >= shown.length) return;
    at = n;
    var p = shown[n], stage = clear($("stage")), src = "/file/" + p.id, lower = p.name.toLowerCase();
    if (p.kind === "video") { var v = el("video"); v.controls = true; v.autoplay = true; v.src = src; stage.appendChild(v); }
    else if (lower.slice(-4) === ".pdf") { var f = el("iframe"); f.src = src; f.title = p.name; stage.appendChild(f); }
    else if (/\.(docx?|xlsx?|pptx?|txt|rtf|csv)$/.test(lower)) { stage.appendChild(el("p", "No preview for " + p.name + ": use Open its folder.", "note")); }
    else { var i = el("img"); i.src = src; i.alt = p.name; stage.appendChild(i); }
    $("viewer-name").textContent = p.name + (p.when ? "  -  " + p.when : "") + (p.family ? "  -  " + p.family : "");
    $("v-desktop").disabled = p.kind !== "photo";
    $("v-share").disabled = p.kind !== "photo";
    $("viewer-said").textContent = "";
    $("viewer").classList.add("open");
    $("v-close").focus();
  }
  function closeViewer() { $("viewer").classList.remove("open"); clear($("stage")); at = -1; }
  function act(action, extra) {
    if (at < 0) return;
    $("viewer-said").textContent = "...";
    var ask = { token: TOKEN, action: action, id: shown[at].id };
    if (extra) Object.keys(extra).forEach(function (k) { ask[k] = extra[k]; });
    fetch("/api/action", { method: "POST", headers: { "Content-Type": "application/json" },
                           body: JSON.stringify(ask) })
      .then(function (r) { return r.json(); })
      .then(function (r) { $("viewer-said").textContent = r.message || (r.ok ? "Done." : "Didn't work."); })
      .catch(function () { $("viewer-said").textContent = "The dashboard didn't answer."; });
  }
  $("pick-folder").addEventListener("change", loadPictures);
  $("v-close").addEventListener("click", closeViewer);
  $("v-prev").addEventListener("click", function () { openAt(at - 1); });
  $("v-next").addEventListener("click", function () { openAt(at + 1); });
  $("v-desktop").addEventListener("click", function () { act("desktop"); });
  $("v-folder").addEventListener("click", function () { act("folder"); });
  $("v-share").addEventListener("click", function () {
    fetch("/api/share-lists", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (names) {
      if (!names.length) { $("viewer-said").textContent = "No share lists yet: add them to da-archive.yaml (share: lists:)."; return; }
      var pick = names.length === 1 ? names[0] : window.prompt("Send it to which list? " + names.join(", "), names[0]);
      if (!pick) return;
      if (names.length === 1 && !window.confirm("Email this photo to " + pick + "?")) return;
      act("share", { list: pick });
    });
  });
  $("viewer").addEventListener("click", function (e) { if (e.target.id === "viewer" || e.target.id === "stage") closeViewer(); });
  document.addEventListener("keydown", function (e) {
    if (at < 0) return;
    if (e.key === "Escape") closeViewer();
    else if (e.key === "ArrowLeft") openAt(at - 1);
    else if (e.key === "ArrowRight") openAt(at + 1);
  });
  loadFolders();
  loadPictures();

  // ----------------------------------------------------------------- people
  function facesGrid(ids, labels) {
    var grid = el("div", null, "faces");
    ids.forEach(function (id, n) {
      var b = el("button", null, "face");
      b.dataset.id = id;
      b.title = "Click to untick (not them)";
      var img = el("img"); img.loading = "lazy"; img.alt = "face"; img.src = "/face/" + id;
      b.appendChild(img);
      if (labels && labels[n]) b.appendChild(el("span", labels[n], "lvl"));
      b.addEventListener("click", function () { b.classList.toggle("off"); });
      grid.appendChild(b);
    });
    return grid;
  }
  function picked(grid, on) {
    return Array.prototype.filter.call(grid.querySelectorAll(".face"), function (b) {
      return b.classList.contains("off") !== on;
    }).map(function (b) { return Number(b.dataset.id); });
  }
  function peopleAsk(body) {
    body.token = TOKEN;
    $("people-said").textContent = "...";
    return fetch("/api/people", { method: "POST", headers: { "Content-Type": "application/json" },
                                  body: JSON.stringify(body) })
      .then(function (r) { return r.json(); })
      .then(function (r) { $("people-said").textContent = r.message || (r.ok ? "Done." : "Didn't work."); return r; })
      .catch(function () { $("people-said").textContent = "The dashboard didn't answer."; return {}; });
  }
  function loadPeople() {
    fetch("/api/people", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) {
      $("people").hidden = false;
      $("people-load").textContent = "Refresh";
      $("people-note").textContent = fmt(d.photos_scanned) + " photos looked at, " + fmt(d.faces_found) + " faces, " +
        fmt(d.people.length) + " people. Nothing is named until you confirm it. Click a face to untick it.";
      var everyone = clear($("everyone")), list = clear($("known-names"));
      if (!d.people.length) everyone.appendChild(el("span", "Nobody yet: run da facial scan, then da facial suggest.", "note"));
      d.people.forEach(function (p) {
        var c = el("button", null, "chip");
        c.appendChild(el("b", p.name)); c.appendChild(el("span", "  " + fmt(p.photos) + (p.waiting ? " \u00b7 " + fmt(p.waiting) + " waiting" : "")));
        c.addEventListener("click", function () {
          var to = window.prompt("Rename " + p.name + " to (the same person under another name too):", p.name);
          if (to && to.trim() && to.trim() !== p.name) peopleAsk({ action: "rename", old: p.name, new: to.trim() }).then(loadPeople);
        });
        everyone.appendChild(c);
        var o = el("option"); o.value = p.name; list.appendChild(o);
      });
      var waiting = clear($("waiting"));
      $("waiting-note").textContent = d.waiting.length ? "" : "(nothing: run da facial suggest after a scan)";
      d.waiting.forEach(function (w) {
        var box = el("div", null, "person"), h = el("h3", w.name);
        h.appendChild(el("span", fmt(w.count) + " suggested" + (w.count > w.faces.length ? " (the first " + w.faces.length + " shown)" : ""), "note"));
        box.appendChild(h);
        var grid = facesGrid(w.faces.map(function (f) { return f.id; }),
                             w.faces.map(function (f) { return f.level + " " + (f.similarity || 0).toFixed(2); }));
        box.appendChild(grid);
        var acts = el("div", null, "acts"), yes = el("button", "Confirm the ticked ones", "primary");
        yes.addEventListener("click", function () {
          var on = picked(grid, true), off = picked(grid, false);
          var done = on.length ? peopleAsk({ action: "confirm", ids: on, name: w.name }) : Promise.resolve();
          done.then(function () { return off.length ? peopleAsk({ action: "reject", ids: off }) : null; }).then(loadPeople);
        });
        var none = el("button", "None of them are " + w.name);
        none.addEventListener("click", function () { peopleAsk({ action: "reject", ids: picked(grid, true).concat(picked(grid, false)) }).then(loadPeople); });
        acts.appendChild(yes); acts.appendChild(none);
        box.appendChild(acts);
        waiting.appendChild(box);
      });
      var groups = clear($("groups"));
      $("groups-note").textContent = d.groups.length ? "(" + fmt(d.groups_total) + " groups of faces that look alike; the biggest first)" :
        "(nothing: faces nobody is like are grouped by da facial suggest)";
      d.groups.forEach(function (g) {
        var box = el("div", null, "person"), h = el("h3", "Group " + g.group);
        h.appendChild(el("span", fmt(g.count) + " faces" + (g.count > g.faces.length ? " (" + g.faces.length + " shown)" : ""), "note"));
        box.appendChild(h);
        var grid = facesGrid(g.faces);
        box.appendChild(grid);
        var acts = el("div", null, "acts"), name = el("input");
        name.placeholder = "Who is this?"; name.setAttribute("list", "known-names"); name.setAttribute("aria-label", "Name");
        var give = el("button", "Name the ticked ones", "primary"), nope = el("button", "Not a face"), skip = el("button", "Skip");
        give.addEventListener("click", function () {
          if (!name.value.trim()) { name.focus(); $("people-said").textContent = "Type a name first."; return; }
          peopleAsk({ action: "name", ids: picked(grid, true), name: name.value.trim() }).then(loadPeople);
        });
        nope.addEventListener("click", function () { peopleAsk({ action: "not_a_face", ids: picked(grid, true) }).then(loadPeople); });
        skip.addEventListener("click", function () { box.remove(); });
        acts.appendChild(name); acts.appendChild(give); acts.appendChild(nope); acts.appendChild(skip);
        box.appendChild(acts);
        groups.appendChild(box);
      });
    }).catch(function () { $("people-said").textContent = "Couldn't read the people (is the dashboard running?)."; });
  }
  $("people-load").addEventListener("click", loadPeople);
  if (location.hash === "#people") { loadPeople(); $("people-card").scrollIntoView(); }

  // ----------------------------------------------------------------- dates (the review folder)
  var dPhotos = [], dSel = {}, dLast = -1, dNow = null, dSource = "", dTouched = false, dActive = false, dTile = 150;
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function ym(v) { return v ? v.y + "-" + pad(v.m) : "----"; }
  function parseYm(text) {
    var m = /^(\d{4})-(\d{2})/.exec(text || "");
    return m ? { y: Number(m[1]), m: Number(m[2]) } : null;
  }
  function datesAsk(body) {
    body.token = TOKEN;
    $("dates-said").textContent = "...";
    return fetch("/api/dates", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
      .then(function (r) { return r.json(); })
      .then(function (r) { $("dates-said").textContent = r.message || (r.ok ? "Done." : "Didn't work."); return r; })
      .catch(function () { $("dates-said").textContent = "The dashboard didn't answer."; return {}; });
  }
  function selected() {
    return dPhotos.filter(function (p) { return dSel[p.id]; });
  }
  function showNow() {
    $("d-now").textContent = ym(dNow);
    $("d-src").textContent = dTouched ? "chosen with Older / Newer" : dSource ? "best guess: " + dSource
      : dNow ? "no guess for this one: the month last used" : "no guess: pick the month with Older / Newer, or click it to type it";
    var n = selected().length;
    $("dates-count").textContent = n ? n + " selected" + (n === 1 ? ": " + selected()[0].name : "") : "Nothing selected: click photos (Shift-click a run)";
    $("d-set").disabled = !n || !dNow;
    $("d-edit").disabled = n !== 1;
  }
  function guessesOf(p) {
    var box = clear($("d-guesses"));
    if (!p || !p.guesses || !p.guesses.length) return;
    box.appendChild(el("span", "Guesses:", "lbl"));
    p.guesses.forEach(function (g) {
      var c = el("button", null, "chip");
      c.appendChild(el("b", g.label)); c.appendChild(el("span", "  " + g.source));
      c.addEventListener("click", function () {
        var v = parseYm(g.start.slice(0, 4) === "1826" ? g.end : g.start);
        if (v) { dNow = v; dSource = g.source; dTouched = false; showNow(); }
      });
      box.appendChild(c);
    });
  }
  function pickChanged() {
    var first = selected()[0];
    if (first && !dTouched) {
      var g = first.start && first.guesses && first.guesses.length ? first.guesses[0] : null;
      if (g) { dNow = parseYm(first.start); dSource = g.label + " (" + g.source + ")"; }
      else { dSource = ""; }                    // no real guess: keep the month last chosen
    }
    guessesOf(first);
    dPhotos.forEach(function (p) {
      var t = document.querySelector('.dtile[data-id="' + p.id + '"]');
      if (t) t.classList.toggle("sel", !!dSel[p.id]);
    });
    $("d-editbox").hidden = true;
    showNow();
  }
  function line(box, text, cls) { if (text) { var s = el("span", text, cls); s.title = text; box.appendChild(s); } }
  function tile(p, n) {
    var b = el("button", null, "dtile");
    b.dataset.id = p.id;
    var ph = el("span", null, "ph"), img = el("img");
    img.loading = "lazy"; img.alt = p.name; img.src = "/thumb/" + p.id;
    img.onerror = function () { img.remove(); };
    ph.appendChild(img); b.appendChild(ph);
    var f = el("span", null, "facts");
    if (p.date) line(f, "dated " + p.date + (p.certain ? "" : " (needs a month)"), "when dated");
    else line(f, p.guesses && p.guesses.length ? "guess " + p.guesses[0].label : "no date yet", "when");
    line(f, (p.people || []).join(", "));
    line(f, p.place);
    line(f, p.taken_with ? "taken with " + p.taken_with : p.camera);
    line(f, (p.tags || []).slice(0, 4).join(" "));
    line(f, p.name, "note");
    b.appendChild(f);
    b.addEventListener("click", function (e) {
      dActive = true;
      if (e.shiftKey && dLast >= 0) {
        var a = Math.min(dLast, n), z = Math.max(dLast, n);
        for (var i = a; i <= z; i++) dSel[dPhotos[i].id] = true;
      } else {
        dSel[p.id] = !dSel[p.id];
      }
      dLast = n;
      pickChanged();
    });
    b.addEventListener("dblclick", function () { shown = dPhotos.map(function (q) { return { id: q.id, name: q.name, kind: "photo" }; }); openAt(n); });
    return b;
  }
  function loadDatePhotos() {
    var folder = $("dates-folder").value;
    var grid = clear($("dates-grid"));
    grid.appendChild(el("p", "Loading ...", "note"));
    fetch("/api/dates/photos?folder=" + encodeURIComponent(folder), { cache: "no-store" })
      .then(function (r) { return r.json(); }).then(function (rows) {
        dPhotos = rows; dSel = {}; dLast = -1; dTouched = false;
        clear(grid);
        if (!rows.length) grid.appendChild(el("p", "Nothing waiting here.", "note"));
        rows.forEach(function (p, n) { grid.appendChild(tile(p, n)); });
        pickChanged();
      });
  }
  function loadDates(keep) {
    fetch("/api/dates", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (d) {
      $("dates").hidden = false;
      $("dates-load").textContent = "Refresh";
      if (!d.on) { $("dates-note").textContent = d.message; return; }
      $("dates-note").textContent = fmt(d.total) + " photos waiting for a date in " + fmt(d.folders.length) +
        " folders. Pick photos, choose the month (Older / Newer), Set. Double-click a photo to see it big." +
        (d.filing ? " Filing now ..." : (d.message ? " Last filing: " + d.message : ""));
      var pick = $("dates-folder"), was = keep ? pick.value : "";
      clear(pick);
      d.folders.forEach(function (f) {
        var o = el("option", (f.folder || "(top)") + "  (" + fmt(f.count) + ")"); o.value = f.folder; pick.appendChild(o);
      });
      if (was && d.folders.some(function (f) { return f.folder === was; })) pick.value = was;
      $("dates-undo").hidden = !d.undo.length;
      $("dates-undo-note").textContent = d.undo.length ? "Last set: " + d.undo[0] : "";
      if (d.folders.length) loadDatePhotos(); else clear($("dates-grid")).appendChild(el("p", "Nothing waiting for a date.", "note"));
    }).catch(function () { $("dates-said").textContent = "Couldn't read the review folder (is the dashboard running?)."; });
  }
  function step(months) {
    if (!dNow) { var t = new Date(); dNow = { y: t.getFullYear() - 30, m: 1 }; }
    var total = dNow.y * 12 + (dNow.m - 1) + months;
    dNow = { y: Math.floor(total / 12), m: total % 12 + 1 };
    dTouched = true; dActive = true;
    showNow();
  }
  function setDate() {
    var ids = selected().map(function (p) { return p.id; });
    if (!ids.length || !dNow) return;
    datesAsk({ action: "set", ids: ids, date: ym(dNow), source: dTouched ? "chosen" : dSource }).then(function (r) {
      if (r.ok) loadDates(true);
    });
  }
  $("d-yy").addEventListener("click", function () { step(-12); });
  $("d-m").addEventListener("click", function () { step(-1); });
  $("d-p").addEventListener("click", function () { step(1); });
  $("d-pp").addEventListener("click", function () { step(12); });
  $("d-set").addEventListener("click", setDate);
  $("d-now").addEventListener("click", function () {
    var typed = window.prompt("Type the month (1987-03) or the year (1987):", dNow ? ym(dNow) : "");
    var v = typed && /^\s*(\d{4})(?:-(\d{1,2}))?\s*$/.exec(typed);
    if (v && Number(v[2] || 1) >= 1 && Number(v[2] || 1) <= 12) {
      dNow = { y: Number(v[1]), m: Number(v[2] || 1) }; dTouched = true; dActive = true; showNow();
    }
  });
  $("d-edit").addEventListener("click", function () {
    var p = selected()[0];
    if (!p) return;
    $("d-edit-name").textContent = p.name;
    $("e-date").value = p.date || "";
    $("e-people").value = (p.people || []).join(", ");
    $("e-tags").value = "";
    fetch("/api/dates/cameras", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (cams) {
      var s = clear($("e-camera"));
      var none = el("option", "(not known: the camera or scanner that made the file)"); none.value = ""; s.appendChild(none);
      cams.forEach(function (c) {
        var o = el("option", c.name + (c.type ? "  - " + c.type : "") + (c.owner ? ", " + c.owner : "") + (c.years ? ", " + c.years : ""));
        o.value = c.name; s.appendChild(o);
      });
      s.value = p.taken_with || "";
      $("d-editbox").hidden = false;
      $("d-editbox").scrollIntoView({ block: "nearest" });
      $("e-date").focus();
    });
  });
  function list(text) { return (text || "").split(",").map(function (t) { return t.trim(); }).filter(Boolean); }
  $("e-save").addEventListener("click", function () {
    var p = selected()[0];
    if (!p) return;
    var had = p.people || [];
    var ask = { action: "edit", id: p.id, camera: $("e-camera").value, add_tags: list($("e-tags").value),
                people: list($("e-people").value).filter(function (n) { return had.indexOf(n) < 0; }) };
    if ($("e-date").value.trim() && $("e-date").value.trim() !== p.date) ask.date = $("e-date").value.trim();
    datesAsk(ask).then(function (r) { if (r.ok) { $("d-editbox").hidden = true; loadDates(true); } });
  });
  $("e-cancel").addEventListener("click", function () { $("d-editbox").hidden = true; });
  $("dates-folder").addEventListener("change", loadDatePhotos);
  $("dates-load").addEventListener("click", function () { loadDates(true); });
  $("dates-smaller").addEventListener("click", function () { dTile = Math.max(90, dTile - 30); $("dates-grid").style.setProperty("--tile", dTile + "px"); });
  $("dates-bigger").addEventListener("click", function () { dTile = Math.min(420, dTile + 30); $("dates-grid").style.setProperty("--tile", dTile + "px"); });
  $("dates-all").addEventListener("click", function () { dPhotos.forEach(function (p) { dSel[p.id] = true; }); pickChanged(); });
  $("dates-none").addEventListener("click", function () { dSel = {}; pickChanged(); });
  $("dates-undo").addEventListener("click", function () { datesAsk({ action: "undo" }).then(function () { loadDates(true); }); });
  $("dates-file").addEventListener("click", function () {
    if (window.confirm("File the dated photos now (as Autorun would)?")) datesAsk({ action: "file" }).then(function () { setTimeout(function () { loadDates(true); }, 3000); });
  });
  $("dates-card").addEventListener("mouseenter", function () { dActive = true; });
  $("people-card").addEventListener("mouseenter", function () { dActive = false; });
  document.addEventListener("keydown", function (e) {
    var typing = /^(INPUT|SELECT|TEXTAREA)$/.test((document.activeElement || {}).tagName || "");
    if (at >= 0 || !dActive || typing || $("dates").hidden) return;
    if (e.key === "ArrowLeft") { step(e.shiftKey ? -12 : -1); e.preventDefault(); }
    else if (e.key === "ArrowRight") { step(e.shiftKey ? 12 : 1); e.preventDefault(); }
    else if (e.key === "Enter") { setDate(); e.preventDefault(); }
    else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a") {
      dPhotos.forEach(function (p) { dSel[p.id] = true; }); pickChanged(); e.preventDefault();
    }
  });
  if (location.hash === "#dates") { loadDates(false); $("dates-card").scrollIntoView(); }
})();
</script>
</body>
</html>
"""
