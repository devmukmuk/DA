# src/mindit/services/dashboard/dates_page.py

"""The dashboard's Dates page: the photos waiting in the review folder, what's known about each, and setting dates.

`folders()` and `photos()` read; `act()` does the page's buttons: set a date on the selected photos (set by hand, the
note naming the guess it came from), undo the last ones, edit one photo (its date, the camera it was taken with, tags,
people) and file the dated ones (as Autorun would). Design: docs/da-docs/SCANS-DESIGN.md.
"""

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path
from typing import Any

from mindit.services.dates import user_dates as ud

_UNDO: list[dict[str, Any]] = []                 # the last sets, newest last: {label, before: {path: user date keys}}
_FILING = threading.Lock()


def _paths(db_path: Path, archive: Path, ids: list[Any]) -> list[Path]:
    from mindit.services.dashboard.pictures import find  # pylint: disable=import-outside-toplevel

    found = []
    for raw in ids[:5000]:
        try:
            hit = find(db_path, archive, int(raw))
        except (TypeError, ValueError):
            continue
        if hit is not None and hit[1] == "photo":
            found.append(hit[0])
    return found


def folders(db_path: Path, organized: Path) -> dict[str, Any]:
    """Return the review folders and how many photos wait in each, biggest first."""
    from mindit.services.scans.review import review_root, waiting  # pylint: disable=import-outside-toplevel

    root = review_root(organized)
    if root is None:
        return {"on": False, "folders": [], "message": "This archive has no review folder (review_folder: review in "
                                                       "da-archive.yaml)."}
    rows = waiting(db_path, organized)
    return {"on": True, "root": str(root), "total": sum(len(w.photos) for w in rows),
            "folders": [{"folder": w.folder, "count": len(w.photos)} for w in rows],
            "undo": [u["label"] for u in _UNDO[-5:]][::-1]}


def photos(db_path: Path, organized: Path, folder: str) -> list[dict[str, Any]]:
    """Return one review folder's photos (in name order: scans stay in the order they were made) and their facts."""
    from mindit.services.scans.review import photo_facts, waiting  # pylint: disable=import-outside-toplevel

    wanted = next((w for w in waiting(db_path, organized) if w.folder == folder), None)
    if wanted is None:
        return []
    out = []
    for row in wanted.photos[:1000]:
        path = Path(row["path"])
        try:
            facts = photo_facts(path)
        except Exception:  # pylint: disable=broad-except
            facts = {"guesses": [], "start": ""}
        out.append({"id": row["id"], "name": path.name, **facts})
    return out


def cameras() -> list[dict[str, Any]]:
    """Return the cameras a photo can be said to be taken with (cameras.json), film cameras first."""
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    rows = [r for r in cams.current().rows if r.get("type") != "scanner"]
    rows.sort(key=lambda r: (r.get("type") != "film", r["name"].lower()))
    return [{"name": r["name"], "type": r.get("type") or "", "owner": r.get("owner") or "", "years": r.get("years") or ""}
            for r in rows]


def _before(paths: list[Path]) -> dict[str, dict[str, Any]]:
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    kept = {}
    for path in paths:
        user = SidecarService.load(path).get(ud.USER_BLOCK) or {}
        kept[str(path)] = {k: user.get(k) for k in ud.DATE_KEYS}
    return kept


def _restore(before: dict[str, dict[str, Any]]) -> dict[str, str | None]:
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    changed: dict[str, str | None] = {}
    for path_text, values in before.items():
        path = Path(path_text)
        if not path.exists():
            continue                                     # filed since: undo it with da date there
        data = SidecarService.load(path)
        block = data.get(ud.USER_BLOCK) if isinstance(data.get(ud.USER_BLOCK), dict) else {}
        for key in ud.DATE_KEYS:
            block.pop(key, None)
            if values.get(key):
                block[key] = values[key]
        if block:
            data[ud.USER_BLOCK] = block
        else:
            data.pop(ud.USER_BLOCK, None)
        SidecarService.save(path, data)
        changed[path_text] = values.get("captured_at")
    return changed


def act(db_path: Path, archive: Path, ask: dict[str, Any]) -> dict[str, Any]:
    """Do one of the page's buttons: set, undo, edit, file."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    action = str(ask.get("action") or "")
    if action == "set":
        paths = _paths(db_path, archive, ask.get("ids") if isinstance(ask.get("ids"), list) else [])
        text, source = str(ask.get("date") or "").strip(), str(ask.get("source") or "").strip()[:120]
        if not paths:
            return {"ok": False, "message": "Pick one or more photos first."}
        try:
            when, precision = ud.parse_when(text)
        except ud.DateError as error:
            return {"ok": False, "message": str(error)}
        before = _before(paths)
        result = ud.set_dates(paths, when, precision, text + (f" ({source})" if source else ""))
        ud.update_index(db_path, result.changed)
        _UNDO.append({"label": f"{text} on {len(paths)} photo{'s' if len(paths) != 1 else ''}", "before": before})
        del _UNDO[:-20]
        log_event("dates_page", f"Dates page: {text} set on {len(paths)} photos", path=str(paths[0].parent),
                  photos=len(paths))
        wait = "" if precision in ("month", "day", "time") else " A year alone waits here for a month."
        return {"ok": True, "message": f"{text} set on {len(paths)} photo{'s' if len(paths) != 1 else ''}.{wait}"}
    if action == "undo":
        if not _UNDO:
            return {"ok": False, "message": "Nothing to undo."}
        last = _UNDO.pop()
        changed = _restore(last["before"])
        ud.update_index(db_path, changed)
        log_event("dates_page", f"Dates page: undid {last['label']}", path=str(archive), photos=len(changed))
        return {"ok": True, "message": f"Undone: {last['label']}."}
    if action == "edit":
        return _edit(db_path, archive, ask)
    if action == "file":
        return _file_now(archive)
    return {"ok": False, "message": "Not something this page does."}


def _edit(db_path: Path, archive: Path, ask: dict[str, Any]) -> dict[str, Any]:
    """Change one photo: its date, the camera it was taken with, your tags and people (person: tags)."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging import tags as tg  # pylint: disable=import-outside-toplevel

    paths = _paths(db_path, archive, [ask.get("id")])
    if not paths:
        return {"ok": False, "message": "That photo isn't in the archive any more."}
    path, said = paths[0], []
    text = str(ask.get("date") or "").strip()
    if text:
        try:
            when, precision = ud.parse_when(text)
        except ud.DateError as error:
            return {"ok": False, "message": str(error)}
        _UNDO.append({"label": f"{text} on {path.name}", "before": _before([path])})
        ud.update_index(db_path, ud.set_dates([path], when, precision, text).changed)
        said.append(f"date {text}")
    if "camera" in ask:
        camera = " ".join(str(ask.get("camera") or "").split())[:80]
        data = SidecarService.load(path)
        if camera:
            from datetime import datetime  # pylint: disable=import-outside-toplevel

            data["taken_with"] = {"camera": camera, "set_at": datetime.now().isoformat(timespec="seconds")}
        else:
            data.pop("taken_with", None)
        SidecarService.save(path, data)
        said.append(f"taken with {camera}" if camera else "camera taken off")
    add = [t for t in (ask.get("add_tags") or []) if isinstance(t, str) and t.strip()][:30]
    add += [f"person:{p}" for p in (ask.get("people") or []) if isinstance(p, str) and p.strip()][:30]
    remove = [t for t in (ask.get("remove_tags") or []) if isinstance(t, str) and t.strip()][:30]
    if add or remove:
        tg.change_user_tags([path], add, remove)
        said.append("tags")
    from mindit.services.scans.cameras import owners  # pylint: disable=import-outside-toplevel

    result = tg.tag_photos([path], owners())              # the camera's owner: and camera: tags follow
    tg.update_index(db_path, result.changed)
    log_event("dates_page", f"Dates page: edited {path.name}: {', '.join(said) or 'nothing'}", path=str(path))
    return {"ok": True, "message": f"{path.name}: " + (", ".join(said) or "nothing changed") + "."}


_FILED: dict[str, Any] = {}


def _file_now(archive: Path) -> dict[str, Any]:
    """File the dated photos in review, in the background (as Autorun would); one at a time."""
    if not _FILING.acquire(blocking=False):                # pylint: disable=consider-using-with
        return {"ok": False, "message": "Already filing; give it a minute."}

    def work() -> None:
        try:
            from mindit.config.settings import resolve_database_path  # pylint: disable=import-outside-toplevel
            from mindit.core.progress import NullProgressReporter  # pylint: disable=import-outside-toplevel
            from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel
            from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel
            from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel
            from mindit.services.workflow.run_workflow import _file_reviewed  # pylint: disable=import-outside-toplevel
            from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

            layout = default_layout()
            run_dir = layout.run_dir("review")
            said: list[str] = []
            done = _file_reviewed(layout, run_dir, None, lambda name, data: None, said.append, lambda q: True,
                                  NullProgressReporter())
            ArchiveIndexService(DbitService(resolve_database_path())).build(default_areas())
            _FILED.update({"message": said[-1].strip() if said else "Nothing dated to file.", "folders": len(done)})
            log_event("review", f"Dates page: filed dated photos into {len(done)} folders", path=str(run_dir),
                      folders=len(done))
        except Exception as exc:  # pylint: disable=broad-except
            _FILED.update({"message": f"Filing stopped: {type(exc).__name__}: {exc}"})
        finally:
            _FILING.release()

    threading.Thread(target=work, daemon=True).start()
    return {"ok": True, "message": "Filing the dated photos ... (Refresh in a minute)"}


def filing_state() -> dict[str, Any]:
    """Return whether filing is going on, and what the last one did."""
    return {"filing": _FILING.locked(), **_FILED}


def index_has(db_path: Path) -> bool:
    """Return whether the index exists (the page says to run Autorun first otherwise)."""
    if not Path(db_path).exists():
        return False
    with sqlite3.connect(db_path) as conn:
        try:
            return conn.execute("SELECT 1 FROM files LIMIT 1").fetchone() is not None
        except sqlite3.Error:
            return False
