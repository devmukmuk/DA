﻿# src/mindit/services/naming/tokens.py

"""The tokens names (and later folders) are made from, beyond the dates, hash and original name.

Every value comes from the sidecar: the camera block (`da tag`), the location block (`da location lookup`),
the OCR block (`da tag ocr`), the archive's camera owners. A file without that fact gets "" for the token,
and the name drops it with its separator. Design: docs/da-docs/RENAME-DESIGN.md.
"""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any

TOKEN = re.compile(r"\{([^{}]+)\}")
CODE_TOKENS = {"state:2": "state_code", "country:2": "country_code"}   # the 2-letter codes, not "il"[:2]


def slug(text: Any) -> str:
    """Return lower case words joined by '-' ('Apple iPhone 12 Pro' -> 'apple-iphone-12-pro')."""
    return re.sub(r"[^a-z0-9]+", "-", str(text or "").lower()).strip("-")


def _block(data: dict[str, Any], name: str) -> dict[str, Any]:
    block = data.get(name)
    return block if isinstance(block, dict) else {}


_CAMERAS: dict[tuple[str, float], dict[str, str]] = {}


def _cameras() -> dict[str, str]:
    """Return the archive's camera owners, read again only when da-archive.yaml or cameras.json changes."""
    try:
        from mindit.config.settings import get_cameras_file, get_config_path  # pylint: disable=import-outside-toplevel
        from mindit.services.scans.cameras import owners  # pylint: disable=import-outside-toplevel

        config, listed = get_config_path(), get_cameras_file()
        key = (str(config), (config.stat().st_mtime if config.exists() else 0.0)
               + (listed.stat().st_mtime if listed.exists() else 0.0))
        if key not in _CAMERAS:
            _CAMERAS.clear()
            _CAMERAS[key] = owners()
        return _CAMERAS[key]
    except Exception:  # pylint: disable=broad-except
        return {}


def _kind(path: Path, data: dict[str, Any]) -> str:
    from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS  # pylint: disable=import-outside-toplevel

    classification = _block(data, "classification")
    if classification.get("module") == "scanit" or classification.get("media_type") == "document":
        return "document"
    return "video" if path.suffix.lower() in VIDEO_EXTENSIONS else "photo"


def sidecar_tokens(path: Path, data: dict[str, Any] | None, capture_dt: datetime | None,
                   cameras: dict[str, str] | None = None) -> dict[str, str]:
    """Return the camera, owner, place, title, kind and OCR tokens (and {YYYY}... dates) for one file."""
    from mindit.services.location.places import place_name  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar.origin import levels  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.camera_info import camera_name, maker_name  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import owner_for  # pylint: disable=import-outside-toplevel

    data = data or {}
    camera = _block(data, "camera")
    location = _block(data, "location")
    place = location.get("place") if isinstance(location.get("place"), dict) else {}
    owner = owner_for(camera, _cameras() if cameras is None else cameras) if camera else None
    level = _block(data, "ocr").get("level")
    tokens = {
        "maker": slug(maker_name(camera.get("make"))),
        "camera": slug(camera_name(camera)),
        "lens": slug(camera.get("lens_model")),
        "owner": slug(owner),
        "street": slug(place.get("street")),
        "neighbourhood": slug(place.get("neighbourhood")),
        "city": slug(place.get("city")),
        "county": slug(place.get("county")),
        "state": slug(place.get("state")),
        "state_code": slug(place.get("state_code")),
        "country": slug(place.get("country")),
        "country_code": slug(place.get("country_code")),
        "place": place_name(place) or "",
        "title": str(location.get("title") or "").strip(),
        "kind": _kind(path, data),
        "ext": path.suffix.lower().lstrip("."),
        "text": "" if level in (None, "", "none") else str(level),
    }
    from_levels = levels(data)
    tokens["from_levels"] = from_levels                         # {from:1} {from:-1}: one level (origin.level_token)
    tokens["from"] = " - ".join(from_levels)                    # in a folder pattern: every level, as folders
    if capture_dt is not None:
        tokens.update(YYYY=f"{capture_dt:%Y}", MM=f"{capture_dt:%m}", DD=f"{capture_dt:%d}",
                      hh=f"{capture_dt:%H}", mm=f"{capture_dt:%M}", ss=f"{capture_dt:%S}")
    return tokens


def token_value(token: str, context: dict[str, Any]) -> Any:
    """Return what a {token} stands for in context ({state:2} is the state's code), or None."""
    from mindit.services.sidecar.origin import level_token  # pylint: disable=import-outside-toplevel

    if token in CODE_TOKENS:
        return context.get(CODE_TOKENS[token])
    one_level = level_token(token, context)
    if one_level is not None:
        return one_level
    return context.get(token.split(":", 1)[0].strip())


def missing_tokens(pattern: str, context: dict[str, Any]) -> list[str]:
    """Return the tokens in pattern that have nothing for this file, e.g. ['owner', 'city']."""
    missing: list[str] = []
    for match in TOKEN.finditer(pattern):
        token = match.group(1).strip()
        value = token_value(token, context)
        if value is None or (isinstance(value, (str, list)) and not value):
            name = token.split(":", 1)[0].strip() if token not in CODE_TOKENS else token
            if name not in missing:
                missing.append(name)
    return missing
