# src/mindit/services/dates/user_dates.py

"""Dates you know better than the camera: set by hand, or a whole camera's clock shifted.

Kept in the sidecar's "user" block, which wins over everything else (file name, EXIF, modified time):
    "user": {"captured_at": "1998-07-01T00:00:00", "date_precision": "month",
             "date_note": "set by hand: 1998-07", "tags": [...]}
`da run` and `da validate` then name and file the photo by it. A date set to a month or a year (an old
print: "summer 1998") is filed under that month, or January of that year - except a scanned print, which needs a
month (a year or a decade, 1990s, keeps it in review: docs/da-docs/SCANS-DESIGN.md).
"""

from __future__ import annotations

import calendar
import json
import re
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

USER_BLOCK = "user"
DATE_KEYS = ("captured_at", "date_precision", "date_note")
SIDECAR_SUFFIX = ".meta.json"

_WHEN = re.compile(r"^\s*(?P<y>\d{4})(?:[-/.](?P<m>\d{1,2})(?:[-/.](?P<d>\d{1,2})"
                   r"(?:[ T](?P<H>\d{1,2}):(?P<M>\d{2})(?::(?P<S>\d{2}))?)?)?)?\s*$")
_DECADE = re.compile(r"^\s*(?P<y>\d{3}0)'?s\s*$", re.IGNORECASE)
_SHIFT = re.compile(r"^\s*(?P<sign>[+-])\s*(?P<n>\d+)\s*(?P<unit>y|years?|mo|months?|d|days?|h|hours?|m|min|minutes?)\s*$",
                    re.IGNORECASE)


class DateError(ValueError):
    """A date or a shift DA can't read."""


def parse_when(text: str, now: datetime | None = None) -> tuple[datetime, str]:
    """Return the date and how precise it is ('decade', 'year', 'month', 'day', 'time') from 1990s, 1998, 1998-07,
    1998-07-04 14:30."""
    decade = _DECADE.match(text or "")
    if decade:
        value = datetime(int(decade["y"]), 1, 1)
        if not 1820 <= value.year <= (now or datetime.now()).year:
            raise DateError(f"{text.strip()} isn't a decade a photo can be from.")
        return value, "decade"
    m = _WHEN.match(text or "")
    if not m:
        raise DateError(f"{text!r} isn't a date DA reads. Use 1990s, 1998, 1998-07, 1998-07-04 or 1998-07-04 14:30.")
    parts = {k: int(v) for k, v in m.groupdict().items() if v is not None}
    precision = "time" if "H" in parts else "day" if "d" in parts else "month" if "m" in parts else "year"
    try:
        value = datetime(parts["y"], parts.get("m", 1), parts.get("d", 1), parts.get("H", 0), parts.get("M", 0),
                         parts.get("S", 0))
    except ValueError as error:
        raise DateError(f"{text!r} isn't a real date ({error}).") from error
    if not 1826 <= value.year <= (now or datetime.now()).year:
        raise DateError(f"{value.year} isn't a year a photo can be from.")
    return value, precision


@dataclass(frozen=True)
class Shift:
    """An amount to move dates by: +1h, -30m, +2d, -1y, +3mo."""

    amount: int
    unit: str                       # "years", "months", "days", "hours", "minutes"
    text: str

    def apply(self, value: datetime) -> datetime:
        """Return value moved by this amount (months and years keep the day, or the month's last day)."""
        if self.unit in ("years", "months"):
            months = self.amount * (12 if self.unit == "years" else 1)
            total = value.year * 12 + value.month - 1 + months
            year, month = divmod(total, 12)
            day = min(value.day, calendar.monthrange(year, month + 1)[1])
            return value.replace(year=year, month=month + 1, day=day)
        return value + timedelta(**{self.unit: self.amount})


def parse_shift(text: str) -> Shift:
    """Return the shift in '+1h', '-30m', '+2d', '-1y', '+3mo'."""
    m = _SHIFT.match(text or "")
    if not m:
        raise DateError(f"{text!r} isn't a shift DA reads. Use +1h, -30m, +2d, -1y or +3mo.")
    unit = m["unit"].lower()
    unit = ("years" if unit.startswith("y") else "months" if unit.startswith("mo") else
            "days" if unit.startswith("d") else "hours" if unit.startswith("h") else "minutes")
    amount = int(m["n"]) * (-1 if m["sign"] == "-" else 1)
    return Shift(amount, unit, f"{m['sign']}{m['n']}{m['unit'].lower()}")


def user_date(sidecar: dict[str, Any] | None) -> datetime | None:
    """Return the date set by hand in a sidecar, or None."""
    block = (sidecar or {}).get(USER_BLOCK)
    raw = block.get("captured_at") if isinstance(block, dict) else None
    if not raw:
        return None
    try:
        return datetime.fromisoformat(str(raw)).replace(tzinfo=None)
    except ValueError:
        return None


def read_user_date(path: Path) -> datetime | None:
    """Return the date set by hand for a file (from its sidecar), or None. Cheap: no file but the sidecar is read."""
    side = Path(f"{path}{SIDECAR_SUFFIX}")
    if not side.exists():
        return None
    try:
        return user_date(json.loads(side.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------------- changing dates

@dataclass
class DateResult:
    """What a set, shift or clear did."""

    changed: dict[str, str | None] = field(default_factory=dict)      # path -> new captured_at (None: cleared)
    skipped: list[tuple[Path, str]] = field(default_factory=list)     # path, why


def _save(path: Path, value: datetime | None, precision: str | None, note: str | None) -> None:
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    data = SidecarService.load(path)
    block = data.get(USER_BLOCK) if isinstance(data.get(USER_BLOCK), dict) else {}
    for key in DATE_KEYS:
        block.pop(key, None)
    if value is not None:
        block.update({"captured_at": value.isoformat(timespec="seconds"), "date_precision": precision,
                      "date_note": note})
    if block:
        data[USER_BLOCK] = block
    else:
        data.pop(USER_BLOCK, None)
    SidecarService.save(path, data)


def set_dates(files: list[Path], when: datetime, precision: str, text: str) -> DateResult:
    """Give each file this date (set by hand)."""
    result = DateResult()
    for path in files:
        _save(path, when, precision, f"set by hand: {text.strip()}")
        result.changed[str(path)] = when.isoformat(timespec="seconds")
    _log(f"date set to {text.strip()} on {len(result.changed)} files")
    return result


def shift_dates(files: list[Path], shift: Shift) -> DateResult:
    """Move each file's date by the shift (a camera whose clock was off). Files with no sure date are skipped."""
    from mindit.services.validateit.capture_date import resolve_capture_date  # pylint: disable=import-outside-toplevel

    result = DateResult()
    for path in files:
        capture = resolve_capture_date(path)
        if not capture.certain:
            result.skipped.append((path, "no sure date to shift"))
            continue
        new = shift.apply(capture.value)
        _save(path, new, "time", f"shifted {shift.text} from {capture.value:%Y-%m-%d %H:%M:%S} ({capture.source})")
        result.changed[str(path)] = new.isoformat(timespec="seconds")
    _log(f"date shifted {shift.text} on {len(result.changed)} files ({len(result.skipped)} skipped)")
    return result


def clear_dates(files: list[Path]) -> DateResult:
    """Take dates set by hand off again (the file's own date counts again)."""
    result = DateResult()
    for path in files:
        if read_user_date(path) is None:
            continue
        _save(path, None, None, None)
        result.changed[str(path)] = None
    _log(f"dates set by hand cleared on {len(result.changed)} files")
    return result


def update_index(db_path: Path, changed: dict[str, str | None]) -> int:
    """Write the new dates into the index rows of those files; return how many rows matched."""
    if not changed or not Path(db_path).exists():
        return 0
    with sqlite3.connect(db_path) as conn:
        before = conn.total_changes
        conn.executemany("UPDATE files SET captured_at = COALESCE(?, captured_at) WHERE path = ?",
                         [(value, path) for path, value in changed.items()])
        return conn.total_changes - before


def _log(message: str) -> None:
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("date", message)
