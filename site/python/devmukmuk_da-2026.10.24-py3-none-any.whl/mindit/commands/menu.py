# src/mindit/commands/menu.py

"""The interactive menu: `da` with no command (and Open DA.cmd) opens it for the archive you're in."""

from __future__ import annotations

import csv
import json
import os
from collections import Counter
from pathlib import Path
from typing import Callable

from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from rich.text import Text

from mindit.config.archive import known_archives
from mindit.config.settings import get_archive_root, load_settings, resolve_database_path, set_archive_root

console = Console()

REVIEW_CODES = {
    "capture_date_uncertain": "No date (in the file or its name)",
    "outside_archive_years": "Taken outside this archive's years",
    "name_date_differs_from_exif": "File name and camera date disagree (filed by the name)",
    "duplicate_file": "Duplicate inside the folder (left for you to decide)",
    "document_in_photos_folder": "Looks like a document, not a photo",
}

HELP = """\
[bold]How DA works[/bold]
  An archive is a folder (like D:\\jane-archive-202x) with its own da-archive.yaml.
  1. Copy photos into the archive's [bold]intake\\[/bold] folder (any subfolders, any names).
  2. Choose [bold]1 Process intake[/bold]. DA hashes the photos, sets exact duplicates aside in
     _duplicates-holding\\, works out each photo's date, then files it as
     photos\\organized\\YYYY\\YYYY-MM\\photo_YYYYMMDD_HHMMSS_xxxx.jpg - asking before it moves anything.
  3. Choose [bold]3 What needs review[/bold] for what stayed behind (no date, wrong decade, ...).
  Nothing is ever deleted. Every run is recorded in output\\runs\\.

[bold]Commands[/bold] (type these instead of using the menu)
  da run [folder]     process intake            da status        this archive
  da archives         all archives on this PC   da setup <dir>   new archive
  da db stats         counts by year            da intake undo   put duplicates back
  da location lookup  towns for GPS photos      da location group <month>  location folders
  da split            other decades' files      logs\\da.jsonl   what DA did, and when
  da merge --from <a> copy in another copy's    da report        a one-page PDF in output\\
  Full guide: U in the menu, or https://da.gamenightbymike.com
"""


def run_menu() -> None:
    """Show the menu until the user quits."""
    if get_archive_root() is None and not _choose_archive(first_time=True):
        return
    show_status = True                                  # the Status summary when the menu opens
    while True:
        _header()
        if show_status:
            _status()
            show_status = False
        choice = Prompt.ask(
            "\n  [bold]1[/bold] Process intake    [bold]2[/bold] Status    [bold]3[/bold] What needs review    "
            "[bold]4[/bold] Undo last set-aside\n  [bold]5[/bold] Refresh index     [bold]6[/bold] Switch archive    "
            "[bold]7[/bold] New archive\n  [bold]L[/bold] Location folders  [bold]S[/bold] Split by years    "
            "[bold]M[/bold] Merge from another copy    [bold]R[/bold] Report (PDF)\n  "
            "[bold]D[/bold] Fix dates    [bold]J[/bold] Update sidecars    [bold]U[/bold] User guide    "
            "[bold]H[/bold] Help    [bold]Q[/bold] Quit\n  Choose",
            default="q").strip().lower()
        actions: dict[str, Callable[[], object]] = {
            "1": _process, "2": _status, "3": _review, "4": _undo_last, "5": _refresh,
            "6": lambda: _choose_archive(first_time=False), "7": _new_archive, "l": _location, "s": _split, "m": _merge, "r": _report, "d": _dates, "j": _sidecars, "u": _user_guide,
            "h": lambda: console.print(HELP),
        }
        if choice in ("q", "quit", "exit"):
            return
        action = actions.get(choice)
        if action is None:
            console.print("  Pick one of the numbers or letters shown.")
            continue
        from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

        log_event("menu", f"menu: {choice}")
        if choice in ("6", "7"):
            show_status = True                          # a different archive: show where it stands
        try:
            action()
        except KeyboardInterrupt:
            console.print("\n  Stopped.")
        except Exception as exc:  # pylint: disable=broad-except
            console.print(f"  [red]{type(exc).__name__}: {exc}[/red]")


# --------------------------------------------------------------------------- pieces

def _header() -> None:
    from mindit.commands.workflow_cli import _db_counts, _intake_counts_from_db  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel

    settings = load_settings()
    layout = default_layout()
    root = get_archive_root() or layout.data_root
    db_path = resolve_database_path()
    counts = _db_counts(db_path, layout) if db_path.exists() else None
    intake = _intake_counts_from_db(db_path, layout) if counts else None
    if counts is None:                              # a new archive, or one never processed
        waiting, organized = "not indexed yet (1 processes it, 5 just indexes)", "-"
    else:
        waiting = f"{sum((intake or {}).values()):,} files waiting"
        organized = f"{counts['photos']:,} photos, {counts['documents']:,} documents"
    last = _last_run(layout.output_root)
    console.print(Panel.fit(
        f"[bold]DA - {settings.archive.name or root.name}[/bold]   {root}   years: {settings.archive.years or 'any'}\n"
        f"intake: {waiting}    organized: {organized}    last run: {last or 'never'}",
        border_style="cyan"))


def _last_run(output_root: Path) -> str | None:
    runs = sorted((output_root / "runs").glob("*-run/summary.json")) if (output_root / "runs").exists() else []
    if not runs:
        return None
    data = json.loads(runs[-1].read_text(encoding="utf-8"))
    filed = ((data.get("steps", {}).get("6_file", {}) or {}).get("verify") or {}).get("moved", 0)
    end = f"stopped at {data['stopped_at_step']}" if data.get("stopped_at_step") else f"filed {filed:,}"
    return f"{(data.get('started_at') or '')[:16].replace('T', ' ')} ({end})"


def _has_files(folder: Path) -> bool:
    """Return True as soon as any file (not a sidecar) turns up under folder."""
    return any(not f.lower().endswith(".meta.json") for _, _, files in os.walk(folder) for f in files)


def _tree_counts(root: Path) -> tuple[dict[Path, int], dict[Path, int]]:
    """Walk root once: files under each folder (all levels), and files directly in each folder."""
    under: dict[Path, int] = {}
    direct: dict[Path, int] = {}
    for dirpath, _dirs, files in os.walk(root):
        n = sum(1 for f in files if not f.lower().endswith(".meta.json"))
        folder = Path(dirpath)
        direct[folder] = n
        under.setdefault(folder, 0)
        if n:
            for parent in (folder, *folder.parents):
                under[parent] = under.get(parent, 0) + n
                if parent == root:
                    break
    return under, direct


def _subfolders(folder: Path, under: dict[Path, int]) -> list[tuple[str, int]]:
    """Return folder's subfolders, by name, with their file counts."""
    if not folder.is_dir():
        return []
    entries = sorted((e for e in folder.iterdir() if e.is_dir()), key=lambda e: e.name.lower())
    return [(e.name, under.get(e, 0)) for e in entries]


def browse_intake(intake: Path, ask: Callable[[str], str], say: Callable[[object], None]) -> Path | None:
    """Walk intake's folders: a number goes into one, 0 picks this one, text filters, .. goes up."""
    under, direct = _tree_counts(intake)              # one walk; moving between folders is then instant
    current, text = intake, ""
    while True:
        subs = _subfolders(current, under)
        total, loose = under.get(current, 0), direct.get(current, 0)
        shown = [(name, n) for name, n in subs if text.lower() in name.lower()]
        plain = str(Path("intake") / current.relative_to(intake)) + "\\"
        where = escape(plain)
        table = Table(show_header=True, box=None, title_justify="left",
                      title=Text(plain + (f"   filter: {text!r}" if text else ""), style="bold"))
        table.add_column("#", justify="right")
        table.add_column("folder")
        table.add_column("files", justify="right")
        table.add_row("0", f"[bold]process all of {where}[/bold]", f"{total:,}")
        for i, (name, n) in enumerate(shown, 1):
            table.add_row(str(i), escape(name) + ("\\" if n else "\\  (empty)"), f"{n:,}")
        say(table)
        if loose:
            say(f"  ({loose:,} files directly in this folder are included in 0.)")
        if text and not shown:
            say(f"  No folder here matches {text!r}.")
        hints = ["number: open", "0: process", "text: filter"] + ([".. up"] if current != intake else []) + ["Enter: back"]
        pick = ask("  " + "   ".join(hints)).strip()
        if not pick:
            if text:                                   # Enter first clears a filter
                text = ""
                continue
            return None
        if pick == "..":
            if current != intake:
                current, text = current.parent, ""
            continue
        if pick == "0":
            if total == 0:
                say("  Nothing to process here.")
                continue
            return current
        if pick.isdigit():
            if not 1 <= int(pick) <= len(shown):
                say("  Not one of the numbers shown.")
                continue
            name, n = shown[int(pick) - 1]
            child = current / name
            if n and not _subfolders(child, under):
                return child                           # no subfolders: nothing more to pick, process it
            if not n:
                say(f"  {name} is empty.")
                continue
            current, text = child, ""
            continue
        text = pick


def _process() -> None:
    from mindit.commands.progress import ConsoleProgressReporter  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.run_workflow import run_workflow  # pylint: disable=import-outside-toplevel

    layout = default_layout()
    console.print("  Counting what's in intake ...")
    if not _has_files(layout.intake_root):
        console.print(f"  Nothing in {layout.intake_root}. Copy photos there first.")
        return
    folder = browse_intake(layout.intake_root, ask=lambda q: Prompt.ask(q, default=""), say=console.print)
    if folder is None:
        return
    console.print(f"  Processing {folder}. DA asks before moving anything; answer n to stop at that point.\n")
    run_workflow(folder, DbitService(resolve_database_path()), layout, say=console.print,
                 ask=lambda q: Confirm.ask("  " + q, default=False),
                 progress=ConsoleProgressReporter(console=console, update_every=1000))
    console.print("\n  [bold]Where things stand now:[/bold]")
    _status()


def gps_months(db_path: Path) -> list[tuple[str, int]]:
    """Return the plain month folders (2019\\2019-04) with GPS photos, newest first, from the index."""
    import re  # pylint: disable=import-outside-toplevel
    import sqlite3  # pylint: disable=import-outside-toplevel

    if not db_path.exists():
        return []
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute("SELECT folder, COUNT(*) FROM files WHERE area = 'photos' AND media_type = 'photo' "
                            "AND gps_present = 1 GROUP BY folder").fetchall()
    months = [(f, n) for f, n in rows if f and re.match(r"^\d{4}[\\/]\d{4}-\d{2}$", f)]
    return sorted(months, reverse=True)


def _location() -> None:
    """Pick a month with GPS photos and group it into location folders."""
    from mindit.commands.location_cli import group  # pylint: disable=import-outside-toplevel
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel

    organized = resolve_photoit_organized_path()
    months = gps_months(resolve_database_path())
    if not months:
        console.print("  No filed photos with GPS in the index. Run 5 Refresh index (and `da tag` for older photos).")
        return
    console.print("  Months with GPS photos (newest first):")
    shown = months[:20]
    for i, (folder, count) in enumerate(shown, 1):
        console.print(f"   [bold]{i:>2}[/bold]  {folder}  ({count:,} photos)")
    if len(months) > len(shown):
        console.print(f"       ... and {len(months) - len(shown):,} older months (type one, e.g. 2019\\2019-04)")
    answer = Prompt.ask("  Which month? (number or folder, Enter to go back)", default="").strip()
    if not answer:
        return
    pick = shown[int(answer) - 1][0] if answer.isdigit() and 1 <= int(answer) <= len(shown) else answer
    folder = organized / pick
    if not folder.is_dir():
        console.print(f"  No such folder: {folder}")
        return
    group(folder, title=None, hours=6.0, km=2.0, yes=False)


def _split() -> None:
    """Show where intake's files from other years belong, then move them to an archive picked from the list."""
    from mindit.commands.workflow_cli import split  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.split import archive_years  # pylint: disable=import-outside-toplevel

    if not split(to=None, years=None, yes=False):
        return
    here = get_archive_root()
    others = [a for a in known_archives()
              if archive_years(a) and os.path.normcase(str(a)) != os.path.normcase(str(here))]
    if not others or not load_settings().archive.years:
        return
    console.print("\n  Move them to:")
    for i, folder in enumerate(others, 1):
        years = archive_years(folder)
        console.print(f"   [bold]{i}[/bold]  {folder.name}  ({years[0]}-{years[1]})  {folder}")
    pick = Prompt.ask("  Which? (number, Enter to stop)", default="").strip()
    if pick.isdigit() and 1 <= int(pick) <= len(others):
        split(to=others[int(pick) - 1], years=None, yes=False)


def _dates() -> None:
    """Give a date to each intake folder whose photos have none, then offer to process intake."""
    from mindit.commands.date_cli import undated_by_folder  # pylint: disable=import-outside-toplevel
    from mindit.services.dates.user_dates import DateError, parse_when, set_dates, update_index  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel

    intake = default_layout().intake_root
    console.print(f"  Looking for photos and documents with no sure date in {intake} ...")
    found = undated_by_folder(intake)
    if not found:
        console.print("  Every photo and document in intake has a sure date.")
        return
    console.print("  For each folder, type the date its photos were taken: 1998, 1998-07 or 1998-07-04.")
    console.print("  Enter skips a folder; q stops. (One photo at a time: da date set <photo> --date ...)")
    changed: dict[str, str | None] = {}
    for folder, files in found.items():
        where = _rel(str(folder), intake)
        while True:
            answer = Prompt.ask(f"  {where}  ({len(files):,}, e.g. {files[0].name})", default="").strip()
            if not answer or answer.lower() == "q":
                break
            try:
                when, precision = parse_when(answer)
            except DateError as error:
                console.print(f"  {error}")
                continue
            changed.update(set_dates(files, when, precision, answer).changed)
            break
        if answer.lower() == "q":
            break
    if not changed:
        return
    update_index(resolve_database_path(), changed)
    console.print(f"  Dates set on {len(changed):,} file{'s' if len(changed) != 1 else ''}.")
    if Confirm.ask("  Process intake now, so they're filed by these dates?", default=True):
        _process()


def _sidecars() -> None:
    """Show which sidecars are out of date and offer to upgrade them (a copy of each is kept)."""
    from mindit.commands.sidecar_cli import upgrade  # pylint: disable=import-outside-toplevel

    upgrade(folder=None, yes=False, restore_from=None)


def _merge() -> None:
    """Pick another copy of this archive (or type its folder) and copy in what it has that this one doesn't."""
    from mindit.commands.workflow_cli import merge  # pylint: disable=import-outside-toplevel

    here = get_archive_root()
    others = [a for a in known_archives() if os.path.normcase(str(a)) != os.path.normcase(str(here))]
    console.print("  Copy into this archive what another copy of it has (that one isn't changed).")
    for i, folder in enumerate(others, 1):
        console.print(f"   [bold]{i}[/bold]  {folder}")
    answer = Prompt.ask("  From which? (number or folder, Enter to go back)", default="").strip().strip('"')
    if not answer:
        return
    other = others[int(answer) - 1] if answer.isdigit() and 1 <= int(answer) <= len(others) else Path(answer)
    if not other.is_dir():
        console.print(f"  No such folder: {other}")
        return
    merge(other=other, yes=False)


def _report() -> None:
    """Make this archive's one-page PDF report and open it."""
    from mindit.commands.workflow_cli import _interactive, report  # pylint: disable=import-outside-toplevel

    report(open_it=_interactive(), refresh=False)       # a script or test gets the file, not a window


def _user_guide() -> None:
    from mindit.commands.workflow_cli import guide  # pylint: disable=import-outside-toplevel

    guide(pdf=False)


def _status() -> None:
    from mindit.commands.workflow_cli import status  # pylint: disable=import-outside-toplevel

    status(title=False)


def _review() -> None:
    """List what the last run left behind, by reason, with examples; write the full list to review.csv."""
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel

    layout = default_layout()
    runs = sorted((layout.output_root / "runs").glob("*-run/summary.json")) if (layout.output_root / "runs").exists() else []
    report_path = None
    for summary in reversed(runs):
        data = json.loads(summary.read_text(encoding="utf-8"))
        report_path = (data.get("steps", {}).get("4_preview") or {}).get("report")
        if report_path and Path(report_path).exists():
            break
    if not report_path:
        console.print("  No run yet - choose 1 Process intake first.")
        return
    report = json.loads(Path(report_path).read_text(encoding="utf-8"))
    rows = [p for p in report.get("problems", []) if p.get("code") in REVIEW_CODES]
    if not rows:
        console.print("  Nothing needs review from the last run.")
        return
    root = get_archive_root() or layout.data_root
    by_code = Counter(p["code"] for p in rows)
    for code, n in by_code.most_common():
        console.print(f"\n  [bold]{REVIEW_CODES[code]}[/bold]: {n:,}")
        for p in [p for p in rows if p["code"] == code][:5]:
            console.print(f"     {_rel(p.get('file_path'), root)}")
        if n > 5:
            console.print(f"     ... and {n - 5:,} more")
    out = Path(report_path).parent / "review.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["reason", "file", "detail"])
        for p in rows:
            w.writerow([REVIEW_CODES[p["code"]], p.get("file_path"), p.get("message")])
    console.print(f"\n  Full list: {out}")


def _rel(path: str | None, root: Path) -> str:
    if not path:
        return "?"
    try:
        return str(Path(path).relative_to(root))
    except ValueError:
        return path


def _undo_last() -> None:
    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout, undo_set_aside  # pylint: disable=import-outside-toplevel

    layout = default_layout()
    logs = sorted((layout.output_root / "runs").glob("*/set-aside-moved.csv")) + \
        sorted((layout.output_root / "runs").glob("*-set-aside/moved.csv"))
    if not logs:
        console.print("  No duplicate set-aside to undo.")
        return
    last = max(logs, key=lambda p: p.stat().st_mtime)
    with last.open(encoding="utf-8") as f:
        moved = sum(1 for r in csv.DictReader(f) if r["result"] == "moved")
    if not Confirm.ask(f"  Put {moved:,} files back where they were (from {last.parent.name})?", default=False):
        return
    stats = undo_set_aside(DbitService(resolve_database_path()), last)
    console.print(f"  Restored {stats['restored']:,}; skipped {stats['skipped']:,}.")


def _refresh() -> None:
    from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel

    console.print("  Indexing the archive ...")
    result = ArchiveIndexService(DbitService(resolve_database_path())).build(
        default_areas(), progress=lambda m: console.print(f"    {m}"))
    for area, s in result.as_dict()["areas"].items():
        console.print(f"    {area:10} {s['files']:>9,} files  {s['gb']:>8,} GB")


def _choose_archive(first_time: bool) -> bool:
    """Pick one of this PC's archives (or create one). Returns False when the user backs out."""
    found = known_archives()
    if first_time:
        console.print("You're not inside an archive.")
    if not found:
        console.print("There are no archives on this PC yet.")
        if Confirm.ask("Create one now?", default=True):
            return _new_archive()
        return False
    list_archives()
    pick = Prompt.ask("  Open which? (number, N for a new one, Enter to cancel)", default="").strip().lower()
    if pick == "n":
        return _new_archive()
    if pick.isdigit() and 1 <= int(pick) <= len(found):
        set_archive_root(found[int(pick) - 1])
        return True
    return False


def list_archives() -> list[Path]:
    """Print this PC's archives (name, years, folder) and return them."""
    from mindit.commands.workflow_cli import _archive_label  # pylint: disable=import-outside-toplevel

    found = known_archives()
    here = get_archive_root()
    for i, folder in enumerate(found, 1):
        name, years = _archive_label(folder)
        mark = "  <- open now" if here and os.path.normcase(str(folder)) == os.path.normcase(str(here)) else ""
        console.print(f"  [bold]{i}[/bold]  {name:28} years {years:10} {folder}{mark}")
    return found


def _new_archive() -> bool:
    from mindit.services.workflow.archive_setup import inspect_target, parse_years, setup_archive  # pylint: disable=import-outside-toplevel

    if known_archives():
        console.print("  Archives on this PC already:")
        list_archives()
        console.print("  (To open one of these, use 6 Switch archive.)")
    folder = Prompt.ask("  Archive folder (e.g. D:\\jane-archive-202x)", default="").strip().strip('"')
    if not folder:
        return False
    years = Prompt.ask("  Years it takes, like 2020-2029 (Enter for any)", default="").strip() or None
    try:
        parse_years(years)
    except ValueError as exc:
        console.print(f"  {exc}")
        return False
    state = inspect_target(Path(folder))
    if state.kind == "folder":
        console.print(f"  {state.root} already has {len(state.items)} items: "
                      + ", ".join(i.name for i in state.items[:8]) + (" ..." if len(state.items) > 8 else ""))
        if not Confirm.ask("  Make it an archive and move these into intake\\?", default=False):
            return False
    elif state.kind == "archive" and not Confirm.ask("  That's already an archive. Use it?", default=True):
        return False
    result = setup_archive(Path(folder), years=years)
    set_archive_root(result.root)
    console.print(f"  Archive ready: {result.root}" + (f" ({len(result.moved)} items moved into intake\\)" if result.moved else ""))
    return True
