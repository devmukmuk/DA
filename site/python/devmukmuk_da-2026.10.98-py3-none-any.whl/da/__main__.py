# src/da/__main__.py
"""Run DA with `python -m da ...`, the same as `da ...` and `python -m mindit ...`."""

from mindit.__main__ import main

if __name__ == "__main__":
    main()
