"""DA's import name: `python -m da` runs the CLI (the code lives in the mindit package)."""
# src/da/__init__.py

from mindit import __app_name__, __version__

__all__ = ["__app_name__", "__version__"]
