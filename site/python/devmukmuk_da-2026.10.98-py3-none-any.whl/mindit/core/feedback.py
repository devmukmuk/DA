# src/mindit/core/feedback.py

"""Chimes when a command starts and ends: --feedback / --no-feedback on any command, else the archive's setting."""

from __future__ import annotations

from typing import Any

from mindit.utils.feedback import chime_done, chime_start

FLAGS = {"--feedback": True, "--no-feedback": False}
LONG_ENOUGH = 60                                     # seconds: the setting chimes only after a command this long
QUIET_COMMANDS = {None, "menu", "dashboard", "guide"}   # open until you close them; a chime then says nothing


def take_flag(argv: list[str]) -> tuple[list[str], bool | None]:
    """Return argv without --feedback / --no-feedback, and the last one given (None: neither)."""
    choice = None
    kept = []
    for arg in argv:
        if arg in FLAGS:
            choice = FLAGS[arg]
        else:
            kept.append(arg)
    return kept, choice


def _settings(settings: Any) -> tuple[bool, bool, bool]:
    feedback = getattr(settings, "feedback", None)
    return (bool(getattr(feedback, "enabled", False)), bool(getattr(feedback, "chime_start", True)),
            bool(getattr(feedback, "chime_done", True)))


def started(flag: bool | None, settings: Any) -> None:
    """Chime as a command starts: only when --feedback asked for it."""
    if flag:
        chime_start(_settings(settings)[1])


def ended(flag: bool | None, settings: Any, command: str | None, seconds: float) -> None:
    """Chime as a command ends: --feedback always, feedback.enabled after a long one, --no-feedback never."""
    enabled, _start, done = _settings(settings)
    if flag is None:
        flag = enabled and seconds >= LONG_ENOUGH and command not in QUIET_COMMANDS
    if flag:
        chime_done(done)
