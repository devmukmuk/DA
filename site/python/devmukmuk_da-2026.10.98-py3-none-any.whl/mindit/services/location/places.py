# src/mindit/services/location/places.py

"""Where a photo was taken, in words: its GPS position turned into a town and state.

Positions are rounded to a *spot* (3 decimals, about 100 m) and each spot is looked up once, through
OpenStreetMap's free Nominatim service, then remembered in the archive's index (the `places` table).
The place goes into the photo's sidecar as a "location" block and gives it place:, state: and country:
tags. Only the spot (never the photo) is sent, and `location.lookup: off` in da-archive.yaml stops it.
"""

from __future__ import annotations

import json
import sqlite3
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Protocol

from mindit.services.tagging.tags import AUTO_BLOCK, PLACE_TAG_LABELS, all_tags, slug

LOCATION_BLOCK = "location"
PLACE_FIELDS = ("street", "neighbourhood", "city", "county", "state", "state_code",
                "country", "country_code", "postcode")
NOMINATIM_URL = "https://nominatim.openstreetmap.org/reverse"

PLACES_SQL = """
CREATE TABLE IF NOT EXISTS places (
    spot TEXT PRIMARY KEY,
    street TEXT, neighbourhood TEXT, city TEXT, county TEXT, state TEXT, state_code TEXT,
    country TEXT, country_code TEXT, postcode TEXT,
    display TEXT,
    source TEXT,
    looked_up_at TEXT
);
"""


CERTIFICATE_PROBLEM = "this PC couldn't check the lookup service's security certificate"


class LookupUnavailable(Exception):
    """The lookup service couldn't be reached (no internet, or it's busy)."""

    @property
    def certificate(self) -> bool:
        """Whether a certificate check failed, which waiting won't fix."""
        return CERTIFICATE_PROBLEM in str(self)


def what_to_do(stopped: str | None, again: str = "Run `da location lookup` again later.") -> str:
    """Return what to tell the user when lookups stopped: try again later, or (a certificate) what to change."""
    if stopped and CERTIFICATE_PROBLEM in stopped:
        return ("Waiting won't fix this. Usually an antivirus that checks secure connections (turn off its HTTPS "
                "or web-shield scanning, or allow nominatim.openstreetmap.org), or a work or school network, is "
                "in the way. The guide's If something goes wrong has more.")
    return again


class Geocoder(Protocol):  # pylint: disable=too-few-public-methods
    """Something that turns a position into a place (None: nowhere with a name, e.g. the sea)."""

    def reverse(self, lat: float, lon: float) -> dict[str, Any] | None:
        """Return the place at a position."""


# --------------------------------------------------------------------------- positions and spots

def position(sidecar: dict[str, Any]) -> tuple[float, float] | None:
    """Return the photo's (latitude, longitude) from its sidecar, or None."""
    for block in ("camera", "photoit"):
        value = sidecar.get(block)
        gps = value.get("gps") if isinstance(value, dict) else None
        if isinstance(gps, dict):
            try:
                lat, lon = float(gps["latitude"]), float(gps["longitude"])
            except (KeyError, TypeError, ValueError):
                continue
            if -90 <= lat <= 90 and -180 <= lon <= 180 and (lat, lon) != (0.0, 0.0):
                return lat, lon
    return None


def spot_key(lat: float, lon: float, digits: int = 3) -> str:
    """Return the spot a position falls in: '28.642,-81.208' (3 digits = about 100 m)."""
    return f"{round(lat, digits):.{digits}f},{round(lon, digits):.{digits}f}"


def spot_position(spot: str) -> tuple[float, float]:
    """Return the middle of a spot, the position actually sent for lookup."""
    lat, lon = spot.split(",")
    return float(lat), float(lon)


# --------------------------------------------------------------------------- places

def parse_nominatim(data: dict[str, Any]) -> dict[str, Any] | None:
    """Return a place from a Nominatim reverse answer, or None when nothing is there."""
    address = data.get("address") if isinstance(data, dict) else None
    if not isinstance(address, dict) or not address:
        return None
    region = address.get("ISO3166-2-lvl4") or address.get("ISO3166-2-lvl6") or ""
    country_code = (address.get("country_code") or "").lower() or None
    state_code = None
    if "-" in region and region.split("-", 1)[0].lower() == (country_code or ""):
        state_code = region.split("-", 1)[1].upper()
    place = {
        "street": address.get("road") or address.get("pedestrian") or address.get("footway"),
        "neighbourhood": address.get("neighbourhood") or address.get("suburb") or address.get("quarter"),
        "city": (address.get("city") or address.get("town") or address.get("village")
                 or address.get("hamlet") or address.get("municipality")),
        "county": address.get("county"),
        "state": address.get("state") or address.get("region"),
        "state_code": state_code,
        "country": address.get("country"),
        "country_code": country_code,
        "postcode": address.get("postcode"),
        "display": data.get("display_name"),
    }
    return place if any(place[f] for f in PLACE_FIELDS) else None


def place_name(place: dict[str, Any] | None) -> str | None:
    """Return the short place name used in tags and folders: 'springfield-il', or 'paris-fr' outside the US."""
    if not place:
        return None
    city = place.get("city") or place.get("county") or place.get("state")
    region = place.get("state_code") if (place.get("country_code") or "us") == "us" else place.get("country_code")
    parts = [slug(p) for p in (city, region) if p]
    return "-".join(p for p in parts if p) or None


def place_tags(place: dict[str, Any] | None) -> list[str]:
    """Return a place's tags: place:springfield-il, state:il, country:us."""
    if not place:
        return []
    tags = []
    name = place_name(place)
    if name:
        tags.append(f"place:{name}")
    state = place.get("state_code") or place.get("state")
    if state:
        tags.append(f"state:{slug(state)}")
    if place.get("country_code"):
        tags.append(f"country:{slug(place['country_code'])}")
    return tags


def with_place_tags(tags: list[str], place: dict[str, Any] | None) -> list[str]:
    """Return automatic tags with any old place tags swapped for this place's."""
    kept = [t for t in tags if t.partition(":")[0] not in PLACE_TAG_LABELS]
    return kept + place_tags(place)


# --------------------------------------------------------------------------- the lookup service

def user_agent() -> str:
    """Return the User-Agent Nominatim's usage policy asks for: the application and where to read about it."""
    from mindit import __version__  # pylint: disable=import-outside-toplevel

    return f"DA/{__version__} (https://da.gamenightbymike.com)"


class NominatimGeocoder:
    """OpenStreetMap's free lookup: at most one request a second, a real User-Agent, answers in English."""

    def __init__(self, *, url: str = NOMINATIM_URL, interval: float = 1.0, timeout: float = 20.0,
                 opener: Callable[..., Any] | None = None, sleep: Callable[[float], None] = time.sleep,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self.url, self.interval, self.timeout = url, interval, timeout
        self._open = opener or urllib.request.urlopen
        self._sleep, self._clock = sleep, clock
        self._last: float | None = None

    def reverse(self, lat: float, lon: float) -> dict[str, Any] | None:
        """Return the place at a position, or None; raise LookupUnavailable when the service can't answer."""
        return parse_nominatim(self._get(self.url, {"lat": f"{lat}", "lon": f"{lon}", "zoom": 18}))

    def search(self, text: str) -> tuple[dict[str, Any], float, float] | None:
        """Return the place a name means ("Springfield, IL") and its position, or None when it isn't found."""
        found = self._get(self.url.rsplit("/", 1)[0] + "/search", {"q": text, "limit": 1})
        if not isinstance(found, list) or not found:
            return None
        place = parse_nominatim(found[0])
        try:
            return (place, float(found[0]["lat"]), float(found[0]["lon"])) if place else None
        except (KeyError, TypeError, ValueError):
            return None

    def _get(self, url: str, params: dict[str, Any]) -> Any:
        if self._last is not None:
            wait = self.interval - (self._clock() - self._last)
            if wait > 0:
                self._sleep(wait)
        query = urllib.parse.urlencode({"format": "jsonv2", "addressdetails": 1, **params})
        request = urllib.request.Request(f"{url}?{query}",
                                         headers={"User-Agent": user_agent(), "Accept-Language": "en"})
        try:
            with self._open(request, timeout=self.timeout) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            raise LookupUnavailable(f"the lookup service answered {error.code}") from error
        except (urllib.error.URLError, OSError, ValueError) as error:
            if isinstance(getattr(error, "reason", error), ssl.SSLCertVerificationError):
                raise LookupUnavailable(f"{CERTIFICATE_PROBLEM} ({getattr(error, 'reason', error)})") from error
            raise LookupUnavailable(f"couldn't reach the lookup service ({error})") from error
        finally:
            self._last = self._clock()


# --------------------------------------------------------------------------- the spot cache

class PlaceCache:
    """The archive's remembered spots (the `places` table in its index), so each is looked up once."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript(PLACES_SQL)
        self._known: dict[str, dict[str, Any] | None] = {}
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            for row in conn.execute("SELECT * FROM places"):
                self._known[row["spot"]] = _row_place(row)

    def __contains__(self, spot: str) -> bool:
        return spot in self._known

    def get(self, spot: str) -> dict[str, Any] | None:
        """Return the place remembered for a spot (None: unknown, or nowhere with a name)."""
        return self._known.get(spot)

    def put(self, spot: str, place: dict[str, Any] | None, source: str = "nominatim") -> None:
        """Remember a spot's place; None remembers that nothing is there, so it isn't asked again."""
        self._known[spot] = place
        values = [(place or {}).get(f) for f in PLACE_FIELDS]
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                f"INSERT OR REPLACE INTO places (spot, {', '.join(PLACE_FIELDS)}, display, source, looked_up_at) "
                f"VALUES ({', '.join('?' * (len(PLACE_FIELDS) + 4))})",
                (spot, *values, (place or {}).get("display"), source, _now()))


def _row_place(row: sqlite3.Row) -> dict[str, Any] | None:
    place = {f: row[f] for f in PLACE_FIELDS}
    if not any(place.values()):
        return None
    place["display"] = row["display"]
    return place


# --------------------------------------------------------------------------- looking up photos

@dataclass
class LookupResult:  # pylint: disable=too-many-instance-attributes
    """What a lookup run did."""

    files: int = 0
    with_gps: int = 0
    placed: int = 0                 # photos that now have a place
    manual: int = 0                 # photos whose place was set by hand (left alone)
    looked_up: int = 0              # spots asked of the service this run
    no_place: int = 0               # photos at a spot with no name (the sea, the wilderness)
    waiting: int = 0                # photos left without a place because the service couldn't be reached
    stopped: str | None = None      # why lookups stopped early
    places: dict[str, int] = field(default_factory=dict)     # place name -> photos
    changed: dict[str, dict[str, Any]] = field(default_factory=dict)  # path -> index columns + tags


def spots_to_look_up(photos: list[Path], cache: PlaceCache, *, digits: int = 3) -> tuple[int, int]:
    """Return (photos with GPS, new spots) so the user can be told how long a lookup will take."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    with_gps, spots = 0, set()
    for photo in photos:
        if not SidecarService.sidecar_path_for(photo).exists():
            continue
        pos = position(SidecarService.load(photo))
        if pos:
            with_gps += 1
            spot = spot_key(*pos, digits)
            if spot not in cache:
                spots.add(spot)
    return with_gps, len(spots)


def lookup_places(photos: list[Path], geocoder: Geocoder | None, cache: PlaceCache, *, digits: int = 3,
                  force: bool = False, progress: Callable[[int, int], None] | None = None) -> LookupResult:
    """Give each photo with a position its place (from the cache, else the service) and place tags.

    geocoder None: use only spots already remembered. A place set by hand is never replaced. If the
    service can't be reached twice in a row, lookups stop for this run and those photos wait for the next.
    """
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    result = LookupResult(files=len(photos))
    asked: set[str] = set()                      # spots asked this run (force asks each one once)
    failures = 0
    for i, photo in enumerate(photos, 1):
        if progress:
            progress(i, len(photos))
        if not SidecarService.sidecar_path_for(photo).exists():
            continue
        data = SidecarService.load(photo)
        pos = position(data)
        if pos is None:
            continue
        result.with_gps += 1
        block = data.get(LOCATION_BLOCK) if isinstance(data.get(LOCATION_BLOCK), dict) else {}
        if block.get("source") == "manual":
            result.manual += 1
            _count(result, block.get("place"))
            continue
        spot = spot_key(*pos, digits)
        if spot in cache and not (force and spot not in asked):
            place = cache.get(spot)
        elif geocoder is None or result.stopped:
            result.waiting += 1
            continue
        else:
            try:
                place = geocoder.reverse(*spot_position(spot))
            except LookupUnavailable as error:
                failures += 1
                result.waiting += 1
                if failures >= 2 or error.certificate:
                    result.stopped = str(error)
                continue
            failures = 0
            asked.add(spot)
            result.looked_up += 1
            cache.put(spot, place)
        if place is None:
            result.no_place += 1
        _count(result, place)
        clean = {f: (place or {}).get(f) for f in PLACE_FIELDS} if place else None
        new_block = {**block, "spot": spot, "place": clean, "source": "lookup",
                     "updated_at": block.get("updated_at")}
        auto = data.get(AUTO_BLOCK) if isinstance(data.get(AUTO_BLOCK), dict) else {}
        new_tags = with_place_tags(list(auto.get("tags") or []), place)
        if {k: v for k, v in new_block.items() if k != "updated_at"} != \
                {k: v for k, v in block.items() if k != "updated_at"} or new_tags != (auto.get("tags") or []):
            new_block["updated_at"] = _now()
            data[LOCATION_BLOCK] = new_block
            data[AUTO_BLOCK] = {**auto, "tags": new_tags}
            SidecarService.save(photo, data)
        result.changed[str(photo)] = index_columns(data)
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("location_lookup", f"{result.placed} of {result.with_gps} GPS photos have a place; "
              f"{result.looked_up} spots looked up, {result.waiting} waiting"
              + (f" ({result.stopped})" if result.stopped else ""))
    return result


def place_of(sidecar: dict[str, Any]) -> tuple[dict[str, Any] | None, tuple[float, float] | None]:
    """Return a sidecar's place and its position (the photo's GPS, else the position set with the place)."""
    block = sidecar.get(LOCATION_BLOCK) if isinstance(sidecar.get(LOCATION_BLOCK), dict) else {}
    place = block.get("place") if isinstance(block.get("place"), dict) else None
    return place, position(sidecar) or manual_position(sidecar)


def manual_position(sidecar: dict[str, Any]) -> tuple[float, float] | None:
    """Return the position kept with a place set by hand (for a photo with no GPS of its own), or None."""
    block = sidecar.get(LOCATION_BLOCK) if isinstance(sidecar.get(LOCATION_BLOCK), dict) else {}
    pos = block.get("position") if isinstance(block.get("position"), dict) else {}
    try:
        return float(pos["latitude"]), float(pos["longitude"])
    except (KeyError, TypeError, ValueError):
        return None


def set_places(files: list[Path], place: dict[str, Any] | None,
               where: tuple[float, float] | None = None) -> dict[str, dict[str, Any]]:
    """Set (or, with place None, clear) a place by hand on each file; return the index changes.

    A place set by hand is marked `source: manual`, so lookups never replace it. A photo with no GPS keeps
    the place's position too, so `da location group` can put it with photos taken nearby. Clearing leaves
    the photo for the next `da location lookup`. Titles (from location folders) are kept.
    """
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    changed: dict[str, dict[str, Any]] = {}
    clean = {f: place.get(f) for f in PLACE_FIELDS} if place else None
    for path in files:
        data = SidecarService.load(path)
        block = data.get(LOCATION_BLOCK) if isinstance(data.get(LOCATION_BLOCK), dict) else {}
        kept = {k: v for k, v in block.items() if k in ("title", "group")}
        if clean:
            block = {**kept, "place": clean, "source": "manual", "updated_at": _now()}
            if where and position(data) is None:
                block["position"] = {"latitude": round(where[0], 6), "longitude": round(where[1], 6)}
        else:
            block = {**kept, "updated_at": _now()} if kept else {}
        if block:
            data[LOCATION_BLOCK] = block
        else:
            data.pop(LOCATION_BLOCK, None)
        auto = data.get(AUTO_BLOCK) if isinstance(data.get(AUTO_BLOCK), dict) else {}
        data[AUTO_BLOCK] = {**auto, "tags": with_place_tags(list(auto.get("tags") or []), clean)}
        SidecarService.save(path, data)
        changed[str(path)] = index_columns(data)
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("location_set", f"place {'cleared' if not clean else place_name(clean)} on {len(changed)} photos")
    return changed


def _count(result: LookupResult, place: dict[str, Any] | None) -> None:
    name = place_name(place)
    if name:
        result.placed += 1
        result.places[name] = result.places.get(name, 0) + 1


def index_columns(sidecar: dict[str, Any]) -> dict[str, Any]:
    """Return the index's place columns (city, state_code, country_code, title) and tags for a sidecar."""
    block = sidecar.get(LOCATION_BLOCK) if isinstance(sidecar.get(LOCATION_BLOCK), dict) else {}
    place = block.get("place") if isinstance(block.get("place"), dict) else {}
    tags = all_tags(sidecar)
    return {"city": place.get("city"), "state_code": place.get("state_code"),
            "country_code": place.get("country_code"), "title": block.get("title"),
            "tags": json.dumps(tags) if tags else None}


def update_index(db_path: Path, changed: dict[str, dict[str, Any]]) -> int:
    """Write the new places and tags into the index rows of those files; return how many rows matched."""
    if not changed or not Path(db_path).exists():
        return 0
    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel

    DbitService(db_path).initialize(log=False)          # adds the place columns to an older index
    with sqlite3.connect(db_path) as conn:
        before = conn.total_changes
        conn.executemany(
            "UPDATE files SET city = ?, state_code = ?, country_code = ?, title = ?, tags = ? WHERE path = ?",
            [(c["city"], c["state_code"], c["country_code"], c["title"], c["tags"], path)
             for path, c in changed.items()])
        return conn.total_changes - before


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")
