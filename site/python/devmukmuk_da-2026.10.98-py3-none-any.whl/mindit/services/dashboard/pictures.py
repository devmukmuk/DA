# src/mindit/services/dashboard/pictures.py

"""The dashboard's pictures: what's filed by month, small pictures of them, the full file, and two actions.

Files are only ever found through the index (by its row id), and only filed ones (photos and documents areas)
inside the archive's own folder - never a path the browser names. Documents set aside by `da find --passwords`
are out of the index, so they never show. Thumbnails are the contact sheets' (.da\\thumbs, by SHA-256).
"""

from __future__ import annotations

import io
import json
import os
import sqlite3
import subprocess
from pathlib import Path
from typing import Any

AREAS = ("photos", "documents")
KINDS = ("photo", "video", "document")
LATEST = 60                              # pictures shown for "latest filed"
PER_FOLDER = 400                         # at most this many in one month
ENLARGED = 2400                          # px on the long side of a HEIC turned into JPEG to look at
TYPES = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif",
         ".webp": "image/webp", ".bmp": "image/bmp", ".pdf": "application/pdf", ".mp4": "video/mp4",
         ".m4v": "video/mp4", ".mov": "video/quicktime", ".webm": "video/webm"}


def _connect(db_path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{Path(db_path).as_posix()}?mode=ro", uri=True, timeout=5)


def folders(db_path: Path) -> list[dict[str, Any]]:
    """Return the filed folders with how many pictures each holds, newest first."""
    if not Path(db_path).exists():
        return []
    with _connect(db_path) as conn:
        rows = conn.execute(
            "SELECT area, folder, COUNT(*) FROM files WHERE area IN (?, ?) AND media_type IN (?, ?, ?) "
            "GROUP BY area, folder ORDER BY folder DESC, area", (*AREAS, *KINDS)).fetchall()
    return [{"area": a, "folder": f or "", "count": n} for a, f, n in rows]


def items(db_path: Path, area: str | None = None, folder: str | None = None) -> list[dict[str, Any]]:
    """Return one folder's pictures (or the latest filed when no folder), for the grid."""
    if not Path(db_path).exists():
        return []
    sql = ("SELECT rowid, file_name, media_type, captured_at, area, folder, path FROM files "
           "WHERE area IN (?, ?) AND media_type IN (?, ?, ?)")
    args: list[Any] = [*AREAS, *KINDS]
    if area in AREAS and folder is not None:
        sql += " AND area = ? AND COALESCE(folder, '') = ? ORDER BY captured_at, file_name LIMIT ?"
        args += [area, folder, PER_FOLDER]
    else:
        sql += " ORDER BY indexed_at DESC, rowid DESC LIMIT ?"
        args.append(LATEST)
    with _connect(db_path) as conn:
        rows = conn.execute(sql, args).fetchall()
    return [{"id": r[0], "name": r[1], "kind": r[2], "when": (r[3] or "").replace("T", " ")[:16], "area": r[4],
             "folder": r[5] or "", "family": _family(r[6])} for r in rows]


def _family(path: str | None) -> str:
    """Return the photo's home and ages (its sidecar's `life` block, one line), or ''."""
    from mindit.services.family.life import describe  # pylint: disable=import-outside-toplevel

    try:
        data = json.loads(Path(f"{path}.meta.json").read_text(encoding="utf-8")) if path else None
    except (OSError, ValueError):
        return ""
    return describe(data) if isinstance(data, dict) else ""


def find(db_path: Path, archive: Path, rowid: int) -> tuple[Path, str, str | None] | None:
    """Return (path, kind, sha256) of a filed picture by its index row, only if it's in the archive."""
    if not Path(db_path).exists():
        return None
    with _connect(db_path) as conn:
        row = conn.execute("SELECT path, media_type, sha256, area FROM files WHERE rowid = ?", (rowid,)).fetchone()
    if not row or row[3] not in AREAS or row[1] not in KINDS:
        return None
    path = Path(row[0])
    try:
        path.resolve().relative_to(Path(archive).resolve())
    except ValueError:
        return None
    return (path, row[1], row[2]) if path.is_file() else None


def thumbnail(path: Path, kind: str, sha256: str | None) -> bytes | None:
    """Return a small JPEG of a photo or a document (a scan, or a PDF's first page image); None for the rest."""
    from mindit.services.contactsheet import contact_sheet as cs  # pylint: disable=import-outside-toplevel

    suffix = path.suffix.lower()
    if kind == "video":
        return None
    if suffix == ".pdf":
        return _pdf_preview(path)
    if suffix not in cs.IMAGE_EXTENSIONS:
        return None
    archive = cs.thumbs_dir(path.parent)
    cached = archive / sha256[:2] / f"{sha256}.jpg" if archive and sha256 else None
    if cached and cached.exists():
        return cached.read_bytes()
    small = cs._small_copy(path, (cs.THUMB_SIZE, cs.THUMB_SIZE))  # pylint: disable=protected-access
    if small is None:
        return None
    data = small.getvalue()
    if cached:
        try:
            cached.parent.mkdir(parents=True, exist_ok=True)
            part = cached.with_name(cached.name + ".part")
            part.write_bytes(data)
            os.replace(part, cached)
        except OSError:
            pass
    return data


def _pdf_preview(path: Path) -> bytes | None:
    """Return a small JPEG of a scanned PDF's first page (its picture), or None for a text PDF."""
    import logging  # pylint: disable=import-outside-toplevel

    from PIL import Image  # pylint: disable=import-outside-toplevel
    from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

    logging.getLogger("pypdf").setLevel(logging.ERROR)
    try:
        page = PdfReader(path, strict=False).pages[0]
        images = list(page.images)
        if not images:
            return None
        with Image.open(io.BytesIO(images[0].data)) as img:
            img.thumbnail((400, 400))
            out = io.BytesIO()
            img.convert("RGB").save(out, "JPEG", quality=80)
        return out.getvalue()
    except Exception:  # pylint: disable=broad-except
        return None


def full(path: Path) -> tuple[bytes | None, str]:
    """Return (bytes, type) to look at a file in the browser: a HEIC turned into JPEG, others as they are.

    Returns (None, type) for a file to be streamed from disk as it is.
    """
    suffix = path.suffix.lower()
    if suffix in (".heic", ".heif", ".tif", ".tiff"):
        from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

        try:
            from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

            register_heif_opener()
        except ImportError:
            pass
        with Image.open(path) as img:
            img = ImageOps.exif_transpose(img)
            img.thumbnail((ENLARGED, ENLARGED))
            out = io.BytesIO()
            img.convert("RGB").save(out, "JPEG", quality=88)
        return out.getvalue(), "image/jpeg"
    return None, TYPES.get(suffix, "application/octet-stream")


def wallpaper_copy(path: Path, archive: Path) -> Path:
    """Write a JPEG of a photo for the desktop (.da\\wallpaper.jpg) and return it."""
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    try:
        from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

        register_heif_opener()
    except ImportError:
        pass
    target = Path(archive) / ".da" / "wallpaper.jpg"
    target.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(path) as img:
        img = ImageOps.exif_transpose(img)
        img.thumbnail((3840, 3840))
        img.convert("RGB").save(target, "JPEG", quality=92)
    return target


def set_desktop(picture: Path) -> None:
    """Make picture this PC's desktop background (Windows)."""
    if os.name != "nt":
        raise OSError("setting the desktop needs Windows")
    import ctypes  # pylint: disable=import-outside-toplevel

    spi_setdeskwallpaper, update_and_send = 20, 3
    if not ctypes.windll.user32.SystemParametersInfoW(spi_setdeskwallpaper, 0, str(picture), update_and_send):
        raise OSError("Windows didn't take it as the desktop background")


def open_folder(path: Path) -> None:
    """Open File Explorer at the file, selected."""
    if os.name != "nt":
        raise OSError("opening File Explorer needs Windows")
    subprocess.Popen(["explorer", "/select,", str(path)])  # pylint: disable=consider-using-with
