# src/mindit/services/templates/draft.py

"""`da template new`: draft a template from a few sample documents (you check it, then edit what it missed)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from mindit.services.templates.reading import has_phrase, normalize, read_field
from mindit.services.templates.template import Field

# What a bill or statement usually prints: a field's name, the labels it goes by (most particular first), its type.
VOCABULARY: tuple[tuple[str, tuple[str, ...], str], ...] = (
    ("date", ("bill date", "statement date", "invoice date", "billing date", "date of bill", "date issued",
              "issue date", "statement closing date", "pay date", "date"), "date"),
    ("account", ("account number", "account no", "account #", "acct number", "acct no", "acct #", "customer number",
                 "member number", "policy number", "account"), "account"),
    ("name", ("customer name", "account name", "account holder", "employee name", "prepared for", "bill to"), "text"),
    ("address", ("service address", "service location", "property address", "mailing address"), "lines"),
    ("pay_period", ("billing period", "service period", "billing cycle", "statement period", "pay period",
                    "service from", "for service"), "period"),
    ("amount", ("total amount due", "amount due", "total due", "balance due", "new balance", "amount to pay",
                "net pay", "please pay"), "money"),
    ("due_date", ("due date", "payment due", "please pay by", "pay by", "due by"), "date"),
    ("invoice", ("invoice number", "invoice #", "invoice no", "bill number", "statement number"), "account"),
)


@dataclass
class Draft:
    """A template drafted from samples, before it's written."""

    name: str
    title: str
    phrases: list[str] = field(default_factory=list)
    fields: list[tuple[Field, int]] = field(default_factory=list)        # the field and how many samples it read
    samples: int = 0


def common_lines(texts: list[str]) -> list[str]:
    """Return lines every sample prints that could name the company (letters, no digits, short), first sample's order."""
    if not texts:
        return []
    labels = {label for _n, labels, _t in VOCABULARY for label in labels}
    out: list[str] = []
    for line in texts[0].split("\n"):
        words = line.strip()
        if not 4 <= len(words) <= 40 or re.search(r"\d", words) or len(re.findall(r"[A-Za-z]", words)) < 4:
            continue
        if words.lower().strip(" :#") in labels or words in out:
            continue
        if all(has_phrase(t, words) for t in texts[1:]):
            out.append(words)
    return out


def draft(name: str, texts: list[str], title: str | None = None) -> Draft:
    """Draft a template from samples' text: the company's lines they share, and the usual fields they all have."""
    texts = [normalize(t) for t in texts if t and t.strip()]
    lines = common_lines(texts)
    out = Draft(name=name, title=title or (lines[0] if lines else name), samples=len(texts))
    if title and texts and all(has_phrase(t, title) for t in texts):
        out.phrases = [title]                         # the name you gave is printed on every sample
    else:
        out.phrases = lines[:1]
    for field_name, labels, kind in VOCABULARY:
        # Most particular label first ("Total amount due" before "Amount due", which a "Previous amount due" line
        # has too); another label only when it reads a sample the ones before it didn't (a second layout).
        used: list[str] = []
        covered: set[int] = set()
        for label in labels:
            spec = Field(name=field_name, labels=(label,), type=kind, lines=2)
            reads = {i for i, t in enumerate(texts) if read_field(t, spec)[0] is not None}
            if reads - covered:
                used.append(label[:1].upper() + label[1:])
                covered |= reads
            if len(covered) == len(texts):
                break
        if used:
            out.fields.append((Field(name=field_name, labels=tuple(used), type=kind,
                                     required=len(covered) == len(texts) and field_name in ("date", "account", "amount")),
                               len(covered)))
    return out


def _quoted(text: str) -> str:
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def template_text(d: Draft, samples: list[Path] | None = None) -> str:
    """Return the YAML for a drafted template, with notes saying what each part does."""
    lines = [
        f"# DA document template: {d.title}",
        f"# Drafted by `da template new` from {d.samples} sample(s)"
        + (f" ({', '.join(p.name for p in (samples or [])[:5])})" if samples else "") + ".",
        "# Check it with: da template test " + d.name + " <some of these documents>",
        "# A document matches only when every check passes: all of match: all, one of match: any (when given),",
        "# none of match: none, and every field marked required (with expect:, one of the values listed).",
        "",
        f"title: {_quoted(d.title)}",
        "kind: bill                # a word for what these are (bill, statement, payslip); {kind} in names",
        "version: 1                # change it when you change the template (kept with each document it read)",
        "",
        "match:",
        "  all:                    # printed on every one of these documents (the company's name, as printed)",
    ]
    lines += [f"    - {_quoted(p)}" for p in d.phrases] or ['    - "COMPANY NAME AS PRINTED"   # <-- fill this in']
    lines += [
        "  # any: [\"Amount due\", \"Total due\"]   # at least one of these",
        "  # none: [\"Some other company\"]        # none of these: a look-alike's name",
        "",
        "fields:                   # what to read: the words printed before each value (label) and its type",
        "                          # types: date, money, account, text, lines, period (two dates), number",
    ]
    if not any(f.name == "date" for f, _n in d.fields):
        lines.append('  date: {label: ["Bill date"], type: date, required: true}   # <-- the label before its date')
    for spec, read in d.fields:
        extra = ", lines: 2" if spec.type == "lines" else ""
        required = ", required: true" if spec.required or spec.name == "date" else ""
        note = "" if read == d.samples else f"   # read in {read} of {d.samples} samples"
        labels = ", ".join(_quoted(label) for label in spec.labels)
        lines.append(f"  {spec.name}: {{label: [{labels}], type: {spec.type}{extra}{required}}}{note}")
    lines += [
        "  # account: {label: [\"Account number\"], type: account, required: true, expect: [\"1234567890\"]}",
        "",
        "file:",
        "  name: \"{template}_{date:%Y-%m-%d}" + ("_{account:-4}" if any(f.name == "account" for f, _ in d.fields)
                                                else "") + "_{hash:4}\"",
        "  # folder: \"Bills\\\\{title}\\\\{YYYY}\"    # under documents\\organized; default: the archive's date folders",
        "",
        "tags: [" + ", ".join(_quoted(t) for t in ("bill", f"company:{d.name}")) + "]",
        "",
    ]
    return "\n".join(lines)
