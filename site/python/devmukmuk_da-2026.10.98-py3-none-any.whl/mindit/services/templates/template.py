# src/mindit/services/templates/template.py

"""Document templates: how DA knows one company's documents (a utility's bills) and what to read in them.

A template is a YAML file in the archive's templates\\ folder (or the shared folder `templates:` names), e.g.
templates\\acme-power.yaml:

    title: Acme Power
    kind: bill
    match:
      all: ["Acme Power"]                 # every one of these is in the text
      any: ["Amount due", "Total due"]    # at least one of these (optional)
      none: ["Acme Power Tools"]          # none of these (optional)
    fields:
      date:    {label: [Bill date, Statement date], type: date, required: true}
      account: {label: Account number, type: account, required: true}
      amount:  {label: [Total amount due, Amount due], type: money, required: true}
    file:
      name: "{template}_{date:%Y-%m-%d}_{account:-4}_{hash:4}"

A document matches only when every check passes: each `all` phrase, one `any` phrase, no `none` phrase, and every
required field found (and, with `expect`, one of the values listed). See docs/da-docs/TEMPLATES-DESIGN.md.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

FIELD_TYPES = ("date", "money", "account", "text", "lines", "period", "number")
BLOCK = "template"                                  # the sidecar block a template's reading is kept in
DEFAULT_NAME = "{template}_{date:%Y-%m-%d}_{hash:4}"
DEFAULT_FOLDER_NAME = "templates"
_NAME = re.compile(r"^[a-z0-9][a-z0-9_-]{0,39}$")
_TOP_KEYS = {"title", "kind", "version", "notes", "match", "fields", "date", "file", "tags"}
_MATCH_KEYS = {"all", "any", "none"}
_FIELD_KEYS = {"label", "type", "pattern", "required", "expect", "within", "lines"}
_FILE_KEYS = {"name", "folder"}


class TemplateError(ValueError):
    """A template DA can't use: missing, unreadable, or with a mistake in it."""


@dataclass(frozen=True)
class Field:
    """One value to read: found after one of its labels (or by its own pattern), of one type."""

    name: str
    labels: tuple[str, ...] = ()
    type: str = "text"
    pattern: str | None = None
    required: bool = False
    expect: tuple[str, ...] = ()                    # the only values that count (e.g. your account numbers)
    within: int = 120                               # how far after the label the value may be, in characters
    lines: int = 2                                  # type lines: how many lines


@dataclass(frozen=True)
class Template:
    """A loaded template."""

    name: str
    title: str
    path: Path
    fingerprint: str                                # the file's sha256 (first 12): which revision read a document
    kind: str = "document"
    version: str = ""
    all: tuple[str, ...] = ()
    any: tuple[str, ...] = ()
    none: tuple[str, ...] = ()
    fields: tuple[Field, ...] = ()
    date_field: str = "date"
    file_name: str = DEFAULT_NAME
    folder: str | None = None                       # under documents\organized; None = the archive's date folders
    tags: tuple[str, ...] = field(default_factory=tuple)

    def field_named(self, name: str) -> Field | None:
        """Return the field called name, or None."""
        return next((f for f in self.fields if f.name == name), None)


def templates_folder(settings: Any | None = None) -> Path:
    """Return the folder templates are kept in: da-archive.yaml's `templates:` (relative = in the archive), else templates\\."""
    from mindit.config.settings import get_archive_root, load_settings  # pylint: disable=import-outside-toplevel

    loaded = settings or load_settings()
    root = get_archive_root() or Path.cwd()
    named = getattr(loaded, "templates", None)
    if not named:
        return root / DEFAULT_FOLDER_NAME
    folder = Path(named).expanduser()
    return folder if folder.is_absolute() else root / folder


def template_files(folder: Path) -> list[Path]:
    """Return the templates in a folder, by name."""
    return sorted(p for p in folder.glob("*.yaml") if p.is_file()) if folder.is_dir() else []


def check_name(name: str) -> str:
    """Return a template's name (lower case) or raise TemplateError when it can't be one."""
    name = (name or "").strip().lower()
    if not _NAME.match(name):
        raise TemplateError(f"{name!r} can't be a template's name: use letters, digits, - and _ (e.g. acme-power).")
    return name


def load_named(names: list[str], folder: Path) -> list[Template]:
    """Return the templates named (`all` = every one in the folder); a name with no file stops with the ones there are."""
    files = template_files(folder)
    if [n.lower() for n in names] == ["all"]:
        if not files:
            raise TemplateError(f"There are no templates in {folder}. Make one: da template new <name> --from <a sample PDF>")
        return [load_template(p) for p in files]
    found = []
    for name in names:
        path = folder / f"{check_name(name)}.yaml"
        if not path.is_file():
            there = ", ".join(p.stem for p in files) or "none yet"
            raise TemplateError(f"No template {name!r} in {folder} (there: {there}). "
                                f"Make one: da template new {name} --from <a sample PDF>")
        found.append(load_template(path))
    return found


def load_template(path: Path) -> Template:
    """Read and check one template file."""
    import yaml  # pylint: disable=import-outside-toplevel

    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8")
        data = yaml.safe_load(text) or {}
    except OSError as exc:
        raise TemplateError(f"Can't read {path}: {exc}") from exc
    except yaml.YAMLError as exc:
        raise TemplateError(f"{path.name} isn't valid YAML: {exc}") from exc
    if not isinstance(data, dict):
        raise TemplateError(f"{path.name}: a template is a list of settings (title:, match:, fields: ...).")
    name = check_name(path.stem)
    _no_unknown(data, _TOP_KEYS, path.name)

    match = data.get("match") or {}
    if not isinstance(match, dict):
        raise TemplateError(f"{path.name}: match: holds all:, any: and none:.")
    _no_unknown(match, _MATCH_KEYS, f"{path.name} match:")
    phrases = {key: _strings(match.get(key), f"match: {key}", path.name) for key in _MATCH_KEYS}
    if not phrases["all"]:
        raise TemplateError(f"{path.name}: match: all: needs at least one phrase every one of these documents has "
                            "(the company's name, as printed), so other documents aren't taken for them.")

    raw_fields = data.get("fields") or {}
    if not isinstance(raw_fields, dict) or not raw_fields:
        raise TemplateError(f"{path.name}: fields: lists what to read, at least the document's date.")
    date_field = str(data.get("date") or "date")
    fields = tuple(_field(n, spec, path.name, required=(n == date_field)) for n, spec in raw_fields.items())
    dated = next((f for f in fields if f.name == date_field), None)
    if dated is None or dated.type != "date":
        raise TemplateError(f"{path.name}: the field {date_field!r} (type: date) dates each document; add it to fields: "
                            "or say which field does with date: <field>.")

    file_spec = data.get("file") or {}
    if not isinstance(file_spec, dict):
        raise TemplateError(f"{path.name}: file: holds name: and folder:.")
    _no_unknown(file_spec, _FILE_KEYS, f"{path.name} file:")
    return Template(
        name=name,
        title=str(data.get("title") or name),
        path=path,
        fingerprint=hashlib.sha256(text.encode("utf-8")).hexdigest()[:12],
        kind=str(data.get("kind") or "document"),
        version=str(data.get("version") or ""),
        all=phrases["all"], any=phrases["any"], none=phrases["none"],
        fields=fields,
        date_field=date_field,
        file_name=str(file_spec.get("name") or DEFAULT_NAME),
        folder=str(file_spec["folder"]) if file_spec.get("folder") else None,
        tags=_strings(data.get("tags"), "tags", path.name),
    )


def _field(name: Any, spec: Any, where: str, required: bool) -> Field:
    name = str(name)
    if not re.match(r"^[A-Za-z_]\w*$", name):
        raise TemplateError(f"{where}: {name!r} can't be a field's name: use letters, digits and _ (pay_period).")
    if isinstance(spec, str):
        spec = {"label": spec}
    if not isinstance(spec, dict):
        raise TemplateError(f"{where}: field {name}: give it label: and type:.")
    _no_unknown(spec, _FIELD_KEYS, f"{where} field {name}")
    kind = str(spec.get("type") or "text")
    if kind not in FIELD_TYPES:
        raise TemplateError(f"{where}: field {name}: type {kind!r} isn't one DA reads ({', '.join(FIELD_TYPES)}).")
    labels = _strings(spec.get("label"), f"field {name} label", where)
    pattern = spec.get("pattern")
    if pattern is not None:
        try:
            re.compile(str(pattern))
        except re.error as exc:
            raise TemplateError(f"{where}: field {name}: pattern isn't a regular expression DA can use: {exc}") from exc
    if not labels and pattern is None:
        raise TemplateError(f"{where}: field {name}: needs label: (the words printed before it) or pattern:.")
    return Field(name=name, labels=labels, type=kind, pattern=str(pattern) if pattern is not None else None,
                 required=bool(spec.get("required", False)) or required,
                 expect=_strings(spec.get("expect"), f"field {name} expect", where),
                 within=int(spec.get("within") or 120), lines=int(spec.get("lines") or 2))


def _strings(value: Any, what: str, where: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, (str, int, float)):
        value = [value]
    if not isinstance(value, list) or not all(isinstance(v, (str, int, float)) for v in value):
        raise TemplateError(f"{where}: {what}: a word or phrase, or a list of them.")
    return tuple(str(v).strip() for v in value if str(v).strip())


def _no_unknown(data: dict[str, Any], known: set[str], where: str) -> None:
    unknown = sorted(str(k) for k in data if k not in known)
    if unknown:
        raise TemplateError(f"{where}: DA doesn't know {', '.join(unknown)} (it reads {', '.join(sorted(known))}).")


# --------------------------------------------------------------------------- the reading, kept in the sidecar

def template_date(sidecar: dict[str, Any] | None) -> datetime | None:
    """Return the date a template read in a document (its sidecar's template block), or None."""
    block = (sidecar or {}).get(BLOCK)
    if not isinstance(block, dict) or not block.get("date"):
        return None
    try:
        return datetime.fromisoformat(str(block["date"]))
    except ValueError:
        return None


def read_template_date(path: Path) -> datetime | None:
    """Return the date a template read in path, from its sidecar only."""
    side = Path(f"{path}.meta.json")
    if not side.exists():
        return None
    try:
        return template_date(json.loads(side.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return None


def template_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the tags a template gave a document (template:<name> and the template's own), so `da tag` keeps them."""
    block = sidecar.get(BLOCK)
    if not isinstance(block, dict):
        return []
    return [str(t) for t in block.get("tags") or [] if str(t).strip()]
