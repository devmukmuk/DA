# src/mindit/services/templates/reading.py

"""Read documents with templates: does each match one, and what's in it (date, account, amount ...)."""

from __future__ import annotations

import csv
import json
import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Callable, Iterable

from mindit.services.templates.template import BLOCK, Field, Template

_MONTH = (r"(?P<mon>jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?"
          r"|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)(?![a-z])")
_MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                       "dec"], 1)}
_DATES = (
    re.compile(r"(?<![A-Za-z])" + _MONTH + r"\.?\s+(?P<d>\d{1,2})(?:st|nd|rd|th)?(?!\d)(?:,?\s+(?P<y>(?:19|20)\d{2})(?!\d))?",
               re.IGNORECASE),                                              # Mar 15, 2025 / March 15 2025 / Feb 10
    re.compile(r"(?<!\d)(?P<d>\d{1,2})(?:st|nd|rd|th)?\s+" + _MONTH + r"\.?,?\s+(?P<y>(?:19|20)\d{2})(?!\d)",
               re.IGNORECASE),                                              # 15 March 2025
    re.compile(r"(?<![\d/.-])(?P<y>(?:19|20)\d{2})-(?P<m>\d{1,2})-(?P<d>\d{1,2})(?![\d-])"),         # 2025-03-15
    re.compile(r"(?<![\d/.-])(?P<m>\d{1,2})(?P<sep>[/.-])(?P<d>\d{1,2})(?P=sep)(?P<y>\d{4}|\d{2})(?![\d/.-])"),  # 3/15/25
)
_MONEY = re.compile(r"(?<![\d.,])(?P<neg>-\s?)?(?P<cur>\$)?\s?(?P<neg2>-)?(?P<n>\d{1,3}(?:,\d{3})+|\d+)\.(?P<c>\d{2})(?![\d.])"
                    r"(?P<cr>\s?CR\b)?")
_ACCOUNT = re.compile(r"(?<![\w])(?:[A-Z]{1,3}[ -]?)?\d(?:[ -]?\d){4,29}(?![\d])")
_NUMBER = re.compile(r"(?<![\d.])-?\d[\d,]*(?:\.\d+)?(?![\d])")
_FORBIDDEN = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_TOKEN = re.compile(r"\{([A-Za-z_]\w*)(?::([^}]*))?\}")


@dataclass
class Reading:
    """What one template found in one document."""

    template: Template
    matched: bool
    passed: int = 0
    checks: int = 0
    fields: dict[str, Any] = field(default_factory=dict)          # name -> value (str, or {from, to, days})
    why: list[str] = field(default_factory=list)                   # each check that failed
    date: datetime | None = None

    @property
    def score(self) -> float:
        """Return the share of the template's checks this document passed (1.0 = all of them)."""
        return round(self.passed / self.checks, 2) if self.checks else 0.0

    def reason(self) -> str:
        """Return why it didn't match, in a few words."""
        return "; ".join(self.why[:3]) + (f" (+{len(self.why) - 3} more)" if len(self.why) > 3 else "")


@dataclass
class DocumentResult:
    """One document: the template it matched (or why none did)."""

    path: Path
    reading: Reading | None = None                                 # the matching template's reading
    best: Reading | None = None                                    # no match: the closest one
    error: str = ""                                                # no text to read, or matched two templates

    @property
    def matched(self) -> bool:
        return self.reading is not None

    def failure(self, names: str) -> str:
        """Return the line a run shows for a document no template took."""
        why = self.error or (self.best.reason() if self.best else "nothing to read")
        return f"{self.path.name} read by {names} template and failed: {why}"


# --------------------------------------------------------------------------- text

def normalize(text: str) -> str:
    """Return text with odd spaces, ligatures and runs of spaces tidied, one line per line."""
    text = unicodedata.normalize("NFKC", text or "").replace(" ", " ").replace("\r", "\n")
    text = text.replace("–", "-").replace("—", "-").replace("’", "'")
    lines = (re.sub(r"[ \t\f\v]+", " ", line).strip() for line in text.split("\n"))
    return "\n".join(line for line in lines if line)


def phrase_regex(phrase: str) -> re.Pattern[str]:
    """Return a pattern for a printed phrase: any case, any spacing (a PDF's text is often spaced oddly)."""
    words = [re.escape(w) for w in phrase.split()]
    return re.compile(r"(?<![A-Za-z0-9])" + r"\s*".join(words) + r"(?![a-z])", re.IGNORECASE)


def has_phrase(text: str, phrase: str) -> bool:
    """Return True when text holds phrase (any case, any spacing)."""
    return phrase_regex(phrase).search(text) is not None


# --------------------------------------------------------------------------- values

def dates_in(window: str, limit: int = 2) -> list[tuple[date | None, int, int, int]]:
    """Return the first dates in window as (date or None without a year, month, day, end) - at most limit."""
    found: list[tuple[int, int, re.Match[str]]] = []
    for pattern in _DATES:
        found += [(m.start(), m.end(), m) for m in pattern.finditer(window)]
    found.sort(key=lambda t: (t[0], -t[1]))
    out: list[tuple[date | None, int, int, int]] = []
    end = -1
    for start, stop, m in found:
        if start < end:
            continue                                      # inside one already taken
        parts = m.groupdict()
        month = _MONTHS[parts["mon"][:3].lower()] if parts.get("mon") else int(parts["m"])
        day = int(parts["d"])
        year = parts.get("y")
        if year is not None and len(year) == 2:
            year = str(2000 + int(year) if int(year) <= (datetime.now().year % 100) + 1 else 1900 + int(year))
        try:
            value = date(int(year), month, day) if year else None
            if value is None:
                date(2000, month, day)                    # a real month and day, even without a year
        except ValueError:
            continue
        if value is not None and not 1900 <= value.year <= datetime.now().year + 1:
            continue
        out.append((value, month, day, stop))
        end = stop
        if len(out) >= limit:
            break
    return out


def _date_value(window: str) -> tuple[str | None, str]:
    for value, _m, _d, _end in dates_in(window, limit=4):
        if value is not None:
            return value.isoformat(), ""
    return None, "no date"


def _period_value(window: str) -> tuple[dict[str, Any] | None, str]:
    found = dates_in(window, limit=2)
    if len(found) < 2 or found[1][0] is None:
        return None, "no two dates (from - to)"
    (first, month, day, _), (last, *_rest) = found
    if first is None:                                     # Feb 10 - Mar 11, 2025: the year is the second's
        first = date(last.year, month, day)
        if first > last:
            first = date(last.year - 1, month, day)
    if first > last:
        return None, "the period's first date is after its last"
    return {"from": first.isoformat(), "to": last.isoformat(), "days": (last - first).days}, ""


def _money_value(window: str) -> tuple[str | None, str]:
    matches = list(_MONEY.finditer(window))
    m = next((m for m in matches if m["cur"]), None) or (matches[0] if matches else None)   # a $ amount first
    if m is None:
        return None, "no amount"
    try:
        amount = Decimal(m["n"].replace(",", "") + "." + m["c"])
    except InvalidOperation:
        return None, "no amount"
    if m["neg"] or m["neg2"] or m["cr"]:
        amount = -amount
    return f"{amount:.2f}", ""


def _account_value(window: str) -> tuple[str | None, str]:
    m = _ACCOUNT.search("\n".join(window.split("\n")[:2]))          # on the label's line or the next
    if m is None:
        return None, "no account number"
    return re.sub(r"[ -]", "", m.group(0)), ""


def _number_value(window: str) -> tuple[str | None, str]:
    m = _NUMBER.search(window)
    return (m.group(0).replace(",", ""), "") if m else (None, "no number")


def _text_value(window: str) -> tuple[str | None, str]:
    for line in window.split("\n")[:2]:
        line = line.strip(" :#-\t")
        if line:
            return line[:80], ""
    return None, "nothing after it"


def _lines_value(window: str, count: int) -> tuple[str | None, str]:
    lines = [line.strip(" :#-\t") for line in window.split("\n")]
    lines = [line for line in lines if line][:count]
    return (", ".join(lines), "") if lines else (None, "nothing after it")


def value_of(kind: str, window: str, lines: int = 2) -> tuple[Any, str]:
    """Return the first value of a type in window, and why there's none ('' when found)."""
    if kind == "date":
        return _date_value(window)
    if kind == "period":
        return _period_value(window)
    if kind == "money":
        return _money_value(window)
    if kind == "account":
        return _account_value(window)
    if kind == "number":
        return _number_value(window)
    if kind == "lines":
        return _lines_value(window, lines)
    return _text_value(window)


def read_field(text: str, spec: Field) -> tuple[Any, str]:
    """Return one field's value in a document's text, or None and why not."""
    windows: list[str] = []
    seen_label = False
    for label in spec.labels:
        for m in phrase_regex(label).finditer(text):
            seen_label = True
            windows.append(text[m.end():m.end() + spec.within].lstrip(" :#.\t"))
    if not spec.labels:
        windows = [text]
    elif not seen_label:
        return None, f"no '{spec.labels[0]}' in it"
    why = ""
    for window in windows:
        if spec.pattern:
            m = re.search(spec.pattern, window, re.IGNORECASE | re.MULTILINE)
            if m is None:
                why = "nothing like its pattern"
                continue
            found = m.groupdict().get("value") or (m.group(1) if m.groups() else m.group(0))
            value, why = (found.strip(), "") if spec.type in ("text", "lines") else value_of(spec.type, found, spec.lines)
        else:
            value, why = value_of(spec.type, window, spec.lines)
        if value is not None:
            return value, ""
    where = f" after '{spec.labels[0]}'" if spec.labels else ""
    return None, f"{why}{where}"


def _same(a: str, b: str) -> bool:
    return re.sub(r"[^a-z0-9]", "", a.lower()) == re.sub(r"[^a-z0-9]", "", b.lower())


def read_with(text: str, template: Template) -> Reading:
    """Check text against one template and read its fields."""
    reading = Reading(template=template, matched=False)

    def check(ok: bool, why: str) -> None:
        reading.checks += 1
        if ok:
            reading.passed += 1
        else:
            reading.why.append(why)

    for phrase in template.all:
        check(has_phrase(text, phrase), f"no '{phrase}' in it")
    if template.any:
        check(any(has_phrase(text, p) for p in template.any), "none of " + ", ".join(f"'{p}'" for p in template.any))
    for phrase in template.none:
        check(not has_phrase(text, phrase), f"'{phrase}' is in it")
    for spec in template.fields:
        value, why = read_field(text, spec)
        if value is not None:
            reading.fields[spec.name] = value
            if spec.expect:
                check(any(_same(str(value), e) for e in spec.expect), f"{spec.name} {value} isn't one listed in expect")
            elif spec.required:
                check(True, "")
        elif spec.required:
            check(False, f"no {spec.name}: {why}")
    dated = reading.fields.get(template.date_field)
    reading.date = datetime.fromisoformat(dated) if isinstance(dated, str) else None
    reading.matched = reading.passed == reading.checks and reading.date is not None
    return reading


def read_document(path: Path, text: str, templates: list[Template]) -> DocumentResult:
    """Return which of the templates a document matches (exactly one, or it's a failure) and what it read."""
    result = DocumentResult(path=path)
    text = normalize(text)
    if not text:
        result.error = "no text in it (a scan needs Windows' OCR)"
        return result
    readings = [read_with(text, t) for t in templates]
    matched = [r for r in readings if r.matched]
    if len(matched) > 1:
        result.error = "it matches " + " and ".join(r.template.name for r in matched) + " (make one template stricter)"
        result.best = matched[0]
        return result
    if matched:
        result.reading = matched[0]
    else:
        result.best = max(readings, key=lambda r: (r.score, r.passed), default=None)
    return result


# --------------------------------------------------------------------------- names and folders

def _context(reading: Reading, sha256: str) -> dict[str, Any]:
    t = reading.template
    context: dict[str, Any] = {"template": t.name, "title": t.title, "kind": t.kind, "hash": sha256}
    for name, value in reading.fields.items():
        spec = t.field_named(name)
        if isinstance(value, dict):                                  # a period
            context[f"{name}_from"] = datetime.fromisoformat(value["from"])
            context[f"{name}_to"] = datetime.fromisoformat(value["to"])
            context[name] = f"{value['from']}_{value['to']}"
        elif spec is not None and spec.type == "date":
            context[name] = datetime.fromisoformat(value)
        else:
            context[name] = value
    if reading.date is not None:
        context.update(YYYY=f"{reading.date:%Y}", MM=f"{reading.date:%m}", DD=f"{reading.date:%d}")
    return context


def render(pattern: str, context: dict[str, Any]) -> tuple[str, list[str]]:
    """Return pattern with its {tokens} filled ({date:%Y-%m}, {account:-4} last 4, {hash:4} first 4), and the missing ones."""
    missing: list[str] = []

    def one(m: re.Match[str]) -> str:
        name, modifier = m.group(1), (m.group(2) or "").strip()
        value = context.get(name)
        if value is None or value == "":
            missing.append(name)
            return ""
        if isinstance(value, datetime):
            return value.strftime(modifier or "%Y-%m-%d")
        text = str(value)
        if re.fullmatch(r"-\d+", modifier):
            return text[int(modifier):]
        if modifier.isdigit():
            return text[: int(modifier)]
        return text

    return _TOKEN.sub(one, pattern), missing


def file_name(reading: Reading, sha256: str, suffix: str) -> str:
    """Return the name the template gives a document (its suffix kept, lower case)."""
    name, _missing = render(reading.template.file_name, _context(reading, sha256))
    name = _FORBIDDEN.sub("", name)
    name = re.sub(r"\s+", "-", name.strip())
    name = re.sub(r"([_-])[_-]+", r"\1", name).strip("_-. ")
    return (name or f"{reading.template.name}_{sha256[:8]}") + suffix.lower()


def folder_of(reading: Reading, sha256: str) -> str | None:
    """Return the folder (under documents\\organized) the template files a document in, or None for the date folders."""
    if not reading.template.folder:
        return None
    from mindit.services.naming.folders import _level  # pylint: disable=import-outside-toplevel

    context = _context(reading, sha256)
    levels = [_level(render(level, context)[0]) for level in re.split(r"[\\/]", reading.template.folder) if level.strip()]
    return "\\".join(level for level in levels if level) or None


# --------------------------------------------------------------------------- the sidecar

def block_for(reading: Reading, path: Path, sha256: str) -> dict[str, Any]:
    """Return the sidecar `template` block for a document a template matched."""
    t = reading.template
    stat = path.stat()
    return {
        "name": t.name,
        "title": t.title,
        "kind": t.kind,
        "version": t.version,
        "fingerprint": t.fingerprint,
        "read_at": datetime.now().isoformat(timespec="seconds"),
        "score": reading.score,
        "date": reading.date.isoformat() if reading.date else None,
        "fields": dict(reading.fields),
        "file_name": file_name(reading, sha256, path.suffix),
        "folder": folder_of(reading, sha256),
        "tags": [f"template:{t.name}", *[x for x in t.tags if x != f"template:{t.name}"]],
        "file": {"size": stat.st_size, "mtime": int(stat.st_mtime)},
    }


def write_block(path: Path, block: dict[str, Any]) -> None:
    """Keep a template's reading in a document's sidecar, and its tags with the automatic ones."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    data = SidecarService.load(path)
    old = data.get(BLOCK) if isinstance(data.get(BLOCK), dict) else {}
    auto = data.get("auto_tags") if isinstance(data.get("auto_tags"), dict) else {}
    tags = [t for t in auto.get("tags") or [] if t not in (old.get("tags") or [])]
    data[BLOCK] = block
    data["auto_tags"] = {**auto, "tags": tags + [t for t in block["tags"] if t not in tags],
                         "made_at": datetime.now().isoformat(timespec="seconds")}
    SidecarService.save(path, data)


# --------------------------------------------------------------------------- a folder of documents

READABLE = {".pdf", ".docx", ".xlsx", ".pptx", ".txt", ".csv", ".md", ".rtf"}
SCANS = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp"}


@dataclass
class FolderResult:
    """What reading a folder with templates found."""

    results: list[DocumentResult] = field(default_factory=list)
    other: int = 0                                                  # files no template reads (photos, videos ...)

    @property
    def matched(self) -> list[DocumentResult]:
        return [r for r in self.results if r.matched]

    @property
    def failed(self) -> list[DocumentResult]:
        return [r for r in self.results if not r.matched]


def documents_in(folder: Path, with_scans: bool, scan: Callable[[Path], bool] | None = None) -> tuple[list[Path], int]:
    """Return the files under folder a template can read, and how many others there are.

    Pictures only with_scans, and then only those `scan` says are documents (a photo isn't put through OCR).
    """
    found, other = [], 0
    for path in sorted(folder.rglob("*")):
        if not path.is_file() or path.name.endswith(".meta.json") or path.name.startswith("_contact-sheet"):
            continue
        suffix = path.suffix.lower()
        if suffix in READABLE or (with_scans and suffix in SCANS and (scan is None or scan(path))):
            found.append(path)
        else:
            other += 1
    return found, other


def _is_scan(path: Path) -> bool:
    """Return True when a picture is a document by where it is (intake\\docs, intake\\scans ...), not a photo."""
    from mindit.services.validateit.validateit_file_types import MediaClassifier, MediaKind  # pylint: disable=import-outside-toplevel

    return MediaClassifier(default_kind=MediaKind.PHOTO).kind(path) == MediaKind.DOCUMENT


def _forget_reading(path: Path, names: set[str]) -> None:
    """Take a template's old reading out of a document it no longer matches (it'd still be filed by it)."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    if not Path(f"{path}.meta.json").exists():
        return
    data = SidecarService.load(path)
    old = data.get(BLOCK)
    if not isinstance(old, dict) or old.get("name") not in names:
        return
    auto = data.get("auto_tags") if isinstance(data.get("auto_tags"), dict) else {}
    data["auto_tags"] = {**auto, "tags": [t for t in auto.get("tags") or [] if t not in (old.get("tags") or [])]}
    del data[BLOCK]
    SidecarService.save(path, data)


def read_folder(folder: Path, templates: list[Template], reader: Any | None = None, apply: bool = True,
                progress: Callable[[int, int], None] | None = None) -> FolderResult:
    """Read every document under folder with the templates; with apply, keep each match's reading in its sidecar."""
    from mindit.services.secure.passwords import text_of  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    paths, other = documents_in(folder, with_scans=reader is not None, scan=_is_scan)
    out = FolderResult(other=other)
    names = {t.name for t in templates}
    for i, path in enumerate(paths, 1):
        result = read_document(path, text_of(path, reader, SidecarService.load(path)), templates)
        if result.matched and apply:
            sha256 = _ensure_sidecar(path)
            write_block(path, block_for(result.reading, path, sha256))
        elif apply:
            _forget_reading(path, names)
        out.results.append(result)
        if progress:
            progress(i, len(paths))
    return out


def read_files(paths: Iterable[Path], templates: list[Template], reader: Any | None = None) -> list[DocumentResult]:
    """Read some files with the templates; nothing is written (`da template test`)."""
    from mindit.services.secure.passwords import text_of  # pylint: disable=import-outside-toplevel

    return [read_document(Path(p), text_of(Path(p), reader, None), templates) for p in paths]


def _ensure_sidecar(path: Path) -> str:
    """Return the document's sha256, making its sidecar first when it has none (the way validate would)."""
    from mindit.services.validateit.quarantine_hash_service import (  # pylint: disable=import-outside-toplevel
        compute_sha256,
        record_file_hash,
        stored_or_computed_sha256,
    )
    from mindit.services.validateit.scanit_repair_provider import ScanItRepairProvider  # pylint: disable=import-outside-toplevel

    if Path(f"{path}.meta.json").exists():
        return stored_or_computed_sha256(path)
    sha256 = compute_sha256(path)
    ScanItRepairProvider().create_or_refresh_sidecar(path, sha256=sha256)
    record_file_hash(path, sha256)
    return sha256


def write_results(results: list[DocumentResult], path: Path) -> Path:
    """Write one row per document: matched or failed, which template, why, and every field read."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["file", "result", "template", "score", "date", "why", "fields"])
        for r in results:
            reading = r.reading or r.best
            writer.writerow([str(r.path), "matched" if r.matched else "failed",
                             reading.template.name if reading else "", reading.score if reading else "",
                             reading.date.date().isoformat() if r.matched and reading.date else "",
                             "" if r.matched else (r.error or (reading.reason() if reading else "")),
                             json.dumps(reading.fields if reading else {}, ensure_ascii=False)])
    return path
