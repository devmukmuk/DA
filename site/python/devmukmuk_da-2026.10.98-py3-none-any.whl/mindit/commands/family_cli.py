# src/mindit/commands/family_cli.py

"""`da family`: check the family folder (houses, birthdays, who lived where) and print the timeline."""

from __future__ import annotations

from datetime import date
from pathlib import Path

import typer
from rich.console import Console
from rich.markup import escape

console = Console()


def family(
    targets: list[Path] = typer.Argument(None, help="With --update: the folders (or files) to update. "
                                         "Default: photos\\organized."),
    folder: Path | None = typer.Option(None, "--folder", help="The family folder. Default: `family:` in da-archive.yaml."),
    on: str | None = typer.Option(None, "--on", help="Show the home and everyone's age on this date (6/1/1998)."),
    csv_path: Path | None = typer.Option(None, "--csv", help="Also write the timeline as a CSV file here."),
    locate: bool = typer.Option(False, "--locate", help="Look up where each home is (once; kept in house-positions.csv), "
                                "so photos with GPS show at home or away."),
    again: bool = typer.Option(False, "--again", help="With --locate: also ask again for the homes not found before "
                               "(town only / missing)."),
    update: bool = typer.Option(False, "--update", help="Write each photo's and video's home and ages into its "
                                "sidecar (da tag does it too); then da contact-sheets shows them."),
    person: str | None = typer.Option(None, "--person", help="Whose houses (houses.csv `people`): default the "
                                      "archive's owner; 'all' = every house."),
) -> None:
    """Check the family folder (houses.csv, people.csv, members.csv) and print who lived where, and how old they were."""
    from mindit.config.settings import get_family_folder  # pylint: disable=import-outside-toplevel
    from mindit.services.family import family as fam  # pylint: disable=import-outside-toplevel

    folder = folder or get_family_folder()
    if folder is None:
        console.print("No family folder. Add a line to the archive's da-archive.yaml, e.g. "
                      r"[bold]family: D:\family[/bold], or use --folder.")
        console.print("It holds houses.csv (Date,to,address,city,state,zip,people) and people.csv "
                      "(name,birthday,also_known_as); members.csv is optional.")
        raise typer.Exit(1)
    try:
        found = fam.read_family(folder)
    except fam.FamilyError as exc:
        console.print(f"[red]{escape(str(exc))}[/red]")
        raise typer.Exit(1) from exc

    from mindit.services.family import life  # pylint: disable=import-outside-toplevel

    everyone = found
    whose = person or life.archive_person()
    if whose and whose.strip().lower() != "all":
        found = everyone.only(whose)
        if found.whose is None:
            console.print(f"[yellow]{escape(whose)} isn't in people.csv:[/yellow] showing every house.")
    today = date.today()
    console.print(f"Family folder {escape(str(folder))}: {len(found.houses)} houses, {len(found.people)} people"
                  + (", members.csv" if found.has_members else "")
                  + (f" - the houses of {escape(found.whose)}" if found.whose else ""))
    for problem in found.problems + fam.check(found, today):
        console.print(f"  [yellow]![/yellow] {escape(problem)}")
    for start, end in fam.gaps(found, today):
        console.print(f"  [dim]no house from {start:%m/%d/%Y} to {end:%m/%d/%Y}[/dim]")

    if update:
        _update(found, targets)
    elif on:
        try:
            day = fam.parse_date(on, today)
        except ValueError as exc:
            raise typer.BadParameter(str(exc), param_hint="--on") from exc
        _show_day(found, day, today)
    else:
        _show_timeline(found, today)

    if locate:
        _locate(everyone, again)

    if csv_path:
        from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

        path = fam.write_timeline(found, csv_path, today)
        log_event("family", f"da family: {path.name}", path=str(path), houses=len(found.houses),
                  people=len(found.people))
        console.print(f"\nWrote {escape(str(path))}")


def _update(found, targets: list[Path] | None) -> None:
    from mindit.config.settings import get_archive_root, resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.family import life  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import files_under, is_photo  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS  # pylint: disable=import-outside-toplevel

    if not targets and get_archive_root() is None:
        console.print("[yellow]Not inside an archive:[/yellow] name the folders to update, or run it in an archive.")
        raise typer.Exit(1)
    targets = targets or [resolve_photoit_organized_path()]
    missing = [t for t in targets if not Path(t).exists()]
    if missing:
        raise typer.BadParameter(f"not found: {missing[0]}")
    files = [p for p in files_under(targets, photos_only=False) if is_photo(p) or p.suffix.lower() in VIDEO_EXTENSIONS]
    console.print(f"\nUpdating the home and ages of {len(files):,} photos and videos ...")
    result = life.write_life(files, found, life.family_fp(found), life.read_positions(found.folder))
    console.print(f"  {result.written:,} written, {result.removed:,} removed, the rest already current "
                  "(or no date). Remake the sheets to show them: da contact-sheets")
    log_event("family", f"da family --update: {result.written} written, {result.removed} removed",
              path=str(targets[0]), files=result.files, written=result.written, removed=result.removed)


def _locate(found, again: bool = False) -> None:
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.family import life  # pylint: disable=import-outside-toplevel
    from mindit.services.location.places import LookupUnavailable, NominatimGeocoder, what_to_do  # pylint: disable=import-outside-toplevel

    path = found.folder / life.POSITIONS
    console.print("\nLooking up where each home is (OpenStreetMap, one a second) ...")
    try:
        looked, left = life.locate_houses(found, NominatimGeocoder().search, again=again,
                                          say=lambda m: console.print(f"  [dim]{escape(m)}[/dim]"))
    except LookupUnavailable as exc:
        console.print(f"[yellow]{escape(str(exc))}[/yellow] - the homes found so far are kept. "
                      + escape(what_to_do(str(exc), "Run it again later.")))
        return
    console.print(f"  {looked} looked up; kept in {escape(str(path))}")
    for label, source in left.items():
        what = "only the town was found" if source == "town" else "not found"
        console.print(f"  [yellow]{what}:[/yellow] {escape(label)}")
    if left:
        console.print("  Those don't say at home or away. Type each one's latitude and longitude into its row "
                      "(in Google Maps, right-click the house); DA keeps what you type.")
    log_event("family", f"da family --locate: {looked} homes looked up", path=str(path), looked=looked,
              town=sum(1 for v in left.values() if v == "town"), missing=sum(1 for v in left.values() if v == "missing"))
    console.print("Then [bold]da family --update[/bold] (or da tag) puts homes and ages under your photos.")


def _show_timeline(found, today: date) -> None:
    from mindit.services.family import family as fam  # pylint: disable=import-outside-toplevel

    for house in found.houses:
        end = house.last_day(today)
        years = (end - house.start).days / 365.25
        until = f"{house.end:%m/%d/%Y}" if house.end else "now"
        console.print(f"\n[bold]{house.start:%m/%d/%Y} - {until}[/bold]  ({years:.1f} yrs)  {escape(house.label())}")
        people = fam.residents(found, house, today)
        if not people:
            console.print("    [dim](no one from the birthday list)[/dim]")
        for r in people:
            ages = (f"born here {r.first:%m/%d/%Y}, {r.age_out}" if r.born_here
                    else f"{r.age_in}" if r.age_in == r.age_out else f"{r.age_in}-{r.age_out}")
            console.print(f"    {escape(r.name):<14} age {ages}")


def _show_day(found, day: date, today: date) -> None:
    homes = found.homes_on(day, today)
    console.print(f"\n[bold]{day:%m/%d/%Y}[/bold]")
    if len(homes) == 1:
        console.print(f"  Home: {escape(homes[0].label())}")
    elif homes:
        console.print("  Home: one of " + "; ".join(escape(h.label()) for h in homes))
    else:
        console.print("  Home: [dim]none in houses.csv[/dim]")
    for person in found.people:
        age = found.age(person.name, day)
        if age is not None:
            console.print(f"    {escape(person.name):<14} {age}")
