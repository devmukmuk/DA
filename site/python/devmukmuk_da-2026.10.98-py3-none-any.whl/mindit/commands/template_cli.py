# src/mindit/commands/template_cli.py

"""`da template`: make, change and try out document templates (one company's bills, read and filed by `da run --template`)."""

from __future__ import annotations

import os
from pathlib import Path

import typer
from rich.console import Console
from rich.markup import escape

console = Console()
app = typer.Typer(help="Document templates: how DA knows one company's documents and what to read in them. "
                       "Make one from samples (new), change it (edit), try it (test); then: da run --template <name>.",
                  no_args_is_help=True)


def _folder(folder: Path | None) -> Path:
    from mindit.services.templates.template import templates_folder  # pylint: disable=import-outside-toplevel

    return Path(folder) if folder else templates_folder()


def _documents(targets: list[Path]) -> list[Path]:
    from mindit.services.templates.reading import documents_in  # pylint: disable=import-outside-toplevel

    out: list[Path] = []
    for target in targets:
        if target.is_dir():
            out += documents_in(target, with_scans=True)[0]
        elif target.is_file():
            out.append(target)
        else:
            raise typer.BadParameter(f"No such file or folder: {target}")
    return out


class _NoOcr:
    """No OCR (--no-ocr): a scan reads as no text."""

    def read(self, _path: Path) -> dict:
        return {}

    def close(self) -> None:
        pass


def _reader(ocr: bool):
    from mindit.commands.workflow_cli import _LazyOcr  # pylint: disable=import-outside-toplevel

    return _LazyOcr() if ocr else _NoOcr()


@app.command("list")
def list_templates(folder: Path | None = typer.Option(None, "--folder", help="The templates folder. Default: "
                                                       "`templates:` in da-archive.yaml, else the archive's templates\\.")) -> None:
    """List the templates: name, title, what they look for and read."""
    from mindit.services.templates.template import TemplateError, load_template, template_files  # pylint: disable=import-outside-toplevel

    where = _folder(folder)
    files = template_files(where)
    console.print(f"Templates in {escape(str(where))}: {len(files)}")
    for path in files:
        try:
            t = load_template(path)
        except TemplateError as exc:
            console.print(f"  [red]{escape(path.stem)}: {escape(str(exc))}[/red]")
            continue
        required = [f.name for f in t.fields if f.required]
        console.print(f"  [bold]{t.name}[/bold]  {escape(t.title)}"
                      + (f"  (version {escape(t.version)})" if t.version else ""))
        console.print(f"     looks for: {escape(', '.join(repr(p) for p in t.all))}   reads: "
                      f"{escape(', '.join(f.name + ('*' if f.name in required else '') for f in t.fields))}  (* = required)")
    if not files:
        console.print("Make one from a few of the documents: da template new <name> --from <sample.pdf> --from <another.pdf>")


@app.command("new")
def new(
    name: str = typer.Argument(..., help="The template's name, e.g. acme-power (letters, digits, - and _)."),
    samples: list[Path] = typer.Option(None, "--from", help="Sample documents (or a folder of them) to draft it from: "
                                       "two or three of the same company's documents."),
    title: str | None = typer.Option(None, "--title", help="What to call it (the company's name, as printed)."),
    folder: Path | None = typer.Option(None, "--folder", help="The templates folder. Default: the archive's templates\\."),
    force: bool = typer.Option(False, "--force", help="Replace a template of that name (the old one is kept as .bak)."),
    ocr: bool = typer.Option(True, "--ocr/--no-ocr", help="Read scanned samples with Windows' OCR."),
) -> None:
    """Draft a template from sample documents: the company's name they share and the usual fields; then test it."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.secure.passwords import text_of  # pylint: disable=import-outside-toplevel
    from mindit.services.templates import draft as drafting  # pylint: disable=import-outside-toplevel
    from mindit.services.templates.template import TemplateError, check_name, load_template  # pylint: disable=import-outside-toplevel

    try:
        name = check_name(name)
    except TemplateError as exc:
        raise typer.BadParameter(str(exc)) from exc
    where = _folder(folder)
    path = where / f"{name}.yaml"
    if path.exists() and not force:
        console.print(f"[yellow]{escape(str(path))} is there already.[/yellow] Change it: da template edit {name}  "
                      "(or --force to draft it again)")
        raise typer.Exit(1)
    files = _documents(samples or [])
    reader = _reader(ocr)
    try:
        texts = [text_of(p, reader, None) for p in files]
    finally:
        reader.close()
    unread = [p.name for p, t in zip(files, texts) if not t.strip()]
    if unread:
        console.print(f"[yellow]No text in {escape(', '.join(unread))}[/yellow] (a scan needs Windows' OCR).")
    d = drafting.draft(name, texts, title)
    where.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.with_suffix(".yaml.bak").write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
    path.write_text(drafting.template_text(d, files), encoding="utf-8")
    console.print(f"Wrote {escape(str(path))}: looks for {escape(', '.join(repr(p) for p in d.phrases) or 'nothing yet')}, "
                  f"reads {', '.join(f.name for f, _ in d.fields) or 'nothing yet'}.")
    log_event("template", f"drafted template {name} from {len(files)} samples", path=str(path), samples=len(files))
    try:
        load_template(path)
    except TemplateError as exc:
        console.print(f"[yellow]It needs your help before it can be used:[/yellow] {escape(str(exc))}")
        console.print(f"Open it: da template edit {name}")
        return
    if files:
        console.print("\nTrying it on the samples:")
        _show(name, files, where, ocr)
    console.print(f"\nCheck it and fill in what it missed: da template edit {name}   then: da template test {name} <files>")


@app.command("edit")
def edit(
    name: str = typer.Argument(..., help="The template to change."),
    folder: Path | None = typer.Option(None, "--folder", help="The templates folder. Default: the archive's templates\\."),
) -> None:
    """Open a template in Notepad (or $EDITOR); test it after: da template test <name> <files>."""
    import subprocess  # pylint: disable=import-outside-toplevel

    path = _folder(folder) / f"{name.strip().lower()}.yaml"
    if not path.is_file():
        console.print(f"[yellow]No template {escape(name)}[/yellow] in {escape(str(path.parent))}. "
                      f"Make it: da template new {escape(name)} --from <sample.pdf>")
        raise typer.Exit(1)
    editor = os.environ.get("EDITOR") or ("notepad" if os.name == "nt" else "vi")
    console.print(f"Opening {escape(str(path))} ...")
    subprocess.run([editor, str(path)], check=False)
    from mindit.services.templates.template import TemplateError, load_template  # pylint: disable=import-outside-toplevel

    try:
        t = load_template(path)
    except TemplateError as exc:
        console.print(f"[red]It has a mistake now:[/red] {escape(str(exc))}")
        raise typer.Exit(1) from exc
    console.print(f"{t.name} reads: {', '.join(f.name for f in t.fields)}. Try it: da template test {t.name} <files>")


@app.command("test")
def test(
    name: str = typer.Argument(..., help="The template (or several: a,b; or all)."),
    targets: list[Path] = typer.Argument(..., help="Documents, or folders of them, to try it on. Nothing is changed."),
    folder: Path | None = typer.Option(None, "--folder", help="The templates folder. Default: the archive's templates\\."),
    ocr: bool = typer.Option(True, "--ocr/--no-ocr", help="Read scans with Windows' OCR."),
) -> None:
    """Try a template on some documents: which match, what it reads in each, and why the others don't."""
    found = _show(name, _documents(targets), _folder(folder), ocr)
    if not found:
        raise typer.Exit(1)


def _show(name: str, files: list[Path], where: Path, ocr: bool) -> int:
    from mindit.services.templates.reading import read_files  # pylint: disable=import-outside-toplevel
    from mindit.services.templates.template import TemplateError, load_named  # pylint: disable=import-outside-toplevel

    try:
        templates = load_named([n for n in name.split(",") if n.strip()], where)
    except TemplateError as exc:
        console.print(f"[red]{escape(str(exc))}[/red]")
        raise typer.Exit(1) from exc
    names = ", ".join(t.name for t in templates)
    reader = _reader(ocr)
    try:
        results = read_files(files, templates, reader)
    finally:
        reader.close()
    for r in results:
        if r.matched:
            reading = r.reading
            console.print(f"  [green]matched[/green] {escape(r.path.name)} ({reading.template.name}, "
                          f"{reading.passed}/{reading.checks} checks)")
            for key, value in reading.fields.items():
                shown = f"{value['from']} to {value['to']}" if isinstance(value, dict) else value
                console.print(f"      {key}: {escape(str(shown))}")
            missing = [f.name for f in reading.template.fields if f.name not in reading.fields]
            if missing:
                console.print(f"      [yellow]not found: {', '.join(missing)}[/yellow]")
        else:
            console.print(f"  [red]failed[/red]  {escape(r.failure(names))}")
    matched = sum(1 for r in results if r.matched)
    console.print(f"{matched} of {len(results)} matched.")
    return matched
