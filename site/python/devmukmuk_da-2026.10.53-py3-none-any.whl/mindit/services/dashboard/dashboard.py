# src/mindit/services/dashboard/dashboard.py

"""`da dashboard`: a page on this PC (http://127.0.0.1:<port>) showing where the current archive stands.

It only reads: the index (read-only), the runs in output\\runs and the archive's log. The quick numbers (what's
filed, what's waiting, the last runs, what's happening now) are read again on every refresh; the slow ones
(years, cameras, places: the same SQL as `da report`, about a minute on a very big archive) once at the start
and again when the page's Recount button is pressed, in the background.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from mindit.services.report import archive_report as ar

REVIEW_LABELS = {
    "capture_date_uncertain": "No date (in the file or its name)",
    "outside_archive_years": "Taken outside this archive's years",
    "name_date_differs_from_exif": "File name and camera date disagree",
    "duplicate_file": "Duplicate inside the folder",
    "document_in_photos_folder": "Looks like a document, not a photo",
    "move_failed": "Couldn't be moved",
}
RUN_KINDS = {"run": "Process intake", "set-aside": "Set duplicates aside", "split": "Split by years",
             "merge": "Merge", "location-group": "Location folders", "sidecars": "Update sidecars",
             "ocr": "Read text (OCR)"}
IDLE_COMMANDS = {"da", "da menu"}                    # the menu waiting for a choice isn't working
DEFAULT_PORT = 8765
_RUN_DIR = re.compile(r"^(\d{8})-(\d{6})-(.+)$")


@dataclass
class Archive:
    """The archive a dashboard shows."""

    name: str
    folder: Path
    years: str
    db_path: Path
    output_root: Path
    log_path: Path
    version: str = ""


def _connect(db_path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{Path(db_path).as_posix()}?mode=ro", uri=True, timeout=5)


def counts(db_path: Path) -> dict[str, Any]:
    """Return what's filed and what's waiting in intake (by top-level folder), from the index."""
    out: dict[str, Any] = {"indexed": False, "filed": {}, "gigabytes": 0.0, "intake": 0, "intake_folders": [],
                           "holding": 0, "problems": 0, "index_built": None}
    if not Path(db_path).exists():
        return out
    try:
        with _connect(db_path) as conn:
            filed: dict[str, int] = {}
            for area, kind, n, size in conn.execute(
                    "SELECT area, media_type, COUNT(*), SUM(size_bytes) FROM files GROUP BY area, media_type"):
                if area in ("photos", "documents"):
                    filed[kind or "other"] = filed.get(kind or "other", 0) + n
                    out["gigabytes"] += (size or 0) / 1e9
                elif area == "intake":
                    out["intake"] += n
                elif area == "holding":
                    out["holding"] += n
            folders: dict[str, int] = {}
            for folder, n in conn.execute("SELECT folder, COUNT(*) FROM files WHERE area = 'intake' GROUP BY folder"):
                top = re.split(r"[\\/]", folder or "")[0] or "(intake)"
                folders[top] = folders.get(top, 0) + n
            out["problems"] = conn.execute("SELECT COUNT(*) FROM files WHERE area IN ('photos', 'documents') "
                                           "AND validation_status = 'problems'").fetchone()[0]
            built = conn.execute("SELECT MAX(created_at) FROM db_events WHERE event_type = 'db_build'").fetchone()
    except sqlite3.Error as exc:
        out["error"] = f"The index couldn't be read: {exc}"
        return out
    out.update(indexed=True, filed=filed, index_built=built[0] if built else None,
               intake_folders=sorted(folders.items(), key=lambda kv: -kv[1]))
    out["gigabytes"] = round(out["gigabytes"], 1)
    return out


def runs(output_root: Path, limit: int = 10) -> list[dict[str, Any]]:
    """Return the latest runs in output\\runs (newest first): when, what, and for `da run` what it did."""
    runs_dir = Path(output_root) / "runs"
    if not runs_dir.exists():
        return []
    found = []
    for entry in runs_dir.iterdir():
        match = _RUN_DIR.match(entry.name)
        if entry.is_dir() and match:
            found.append((match.group(1) + match.group(2), match.group(3), entry))
    out = []
    for stamp, kind, entry in sorted(found, reverse=True)[:limit]:
        row: dict[str, Any] = {"when": datetime.strptime(stamp, "%Y%m%d%H%M%S").strftime("%Y-%m-%d %H:%M"),
                               "kind": RUN_KINDS.get(kind, kind), "folder": entry.name, "detail": ""}
        if kind == "run":
            summary = _read_json(entry / "summary.json")
            steps = summary.get("steps", {})
            filed = ((steps.get("6_file") or {}).get("verify") or {}).get("moved", 0)
            set_aside = (steps.get("3_set_aside") or {}).get("moved", 0)
            row["detail"] = (f"stopped at {summary['stopped_at_step']}" if summary.get("stopped_at_step")
                             else f"filed {filed:,}") + (f", {set_aside:,} duplicates set aside" if set_aside else "")
            row["intake"] = summary.get("folder")
        out.append(row)
    return out


def review(output_root: Path) -> dict[str, Any]:
    """Return what the last `da run` left for the person to look at, by reason (menu 3 has the files)."""
    runs_dir = Path(output_root) / "runs"
    for summary_path in sorted(runs_dir.glob("*-run/summary.json"), reverse=True) if runs_dir.exists() else []:
        preview = (_read_json(summary_path).get("steps", {}) or {}).get("4_preview") or {}
        if "problems" in preview:
            rows = [(REVIEW_LABELS[code], n) for code, n in preview["problems"].items() if code in REVIEW_LABELS and n]
            return {"run": summary_path.parent.name, "folder": preview.get("target_folder"),
                    "rows": sorted(rows, key=lambda kv: -kv[1])}
    return {"run": None, "folder": None, "rows": []}


def activity(log_path: Path, limit: int = 30, now: datetime | None = None) -> dict[str, Any]:
    """Return the log's latest events (newest first) and the commands that started but haven't finished."""
    lines = _tail(Path(log_path), 256 * 1024)
    events = []
    for line in lines:
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    now = now or datetime.now(timezone.utc)
    open_commands: dict[str, dict] = {}
    for event in events:
        if event.get("event") != "command" or not event.get("command"):
            continue
        if event.get("status") == "start":
            open_commands[event["command"]] = event
        else:
            open_commands.pop(event["command"], None)
    working = []
    for command, event in open_commands.items():
        started = _parse_ts(event.get("ts"))
        # A window closed with its X never logs an end, so a start over 12 hours old isn't "working now".
        if started and now - started < timedelta(hours=12) and command not in IDLE_COMMANDS                 and not command.startswith("da dashboard"):
            working.append({"command": command, "since": _local(started), "minutes": int((now - started).total_seconds() // 60)})
    recent = [{"when": _local(_parse_ts(e.get("ts"))), "message": e.get("message", ""), "status": e.get("status", ""),
               "level": e.get("level", "")} for e in reversed(events) if e.get("event") != "menu"][:limit]
    return {"working": working, "recent": recent}


def details(archive: Archive) -> dict[str, Any]:
    """Return the slow numbers: years, cameras, owners and places (the report's numbers)."""
    data = ar.gather(archive.db_path, name=archive.name, folder=str(archive.folder), years=archive.years)
    out = asdict(data)
    out["made_at"] = data.made_at.strftime("%Y-%m-%d %H:%M")
    out["places_sentence"] = ar.places_sentence(data)
    out["cameras"] = [(ar.nice_name(c), n) for c, n in data.cameras]
    out["places"] = [(ar.place_label(p), n) for p, n in data.places]
    out["years"] = data.every_year + ([("No date", data.undated)] if data.undated else [])
    return out


class Dashboard:
    """The numbers behind the page: quick ones read on each call, the slow ones kept until recounted."""

    def __init__(self, archive: Archive) -> None:
        self.archive = archive
        self._details: dict[str, Any] | None = None
        self._counting = False
        self._lock = threading.Lock()

    def status(self) -> dict[str, Any]:
        """Return everything the page shows."""
        a = self.archive
        return {"archive": {"name": a.name, "folder": str(a.folder), "years": a.years or "any year",
                            "version": a.version},
                "updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "counts": counts(a.db_path), "runs": runs(a.output_root), "review": review(a.output_root),
                "activity": activity(a.log_path),
                "details": self._details, "counting": self._counting}

    def recount(self, wait: bool = False) -> None:
        """Count the slow numbers again, in the background (unless wait)."""
        with self._lock:
            if self._counting:
                return
            self._counting = True
        worker = threading.Thread(target=self._count, daemon=True)
        worker.start()
        if wait:
            worker.join()

    def _count(self) -> None:
        try:
            self._details = details(self.archive)
        except Exception as exc:  # pylint: disable=broad-except
            self._details = {"error": f"{type(exc).__name__}: {exc}"}
        finally:
            self._counting = False


def page() -> str:
    """Return the dashboard's HTML page."""
    from mindit.services.dashboard.page import PAGE  # pylint: disable=import-outside-toplevel

    return PAGE


def make_server(dashboard: Dashboard, port: int = DEFAULT_PORT, tries: int = 20) -> ThreadingHTTPServer:
    """Return a server on 127.0.0.1 (this PC only), on port or the next free one.

    It reads the archive; the only things it does are the page's buttons (set a picture as the desktop, open
    its folder), which need the page's own token, so another website can't press them.
    """
    import secrets  # pylint: disable=import-outside-toplevel
    from urllib.parse import parse_qs, urlparse  # pylint: disable=import-outside-toplevel

    from mindit.services.dashboard import pictures as pix  # pylint: disable=import-outside-toplevel

    token = secrets.token_urlsafe(24)
    html = page().replace("__DA_TOKEN__", token).encode("utf-8")
    archive = dashboard.archive

    class Handler(BaseHTTPRequestHandler):
        """Serve the page, its numbers and pictures; change nothing but the desktop background."""

        def _local(self) -> bool:
            """Refuse requests addressed to another name (a web page pointing its own name at 127.0.0.1)."""
            host = (self.headers.get("Host") or "").rsplit(":", 1)[0].strip("[]").lower()
            if host in ("127.0.0.1", "localhost", "::1"):
                return True
            self._send(403, "text/plain; charset=utf-8", b"Only this PC")
            return False

        def do_GET(self) -> None:  # pylint: disable=invalid-name
            """Answer the page, /api/..., /thumb/<id> and /file/<id>."""
            if not self._local():
                return
            url = urlparse(self.path)
            path, query = url.path, parse_qs(url.query)
            if path.startswith("/thumb/") or path.startswith("/file/"):
                self._picture(path)
            elif path == "/api/folders":
                self._json(pix.folders(archive.db_path))
            elif path == "/api/share-lists":
                self._json(sorted(_share_lists()))
            elif path == "/api/pictures":
                self._json(pix.items(archive.db_path, (query.get("area") or [None])[0],
                                     (query.get("folder") or [None])[0]))
            elif path in ("/", "/index.html"):
                self._send(200, "text/html; charset=utf-8", html)
            elif path == "/api/status":
                self._send(200, "application/json", json.dumps(dashboard.status()).encode("utf-8"))
            elif path == "/api/hello":                # `da dashboard` asking which archive this is
                self._send(200, "application/json",
                           json.dumps({"archive": str(dashboard.archive.folder)}).encode("utf-8"))
            elif path == "/api/recount":
                dashboard.recount()
                self._send(200, "application/json", b'{"counting": true}')
            else:
                self._send(404, "text/plain; charset=utf-8", b"Not found")

        def do_POST(self) -> None:  # pylint: disable=invalid-name
            """Do one of the page's buttons: {"token", "action": "desktop" | "folder", "id"}."""
            if not self._local():
                return
            try:
                ask = json.loads(self.rfile.read(min(int(self.headers.get("Content-Length") or 0), 10_000)))
            except (ValueError, TypeError):
                ask = {}
            if self.path != "/api/action" or not isinstance(ask, dict) or ask.get("token") != token:
                self._send(403, "text/plain; charset=utf-8", b"Not allowed")
                return
            found = pix.find(archive.db_path, archive.folder, int(ask.get("id") or 0))
            if found is None:
                self._json({"ok": False, "message": "That file isn't filed here any more."})
                return
            file_path, kind, _sha = found
            try:
                if ask.get("action") == "desktop" and kind == "photo":
                    pix.set_desktop(pix.wallpaper_copy(file_path, archive.folder))
                    _log("dashboard", f"dashboard: set {file_path.name} as the desktop background", file_path)
                    self._json({"ok": True, "message": "It's the desktop background now."})
                elif ask.get("action") == "folder":
                    pix.open_folder(file_path)
                    _log("dashboard", f"dashboard: opened the folder of {file_path.name}", file_path)
                    self._json({"ok": True, "message": "Opened its folder."})
                elif ask.get("action") == "share" and kind == "photo":
                    self._json(_share_one(file_path, str(ask.get("list") or "")))
                else:
                    self._json({"ok": False, "message": "Not something this button does (Share: photos only)."})
            except Exception as exc:  # pylint: disable=broad-except
                self._json({"ok": False, "message": f"{type(exc).__name__}: {exc}"})

        def _picture(self, path: str) -> None:
            """Send a thumbnail (/thumb/<id>) or the file to look at (/file/<id>)."""
            try:
                rowid = int(path.rsplit("/", 1)[1])
            except ValueError:
                rowid = 0
            found = pix.find(archive.db_path, archive.folder, rowid)
            if found is None:
                self._send(404, "text/plain; charset=utf-8", b"Not found")
                return
            file_path, kind, sha = found
            if path.startswith("/thumb/"):
                small = pix.thumbnail(file_path, kind, sha)
                if small is None:
                    self._send(404, "text/plain; charset=utf-8", b"No picture")
                else:
                    self._send(200, "image/jpeg", small, cache=True)
                return
            data, kind_type = pix.full(file_path)
            if data is not None:
                self._send(200, kind_type, data, cache=True)
            else:
                self._stream(file_path, kind_type)

        def _stream(self, file_path: Path, kind: str) -> None:
            """Send a file from disk, a part at a time when the browser asks (videos)."""
            size = file_path.stat().st_size
            start, end = 0, size - 1
            ranged = (self.headers.get("Range") or "").replace("bytes=", "").split("-", 1)
            if self.headers.get("Range") and ranged[0].isdigit():
                start = int(ranged[0])
                end = min(int(ranged[1]), size - 1) if len(ranged) > 1 and ranged[1].isdigit() else size - 1
                self.send_response(206)
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            else:
                self.send_response(200)
            self.send_header("Content-Type", kind)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            self.end_headers()
            with file_path.open("rb") as f:
                f.seek(start)
                left = end - start + 1
                try:
                    while left > 0:
                        chunk = f.read(min(1 << 20, left))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        left -= len(chunk)
                except (ConnectionError, OSError):
                    pass                                   # the browser stopped (a video skipped ahead)

        def _json(self, value: Any) -> None:
            self._send(200, "application/json", json.dumps(value).encode("utf-8"))

        def _send(self, code: int, kind: str, body: bytes, cache: bool = False) -> None:
            self.send_response(code)
            self.send_header("Content-Type", kind)
            self.send_header("Cache-Control", "private, max-age=3600" if cache else "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format: str, *args: Any) -> None:  # pylint: disable=redefined-builtin
            """Keep the terminal quiet: the page asks every few seconds."""

    class Server(ThreadingHTTPServer):
        """On Windows, address reuse lets a second server share a port in use; a taken port must fail instead."""

        allow_reuse_address = os.name != "nt"
        daemon_threads = True

    last_error: OSError | None = None
    for candidate in range(port, port + tries) if port else [0]:
        try:
            return Server(("127.0.0.1", candidate), Handler)
        except OSError as exc:                       # in use (another dashboard, or something else)
            last_error = exc
    raise OSError(f"No free port from {port} to {port + tries - 1}: {last_error}")


def _log(event: str, message: str, path: Path) -> None:
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event(event, message, path=str(path))


def _share_lists() -> dict[str, list[str]]:
    """Return the archive's share lists (da-archive.yaml share: lists:)."""
    from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

    try:
        return dict(load_settings().share.lists)
    except Exception:  # pylint: disable=broad-except
        return {}


def _share_one(photo: Path, name: str) -> dict[str, Any]:
    """Email one photo (a JPEG up to 2000 px) to a share list from the user's Gmail; never asks to sign in."""
    import io  # pylint: disable=import-outside-toplevel

    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    from mindit.services.share import gmail  # pylint: disable=import-outside-toplevel
    from mindit.services.share.sheet import caption_of  # pylint: disable=import-outside-toplevel

    people = next((v for k, v in _share_lists().items() if k.lower() == name.lower()), None)
    if not people:
        return {"ok": False, "message": f"No share list called {name!r} in da-archive.yaml."}
    try:
        creds = gmail.credentials(interactive=False)
    except gmail.ShareSetupError as exc:
        return {"ok": False, "message": str(exc)}
    try:
        from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

        register_heif_opener()
    except ImportError:
        pass
    with Image.open(photo) as img:
        img = ImageOps.exif_transpose(img)
        img.thumbnail((2000, 2000))
        out = io.BytesIO()
        img.convert("RGB").save(out, "JPEG", quality=88)
    caption, _when = caption_of(photo)
    gmail.send_each(people, f"Photo: {caption or photo.stem}", (caption + "\n\n" if caption else "")
                             + "Sent with DA (Digital Archive).",
                             [(photo.stem + ".jpg", out.getvalue(), "image/jpeg")], creds)
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("share", f"dashboard: shared 1 photo with {name}", path=str(photo))
    return {"ok": True, "message": f"Sent to {name} ({len(people)} people)."}


def _read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _tail(path: Path, size: int) -> list[str]:
    """Return the last lines in the last size bytes of a file (all of a small one)."""
    try:
        with path.open("rb") as handle:
            handle.seek(0, os.SEEK_END)
            end = handle.tell()
            handle.seek(max(0, end - size))
            text = handle.read().decode("utf-8", errors="replace")
    except OSError:
        return []
    lines = text.splitlines()
    return lines[1:] if end > size else lines         # the first line may be cut


def _parse_ts(value: str | None) -> datetime | None:
    try:
        stamp = datetime.fromisoformat(value or "")
    except ValueError:
        return None
    return stamp if stamp.tzinfo else stamp.replace(tzinfo=timezone.utc)


def _local(stamp: datetime | None) -> str:
    return stamp.astimezone().strftime("%Y-%m-%d %H:%M") if stamp else ""
