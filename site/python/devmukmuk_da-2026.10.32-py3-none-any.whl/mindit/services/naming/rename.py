# src/mindit/services/naming/rename.py

"""`da rename`: what every filed file would be called with the archive's name patterns (or one to try).

A preview: nothing changes. Raw files and Live Photo videos follow their photo's new name; a file with no
sure date, or no sidecar, keeps its name with a note to follow up; two files wanting one name are listed as
a conflict. Design: docs/da-docs/RENAME-DESIGN.md.
"""

from __future__ import annotations

import csv
import os
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from mindit.services.naming.tokens import missing_tokens

PLAN_FIELDS = ["path", "new_name", "action", "notes"]
MODULES = {"photo": "photoit", "video": "video", "document": "scanit"}
NO_DATE = "no sure date - set one with da date set, then rename again"
NO_SIDECAR = "no sidecar - run da validate on this folder first"


@dataclass
class NamePlan:
    """What each file would be called."""

    rows: list[dict[str, str]] = field(default_factory=list)
    counts: Counter = field(default_factory=Counter)
    missing: Counter = field(default_factory=Counter)      # token -> files that had nothing for it

    @property
    def renames(self) -> list[dict[str, str]]:
        """Return the rows that would change a name."""
        return [r for r in self.rows if r["action"] in ("rename", "follows")]


def _skip(path: Path) -> bool:
    from mindit.services.contactsheet.contact_sheet import is_sheet  # pylint: disable=import-outside-toplevel

    return (path.name.endswith(".meta.json") or is_sheet(path) or path.name.startswith(".")
            or any(part.lower() == "_duplicates-holding" for part in path.parts))


def files_to_name(targets: Iterable[Path]) -> list[Path]:
    """Return the files under targets that are named on their own (not sidecars, sheets or raw files)."""
    from mindit.services.validateit.validateit_file_types import RAW_EXTENSIONS  # pylint: disable=import-outside-toplevel

    seen: set[str] = set()
    out: list[Path] = []
    for target in targets:
        paths = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
        for path in paths:
            key = os.path.normcase(str(path))
            if key in seen or _skip(path) or path.suffix.lower() in RAW_EXTENSIONS:
                continue
            seen.add(key)
            out.append(path)
    return out


def _providers(documents_root: Path | None) -> Callable[[Path], tuple[str, Any]]:
    from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.scanit_repair_provider import ScanItRepairProvider  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.video_repair_provider import VideoRepairProvider  # pylint: disable=import-outside-toplevel

    photo, video, document = PhotoItRepairProvider(), VideoRepairProvider(), ScanItRepairProvider()
    docs = os.path.normcase(str(documents_root.resolve())) + os.sep if documents_root else None

    def provider(path: Path) -> tuple[str, Any]:
        if docs and os.path.normcase(str(path.resolve())).startswith(docs):
            return "document", document
        return ("video", video) if path.suffix.lower() in VIDEO_EXTENSIONS else ("photo", photo)

    return provider


def plan_names(files: list[Path], *, pattern: str | None = None, kind: str | None = None,
               documents_root: Path | None = None,
               progress: Callable[[int, int], None] | None = None) -> NamePlan:
    """Work out each file's name by its kind's pattern (or `pattern`); change nothing."""
    from mindit.config.settings import get_rename_pattern  # pylint: disable=import-outside-toplevel
    from mindit.services.photoit.photoit_workflows import (  # pylint: disable=import-outside-toplevel
        RenameFormatOptions,
        _build_rename_context,
        _build_target_filename,
        _load_metadata_json,
    )
    from mindit.services.validateit.quarantine_hash_service import stored_or_computed_sha256  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import companions, is_live_photo_part  # pylint: disable=import-outside-toplevel

    provider_for = _providers(documents_root)
    plan = NamePlan()
    following: set[str] = set()
    planned: list[tuple[Path, list[Path], str, str]] = []           # file, companions, new name, notes
    patterns: dict[str, str] = {}
    for i, path in enumerate(files, 1):
        if progress:
            progress(i, len(files))
        if os.path.normcase(str(path)) in following:
            continue
        this_kind, provider = provider_for(path)
        if kind and this_kind != kind:
            continue
        if this_kind == "video" and is_live_photo_part(path):
            continue                                                 # it follows its still
        sidecar = Path(f"{path}.meta.json")
        if not sidecar.exists():
            plan.rows.append({"path": str(path), "new_name": "", "action": "no sidecar", "notes": NO_SIDECAR})
            plan.counts["no sidecar"] += 1
            continue
        capture = provider.capture_date(path)
        if not capture.certain:
            plan.rows.append({"path": str(path), "new_name": "", "action": "no date", "notes": NO_DATE})
            plan.counts["no date"] += 1
            continue
        if this_kind not in patterns:
            patterns[this_kind] = pattern or get_rename_pattern(MODULES[this_kind])
        metadata = _load_metadata_json(sidecar) or {}
        sha256 = stored_or_computed_sha256(path)
        options = RenameFormatOptions(pattern=patterns[this_kind])
        new_name = _build_target_filename(path, capture.value, None, options, metadata, sha256)
        context = _build_rename_context(path, capture.value, sha256, metadata)
        missing = missing_tokens(patterns[this_kind], context)
        for token in missing:
            plan.missing[token] += 1
        notes = "; ".join(f"the name token {{{t}}} was missing" for t in missing)
        others = [c for c in companions(path) if c.exists()]
        following.update(os.path.normcase(str(c)) for c in others)
        planned.append((path, others, new_name, notes))

    _add_rows(plan, planned)
    return plan


def _add_rows(plan: NamePlan, planned: list[tuple[Path, list[Path], str, str]]) -> None:
    """Add the planned names as rows, marking two files wanting one name (or a name taken) as conflicts."""
    wanted: Counter = Counter()
    leaving = {os.path.normcase(str(p)) for p, _o, new, _n in planned if new != p.name}
    for path, others, new_name, _notes in planned:
        stem = Path(new_name).stem
        for target in [path.with_name(new_name)] + [c.with_name(stem + c.suffix.lower()) for c in others]:
            wanted[os.path.normcase(str(target))] += 1

    def taken(source: Path, target: Path) -> bool:
        key = os.path.normcase(str(target))
        if wanted[key] > 1:
            return True
        same = os.path.normcase(str(source)) == key
        return target.exists() and not same and key not in leaving

    for path, others, new_name, notes in planned:
        stem = Path(new_name).stem
        moves = [(path, path.with_name(new_name))] + [(c, c.with_name(stem + c.suffix.lower())) for c in others]
        if new_name == path.name:
            action = "unchanged"
        elif any(taken(src, dst) for src, dst in moves):
            action, notes = "conflict", "; ".join(x for x in ("another file has (or wants) that name", notes) if x)
        else:
            action = "rename"
        plan.counts[action] += 1
        plan.rows.append({"path": str(path), "new_name": new_name if action != "unchanged" else "",
                          "action": action, "notes": notes})
        if action == "rename":
            for src, dst in moves[1:]:
                plan.counts["follows"] += 1
                plan.rows.append({"path": str(src), "new_name": dst.name, "action": "follows",
                                  "notes": f"follows {path.name}"})


def write_plan(plan: NamePlan, path: Path) -> Path:
    """Write the plan as a CSV Excel opens (UTF-8 with a BOM)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=PLAN_FIELDS)
        writer.writeheader()
        writer.writerows(plan.rows)
    return path
