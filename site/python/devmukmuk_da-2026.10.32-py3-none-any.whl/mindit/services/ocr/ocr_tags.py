# src/mindit/services/ocr/ocr_tags.py

"""`da tag ocr`: read the text in pictures, tag those with text (`text`) or mostly text (`document`), and
optionally move the `document` ones to the documents tree.

What was read goes in the sidecar's `ocr` block (words, how much of the picture they cover, the level, the text)
and the tags in its `auto_tags` (`da tag` keeps them). A preview reads but changes no file; what it read is kept
in .da\\ocr-cache.jsonl so --tag-only or --tag-and-move afterwards doesn't read the same pictures again. Every
run writes output\\runs\\<time>-ocr\\ocr-results.csv; moves are logged like a set-aside (ocr-moved.csv), so
`da intake undo` puts them back.
"""

from __future__ import annotations

import csv
import json
import sqlite3
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Protocol

from mindit.services.dbit.intake_service import LOG_FIELDS
from mindit.services.ocr.windows_ocr import OCR_EXTENSIONS
from mindit.services.tagging.tags import AUTO_BLOCK, SKIP_NAMES, all_tags
from mindit.services.validateit.validateit_file_types import companions

OCR_BLOCK = "ocr"
LOG_CLASS = "ocr_document"
SIDECAR_SUFFIX = ".meta.json"
TEXT_TAG, DOCUMENT_TAG = "text", "document"
OCR_TAGS = (TEXT_TAG, DOCUMENT_TAG)
TEXT_MIN_WORDS = 3                 # one or two "words" are usually noise (a logo, a T-shirt, a pattern)
DOCUMENT_MIN_WORDS = 20            # a receipt, a letter, a screenshot: many words ...
DOCUMENT_MIN_COVERAGE = 0.03       # ... covering a good part of the picture (a sign in a landscape doesn't)
TEXT_KEPT = 5000                   # characters of text kept in the sidecar
RESULT_FIELDS = ["path", "level", "words", "coverage", "action", "destination", "note", "text"]


class Reader(Protocol):  # pylint: disable=too-few-public-methods
    """Something that reads a picture's text (WindowsOcr, or a stand-in in tests)."""

    engine: str
    language: str

    def read(self, path: Path) -> dict[str, Any]:
        """Return {words, coverage, text} or {error}."""


def level(words: int, coverage: float) -> str:
    """Return 'document', 'text' or 'none' for what a picture holds."""
    if words >= DOCUMENT_MIN_WORDS and coverage >= DOCUMENT_MIN_COVERAGE:
        return DOCUMENT_TAG
    if words >= TEXT_MIN_WORDS:
        return TEXT_TAG
    return "none"


def tags_for(level_name: str) -> list[str]:
    """Return the automatic tags for a level: a document has text too."""
    return {DOCUMENT_TAG: [TEXT_TAG, DOCUMENT_TAG], TEXT_TAG: [TEXT_TAG]}.get(level_name, [])


def ocr_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the tags a sidecar's `ocr` block gives (for `da tag`, which remakes the automatic tags)."""
    block = sidecar.get(OCR_BLOCK)
    return tags_for(block.get("level", "none")) if isinstance(block, dict) else []


def pictures_under(targets: list[Path]) -> list[Path]:
    """Return the pictures OCR can read in the files and folders named."""
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel

    return [p for p in files_under(targets, photos_only=False)
            if p.suffix.lower() in OCR_EXTENSIONS and p.name.lower() not in SKIP_NAMES]


# --------------------------------------------------------------------------- what was read before

def _cache_key(path: Path) -> str | None:
    try:
        stat = path.stat()
    except OSError:
        return None
    return f"{path}|{stat.st_size}|{int(stat.st_mtime)}"


class Cache:
    """What previews read (path, size and time -> the result), so the next run doesn't read it again."""

    def __init__(self, path: Path | None) -> None:
        self.path = path
        self.found: dict[str, dict[str, Any]] = {}
        if path and path.exists():
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
                try:
                    entry = json.loads(line)
                    self.found[entry["key"]] = entry["result"]
                except (ValueError, KeyError, TypeError):
                    continue

    def get(self, path: Path) -> dict[str, Any] | None:
        """Return what was read from this file as it is now, if anything."""
        key = _cache_key(path)
        return self.found.get(key) if key else None

    def put(self, path: Path, result: dict[str, Any]) -> None:
        """Remember what was read."""
        key = _cache_key(path)
        if not key or not self.path or "error" in result:
            return
        self.found[key] = result
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"key": key, "result": result}, ensure_ascii=False) + "\n")


# --------------------------------------------------------------------------- a run

@dataclass
class Where:
    """The archive's trees, so a document can be moved to the right one."""

    photos_organized: Path
    documents_organized: Path
    intake: Path
    intake_documents: Path


@dataclass
class OcrRun:
    """What a run found and did."""

    mode: str                                    # preview, tag, move
    results: list[dict[str, Any]] = field(default_factory=list)
    counts: Counter = field(default_factory=Counter)
    changed: dict[str, str] = field(default_factory=dict)    # path -> tags JSON, for the index
    moves: list[dict[str, str]] = field(default_factory=list)


def _under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def destination(path: Path, where: Where) -> tuple[Path | None, str]:
    """Return where a document picture goes, or None and why it stays."""
    if _under(path, where.documents_organized):
        return None, "already in documents"
    if _under(path, where.intake):
        if _under(path, where.intake_documents):
            return None, "already in the documents intake folder"
        # In intake: to the documents intake folder, so `da run` files it as a document (after its checks).
        return where.intake_documents / path.resolve().relative_to(where.intake.resolve()), "to the documents intake"
    from mindit.services.validateit.capture_date import resolve_capture_date  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.scanit_repair_provider import ScanItRepairProvider  # pylint: disable=import-outside-toplevel

    capture = resolve_capture_date(path)
    if not capture.certain or capture.value is None:
        return None, "no date, so it can't be filed (tagged only)"
    name = ScanItRepairProvider().expected_name(path) or path.name
    folder = where.documents_organized / capture.value.strftime("%Y") / capture.value.strftime("%Y-%m")
    return folder / name, "to documents"


def run_ocr(files: list[Path], reader: Reader, *, mode: str, where: Where, cache: Cache | None = None,
            again: bool = False, progress: Callable[[int, int], None] | None = None) -> OcrRun:
    """Read each picture's text (or reuse what was read), then tag and move as the mode says."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    run = OcrRun(mode)
    cache = cache or Cache(None)
    for i, path in enumerate(files, 1):
        data = SidecarService.load(path) if Path(f"{path}{SIDECAR_SUFFIX}").exists() else {}
        block = data.get(OCR_BLOCK) if isinstance(data.get(OCR_BLOCK), dict) else None
        row: dict[str, Any] = {"path": str(path), "destination": "", "note": ""}
        if block is not None and not again:
            found = {"words": block.get("words", 0), "coverage": block.get("coverage", 0.0),
                     "text": block.get("text", "")}
            row["note"] = "read before"
        else:
            found = cache.get(path) if not again else None
            if found is None:
                found = reader.read(path)
                run.counts["read"] += 1
                cache.put(path, found)
            else:
                row["note"] = "read in a preview"
        if "error" in found:
            row.update(level="", words="", coverage="", action="couldn't read", note=str(found["error"]), text="")
            run.counts["unreadable"] += 1
            run.results.append(row)
            continue
        words, coverage = int(found.get("words") or 0), float(found.get("coverage") or 0.0)
        name = level(words, coverage)
        text = " ".join(str(found.get("text") or "").split())
        row.update(level=name, words=words, coverage=coverage, text=text[:120])
        run.counts[name] += 1

        if mode != "preview" and Path(f"{path}{SIDECAR_SUFFIX}").exists():
            new_block = {"engine": reader.engine, "language": reader.language, "read_at":
                         datetime.now().isoformat(timespec="seconds"), "words": words, "coverage": coverage,
                         "level": name, "text": text[:TEXT_KEPT], "text_truncated": len(text) > TEXT_KEPT}
            if block and not again:
                new_block = {**block, "level": name}              # keep when and how it was read
            auto = data.get(AUTO_BLOCK) if isinstance(data.get(AUTO_BLOCK), dict) else {}
            old_tags = list(auto.get("tags") or [])
            tags = [t for t in old_tags if t not in OCR_TAGS] + tags_for(name)
            if new_block != block or tags != old_tags:
                data[OCR_BLOCK] = new_block
                data[AUTO_BLOCK] = {**auto, "tags": tags}
                SidecarService.save(path, data)
                run.changed[str(path)] = json.dumps(all_tags(data))
        elif mode != "preview":
            row["note"] = "no sidecar: run da run or da validate first (not tagged)"

        if name == DOCUMENT_TAG:
            target, why = destination(path, where)
            if target is None:
                row["action"] = "tagged" if mode != "preview" else "would tag"
                row["note"] = (row["note"] + "; " if row["note"] else "") + why
            elif mode == "move":
                row["action"], row["destination"] = "move", str(target)
            else:
                row["action"] = "tagged (would move)" if mode == "tag" else "would tag and move"
                row["destination"] = str(target)
        elif name == TEXT_TAG:
            row["action"] = "tagged" if mode != "preview" else "would tag"
        else:
            row["action"] = "no text"
        run.results.append(row)
        if progress:
            progress(i, len(files))
    return run


# --------------------------------------------------------------------------- moving

def apply_moves(run: OcrRun, log_path: Path, db_path: Path | None, documents_root: Path) -> Counter:
    """Move the document pictures (with companions and sidecars); log each move so undo can reverse it."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.split import _move, _on_disk  # pylint: disable=import-outside-toplevel

    stats: Counter = Counter()
    rows_db: list[tuple] = []
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", newline="", encoding="utf-8") as f:
        log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        log.writeheader()
        for row in run.results:
            if row.get("action") != "move":
                continue
            src, dst = Path(row["path"]), Path(row["destination"])
            pairs = [(src, dst)] + [(_on_disk(c), dst.with_name(dst.stem + _on_disk(c).suffix))
                                    for c in companions(src)]
            if any(d.exists() for _, d in pairs) or not src.exists():
                row["action"], row["note"] = "not moved", "a file of that name is already there"
                stats["skipped"] += 1
                continue
            old_class = SidecarService.get_block(src, "classification")
            for n, (a, b) in enumerate(pairs):
                entry = {"class": LOG_CLASS, "source": str(a), "destination": str(b), "size_bytes": str(a.stat().st_size),
                         "sha256": "", "kept": "" if n == 0 else str(src), "sidecar_source": "",
                         "sidecar_destination": "", "result": "moved",
                         "note": json.dumps({"classification": old_class}) if n == 0 else ""}
                try:
                    _move(a, b)
                except OSError as error:
                    entry["result"], entry["note"] = "skipped", str(error)
                    log.writerow(entry)
                    stats["failed"] += 1
                    continue
                side_a, side_b = Path(f"{a}{SIDECAR_SUFFIX}"), Path(f"{b}{SIDECAR_SUFFIX}")
                if side_a.exists() and not side_b.exists():
                    _move(side_a, side_b)
                    entry["sidecar_source"], entry["sidecar_destination"] = str(side_a), str(side_b)
                log.writerow(entry)
                in_documents = _under(b, documents_root)
                rows_db.append((str(b), b.name, "documents" if in_documents else None,
                                "document" if in_documents else None, str(a)))
            if _under(dst, documents_root):                  # it's a document now: validate keeps it there
                SidecarService.update_block(dst, "classification",
                                            {**old_class, "module": "scanit", "media_type": "document"})
            row["action"] = "moved"
            stats["moved"] += 1
    if db_path and Path(db_path).exists() and rows_db:
        with sqlite3.connect(db_path) as conn:
            conn.executemany("UPDATE files SET path = ?, file_name = ?, area = COALESCE(?, area), "
                             "media_type = COALESCE(?, media_type) WHERE path = ?", rows_db)
    return stats


def undo_rows(db_path: Path, rows: list[dict[str, str]]) -> None:
    """After `da intake undo` moved them back: photos again, in the index and in their sidecars."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    for r in rows:
        try:
            old = json.loads(r.get("note") or "{}").get("classification")
        except ValueError:
            old = None
        if old is not None and Path(r["source"]).exists() and Path(f"{r['source']}{SIDECAR_SUFFIX}").exists():
            SidecarService.update_block(Path(r["source"]), "classification", old)
    if db_path and Path(db_path).exists():
        with sqlite3.connect(db_path) as conn:
            conn.executemany("UPDATE files SET path = ?, file_name = ?, area = CASE WHEN area = 'documents' "
                             "THEN 'photos' ELSE area END, media_type = CASE WHEN media_type = 'document' "
                             "THEN 'photo' ELSE media_type END WHERE path = ?",
                             [(r["source"], Path(r["source"]).name, r["destination"]) for r in rows])


def write_results(run: OcrRun, path: Path) -> Path:
    """Write what each picture held and what was done, one row per picture."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:      # -sig: Excel opens it as UTF-8
        out = csv.DictWriter(f, fieldnames=RESULT_FIELDS, extrasaction="ignore")
        out.writeheader()
        out.writerows(run.results)
    return path
