"""A photographer's edits: exports a photo editor made from a RAW (design: docs/da-docs/EDITS-DESIGN.md, 2026-10-26).

An export carries an XMP packet naming the picture it came from (Lightroom: `xmpMM:PreservedFileName` = the RAW's name
at import, `xmpMM:OriginalDocumentID` = the same id in every export of that RAW). Such an export is never a "copy" to set
aside; it's paired with its RAW (by name + camera + shutter time, else camera + time) and with its sister exports.
"""

from __future__ import annotations

import csv
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

from mindit.services.validateit.validateit_file_types import RAW_EXTENSIONS

EDIT_BLOCK = "edit"                         # on an export: what it says it was made from, and its RAW here
EDITS_BLOCK = "edits"                       # on a RAW: the exports made from it
EDITOR_TOOLS = ("lightroom", "photoshop", "camera raw", "capture one", "affinity", "darktable", "luminar", "on1",
                "dxo", "rawtherapee", "lightzone", "aftershot", "acdsee")
XMP_LIMIT = 1 << 20                         # a JPEG's XMP is in its first 64 KB; a TIFF/PSD's can sit further in
_PURPOSE = re.compile(r"\b(?:for\s+)?(print|social\s*media|screen|web|instagram|facebook|blog|email)\b", re.I)


def xmp_packet(path: Path, limit: int = XMP_LIMIT) -> str:
    """Return the XMP packet in the first part of a file (no image decode), or ''."""
    try:
        with open(path, "rb") as f:
            data = f.read(limit)
    except OSError:
        return ""
    start = data.find(b"<x:xmpmeta")
    end = data.find(b"</x:xmpmeta>", start)
    return data[start:end + 12].decode("utf-8", "replace") if start >= 0 and end > start else ""


def _value(xmp: str, name: str) -> str:
    """Return one XMP property, written as an attribute (name="v") or an element (<name>v</name>)."""
    found = re.search(re.escape(name) + r'\s*=\s*"([^"]*)"', xmp) or \
        re.search("<" + re.escape(name) + r">([^<]*)</" + re.escape(name) + ">", xmp)
    return found.group(1).strip() if found else ""


def purpose_of(path: Path) -> str:
    """Return what an export was for, from its folder names ('For Print', 'For Social Media'), or ''."""
    for part in reversed(Path(path).parent.parts):
        found = _PURPOSE.search(part)
        if found:
            return found.group(1).strip().title().replace("Socialmedia", "Social Media")
    return ""


def edit_info(path: Path) -> dict[str, str] | None:
    """Return what an export says it was made from (tool, from_name, original_id ...), or None when it isn't an edit."""
    xmp = xmp_packet(Path(path))
    if not xmp:
        return None
    tool = _value(xmp, "xmp:CreatorTool")
    info = {
        "tool": tool,
        "from_name": _value(xmp, "xmpMM:PreservedFileName") or _value(xmp, "crs:RawFileName")
                     or Path(_value(xmp, "stRef:filePath")).name,
        "original_id": _value(xmp, "xmpMM:OriginalDocumentID") or _value(xmp, "stRef:documentID"),
        "camera_serial": _value(xmp, "aux:SerialNumber") or _value(xmp, "exifEX:BodySerialNumber"),
        "taken": _value(xmp, "exif:DateTimeOriginal") or _value(xmp, "photoshop:DateCreated"),
    }
    made_by_editor = any(t in tool.lower() for t in EDITOR_TOOLS)
    if not made_by_editor or not (info["from_name"] or info["original_id"]):
        return None
    if Path(info["from_name"]).name.lower() == Path(path).name.lower():
        info["from_name"] = ""                                   # the file's own name: it says nothing about a RAW
        if not info["original_id"]:
            return None
    info["purpose"] = purpose_of(Path(path))
    return {k: v for k, v in info.items() if v}


def edit_key(info: dict[str, str] | None) -> str:
    """Return what the exports of one RAW share (Lightroom's id for it, else its name + camera), or ''."""
    if not info:
        return ""
    if info.get("original_id"):
        return info["original_id"]
    return f"name:{info.get('from_name', '').lower()}|{info.get('camera_serial', '')}"


def _second(text: str) -> str:
    """Return a date/time to the second as 'YYYY-MM-DDTHH:MM:SS' (EXIF 'YYYY:MM:DD HH:MM:SS' or ISO), or ''."""
    found = re.match(r"(\d{4})[:-](\d\d)[:-](\d\d)[T ](\d\d):(\d\d):(\d\d)", (text or "").strip())
    return "{}-{}-{}T{}:{}:{}".format(*found.groups()) if found else ""


def raw_facts(row: dict[str, Any]) -> dict[str, Any]:
    """Return a RAW's names (now, original, imported as), camera serial and shutter time, from its sidecar and row."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    data = SidecarService.load(Path(row["path"])) if Path(f"{row['path']}.meta.json").exists() else {}
    camera = data.get("camera") if isinstance(data.get("camera"), dict) else {}
    origin = data.get("origin") if isinstance(data.get("origin"), dict) else {}
    file_block = data.get("file") if isinstance(data.get("file"), dict) else {}
    names = {Path(row["path"]).name, origin.get("file_name") or "", Path(row.get("source_path") or "").name,
             Path(file_block.get("source_path") or "").name}
    return {**row, "names": {n.lower() for n in names if n}, "serial": str(camera.get("body_serial") or ""),
            "taken": _second(str(camera.get("date_taken") or ""))}


def pair_with_raws(edits: list[dict[str, Any]], raws: list[dict[str, Any]]) -> None:
    """Set each edit's `raw` (a RAW's row) and `matched_by`, or `raw` None and why ('no RAW here', 'two RAWs fit')."""
    by_name: dict[str, list[dict[str, Any]]] = {}
    by_moment: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for raw in raws:
        for name in raw["names"]:
            by_name.setdefault(name, []).append(raw)
        if raw["serial"] and raw["taken"]:
            by_moment.setdefault((raw["serial"], raw["taken"]), []).append(raw)
    for edit in edits:
        info, taken = edit["info"], _second(edit["info"].get("taken", ""))
        serial = info.get("camera_serial", "")
        named = by_name.get(info.get("from_name", "").lower(), [])
        fits = [r for r in named if (not serial or not r["serial"] or r["serial"] == serial)
                and (not taken or not r["taken"] or r["taken"] == taken)]
        how = "name, camera and time"
        if not fits and serial and taken:
            fits, how = by_moment.get((serial, taken), []), "camera and time"
        unique = {r["sha256"]: r for r in fits}
        if len(unique) == 1:
            edit["raw"], edit["matched_by"] = next(iter(unique.values())), how
        else:
            edit["raw"], edit["matched_by"] = None, ("two RAWs fit" if unique else "no RAW here")


def find_edits(db: Any, prefix: str = "", progress: Callable[[str], None] | None = None) -> list[dict[str, Any]]:
    """Return the edits in the index (under prefix when given), each paired with its RAW where one is here."""
    from mindit.services.similar.fingerprints import PICTURE_EXTENSIONS  # pylint: disable=import-outside-toplevel

    db.initialize(log=False)
    with db.connect() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT path, sha256, area, size_bytes, source_path FROM files "
            "WHERE area IN ('photos', 'intake') AND sha256 IS NOT NULL")]
    raws = [raw_facts(r) for r in rows if Path(r["path"]).suffix.lower() in RAW_EXTENSIONS]
    pictures = [r for r in rows if Path(r["path"]).suffix.lower() in PICTURE_EXTENSIONS
                and r["path"].startswith(prefix)]
    edits = []
    for i, row in enumerate(pictures, 1):
        info = edit_info(Path(row["path"]))
        if info:
            if not info.get("purpose"):                         # filed: its intake folders are in the origin block
                info["purpose"] = _origin_purpose(Path(row["path"]))
            edits.append({**row, "info": {k: v for k, v in info.items() if v}, "key": edit_key(info)})
        if progress and i % 2000 == 0:
            progress(f"{i:,} of {len(pictures):,} pictures read")
    pair_with_raws(edits, raws)
    return edits


def describe(raw: dict) -> str:
    """Return 'RAW + 3 edits (print, screen)' for a RAW, 'edit of IMG_1732.CR2 (print)' for an export, or ''."""
    made = raw.get("edits") if isinstance(raw.get("edits"), dict) else {}
    listed = [e for e in made.get("edits") or [] if isinstance(e, dict)]
    if listed:
        purposes = sorted({(e.get("purpose") or "").lower() for e in listed} - {""})
        return f"RAW + {len(listed)} edit{'s' if len(listed) != 1 else ''}" + (f" ({', '.join(purposes)})" if purposes else "")
    edit = raw.get("edit") if isinstance(raw.get("edit"), dict) else {}
    if not edit:
        return ""
    source = (edit.get("raw") or {}).get("file_name") if isinstance(edit.get("raw"), dict) else None
    named = edit.get("from_name") or source or "a RAW not in this archive"
    return f"edit of {named}" + (f" ({edit['purpose'].lower()})" if edit.get("purpose") else "")


def edits_beside(raw_path: Path) -> list[Path]:
    """Return the edits filed with a RAW (beside it, or in a purpose subfolder), found by their `edit` block."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    raw_path = Path(raw_path)
    if not Path(f"{raw_path}.meta.json").exists():
        return []
    raw_data = SidecarService.load(raw_path)
    listed = raw_data.get(EDITS_BLOCK) if isinstance(raw_data.get(EDITS_BLOCK), dict) else {}
    if not listed.get("edits"):
        return []
    file_block = raw_data.get("file") if isinstance(raw_data.get("file"), dict) else {}
    raw_sha = file_block.get("sha256") or ((raw_data.get("quarantine") or {}).get("hash_sha256")
                                          if isinstance(raw_data.get("quarantine"), dict) else None)
    stem = raw_path.stem.lower() + "-"
    found = []
    for candidate in list(raw_path.parent.glob("*")) + list(raw_path.parent.glob("*/*")):
        if not candidate.is_file() or not candidate.name.lower().startswith(stem) \
                or candidate.name.lower().endswith(".meta.json") or not Path(f"{candidate}.meta.json").exists():
            continue
        edit = SidecarService.load(candidate).get(EDIT_BLOCK)
        if isinstance(edit, dict) and isinstance(edit.get("raw"), dict) and raw_sha \
                and edit["raw"].get("sha256") == raw_sha:
            found.append(candidate)
    return sorted(found)


def _origin_purpose(path: Path) -> str:
    """Return the purpose its intake folders named ('For Print'), from the sidecar's origin block, or ''."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    if not Path(f"{path}.meta.json").exists():
        return ""
    origin = SidecarService.load(path).get("origin")
    folders = origin.get("folders") if isinstance(origin, dict) else None
    return purpose_of(Path(*folders, path.name)) if folders else ""


REPORT_FIELDS =["path", "purpose", "tool", "from_name", "raw", "matched_by", "sha256"]


def write_report(edits: Iterable[dict[str, Any]], path: Path) -> Path:
    """Write edits.csv: each edit, what it was for, its RAW here (or why none)."""
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(REPORT_FIELDS)
        for e in edits:
            w.writerow([e["path"], e["info"].get("purpose", ""), e["info"].get("tool", ""),
                        e["info"].get("from_name", ""), e["raw"]["path"] if e["raw"] else "", e["matched_by"],
                        e["sha256"]])
    return Path(path)


def write_blocks(edits: list[dict[str, Any]]) -> int:
    """Write each edit's `edit` block and each RAW's `edits` block; return how many sidecars changed."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    now = datetime.now().isoformat(timespec="seconds")
    sisters: dict[str, list[dict[str, Any]]] = {}
    for e in edits:
        sisters.setdefault(e["key"], []).append(e)
    per_raw: dict[str, list[dict[str, Any]]] = {}
    changed = 0
    for e in edits:
        raw = e["raw"]
        block = {**e["info"], "found_at": now,
                 "raw": ({"sha256": raw["sha256"], "file_name": Path(raw["path"]).name, "matched_by": e["matched_by"]}
                         if raw else None),
                 "exports": [{"sha256": s["sha256"], "file_name": Path(s["path"]).name,
                              "purpose": s["info"].get("purpose", "")} for s in sisters[e["key"]] if s is not e]}
        changed += _save_block(SidecarService, Path(e["path"]), EDIT_BLOCK, block)
        if raw:
            per_raw.setdefault(raw["path"], []).append(e)
    for raw_path, made in per_raw.items():
        block = {"found_at": now, "edits": [{"sha256": e["sha256"], "file_name": Path(e["path"]).name,
                                            "purpose": e["info"].get("purpose", ""), "tool": e["info"].get("tool", "")}
                                           for e in sorted(made, key=lambda x: x["path"])]}
        changed += _save_block(SidecarService, Path(raw_path), EDITS_BLOCK, block)
    return changed


def _save_block(sidecars: Any, path: Path, name: str, block: dict[str, Any]) -> int:
    if not path.exists():
        return 0
    data = sidecars.load(path)
    old = data.get(name) if isinstance(data.get(name), dict) else {}
    if {k: v for k, v in old.items() if k != "found_at"} == {k: v for k, v in block.items() if k != "found_at"}:
        return 0
    data[name] = block
    sidecars.save(path, data)
    return 1
