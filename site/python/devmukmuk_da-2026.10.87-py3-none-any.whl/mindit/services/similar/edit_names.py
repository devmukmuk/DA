"""Where an edit is filed: beside the RAW it was made from, named after it (EDITS-DESIGN.md phase 2).

da-archive.yaml `modules.photoit.edits`: `folder` under the RAW's folder ("" beside it, "{purpose}" a subfolder per
purpose) and `name` ({raw} the RAW's name without its extension, {purpose}/{Purpose} what the export was for, {n} its
number among the RAW's exports, largest first). The RAW's place is where it is filed, or will be.
"""

from __future__ import annotations

import re
import sqlite3
from pathlib import Path
from typing import Any

from mindit.services.similar.edits import EDIT_BLOCK


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def _rows(db_path: Path, shas: list[str]) -> dict[str, dict[str, Any]]:
    """Return {sha256: {path, size_bytes}} from the index (a filed copy before one in intake)."""
    if not db_path.exists() or not shas:
        return {}
    out: dict[str, dict[str, Any]] = {}
    with sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True) as conn:
        marks = ",".join("?" * len(shas))
        for sha, path, size, area in conn.execute(
                f"SELECT sha256, path, size_bytes, area FROM files WHERE sha256 IN ({marks}) "
                "ORDER BY area = 'intake', path", shas):
            if sha not in out and Path(path).exists():
                out[sha] = {"path": Path(path), "size_bytes": size or 0, "area": area}
    return out


def render(pattern: str, raw_stem: str, purpose: str, n: int) -> str:
    """Return a name or folder from the edits pattern; an unknown purpose becomes 'edit<n>' (folder: 'Edits')."""
    text = pattern.replace("{raw}", raw_stem).replace("{n}", str(n))
    if "{purpose}" in text or "{Purpose}" in text:
        if purpose:
            text = text.replace("{purpose}", _slug(purpose)).replace("{Purpose}", purpose)
        else:
            text = text.replace("{purpose}", f"edit{n}").replace("{Purpose}", "Edits")
    return text


def edit_place(path: Path, metadata: dict[str, Any], provider: Any, db_path: Path, settings: Any) -> tuple[Path, str] | None:
    """Return (folder, file name) for an edit paired with a RAW in this archive, or None (filed like any photo)."""
    block = metadata.get(EDIT_BLOCK) if isinstance(metadata, dict) else None
    raw = block.get("raw") if isinstance(block, dict) else None
    if not isinstance(raw, dict) or not raw.get("sha256"):
        return None
    from mindit.services.validateit.quarantine_hash_service import stored_or_computed_sha256  # pylint: disable=import-outside-toplevel

    own = stored_or_computed_sha256(path)
    sisters = [s.get("sha256") for s in block.get("exports") or [] if isinstance(s, dict) and s.get("sha256")]
    known = _rows(db_path, [raw["sha256"], own, *sisters])
    if raw["sha256"] not in known:
        return None                                              # the RAW isn't here (any more): an ordinary photo
    raw_path = known[raw["sha256"]]["path"]
    raw_folder = provider.expected_folder(raw_path) or raw_path.parent
    raw_stem = Path(provider.expected_name(raw_path) or raw_path.name).stem

    purposes = {own: block.get("purpose", "")}
    purposes.update({s.get("sha256"): s.get("purpose", "") for s in block.get("exports") or [] if isinstance(s, dict)})
    members = sorted({own, *[s for s in sisters if s in known]},
                     key=lambda s: (-(known.get(s, {}).get("size_bytes") or path.stat().st_size), s))
    edits = settings.edits
    names: dict[str, str] = {}
    taken: dict[str, int] = {}
    for n, sha in enumerate(members, 1):
        folder = render(edits.folder, raw_stem, purposes.get(sha, ""), n)
        name = render(edits.name, raw_stem, purposes.get(sha, ""), n)
        key = f"{folder}\\{name}".lower()
        taken[key] = taken.get(key, 0) + 1
        names[sha] = f"{folder}\x00{name}" + (f"-{taken[key]}" if taken[key] > 1 else "")   # two alike: -2, -3 ...
    folder, name = names[own].split("\x00")
    return (raw_folder / folder if folder else raw_folder), f"{name}{path.suffix.lower()}"
