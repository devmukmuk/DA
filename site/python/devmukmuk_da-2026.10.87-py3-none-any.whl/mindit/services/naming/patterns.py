# src/mindit/services/naming/patterns.py

"""Save a name pattern into an archive's da-archive.yaml, keeping the earlier ones as dated notes under it.

    modules:
      photoit:
        pattern: "{date_taken:%Y%m%d}_{camera}_{hash:4}"
        # was (2026-10-16): photo_{date_taken:%Y%m%d_%H%M%S}_{hash:4}

The file is changed as text, so its other notes and layout stay; a copy of the old file is kept, and if the
new one doesn't read back as the same settings with only that pattern changed, the old one is put back.
"""

from __future__ import annotations

import json
import re
import shutil
from datetime import date, datetime
from pathlib import Path

import yaml


def _indent(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def _block_end(lines: list[str], start: int) -> int:
    """Return the index after the block starting at `start`: the lines indented deeper (or blank, or notes)."""
    indent = _indent(lines[start])
    end = start + 1
    while end < len(lines) and (not lines[end].strip() or _indent(lines[end]) > indent):
        end += 1
    while end > start + 1 and not lines[end - 1].strip():
        end -= 1
    return end


NOTE = {"pattern": "was", "folder": "folder was"}


def current_pattern(archive_file: Path, module: str, key: str = "pattern") -> str | None:
    """Return modules.<module>.<key> (pattern or folder) as da-archive.yaml has it, or None."""
    data = yaml.safe_load(archive_file.read_text(encoding="utf-8")) or {}
    return ((data.get("modules") or {}).get(module) or {}).get(key)


def save_pattern(archive_file: Path, module: str, pattern: str, *, today: date | None = None,
                 key: str = "pattern") -> Path:
    """Set modules.<module>.<key>; the old one becomes '# was (<date>): <old>' (folder: '# folder was').

    Return the backup copy of the old file.
    """
    text = archive_file.read_text(encoding="utf-8")
    before = yaml.safe_load(text) or {}
    old = ((before.get("modules") or {}).get(module) or {}).get(key)
    lines = text.splitlines()
    new_line = f"    {key}: {json.dumps(pattern)}"
    was = f"    # {NOTE[key]} ({(today or date.today()).isoformat()}): {old}" if old and old != pattern else None

    top = next((i for i, line in enumerate(lines) if re.match(r"^modules:\s*(#.*)?$", line)), None)
    if top is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines += ["modules:", f"  {module}:", new_line]
    else:
        end = _block_end(lines, top)
        at = next((i for i in range(top + 1, end)
                   if re.match(rf"^\s+{re.escape(module)}:\s*(#.*)?$", lines[i])), None)
        if at is None:
            lines[end:end] = [f"  {module}:", new_line]
        else:
            sub_end = _block_end(lines, at)
            children = [lines[i] for i in range(at + 1, sub_end) if lines[i].strip() and not lines[i].lstrip().startswith("#")]
            indent = (len(children[0]) - len(children[0].lstrip())) if children else 4
            line_at = next((i for i in range(at + 1, sub_end)                    # the module's own key, not a
                            if re.match(rf"^ {{{indent}}}{key}:", lines[i])), None)  # nested one (edits: folder:)
            if line_at is None:
                lines.insert(sub_end, new_line)
            else:
                lines[line_at] = new_line
                if was:
                    lines.insert(line_at + 1, was)          # newest first, above the older notes

    backup = archive_file.with_name(f"{archive_file.name}.bak-{datetime.now():%Y%m%d-%H%M%S}")
    shutil.copy2(archive_file, backup)
    archive_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        after = yaml.safe_load(archive_file.read_text(encoding="utf-8")) or {}
        expected = json.loads(json.dumps(before, default=str))
        modules = expected.setdefault("modules", {}) or {}
        expected["modules"] = modules
        modules[module] = {**(modules.get(module) or {}), key: pattern}
        ok = json.loads(json.dumps(after, default=str)) == expected
    except yaml.YAMLError:
        ok = False
    if not ok:
        shutil.copy2(backup, archive_file)
        raise RuntimeError(f"Couldn't update {archive_file} safely; it's unchanged. Set the pattern by hand.")
    return backup


def old_patterns(archive_file: Path, module: str, key: str = "pattern") -> list[tuple[str, str]]:
    """Return the (date, pattern) notes kept under a module's pattern (or folder), newest first."""
    lines = archive_file.read_text(encoding="utf-8").splitlines()
    at = next((i for i, line in enumerate(lines) if re.match(rf"^\s+{re.escape(module)}:\s*(#.*)?$", line)), None)
    if at is None:
        return []
    out = []
    for line in lines[at + 1:_block_end(lines, at)]:
        m = re.match(rf"^\s+# {NOTE[key]} \(([^)]*)\): (.*)$", line)
        if m:
            out.append((m.group(1), m.group(2)))
    return out
