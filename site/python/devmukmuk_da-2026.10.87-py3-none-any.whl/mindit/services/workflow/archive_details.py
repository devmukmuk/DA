# src/mindit/services/workflow/archive_details.py

"""What this PC's list of archives (archives.json) says about each one, worked out from its index."""

from __future__ import annotations

import os
import re
import sqlite3
import subprocess
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.config.archive import entry_for, update_entry, yaml_details
from mindit.services.faces.store import NAMED
from mindit.services.faces.suggest import looks_like_an_id

_ID_TAG = re.compile(r".*-lh-[0-9a-f]{8,}")          # person:jane-doe-lh-4d616da98daf82d3: a Picasa account id


def index_of(root: Path) -> Path:
    """Return the archive's index file."""
    return Path(root) / ".da" / "da.sqlite"


def index_stamp(root: Path) -> float:
    """Return when the index last changed (its -wal file too), or 0.0 when there is none."""
    db = index_of(root)
    stamps = [p.stat().st_mtime for p in (db, db.with_name(db.name + "-wal")) if p.exists()]
    return max(stamps, default=0.0)


def _rows(conn: sqlite3.Connection, sql: str) -> list[tuple]:
    try:
        return conn.execute(sql).fetchall()
    except sqlite3.Error:                   # an older index without that table or column
        return []


def place_name(city: str | None, state: str | None, country: str | None) -> str:
    """Return 'Orlando, FL, US' (whatever parts are known)."""
    return ", ".join(part for part in (city, (state or "").upper(), (country or "").upper()) if part)


def details(root: Path) -> dict[str, Any]:
    """Return the size, file count, years, places and people the archive's index knows (read only)."""
    db = index_of(root)
    if not db.exists():
        return {}
    with sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True) as conn:
        files, size = (_rows(conn, "SELECT COUNT(*), SUM(size_bytes) FROM files") or [(0, 0)])[0]
        first, last = (_rows(conn, "SELECT MIN(substr(captured_at, 1, 4)), MAX(substr(captured_at, 1, 4)) "
                                   "FROM files WHERE area IN ('photos', 'documents') "
                                   "AND captured_at GLOB '[12][0-9][0-9][0-9]*'") or [(None, None)])[0]
        places = [place_name(*row[:3]) for row in
                  _rows(conn, "SELECT city, state_code, country_code, COUNT(*) FROM files "
                              "WHERE city IS NOT NULL OR country_code IS NOT NULL "
                              "GROUP BY 1, 2, 3 ORDER BY 4 DESC, 1")]
        people = Counter({name: n for name, n in
                          _rows(conn, "SELECT name, COUNT(*) FROM faces WHERE name IS NOT NULL AND status IN "
                                      f"{NAMED!r} GROUP BY name") if not looks_like_an_id(name)})
        slugs = {_slug(name) for name in people}
        for value, n in _rows(conn, "SELECT j.value, COUNT(*) FROM files, json_each(files.tags) AS j "
                                    "WHERE files.tags LIKE '%person:%' AND j.value LIKE 'person:%' GROUP BY 1"):
            rest = value.partition(":")[2]
            if rest and rest not in slugs and not _ID_TAG.fullmatch(rest):            # a Picasa name never scanned: only its tag
                people[rest.replace("-", " ").title()] += n
    return {"size_gib": round((size or 0) / 2**30, 1), "files": files or 0,
            "years_found": f"{first}-{last}" if first and last and first != last else first,
            "places": [p for p in dict.fromkeys(places) if p],
            "people": [name for name, _ in sorted(people.items(), key=lambda kv: (-kv[1], kv[0]))],
            "details_at": datetime.now().isoformat(timespec="seconds")}


def _slug(text: str) -> str:
    from mindit.services.tagging.tags import slug  # pylint: disable=import-outside-toplevel

    return slug(text)


def refresh_later(root: Path) -> bool:
    """Start a hidden DA that refreshes the entry when the index changed: a big index read cold takes minutes."""
    entry = entry_for(root)
    if os.environ.get("DA_NO_DETAILS") or entry is None or entry.get("index_stamp") == index_stamp(root):
        return False
    args = ["archives", "details", str(root)]
    command = [sys.executable, *args] if getattr(sys, "frozen", False) else [sys.executable, "-m", "mindit", *args]
    flags = 0
    if os.name == "nt":                               # no window, and it outlives the terminal that started it
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    subprocess.Popen(command, cwd=str(root), env={**os.environ, "DA_NO_DETAILS": "1"},  # pylint: disable=consider-using-with
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     creationflags=flags, start_new_session=os.name != "nt", close_fds=True)
    return True


def refresh(root: Path, force: bool = False) -> bool:
    """Bring an archive's entry up to date when its index changed since; return True when it was."""
    entry = entry_for(root)
    stamp = index_stamp(root)
    if entry is None or (not force and entry.get("index_stamp") == stamp):
        return False
    return update_entry(root, {**yaml_details(root), **details(root), "index_stamp": stamp})
