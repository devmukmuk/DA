# src/mindit/services/contactsheet/office_pages.py

"""Office documents as PDFs, through LibreOffice when it is installed, so a contact sheet can show their first page.

Neither Pillow nor pypdfium2 can lay out a Word or Excel file. `soffice --headless --convert-to pdf` can (.doc .docx
.xls .xlsx .ppt .pptx .rtf .odt .ods .odp .txt): a batch of files per call, since LibreOffice takes seconds to start.
It runs with its own profile in %LOCALAPPDATA%\\DA\\libreoffice, so a LibreOffice the user has open isn't disturbed.
Without LibreOffice, sheets keep the text card.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Iterable

SUFFIXES = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".rtf", ".odt", ".ods", ".odp", ".txt"}
BATCH = 20                       # files per LibreOffice call: one that hangs costs only its batch
START_SECONDS = 60               # a call's time limit: this, plus PER_FILE for each file
PER_FILE = 20


def soffice() -> Path | None:
    """Return LibreOffice's soffice program (DA_SOFFICE, the PATH, Program Files), or None."""
    named = os.environ.get("DA_SOFFICE")
    if named is not None:
        return Path(named) if named and Path(named).exists() else None
    found = shutil.which("soffice")
    if found:
        return Path(found)
    for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)")):
        if base and (Path(base) / "LibreOffice" / "program" / "soffice.exe").exists():
            return Path(base) / "LibreOffice" / "program" / "soffice.exe"
    return None


def _profile() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or Path.home())
    return base / "DA" / "libreoffice"


def _batches(docs: list[Path]) -> Iterable[list[Path]]:
    """Yield batches of at most BATCH files with no two of the same name (the PDFs land in one folder)."""
    left = list(docs)
    while left:
        batch, names, rest = [], set(), []
        for doc in left:
            if len(batch) < BATCH and doc.stem.lower() not in names:
                batch.append(doc)
                names.add(doc.stem.lower())
            else:
                rest.append(doc)
        yield batch
        left = rest


def _run(command: list[str], timeout: float) -> None:
    """Run LibreOffice; past the time limit, stop it and what it started (soffice.exe starts soffice.bin)."""
    try:
        proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError:
        return
    try:
        proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, check=False)
        proc.kill()
        proc.wait()


def to_pdfs(docs: Iterable[Path], out_dir: Path) -> dict[Path, Path]:
    """Return {document: its PDF} for the documents LibreOffice converted into out_dir (none without LibreOffice)."""
    program = soffice()
    docs = [d for d in docs if d.suffix.lower() in SUFFIXES]
    if program is None or not docs:
        return {}
    made: dict[Path, Path] = {}
    for n, batch in enumerate(_batches(docs)):
        folder = out_dir / str(n)
        folder.mkdir(parents=True, exist_ok=True)
        command = [str(program), f"-env:UserInstallation={_profile().as_uri()}", "--headless", "--norestore",
                   "--nologo", "--convert-to", "pdf", "--outdir", str(folder), *map(str, batch)]
        _run(command, START_SECONDS + PER_FILE * len(batch))
        for doc in batch:
            pdf = folder / f"{doc.stem}.pdf"
            if pdf.exists() and pdf.stat().st_size > 0:
                made[doc] = pdf
    return made
