"""A JPG for each camera RAW that has none: the full-size JPEG the camera put inside it (CONVERT-DESIGN.md).

The JPG goes beside its RAW with the RAW's name, so the two are a RAW+JPEG pair; its sidecar says it was made
(`converted` block, `converted` tag) and carries the RAW's origin, place and your tags. `da intake undo` deletes them.
"""

from __future__ import annotations

import copy
import csv
import hashlib
import os
import sqlite3
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit.services.validateit.validateit_file_types import RAW_EXTENSIONS, raw_partner

CONVERTED_BLOCK = "converted"
LOG_CLASS = "convert"
TAG = "converted"
MIN_SIDE = 1000                        # a RAW whose biggest JPEG is smaller than this (a thumbnail) gets none
COPIED_BLOCKS = ("origin", "location", "user", "picasa", "faces", "keywords")
PLAN_FIELDS = ["action", "raw", "jpg", "note"]


def jpg_for(raw: Path) -> Path:
    """Return the JPG a RAW gets: beside it, same name."""
    return raw.with_suffix(".jpg")


def _load(path: Path) -> dict[str, Any]:
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    return SidecarService.load(path) if Path(f"{path}.meta.json").exists() else {}


def why_not(raw: Path) -> str:
    """Return why a RAW gets no JPG, or '' when it should get one."""
    if not raw.is_file():
        return "missing"
    if raw_partner(raw) is not None:
        return "has a JPG"
    edits = _load(raw).get("edits")
    if isinstance(edits, dict) and edits.get("edits"):
        return "has edits (da edits)"
    jpg = jpg_for(raw)
    if jpg.exists() or Path(f"{jpg}.meta.json").exists():
        return "name taken"
    return ""


def plan(db_path: Path, prefixes: list[str] | None = None) -> list[dict[str, str]]:
    """Return a row per RAW in the index (photos and intake, under prefixes): convert, or skip and why."""
    if not Path(db_path).exists():
        return []
    with sqlite3.connect(db_path) as conn:
        paths = [p for (p,) in conn.execute(
            "SELECT path FROM files WHERE area IN ('photos', 'intake') ORDER BY path")]
    paths = [p for p in paths if os.path.splitext(p)[1].lower() in RAW_EXTENSIONS]
    if prefixes:
        paths = [p for p in paths if any(p.lower().startswith(x.lower()) for x in prefixes)]
    rows = []
    for p in paths:
        raw = Path(p)
        note = why_not(raw)
        rows.append({"action": "skip" if note else "convert", "raw": p, "jpg": "" if note else str(jpg_for(raw)),
                     "note": note})
    return rows


def _raw_sha(raw: Path, data: dict[str, Any]) -> str:
    from mindit.services.validateit.quarantine_hash_service import stored_or_computed_sha256  # pylint: disable=import-outside-toplevel

    file_block = data.get("file") if isinstance(data.get("file"), dict) else {}
    held = data.get("quarantine") if isinstance(data.get("quarantine"), dict) else {}
    return file_block.get("sha256") or held.get("hash_sha256") or stored_or_computed_sha256(raw)


def write_sidecar(raw: Path, jpg: Path, sha256: str, size: tuple[int, int]) -> None:
    """Give the made JPG a sidecar: its own file details, the RAW's origin, place and tags, and a `converted` block."""
    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import AUTO_BLOCK  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider  # pylint: disable=import-outside-toplevel

    raw_data = _load(raw)
    PhotoItRepairProvider().create_or_refresh_sidecar(jpg, sha256=sha256)
    data = SidecarService.load(jpg)
    source = (raw_data.get("file") or {}).get("source_path") if isinstance(raw_data.get("file"), dict) else None
    if source:                                                    # came in where the RAW came in, under its name
        data.setdefault("file", {})["source_path"] = str(Path(source).with_suffix(".jpg"))
        if isinstance(data.get("photoit"), dict):
            data["photoit"]["original_file_name"] = Path(source).with_suffix(".jpg").name
        data.pop("origin", None)                                  # worked out again from that, unless the RAW has one
    for block in COPIED_BLOCKS:
        if isinstance(raw_data.get(block), dict):
            data[block] = copy.deepcopy(raw_data[block])
    data[CONVERTED_BLOCK] = {
        "from": raw.name, "raw": {"sha256": _raw_sha(raw, raw_data)},
        "how": "the camera's JPEG inside the RAW", "size": list(size),
        "made_at": datetime.now().isoformat(timespec="seconds"), "by": f"da convert {__version__}",
    }
    tags = list(((data.get(AUTO_BLOCK) or {}).get("tags") or []) if isinstance(data.get(AUTO_BLOCK), dict) else [])
    if TAG not in tags:
        data[AUTO_BLOCK] = {"tags": tags + [TAG], "made_at": datetime.now().isoformat(timespec="seconds")}
    SidecarService.save(jpg, data)


def convert_one(raw: Path) -> tuple[Path, str, tuple[int, int], int]:
    """Write the JPG for one RAW; return (jpg, sha256, size, bytes). Raises ValueError when there's nothing to use."""
    from mindit.services.validateit.raw_files import embedded_jpeg, raw_exif, with_exif  # pylint: disable=import-outside-toplevel

    found = embedded_jpeg(raw)
    if found is None:
        raise ValueError("no JPEG inside")
    jpeg, size = found
    if max(size) < MIN_SIDE:
        raise ValueError(f"only a small preview inside ({size[0]}x{size[1]})")
    data = with_exif(jpeg, raw_exif(raw))
    jpg = jpg_for(raw)
    part = jpg.with_name(jpg.name + ".part")
    part.write_bytes(data)
    os.replace(part, jpg)
    st = raw.stat()
    os.utime(jpg, (st.st_atime, st.st_mtime))                    # sorts with its RAW
    sha = hashlib.sha256(data).hexdigest()
    write_sidecar(raw, jpg, sha, size)
    return jpg, sha, size, len(data)


def apply(rows: list[dict[str, str]], log_path: Path, progress: Callable[[int, int], None] | None = None) -> Counter:
    """Make the planned JPGs, logging each (class convert, result copied) so `da intake undo` can delete them."""
    from mindit.services.dbit.intake_service import LOG_FIELDS  # pylint: disable=import-outside-toplevel

    todo = [r for r in rows if r["action"] == "convert"]
    stats: Counter = Counter()
    with log_path.open("w", newline="", encoding="utf-8") as f:
        log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        log.writeheader()
        for i, r in enumerate(todo, 1):
            raw = Path(r["raw"])
            entry = {k: "" for k in LOG_FIELDS} | {"class": LOG_CLASS, "source": str(raw)}
            note = why_not(raw)                                   # things may have changed since the plan
            try:
                if note:
                    raise ValueError(note)
                jpg, sha, size, length = convert_one(raw)
                entry |= {"result": "copied", "destination": str(jpg), "size_bytes": str(length), "sha256": sha,
                          "sidecar_destination": f"{jpg}.meta.json", "note": f"{size[0]}x{size[1]}"}
                stats["made"] += 1
                stats["bytes"] += length
            except (OSError, ValueError) as error:
                entry |= {"result": "skipped", "note": str(error)}
                stats["skipped"] += 1
            log.writerow(entry)
            f.flush()
            if progress:
                progress(i, len(todo))
    return stats


def converted_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the `converted` tag for a JPG da convert made (da tag keeps it)."""
    return [TAG] if isinstance(sidecar.get(CONVERTED_BLOCK), dict) else []


def raw_sha_of(sidecar: dict[str, Any] | None) -> str | None:
    """Return the RAW's SHA-256 a made JPG was taken from, or None (not a made JPG)."""
    block = sidecar.get(CONVERTED_BLOCK) if isinstance(sidecar, dict) else None
    raw = block.get("raw") if isinstance(block, dict) else None
    return raw.get("sha256") if isinstance(raw, dict) else None
