"""Camera raw files as pictures: their date, camera and built-in preview, for filing, contact sheets and comparing.

CR2 (Canon, 2004-2018), NEF, ARW, DNG and other TIFF-based raws: Pillow reads their EXIF and their big built-in preview.
CR3 (Canon, 2018 on) is an ISO media file like a HEIC: its EXIF is in the `CMT1` (main) and `CMT2` (Exif) records of
Canon's `uuid` box in `moov`, and a 1620 px JPEG preview is in the `PRVW` record of another `uuid` box. open_picture()
returns that preview with the EXIF attached, so everything that reads a photo reads a CR3 the same way.
"""

from __future__ import annotations

import io
import struct
from pathlib import Path
from typing import Any

CANON_META = bytes.fromhex("85c0b687820f11e08111f4ce462b6a48")      # moov/uuid: CNCV, CMT1-4, THMB
CANON_PREVIEW = bytes.fromhex("eaf42b5e1c984b88b9fbb7dc406e4d16")   # uuid: PRVW (the JPEG preview)


def _boxes(data: bytes, start: int = 0, end: int | None = None):
    """Yield (type, payload start, box end) for the ISO media boxes in data[start:end]."""
    end = len(data) if end is None else end
    at = start
    while at + 8 <= end:
        size, kind = struct.unpack(">I4s", data[at:at + 8])
        head = 8
        if size == 1:
            size = struct.unpack(">Q", data[at + 8:at + 16])[0]
            head = 16
        elif size == 0:
            size = end - at
        if size < head or at + size > end:
            return
        yield kind, at + head, at + size
        at += size


def cr3_parts(path: Path) -> dict[str, bytes]:
    """Return a CR3's EXIF records (CMT1 main, CMT2 Exif, both TIFF) and its JPEG preview (PRVW), where found."""
    with Path(path).open("rb") as f:
        data = f.read(8_000_000)                                  # the boxes DA needs come before the raw data
    parts: dict[str, bytes] = {}
    for kind, start, end in _boxes(data):
        if kind == b"moov":
            for inner, s, e in _boxes(data, start, end):
                if inner == b"uuid" and data[s:s + 16] == CANON_META:
                    for rec, rs, re_ in _boxes(data, s + 16, e):
                        if rec in (b"CMT1", b"CMT2"):
                            parts[rec.decode()] = data[rs:re_]
        elif kind == b"uuid" and data[start:start + 16] == CANON_PREVIEW:
            for rec, rs, re_ in _boxes(data, start + 16 + 8, end):     # 8 bytes after the uuid before PRVW
                if rec == b"PRVW":
                    jpeg = data.find(b"\xff\xd8\xff", rs, re_)
                    if jpeg >= 0:
                        parts["PRVW"] = data[jpeg:re_]
    return parts


def cr3_size(path: Path) -> tuple[int, int] | None:
    """Return a CR3's full picture size (from its EXIF), not its preview's - or None (not a CR3, or not recorded)."""
    if not is_cr3(path):
        return None
    from PIL import Image  # pylint: disable=import-outside-toplevel

    parts = cr3_parts(path)
    if "CMT2" not in parts:
        return None
    sub = Image.Exif()
    sub.load(parts["CMT2"])
    w, h = sub.get(0xA002), sub.get(0xA003)                   # PixelXDimension, PixelYDimension
    return (int(w), int(h)) if w and h else None


def is_cr3(path: Path) -> bool:
    """Return whether a file is a Canon CR3 (by its name, then its ISO media brand)."""
    if Path(path).suffix.lower() != ".cr3":
        return False
    try:
        with Path(path).open("rb") as f:
            head = f.read(12)
    except OSError:
        return False
    return head[4:12] == b"ftypcrx "


def _exif_bytes(parts: dict[str, bytes]) -> bytes | None:
    from PIL import Image  # pylint: disable=import-outside-toplevel

    if "CMT1" not in parts:
        return None
    exif = Image.Exif()
    exif.load(parts["CMT1"])
    if "CMT2" in parts:
        sub = Image.Exif()
        sub.load(parts["CMT2"])
        exif[0x8769] = dict(sub)
    return exif.tobytes()


def _cr3_full_jpeg(path: Path) -> bytes | None:
    """Return the full-size JPEG of a CR3: the one sample of its first track (moov/trak/mdia/minf/stbl)."""
    with Path(path).open("rb") as f:
        data = f.read(8_000_000)
        for kind, start, end in _boxes(data):
            if kind != b"moov":
                continue
            for inner, s, e in _boxes(data, start, end):
                if inner != b"trak":
                    continue
                box = (s, e)
                for name in (b"mdia", b"minf", b"stbl"):
                    box = next(((bs, be) for k, bs, be in _boxes(data, *box) if k == name), None)
                    if box is None:
                        return None
                size = offset = None
                for k, bs, _be in _boxes(data, *box):
                    if k == b"stsz":
                        size, count = struct.unpack(">II", data[bs + 4:bs + 12])
                        if size == 0 and count:
                            size = struct.unpack(">I", data[bs + 12:bs + 16])[0]
                    elif k == b"stco":
                        offset = struct.unpack(">I", data[bs + 8:bs + 12])[0]
                    elif k == b"co64":
                        offset = struct.unpack(">Q", data[bs + 8:bs + 16])[0]
                if not size or offset is None:
                    return None
                f.seek(offset)
                jpeg = f.read(size)
                return jpeg if jpeg[:3] == b"\xff\xd8\xff" else None
    return None


def _tiff_jpegs(data: bytes) -> list[bytes]:
    """Return the JPEGs a TIFF-based raw keeps in its IFDs and sub-IFDs (strips or JPEGInterchangeFormat)."""
    order = {b"II": "<", b"MM": ">"}.get(data[:2])
    if order is None or len(data) < 8 or struct.unpack(order + "H", data[2:4])[0] != 42:
        return []
    found: list[bytes] = []
    seen: set[int] = set()
    todo = [struct.unpack(order + "I", data[4:8])[0]]
    while todo:
        at = todo.pop()
        if at in seen or not 8 <= at <= len(data) - 2:
            continue
        seen.add(at)
        count = struct.unpack(order + "H", data[at:at + 2])[0]
        if count > 1000 or at + 2 + count * 12 + 4 > len(data):
            continue
        tags: dict[int, int] = {}
        for i in range(count):
            e = at + 2 + i * 12
            tag, kind, n = struct.unpack(order + "HHI", data[e:e + 8])
            if kind == 3 and n == 1:
                tags[tag] = struct.unpack(order + "H", data[e + 8:e + 10])[0]
            elif kind in (4, 13) and n == 1:
                tags[tag] = struct.unpack(order + "I", data[e + 8:e + 12])[0]
                if tag == 0x14A:                                       # one sub-IFD
                    todo.append(tags[tag])
            elif tag == 0x14A and kind in (4, 13) and n > 1:           # several sub-IFDs: a list of offsets
                ptr = struct.unpack(order + "I", data[e + 8:e + 12])[0]
                todo += [struct.unpack(order + "I", data[ptr + 4 * k:ptr + 4 * k + 4])[0]
                         for k in range(min(n, 16)) if ptr + 4 * k + 4 <= len(data)]
        for where, length in ((0x111, 0x117), (0x201, 0x202)):         # StripOffsets, JPEGInterchangeFormat
            o, n = tags.get(where), tags.get(length)
            if o and n and data[o:o + 3] == b"\xff\xd8\xff":
                found.append(data[o:o + n])
        todo.append(struct.unpack(order + "I", data[at + 2 + count * 12:at + 6 + count * 12])[0])   # the next IFD
    return found


def embedded_jpeg(path: Path) -> tuple[bytes, tuple[int, int]] | None:
    """Return the biggest JPEG the camera put inside a raw file, and its size, or None (none found)."""
    from PIL import Image  # pylint: disable=import-outside-toplevel

    if is_cr3(path):
        found = [j for j in (_cr3_full_jpeg(path), cr3_parts(path).get("PRVW")) if j]
    else:
        found = _tiff_jpegs(Path(path).read_bytes())
    best: tuple[bytes, tuple[int, int]] | None = None
    for jpeg in found:
        try:
            with Image.open(io.BytesIO(jpeg)) as img:
                size = img.size
        except Exception:  # pylint: disable=broad-except
            continue
        if best is None or size[0] * size[1] > best[1][0] * best[1][1]:
            best = (jpeg, size)
    return best


_KEEP_TAGS = (0x10E, 0x10F, 0x110, 0x112, 0x131, 0x132, 0x13B, 0x8298)   # description, make, model, orientation, ...
_DROP_EXIF = (0x927C, 0xA005)                                            # MakerNote (offsets into the raw), Interop


def raw_exif(path: Path) -> bytes | None:
    """Return the raw file's EXIF (camera, date, orientation, exposure, GPS) as bytes for a JPEG, or None."""
    from PIL import Image  # pylint: disable=import-outside-toplevel

    try:
        if is_cr3(path):
            return _exif_bytes(cr3_parts(path))
        src = Image.Exif()
        src.load(Path(path).read_bytes()[:64_000_000])     # the TIFF structure itself: no need for Pillow to open the raw
        sub = {k: v for k, v in src.get_ifd(0x8769).items() if k not in _DROP_EXIF}
        gps = dict(src.get_ifd(0x8825))
        out = Image.Exif()
        for tag in _KEEP_TAGS:
            if tag in src:
                out[tag] = src[tag]
        if sub:
            out[0x8769] = sub
        if gps:
            out[0x8825] = gps
        return out.tobytes()
    except Exception:  # pylint: disable=broad-except
        return None


def with_exif(jpeg: bytes, exif: bytes | None) -> bytes:
    """Return the JPEG with this EXIF in place of any it had (the picture itself untouched)."""
    if not exif:
        return jpeg
    payload = exif if exif.startswith(b"Exif\x00\x00") else b"Exif\x00\x00" + exif
    if len(payload) + 2 > 0xFFFF:
        return jpeg
    at, kept = 2, []
    while at + 4 <= len(jpeg) and jpeg[at] == 0xFF and 0xE0 <= jpeg[at + 1] <= 0xEF:   # the APPn segments
        length = struct.unpack(">H", jpeg[at + 2:at + 4])[0]
        segment = jpeg[at:at + 2 + length]
        if not (jpeg[at + 1] == 0xE1 and segment[4:10] == b"Exif\x00\x00"):
            kept.append(segment)
        at += 2 + length
    return b"\xff\xd8\xff\xe1" + struct.pack(">H", len(payload) + 2) + payload + b"".join(kept) + jpeg[at:]


def open_picture(path: Path) -> Any:
    """Open a photo with Pillow; a CR3 opens as its built-in preview with its own EXIF (date, camera, orientation)."""
    from PIL import Image  # pylint: disable=import-outside-toplevel

    if not is_cr3(path):
        return Image.open(path)
    parts = cr3_parts(path)
    if "PRVW" not in parts:
        raise OSError(f"no preview found in {Path(path).name}")
    img = Image.open(io.BytesIO(parts["PRVW"]))
    exif = _exif_bytes(parts)
    if exif:
        img.info["exif"] = exif
    return img
