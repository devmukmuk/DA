# src/mindit/services/share/sheet.py

"""`da share`'s contact sheet and the details that go in the email.

The first page has your note and every picture small, on retro film strips (4 frames a strip, each with its number
and the picture's short ID); then 6 big pictures a page with the date, place and ID. The email lists each picture by
the same ID: name, where it is in the archive, SHA-256, camera, GPS and place, when it was taken.
Pictures only (videos and documents are left out). Each picture is a JPEG up to 900 px, so a page is about half a
megabyte; a share too big for one email (Gmail takes 25 MB) is made as several PDFs, each with its own strips.
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

COLS, ROWS = 2, 3
PICTURE_PX = 900
STRIP_PX = 240                           # the small copy on a film strip
PART_BYTES = 18_000_000                  # under Gmail's 25 MB once attached (base64 adds a third)
PER_STRIP = 4
FILM_ORANGE = (0.93, 0.62, 0.15)


@dataclass
class Picture:
    """One picture to share, made small, with its caption, its short ID and what's known about it."""

    path: Path
    jpeg: bytes
    caption: str
    when: datetime | None
    sha256: str = ""
    id: str = ""
    facts: dict[str, str] = field(default_factory=dict)
    faces: tuple = ()                                  # yellow boxes and names (from Picasa), on the upright picture
    copies: list = field(default_factory=list)         # its exact and resized copies in _duplicates-holding


def pictures_in(folders: Iterable[Path]) -> tuple[list[Path], int]:
    """Return the photos in the folders (name order, so date order), and how many other files were left out."""
    from mindit.services.contactsheet.contact_sheet import IMAGE_EXTENSIONS, photos_in  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import is_lone_raw  # pylint: disable=import-outside-toplevel

    photos, left_out = [], 0
    for folder in folders:
        for path in photos_in(folder) if folder.is_dir() else [folder]:
            if path.suffix.lower() in IMAGE_EXTENSIONS or is_lone_raw(path):
                photos.append(path)
            else:
                left_out += 1
    return photos, left_out


def _place(data: dict[str, Any]) -> str:
    block = data.get("location") if isinstance(data.get("location"), dict) else {}
    place = block.get("place") if isinstance(block.get("place"), dict) else {}
    town = place.get("city") or place.get("county") or ""
    region = (place.get("state_code") or place.get("state") or "") if (place.get("country_code") or "us") == "us" \
        else (place.get("country") or "")
    return ", ".join(p for p in (town, region.upper() if len(region) == 2 else region) if p)


def caption_of(path: Path) -> tuple[str, datetime | None]:
    """Return 'Sat 20 Apr 2019 - Springfield, IL' from the sidecar (the date the photo was taken, its place)."""
    from mindit.services.location.grouping import taken_at  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    data = SidecarService.load(path) if Path(f"{path}.meta.json").exists() else {}
    when = taken_at(data, path)
    text = " - ".join(p for p in ((f"{when:%a %d %b %Y}" if when else ""), _place(data)) if p)
    return text, when


def facts_of(path: Path) -> tuple[str, dict[str, str]]:
    """Return (sha256, what's known about the photo) from its sidecar: camera, GPS, place, when, where it is."""
    from mindit.services.contactsheet.contact_sheet import thumbs_dir  # pylint: disable=import-outside-toplevel
    from mindit.services.location.grouping import taken_at  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.faces.faces import faces_of, people  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import all_tags  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.quarantine_hash_service import stored_or_computed_sha256  # pylint: disable=import-outside-toplevel

    path = Path(path).resolve()                                   # so its archive (and place in it) can be found
    data = SidecarService.load(path) if Path(f"{path}.meta.json").exists() else {}
    camera = data.get("camera") if isinstance(data.get("camera"), dict) else {}
    photoit = data.get("photoit") if isinstance(data.get("photoit"), dict) else {}
    gps = camera.get("gps") if isinstance(camera.get("gps"), dict) else (photoit.get("gps") or {})
    try:
        sha = stored_or_computed_sha256(path)
    except OSError:
        sha = ""
    when = taken_at(data, path)
    thumbs = thumbs_dir(path.parent)
    try:
        archive = thumbs.parent.parent if thumbs else None
        where = f"{archive.name}\\{path.relative_to(archive)}" if archive else str(path)
    except ValueError:
        where = str(path)
    lat, lon = (gps or {}).get("latitude"), (gps or {}).get("longitude")
    position = f"{float(lat):.5f}, {float(lon):.5f}" if lat is not None and lon is not None else ""
    return sha, {
        "name": path.name,
        "location": where,
        "sha256": sha,
        "camera": camera_name(camera) or "" if camera else "",
        "gps": position,
        "place": _place(data),
        "taken": f"{when:%a %d %b %Y %H:%M}" if when else "",
        "people": ", ".join(people(faces_of(data))),
        "tags": ", ".join(t for t in all_tags(data) if not t.startswith("person:")),
        "burst": _burst(data),
        "edits": _edit_line(data),
        "blurry": "much softer than this camera's other photos" if (data.get("quality") or {}).get("blurry") else "",
    }


def _edit_line(data: dict[str, Any]) -> str:
    from mindit.services.similar.edits import describe  # pylint: disable=import-outside-toplevel

    return describe(data)


def _burst(data: dict[str, Any]) -> str:
    burst = data.get("similar") if isinstance(data.get("similar"), dict) else {}
    if not burst.get("of"):
        return ""
    best = "the sharpest of them" if burst.get("best") else f"the sharpest is {burst.get('best_name', '')}"
    return f"shot {burst['position']} of {burst['of']} taken one after another ({best})"


def assign_ids(pictures: list[Picture]) -> None:
    """Give each picture a short ID from its SHA-256 (4 characters, longer where two would be the same)."""
    size = 4
    while size < 64:
        ids = [(p.sha256 or f"{i:08x}")[:size] for i, p in enumerate(pictures)]
        if len(set(ids)) == len(ids):
            break
        size += 2
    for picture, short in zip(pictures, ids):
        picture.id = short


def prepare(paths: list[Path], progress: Callable[[int, int], None] | None = None) -> list[Picture]:
    """Make each picture small (turned the right way up), caption it and give it an ID; unreadable ones are dropped."""
    from mindit.services.contactsheet.contact_sheet import _small_copy  # pylint: disable=import-outside-toplevel

    out = []
    for i, path in enumerate(paths, 1):
        if progress:
            progress(i, len(paths))
        small = _small_copy(path, (PICTURE_PX, PICTURE_PX), preview=False)
        if small is None:
            continue
        caption, when = caption_of(path)
        sha, facts = facts_of(path)
        out.append(Picture(path, small.getvalue(), caption, when, sha, "", facts, _faces(path)))
    assign_ids(out)
    return out


def _faces(path: Path) -> tuple:
    from mindit.services.faces.faces import faces_of  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    return faces_of(SidecarService.load(path)) if Path(f"{path}.meta.json").exists() else ()


def everyone(pictures: list[Picture]) -> list[tuple[str, int]]:
    """Return the people in the pictures and how many pictures each is in, most first."""
    from collections import Counter  # pylint: disable=import-outside-toplevel

    counts = Counter(name for p in pictures for name in dict.fromkeys(f.name for f in p.faces if f.name))
    return counts.most_common()


def common_tags(pictures: list[Picture], limit: int = 12) -> list[tuple[str, int]]:
    """Return the tags on the pictures (people left out: they have their own line), most first."""
    from collections import Counter  # pylint: disable=import-outside-toplevel

    counts = Counter(t.strip() for p in pictures for t in (p.facts.get("tags") or "").split(",") if t.strip())
    return counts.most_common(limit)


def attach_copies(pictures: list[Picture], data_root: Path, db_path: Path) -> int:
    """Give each picture the copies of it DA set aside (exact and resized); return how many copies in all."""
    import os  # pylint: disable=import-outside-toplevel

    from mindit.services.similar.copies import copies_of  # pylint: disable=import-outside-toplevel

    found = copies_of([(p.path, p.sha256) for p in pictures], data_root, db_path)
    for p in pictures:
        p.copies = found.get(os.path.normcase(str(Path(p.path).resolve())), [])
    return sum(len(p.copies) for p in pictures)


def _in_archive(path: Path, picture: Picture) -> str:
    where = picture.facts.get("location") or ""
    archive = where.split("\\", 1)[0] if "\\" in where else ""
    parts = Path(path).parts
    if archive and archive in parts:
        return "\\".join(parts[parts.index(archive):])
    return str(path)


def archive_label(root: Path | None = None) -> str:
    """Return 'jane-archive-201x (2010-2019)': the archive these pictures are from (its name, and years if set)."""
    from mindit.config.settings import get_archive_root, load_settings  # pylint: disable=import-outside-toplevel

    try:
        settings = load_settings()
        name = settings.archive.name or (root or get_archive_root() or Path(".")).name
        return f"{name} ({settings.archive.years})" if settings.archive.years else name
    except Exception:  # pylint: disable=broad-except
        return (root or Path(".")).name


def details(pictures: list[Picture]) -> str:
    """Return the email's list: each picture by its ID, with its name, place in the archive, hash, camera, GPS, date."""
    from collections import Counter  # pylint: disable=import-outside-toplevel

    from mindit.services.similar.copies import describe  # pylint: disable=import-outside-toplevel

    lines = []
    named = everyone(pictures)
    if named:
        lines += ["People in these pictures: " + ", ".join(f"{name} ({n})" for name, n in named), ""]
    tags = common_tags(pictures)
    if tags:
        lines += ["Tags: " + ", ".join(f"{tag} ({n})" for tag, n in tags), ""]
    kinds = Counter(c["kind"] for p in pictures for c in p.copies)
    if kinds:
        lines += ["Copies and versions (listed under each picture, and on the last pages): "
                  + ", ".join(f"{n} {kind}{'s' if n != 1 else ''}" for kind, n in sorted(kinds.items())), ""]
    lines += ["The pictures (each ID is on the film strips and under the big pictures):", ""]
    for p in pictures:
        f = p.facts
        lines.append(f"[{p.id}] {f.get('name') or p.path.name}")
        for label, key in (("People", "people"), ("Taken", "taken"), ("Camera", "camera"), ("Place", "place"),
                           ("GPS", "gps"), ("Tags", "tags"), ("Edits", "edits"), ("File", "location"),
                           ("SHA-256", "sha256")):
            if f.get(key):
                lines.append(f"    {label + ':':9} {f[key]}")
        for copy in p.copies:
            lines.append(f"    {'Copy:':9} {describe(copy)}: {_in_archive(copy['path'], p)}")
        if f.get("burst"):
            lines.append(f"    {'Burst:':9} {f['burst']}")
        if f.get("blurry"):
            lines.append(f"    {'Blurry:':9} {f['blurry']}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def parts(pictures: list[Picture], limit: int = PART_BYTES) -> list[list[Picture]]:
    """Split the pictures into groups small enough to email (whole pages, in order)."""
    groups: list[list[Picture]] = [[]]
    size = 0
    for picture in pictures:
        if groups[-1] and size + len(picture.jpeg) > limit and len(groups[-1]) % (COLS * ROWS) == 0:
            groups.append([])
            size = 0
        groups[-1].append(picture)
        size += len(picture.jpeg)
    return [g for g in groups if g]


def _wrap(text: str, width: int) -> list[str]:
    lines = []
    for paragraph in text.splitlines() or [""]:
        words, line = paragraph.split(), ""
        for word in words:
            if len(line) + len(word) + 1 > width:
                lines.append(line)
                line = word
            else:
                line = f"{line} {word}".strip()
        lines.append(line)
    return lines


def _strip_copy(jpeg: bytes) -> bytes:
    """Return a small copy for a film strip frame (so the PDF doesn't carry the big picture twice)."""
    from PIL import Image  # pylint: disable=import-outside-toplevel

    with Image.open(io.BytesIO(jpeg)) as img:
        img.thumbnail((STRIP_PX, STRIP_PX))
        out = io.BytesIO()
        img.convert("RGB").save(out, "JPEG", quality=78)
    return out.getvalue()


def draw_strip(pdf: Any, pictures: list[tuple[int, Picture]], x: float, top: float, width: float) -> float:
    """Draw one film strip (up to 4 frames) with its top at `top`; return its height."""
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel

    from mindit.services.faces.faces import draw_faces  # pylint: disable=import-outside-toplevel

    band, gap = 24.0, 6.0                                         # each edge: writing outside, holes inside
    frame_w = (width - gap * (PER_STRIP + 1)) / PER_STRIP
    frame_h = frame_w * 2 / 3
    height = frame_h + 2 * band
    bottom = top - height
    pdf.setFillColorRGB(0.05, 0.05, 0.05)
    pdf.rect(x, bottom, width, height, stroke=0, fill=1)
    pdf.setFillColorRGB(1, 1, 1)                                   # the sprocket holes, top and bottom
    hole_w, hole_h, step = 5.5, 7.5, 12.2
    holes = int((width - 6) // step)
    for i in range(holes):
        hx = x + 4 + i * step
        pdf.roundRect(hx, top - band + 3, hole_w, hole_h, 1.6, stroke=0, fill=1)        # next to the frames
        pdf.roundRect(hx, bottom + band - 3 - hole_h, hole_w, hole_h, 1.6, stroke=0, fill=1)
    for slot in range(PER_STRIP):
        fx = x + gap + slot * (frame_w + gap)
        fy = bottom + band
        pdf.setFillColorRGB(0.12, 0.12, 0.12)
        pdf.rect(fx, fy, frame_w, frame_h, stroke=0, fill=1)
        if slot >= len(pictures):
            continue
        number, picture = pictures[slot]
        image = ImageReader(io.BytesIO(_strip_copy(picture.jpeg)))
        iw, ih = image.getSize()
        scale = min(frame_w / iw, frame_h / ih)
        dw, dh = iw * scale, ih * scale
        pdf.drawImage(image, fx + (frame_w - dw) / 2, fy + (frame_h - dh) / 2, dw, dh)
        draw_faces(pdf, picture.faces, fx + (frame_w - dw) / 2, fy + (frame_h - dh) / 2, dw, dh, size=4.0, names=False)
        pdf.setFillColorRGB(*FILM_ORANGE)                         # frame number (top), arrow + ID (bottom)
        pdf.setFont("Helvetica-Bold", 9)
        pdf.drawCentredString(fx + frame_w / 2, top - 9.5, str(number))                 # along the outer edge
        ax, ay = fx + frame_w / 2 - 20, bottom + 2.6
        path = pdf.beginPath()
        path.moveTo(ax, ay)
        path.lineTo(ax, ay + 6)
        path.lineTo(ax + 6, ay + 3)
        path.close()
        pdf.drawPath(path, stroke=0, fill=1)
        pdf.setFont("Helvetica-Bold", 8)
        pdf.drawString(ax + 9, ay + 0.4, picture.id.upper())
    return height


def make_pdf(pictures: list[Picture], target: Path, *, title: str, note: str = "", part: tuple[int, int] = (1, 1),
             folders: list[str] | None = None, first_number: int = 1, archive: str = "") -> Path:
    """Write one share PDF: the note and the film strips, then the pictures, 6 a page."""
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    from mindit.services.faces.faces import draw_faces  # pylint: disable=import-outside-toplevel

    width, height = letter
    margin = 36
    target.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(target), pagesize=letter)
    pdf.setTitle(title)
    dated = [p.when for p in pictures if p.when]

    y = height - 64
    pdf.setFont("Helvetica-Bold", 22)
    pdf.drawString(margin, y, title[:60])
    y -= 22
    pdf.setFont("Helvetica", 11)
    span = (f"{min(dated):%d %b %Y}" + (f" - {max(dated):%d %b %Y}" if max(dated).date() != min(dated).date() else "")
            if dated else "")
    pdf.drawString(margin, y, f"{len(pictures):,} pictures" + (f", {span}" if span else "")
                   + (f"   (part {part[0]} of {part[1]})" if part[1] > 1 else ""))
    if archive:
        y -= 15
        pdf.setFillGray(0.35)
        pdf.drawString(margin, y, f"From the archive {archive}"[:110])
        pdf.setFillGray(0)
    named = everyone(pictures)
    if named:
        y -= 17
        pdf.setFont("Helvetica-Bold", 11)
        for text in _wrap("People: " + ", ".join(f"{name} ({n})" for name, n in named), 95)[:3]:
            pdf.drawString(margin, y, text)
            y -= 14
        y += 14
        pdf.setFont("Helvetica", 11)
    tags = common_tags(pictures)
    if tags:
        y -= 15
        pdf.setFont("Helvetica", 9.5)
        pdf.setFillGray(0.3)
        for text in _wrap("Tags: " + ", ".join(f"{tag} ({n})" for tag, n in tags), 110)[:2]:
            pdf.drawString(margin, y, text)
            y -= 12
        y += 12
        pdf.setFillGray(0)
    y -= 24
    pdf.setFont("Helvetica", 12)
    for text in _wrap(note, 86):
        pdf.drawString(margin, y, text)
        y -= 16
    if folders:
        pdf.setFont("Helvetica", 8)
        pdf.setFillGray(0.45)
        for name in folders[:6]:
            y -= 2
            pdf.drawString(margin, y, name[:120])
            y -= 9
        pdf.setFillGray(0)
    y -= 14
    numbered = list(enumerate(pictures, first_number))
    for start in range(0, len(numbered), PER_STRIP):
        strip = numbered[start:start + PER_STRIP]
        needed = (width - 2 * margin - 6 * (PER_STRIP + 1)) / PER_STRIP * 2 / 3 + 48
        if y - needed < margin:
            pdf.showPage()
            y = height - margin
        y -= draw_strip(pdf, strip, margin, y, width - 2 * margin) + 12
    pdf.showPage()

    cell_w = (width - 2 * margin) / COLS
    cell_h = (height - 2 * margin) / ROWS
    for start in range(0, len(pictures), COLS * ROWS):
        for i, picture in enumerate(pictures[start:start + COLS * ROWS]):
            col, row = i % COLS, i // COLS
            x = margin + col * cell_w
            top = height - margin - row * cell_h
            box_w, box_h = cell_w - 12, cell_h - 30
            image = ImageReader(io.BytesIO(picture.jpeg))
            iw, ih = image.getSize()
            scale = min(box_w / iw, box_h / ih)
            dw, dh = iw * scale, ih * scale
            bottom = top - 6 - dh
            pdf.drawImage(image, x + 6 + (box_w - dw) / 2, bottom, dw, dh)
            draw_faces(pdf, picture.faces, x + 6 + (box_w - dw) / 2, bottom, dw, dh, size=7.5)
            pdf.setFont("Helvetica", 9)
            label = " - ".join(p for p in (picture.caption, picture.id.upper()) if p)
            pdf.drawCentredString(x + cell_w / 2, bottom - 13, label[:80])     # right under it
        pdf.showPage()
    _copies_pages(pdf, [p for p in pictures if p.copies], width, height, margin)
    pdf.save()
    return target


def _copies_pages(pdf: Any, pictures: list[Picture], width: float, height: float, margin: float) -> None:
    """Draw the 'Copies and versions' pages: a framed block per picture - the one shared, then its copies beside it."""
    if not pictures:
        return
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel

    from mindit.services.contactsheet.contact_sheet import _small_copy  # pylint: disable=import-outside-toplevel
    from mindit.services.similar.copies import describe  # pylint: disable=import-outside-toplevel

    row_h, thumb_w, thumb_h, per_row, head, gap = 128.0, 112.0, 84.0, 3, 18.0, 12.0

    def heading() -> float:
        pdf.setFillGray(0)
        pdf.setFont("Helvetica-Bold", 16)
        pdf.drawString(margin, height - 54, "Copies and versions")
        pdf.setFont("Helvetica", 9)
        pdf.setFillGray(0.35)
        pdf.drawString(margin, height - 68, "Each box is one picture you were sent (left) with its other copies: set aside "
                                            "in _duplicates-holding, or other versions still filed.")
        pdf.setFillGray(0)
        return height - 82

    def thumb(data: bytes | None, x: float, top: float, caption: list[str]) -> None:
        if data:
            image = ImageReader(io.BytesIO(data))
            iw, ih = image.getSize()
            scale = min(thumb_w / iw, thumb_h / ih)
            pdf.drawImage(image, x + (thumb_w - iw * scale) / 2, top - thumb_h + (thumb_h - ih * scale) / 2,
                          iw * scale, ih * scale)
        pdf.setFillGray(0.1)
        pdf.setFont("Helvetica", 6.8)
        for i, text in enumerate(caption):
            pdf.drawString(x, top - thumb_h - 9 - i * 8, text[:38])

    y = heading()
    for number, picture in enumerate(pictures, 1):
        rows = (len(picture.copies) + per_row - 1) // per_row
        block = head + rows * row_h + 6
        if y - block < margin and y < height - 90:
            pdf.showPage()
            y = heading()
        pdf.setFillColorRGB(0.95, 0.96, 0.98)                    # the frame: one picture and its copies
        pdf.setStrokeColorRGB(0.17, 0.43, 0.57)
        pdf.roundRect(margin - 4, y - block, width - 2 * margin + 8, block, 5, stroke=1, fill=1)
        pdf.setFillColorRGB(0.17, 0.43, 0.57)
        pdf.rect(margin - 4, y - head, width - 2 * margin + 8, head, stroke=0, fill=1)
        pdf.setFillGray(1)
        pdf.setFont("Helvetica-Bold", 9)
        count = len(picture.copies)
        pdf.drawString(margin + 2, y - 12.5, f"{number}.  {picture.id.upper()}  {picture.path.name}  -  "
                                              f"{count} other cop{'ies' if count != 1 else 'y'}"[:100])
        top = y - head - 6
        for start in range(0, count, per_row):
            if start == 0:
                thumb(_strip_copy(picture.jpeg), margin, top, ["the picture you were sent", picture.path.name])
            for i, copy in enumerate(picture.copies[start:start + per_row]):
                small = _small_copy(Path(copy["path"]), (240, 240))
                thumb(small.getvalue() if small else None, margin + (i + 1) * (thumb_w + 20), top,
                      _wrap(describe(copy), 36)[:2] + [Path(copy["path"]).name, f"{copy['size_bytes'] / 1e6:,.1f} MB"])
            top -= row_h
        y -= block + gap
    pdf.showPage()


def slug(text: str) -> str:
    """Return a file-name-friendly form of text."""
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()[:50] or "share"
