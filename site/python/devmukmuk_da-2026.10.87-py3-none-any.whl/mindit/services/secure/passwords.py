# src/mindit/services/secure/passwords.py

"""`da find --passwords`: find documents (and photos already read by OCR) that hold passwords, and set them aside.

Text comes from what's already there first - a PDF's own text, a Word/Excel/PowerPoint file's text, a text file, a
picture's OCR block - and from Windows' OCR for scans (images, and the page images of a PDF with no text).
*Strong*: a label with a value ("Password: ...", "PIN 1234", "passcode", "pwd"); *weak*: the word only.
Moving takes them to _secure-holding\\<date>\\<where they were> with their sidecars, logged (class secure_hold,
undo puts them back), out of the index. What DA writes down never holds the secret: the CSV and log show a masked
snippet, the OCR text is taken out of the sidecar and the OCR cache. Design: docs/da-docs/LIFECYCLE-DESIGN.md s.8.
"""

from __future__ import annotations

import csv
import json
import logging
import os
import re
import sys
import tempfile
import zipfile
from collections import Counter
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator, Protocol

log = logging.getLogger(__name__)

SIDECAR_SUFFIX = ".meta.json"
LOG_CLASS = "secure_hold"
HOLDING = "_secure-holding"
MASK = "••••"
PDF_PAGES = 8                            # scanned PDFs: OCR at most this many pages
FIELDS = ["path", "level", "found", "snippet", "action", "destination"]

_LABEL = r"(?:pass\s?words?|passcodes?|pass\s?phrases?|pwd|passwd|p/w)"
_VALUE = r"((?=\S*[A-Za-z0-9])\S{3,})"   # a value, not a blank form line (______)
_STRONG = [
    re.compile(_LABEL + r"\s*[:=#]\s*" + _VALUE, re.I),
    re.compile(_LABEL + r"\s+(?:is|-)\s+((?=\S*[\d\W_])(?=\S*[A-Za-z0-9])\S{4,})", re.I),    # "is Hunter22!"
    re.compile(r"\b(?:pin|pin\s?code|pin\s?number|pin\s?#)\s*(?:is|:|=|-|#)?\s*(\d{4,8})\b", re.I),
    re.compile(r"\bsecurity\s+answer\s*:\s*((?=\S*[A-Za-z0-9])\S{2,})", re.I),
]
_WEAK = [re.compile(r"\b" + _LABEL + r"\b", re.I), re.compile(r"\bsecurity\s+questions?\b", re.I),
         re.compile(r"\blog\s?in\s*:\s*\S+", re.I)]
TEXT_SUFFIXES = {".txt", ".csv", ".md", ".rtf", ".log"}
OFFICE_SUFFIXES = {".docx", ".xlsx", ".pptx"}
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".gif", ".heic", ".heif", ".webp"}


class Reader(Protocol):
    """Reads the text in a picture (WindowsOcr, or a fake in tests)."""

    def read(self, path: Path) -> dict[str, Any]: ...


@dataclass
class Found:
    """One file that holds a password (or might)."""

    path: Path
    level: str                           # strong | weak
    found: str                           # what kind: password, pin, security answer, word
    snippet: str                         # masked: never the secret


@dataclass
class Scan:
    """What a scan found."""

    found: list[Found] = field(default_factory=list)
    counts: Counter = field(default_factory=Counter)


def mask(text: str, match: re.Match) -> str:
    """Return a short snippet around a match with its value replaced by dots."""
    start, end = match.span(1) if match.lastindex else match.span()
    before = text[max(0, start - 30):start].replace("\n", " ")
    after = text[end:end + 15].replace("\n", " ")
    shown = MASK if match.lastindex else text[start:end]
    return re.sub(r"\s+", " ", f"...{before}{shown}{after}...").strip()


def classify(text: str) -> tuple[str, str, str] | None:
    """Return (level, what, masked snippet) for text holding a password, or None."""
    for pattern, what in zip(_STRONG, ("password", "password", "pin", "security answer")):
        match = pattern.search(text)
        if match:
            return "strong", what, mask(text, match)
    for pattern in _WEAK:
        match = pattern.search(text)
        if match:
            return "weak", "word", mask(text, match)
    return None


def _office_text(path: Path) -> str:
    """Return the text in a .docx/.xlsx/.pptx (their XML, tags taken out)."""
    parts = []
    try:
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if name.endswith(".xml") and (name.startswith(("word/", "xl/sharedStrings", "xl/worksheets/",
                                                               "ppt/slides/"))):
                    xml = z.read(name).decode("utf-8", errors="replace")
                    parts.append(re.sub(r"<[^>]+>", " ", xml))
    except (OSError, zipfile.BadZipFile):
        return ""
    return re.sub(r"\s+", " ", " ".join(parts))


@contextmanager
def decoder_messages(into: list[str]) -> Iterator[None]:
    """Catch what C decoders print to stderr (libtiff: "Fax3Decode1D: Bad code word ..."), which Python can't hide."""
    try:
        sys.stderr.flush()
        saved = os.dup(2)
    except (OSError, ValueError, AttributeError):          # no stderr to borrow (a windowed exe)
        yield
        return
    with tempfile.TemporaryFile() as caught:
        os.dup2(caught.fileno(), 2)
        try:
            yield
        finally:
            os.dup2(saved, 2)
            os.close(saved)
            caught.seek(0)
            into.extend(caught.read(1_000_000).decode(errors="replace").splitlines())


def _pdf_text(path: Path, reader: Reader | None) -> str:
    """Return a PDF's own text; for a scan (little text), the OCR text of its first pages' images."""
    from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

    logging.getLogger("pypdf").setLevel(logging.ERROR)
    try:
        pdf = PdfReader(path, strict=False)
        pages = list(pdf.pages)
        text = " ".join((page.extract_text() or "") for page in pages[:50])
    except Exception:  # pylint: disable=broad-except
        return ""
    if len(text.strip()) >= 40 or reader is None:
        return text
    out = [text]
    damaged: list[str] = []
    with tempfile.TemporaryDirectory(prefix="da-pdf-") as tmp:
        for i, page in enumerate(pages[:PDF_PAGES]):
            try:
                with decoder_messages(damaged):             # a damaged fax scan: a line per bad row, read anyway
                    images = list(page.images)
            except Exception:  # pylint: disable=broad-except
                continue
            for j, image in enumerate(images[:3]):
                suffix = Path(image.name).suffix or ".png"
                picture = Path(tmp, f"p{i}-{j}{suffix}")
                picture.write_bytes(image.data)
                out.append(str(reader.read(picture).get("text") or ""))
    if damaged:
        log.warning("%s: a scanned page is damaged (%d bad lines); read what could be", Path(path).name, len(damaged))
    return " ".join(out)


def text_of(path: Path, reader: Reader | None, sidecar: dict[str, Any] | None = None) -> str:
    """Return the text in a file, from what's there first (its sidecar's OCR text), else read now."""
    ocr = (sidecar or {}).get("ocr") if isinstance((sidecar or {}).get("ocr"), dict) else {}
    if ocr.get("text"):
        return str(ocr["text"])
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return _pdf_text(path, reader)
    if suffix in OFFICE_SUFFIXES:
        return _office_text(path)
    if suffix in TEXT_SUFFIXES:
        try:
            return path.read_text(encoding="utf-8", errors="replace")[:200_000]
        except OSError:
            return ""
    if suffix in IMAGE_SUFFIXES and reader is not None:
        return str(reader.read(path).get("text") or "")
    return ""


def scan(documents: Iterable[Path], photos: Iterable[Path], reader: Reader | None,
         progress: Callable[[int, int], None] | None = None) -> Scan:
    """Look through documents (reading them) and photos (only the OCR text already in their sidecars)."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    result = Scan()
    items = [(p, True) for p in documents] + [(p, False) for p in photos]
    for i, (path, read) in enumerate(items, 1):
        if progress:
            progress(i, len(items))
        sidecar = SidecarService.load(path) if Path(f"{path}{SIDECAR_SUFFIX}").exists() else {}
        if not read and not ((sidecar.get("ocr") or {}) if isinstance(sidecar.get("ocr"), dict) else {}).get("text"):
            continue                                          # a photo nobody has read: not looked at
        result.counts["looked at"] += 1
        hit = classify(text_of(path, reader if read else None, sidecar))
        if hit:
            level, what, snippet = hit
            result.counts[level] += 1
            result.found.append(Found(path, level, what, snippet))
    return result


def files_under(targets: Iterable[Path], suffixes: set[str]) -> list[Path]:
    """Return the files under targets with these suffixes (no sidecars, sheets or holding folders)."""
    out = []
    for target in targets:
        paths = [target] if target.is_file() else sorted(p for p in target.rglob("*") if p.is_file())
        for path in paths:
            if path.name.endswith(SIDECAR_SUFFIX) or path.name.lower() == "_contact-sheet.pdf":
                continue
            if any(part.lower() in ("_duplicates-holding", HOLDING) for part in path.parts):
                continue
            if path.suffix.lower() in suffixes:
                out.append(path)
    return out


# --------------------------------------------------------------------------- setting them aside

def destination(path: Path, root: Path, when: datetime | None = None) -> Path:
    """Return where a file goes in _secure-holding (its place in the archive kept)."""
    return root / HOLDING / f"{(when or datetime.now()):%Y-%m-%d}" / path.resolve().relative_to(root.resolve())


def set_aside(found: list[Found], root: Path, log_path: Path, db_path: Path | None) -> Counter:
    """Move the files (with sidecars) into _secure-holding; log, take them out of the index and the OCR cache."""
    import sqlite3  # pylint: disable=import-outside-toplevel

    from mindit.core.long_paths import TOO_LONG, too_long  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import LOG_FIELDS  # pylint: disable=import-outside-toplevel

    stats: Counter = Counter()
    gone: list[str] = []
    log_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        with log_path.open("w", newline="", encoding="utf-8") as f:
            log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
            log.writeheader()
            for item in found:
                src = item.path
                dst = destination(src, root)
                entry = {"class": LOG_CLASS, "source": str(src), "destination": str(dst), "size_bytes": "",
                         "sha256": "", "kept": "", "sidecar_source": "", "sidecar_destination": "",
                         "note": f"{item.level} {item.found}"}
                if not src.exists() or dst.exists() or too_long(dst, f"{dst}{SIDECAR_SUFFIX}"):
                    entry["result"] = "skipped"
                    entry["note"] += "; " + (TOO_LONG if src.exists() and not dst.exists() else "changed or taken")
                    stats["skipped"] += 1
                    log.writerow(entry)
                    continue
                try:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    entry["size_bytes"] = str(src.stat().st_size)
                    os.rename(src, dst)
                except OSError as error:
                    entry["result"], entry["note"] = "failed", str(error)
                    stats["failed"] += 1
                    log.writerow(entry)
                    continue
                side_src, side_dst = Path(f"{src}{SIDECAR_SUFFIX}"), Path(f"{dst}{SIDECAR_SUFFIX}")
                if side_src.exists() and not side_dst.exists():
                    os.rename(side_src, side_dst)
                    entry["sidecar_source"], entry["sidecar_destination"] = str(side_src), str(side_dst)
                    _forget_text(dst)
                entry["result"] = "moved"
                stats["moved"] += 1
                gone.append(str(src))
                log.writerow(entry)
    finally:
        if db_path and Path(db_path).exists() and gone:
            with sqlite3.connect(db_path) as conn:
                conn.executemany("DELETE FROM files WHERE path = ?", [(p,) for p in gone])
        if gone:
            purge_cache(root / ".da" / "ocr-cache.jsonl", gone)
    return stats


def _forget_text(path: Path) -> None:
    """Take the read text out of a file's sidecar (its OCR level and word count stay)."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    data = SidecarService.load(path)
    ocr = data.get("ocr")
    if isinstance(ocr, dict) and ocr.get("text"):
        ocr.pop("text", None)
        ocr.pop("text_truncated", None)
        ocr["text_removed"] = "da find --passwords"
        SidecarService.save(path, data)


def purge_cache(cache: Path, paths: list[str]) -> int:
    """Remove these files' entries from the OCR cache; return how many went."""
    if not cache.exists():
        return 0
    keys = {os.path.normcase(p) for p in paths}
    kept, dropped = [], 0
    for line in cache.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            key = json.loads(line).get("key", "")
        except ValueError:
            kept.append(line)
            continue
        if os.path.normcase(key.rsplit("|", 2)[0]) in keys:
            dropped += 1
        else:
            kept.append(line)
    cache.write_text("".join(f"{line}\n" for line in kept), encoding="utf-8")
    return dropped


def write_results(found: list[Found], path: Path, actions: dict[str, tuple[str, str]] | None = None) -> Path:
    """Write the CSV (masked snippets only); actions: path -> (action, destination)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for item in found:
            action, dest = (actions or {}).get(str(item.path), ("found", ""))
            writer.writerow({"path": str(item.path), "level": item.level, "found": item.found,
                             "snippet": item.snippet, "action": action, "destination": dest})
    return path
