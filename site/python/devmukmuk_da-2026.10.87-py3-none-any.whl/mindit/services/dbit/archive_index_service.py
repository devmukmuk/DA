# src/mindit/services/dbit/archive_index_service.py

"""Index every file in the Digital Archive (organized trees, intake, holding) into the DA database."""

from __future__ import annotations

import json
import os
import re
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit.services.contactsheet.contact_sheet import SHEET_NAME
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.validateit.validateit_file_types import (
    DOCUMENT_ONLY_EXTENSIONS,
    PHOTO_EXTENSIONS,
    RAW_EXTENSIONS,
    VIDEO_EXTENSIONS,
)
from mindit.utils.timestamps import safe_iso_timestamp

SIDECAR_SUFFIX = ".meta.json"
SKIP_DIRS = {"$RECYCLE.BIN", "System Volume Information", ".validateit-quarantine", ".da", ".mindit"}
BATCH_SIZE = 5000
_PHOTO_NAME = re.compile(r"^(?:photo|video)_(\d{8})_(\d{6})_")
_DOC_NAME = re.compile(r"^doc_(\d{6})_(\d{6})_")


@dataclass(frozen=True)
class Area:
    """One indexed tree: its name ('photos', 'documents', 'intake', 'holding') and root folder."""

    name: str
    root: Path


@dataclass
class IndexResult:
    """What one build indexed."""

    files: Counter = field(default_factory=Counter)          # (area, kind) -> count
    bytes: Counter = field(default_factory=Counter)          # area -> bytes
    no_sidecar: Counter = field(default_factory=Counter)     # area -> count
    no_hash: Counter = field(default_factory=Counter)        # area -> count
    removed: int = 0
    outside: list[str] = field(default_factory=list)   # rows for files outside the archive (it was moved)
    seconds: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-friendly summary."""
        areas = sorted({a for a, _ in self.files})
        return {
            "areas": {
                a: {
                    "files": sum(n for (x, _), n in self.files.items() if x == a),
                    "by_kind": {k: n for (x, k), n in sorted(self.files.items()) if x == a},
                    "gb": round(self.bytes[a] / 1e9, 2),
                    "no_sidecar": self.no_sidecar[a],
                    "no_hash": self.no_hash[a],
                }
                for a in areas
            },
            "removed_missing": self.removed,
            "removed_outside": len(self.outside),
            "seconds": round(self.seconds, 1),
        }


def default_areas(settings: Any | None = None) -> list[Area]:
    """Return the archive's areas from the active profile: both organized trees, intake, holding."""
    from mindit.config.settings import (  # pylint: disable=import-outside-toplevel
        get_data_root_path,
        load_settings,
        resolve_data_path,
        resolve_photoit_organized_path,
        resolve_scanit_organized_path,
    )

    loaded = settings or load_settings()
    data_root = get_data_root_path(loaded)
    return [
        Area("photos", resolve_photoit_organized_path(loaded)),
        Area("documents", resolve_scanit_organized_path(loaded)),
        Area("intake", resolve_data_path(loaded.paths.intake, loaded)),
        Area("holding", data_root / "_duplicates-holding"),
    ]


class ArchiveIndexService:
    """Walk each area, read each file's sidecar, and keep the files table in step with the disk."""

    def __init__(self, db_service: DbitService) -> None:
        self.db = db_service

    def build(self, areas: list[Area], progress: Callable[[str], None] | None = None) -> IndexResult:
        """Index every file under the given areas and drop rows for files that are gone."""
        start = time.time()
        started_at = datetime.now().isoformat(timespec="microseconds")  # rows older than this are gone
        self.db.initialize()
        result = IndexResult()
        batch: list[dict[str, Any]] = []
        seen = 0

        for area in areas:
            if not area.root.is_dir():
                continue
            for dirpath, dirnames, filenames in os.walk(area.root):
                dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
                for name in filenames:
                    if name.lower().endswith(SIDECAR_SUFFIX) or name.lower() == SHEET_NAME:
                        continue
                    record = self._record(area, Path(dirpath, name), started_at)
                    if record is None:
                        continue
                    result.files[(area.name, record["media_type"])] += 1
                    result.bytes[area.name] += record["size_bytes"]
                    if not record["sidecar_path"]:
                        result.no_sidecar[area.name] += 1
                    if not record["sha256"]:
                        result.no_hash[area.name] += 1
                    batch.append(record)
                    seen += 1
                    if len(batch) >= BATCH_SIZE:
                        self.db.upsert_files(batch)
                        batch.clear()
                        if progress:
                            progress(f"{seen:,} files indexed ({time.time() - start:.0f}s)")
            self.db.upsert_files(batch)
            batch.clear()
            result.removed += self.db.delete_missing(str(area.root) + os.sep, started_at)

        if self.db.db_path.parent.name == ".da":         # <archive>\.da\da.sqlite: rows outside it are stale
            result.outside = self.db.delete_outside(self.db.db_path.parent.parent)
            if result.outside and progress:
                progress(f"{len(result.outside):,} rows were for files outside this archive (where it used to be, "
                         f"e.g. {result.outside[0]}) - removed")
        result.seconds = time.time() - start
        self.db.log_event("db_build", json.dumps(result.as_dict()))
        return result

    def _record(self, area: Area, path: Path, now: str) -> dict[str, Any] | None:
        try:
            stat = path.stat()
        except OSError:
            return None
        sidecar_path = Path(f"{path}{SIDECAR_SUFFIX}")
        meta = _load_json(sidecar_path)
        file_block = _block(meta, "file")
        quarantine = _block(meta, "quarantine")
        classification = _block(meta, "classification")
        validation = _block(meta, "validation")
        photoit = _block(meta, "photoit")
        scanit = _block(meta, "scanit")
        user = _block(meta, "user")
        location = _block(meta, "location")
        place = location.get("place") if isinstance(location.get("place"), dict) else {}

        kind = _kind(path, area.name)
        rel_parent = os.path.relpath(path.parent, area.root)
        problem_count = validation.get("problem_count")
        return {
            "path": str(path),
            "area": area.name,
            "folder": "" if rel_parent == "." else rel_parent,
            "module": classification.get("module") or {"photo": "photoit", "raw": "photoit", "document": "scanit"}.get(kind),
            "media_type": kind,
            "file_name": path.name,
            "extension": path.suffix.lower(),
            "size_bytes": stat.st_size,
            "modified_at": _iso_mtime(stat.st_mtime),
            "sha256": _sha256(file_block, quarantine, stat.st_size, stat.st_mtime),
            "sidecar_path": str(sidecar_path) if meta is not None else None,
            "sidecar_schema_version": _block(meta, "schema").get("version"),
            "captured_at": (user.get("captured_at") or photoit.get("captured_at") or _block(meta, "video").get("recorded_at")
                            or scanit.get("document_date") or _name_date(path.name)),
            "tags": _tags(photoit, scanit, user, _block(meta, "auto_tags")),
            "gps_present": _gps_present(meta),
            "validation_status": None if problem_count is None else ("ok" if problem_count == 0 else "problems"),
            "validation_problem_count": problem_count or 0,
            "hash_status": quarantine.get("hash_status"),
            "duplicate_status": quarantine.get("duplicate_status"),
            "source_path": file_block.get("source_path"),
            "city": place.get("city"),
            "state_code": place.get("state_code"),
            "country_code": place.get("country_code"),
            "title": location.get("title"),
            "camera": _camera(_block(meta, "camera")),
            "origin": _origin(meta),
            "indexed_at": now,
        }


def _camera(camera: dict[str, Any]) -> str | None:
    """Return the camera that took it ("Canon PowerShot A80"), from the sidecar's camera block."""
    from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel

    return camera_name(camera) if camera else None


def _origin(meta: dict[str, Any] | None) -> str | None:
    """Return the folders it came in from, top first, joined by backslashes ("Jones Family Photos\\Scans")."""
    from mindit.services.sidecar.origin import levels  # pylint: disable=import-outside-toplevel

    return "\\".join(levels(meta)) or None


def _gps_present(meta: dict[str, Any] | None) -> int:
    """Return 1 when the sidecar holds a real position (the same test `da location lookup` uses), else 0.

    An empty `"gps": {"latitude": null, ...}` block isn't one: it once counted, so the report promised places to look up.
    """
    from mindit.services.location.places import manual_position, position  # pylint: disable=import-outside-toplevel

    return int(bool(meta) and (position(meta) is not None or manual_position(meta) is not None))


def _iso_mtime(mtime: float) -> str | None:
    """Return the modified time as ISO text, or None for a timestamp Windows can't convert (pre-1970 etc.)."""
    return safe_iso_timestamp(mtime)


def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _block(meta: dict[str, Any] | None, name: str) -> dict[str, Any]:
    value = (meta or {}).get(name)
    return value if isinstance(value, dict) else {}


def _kind(path: Path, area: str) -> str:
    """Return photo, document, raw, video or other; an image under the documents tree is a document."""
    ext = path.suffix.lower()
    if ext in RAW_EXTENSIONS:
        return "raw"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    if ext in DOCUMENT_ONLY_EXTENSIONS:
        return "document"
    if ext in PHOTO_EXTENSIONS:
        return "document" if area == "documents" else "photo"
    return "other"


def _sha256(file_block: dict[str, Any], quarantine: dict[str, Any], size: int, mtime: float) -> str | None:
    """Return the sidecar's recorded sha256 for the file as it is now.

    Validate's quarantine hash carries the size and modified time it was computed for, so when both still
    match it wins; an older tool's file.sha256 can be stale after an edit that kept the size.
    """
    if quarantine.get("hash_sha256") and quarantine.get("file_size") == size and quarantine.get("file_modified_at") == mtime:
        return quarantine["hash_sha256"]
    if file_block.get("sha256") and file_block.get("size_bytes") in (None, size):
        return file_block["sha256"]
    if quarantine.get("hash_sha256") and quarantine.get("file_size") in (None, size):
        return quarantine["hash_sha256"]
    return None


def _name_date(name: str) -> str | None:
    """Return the date+time a DA name carries (photo_YYYYMMDD_HHMMSS_ / doc_YYMMDD_HHMMSS_)."""
    m = _PHOTO_NAME.match(name)
    if m:
        return datetime.strptime(m[1] + m[2], "%Y%m%d%H%M%S").isoformat()
    m = _DOC_NAME.match(name)
    if m:
        return datetime.strptime(m[1] + m[2], "%y%m%d%H%M%S").isoformat()
    return None


def _tags(*blocks: dict[str, Any]) -> str | None:
    """Return the union of the blocks' tag lists as a JSON array, or None."""
    tags: list[str] = []
    for block in blocks:
        for tag in block.get("tags") or []:
            if isinstance(tag, str) and tag.strip() and tag.strip() not in tags:
                tags.append(tag.strip())
    return json.dumps(tags) if tags else None
