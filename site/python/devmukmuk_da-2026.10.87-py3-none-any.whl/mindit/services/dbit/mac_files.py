# src/mindit/services/dbit/mac_files.py

"""A Mac's hidden "._" files (AppleDouble): its own metadata, left beside each file it copied to a non-Mac drive."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mindit.services.dbit.dbit_service import DbitService

MAGIC = b"\x00\x05\x16\x07"                 # AppleDouble; "Mac OS X" follows in the header
MAX_SIZE = 1 << 20                          # they hold a few KB of metadata, never a picture


def is_apple_double(path: Path) -> bool:
    """Return True for a "._name" file that really is AppleDouble metadata (checked by its header, not just its name)."""
    path = Path(path)
    if not path.name.startswith("._"):
        return False
    try:
        if path.stat().st_size > MAX_SIZE:
            return False
        with path.open("rb") as f:
            return f.read(4) == MAGIC
    except OSError:
        return False


def plan_mac_metadata(db: DbitService, layout: Any, prefix: str) -> list[dict[str, Any]]:
    """Plan moving the AppleDouble files under prefix into holding (class mac_metadata, nothing kept to check)."""
    db.initialize(log=False)
    with db.connect() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT path, size_bytes, sha256 FROM files WHERE area = 'intake' AND file_name LIKE '.\\_%' ESCAPE '\\' "
            "ORDER BY path")]
    plan = []
    for r in rows:
        src = Path(r["path"])
        if not r["path"].startswith(prefix) or not is_apple_double(src):
            continue
        plan.append({
            "class": "mac_metadata", "source": r["path"],
            "destination": str(layout.holding_root / src.relative_to(layout.data_root)),
            "size_bytes": r["size_bytes"], "sha256": r["sha256"] or "", "kept": "",
            "source_mtime": src.stat().st_mtime, "note": "a Mac's hidden metadata file (AppleDouble), not a photo",
        })
    return plan
