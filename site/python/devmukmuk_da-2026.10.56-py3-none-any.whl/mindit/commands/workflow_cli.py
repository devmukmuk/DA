# src/mindit/commands/workflow_cli.py

"""Top-level workflow commands: setup, run, status, archives, install, check, verify."""

from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import sys
from collections import Counter
from enum import StrEnum
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.table import Table

from mindit.commands.progress import ConsoleProgressReporter
from mindit.config.archive import known_archives
from mindit.config.settings import get_archive_root, load_settings, resolve_database_path
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.dbit.intake_service import default_layout
from mindit.services.workflow.archive_setup import LAUNCHER, exe_path, inspect_target, parse_years, setup_archive
from mindit.services.workflow.checks import check_plan, check_report, load_report, verify_report
from mindit.services.workflow.run_workflow import copy_into_intake, free_intake_name, run_workflow

console = Console()
INSTALL_DIR = Path(r"C:\Scripts\DA")


class KindChoice(StrEnum):
    AUTO = "auto"
    PHOTO = "photo"
    DOCUMENT = "document"


# --------------------------------------------------------------------------- setup

def setup(
    folder: Path = typer.Argument(..., help="The archive folder, e.g. D:\\jane-archive-199x."),
    name: str = typer.Option(None, "--name", help="A display name (default: the folder name)."),
    years: str = typer.Option(None, "--years", help="Capture years this archive takes, e.g. 1990-1999."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask."),
) -> None:
    """Make FOLDER an archive: da-archive.yaml, intake\\ and organized\\ folders, and an "Open DA.cmd" launcher.

    An existing archive is reused; a folder that already has files in it is adopted (they move into intake\\).
    """
    try:
        parse_years(years)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    state = inspect_target(folder)
    if state.kind == "archive":
        console.print(f"{state.root} is already an archive.")
        if not (yes or Confirm.ask("Use the existing archive? (keeps its settings, adds anything missing)", default=True)):
            raise typer.Exit(1)
    elif state.kind == "folder":
        files = sum(1 for item in state.items for _ in (_walk_files(item) if item.is_dir() else [item]))
        console.print(f"{state.root} already has {len(state.items)} items ({files:,} files):")
        for item in state.items[:15]:
            console.print(f"   {'[dir] ' if item.is_dir() else '      '}{item.name}")
        if len(state.items) > 15:
            console.print(f"   ... and {len(state.items) - 15} more")
        if not (yes or Confirm.ask(f"Make it an archive and move these {len(state.items)} items into intake\\?",
                                   default=False)):
            raise typer.Exit(1)

    result = setup_archive(folder, name=name, years=years)
    from mindit.core.logging import log_to_archive  # pylint: disable=import-outside-toplevel

    log_to_archive(result.root, "setup", f"da setup: archive {result.root}" + (f", years {years}" if years else "")
                   + (f", {len(result.moved)} items moved into intake" if result.moved else ""),
                   path=str(result.root), log=str(result.move_log) if result.moved else None)
    console.print(f"Archive: [bold]{result.root}[/bold]")
    for f in result.created_folders:
        console.print(f"  created {f.relative_to(result.root)}\\")
    if result.moved:
        console.print(f"  moved {len(result.moved)} items into intake\\ (undo log: {result.move_log})")
    for item, why in result.skipped:
        console.print(f"  [yellow]left {item.name}: {why}[/yellow]")
    console.print(f"  config: {result.archive_file.name}   launcher: {result.launcher.name}")
    console.print(f"\nOpen [bold]{result.launcher}[/bold] (double-click), then:  da run")


def _walk_files(folder: Path):
    for _dirpath, _dirs, files in os.walk(folder):
        yield from files


# --------------------------------------------------------------------------- run / status

def run(
    folder: Path = typer.Argument(None, help="Folder to process (default: this archive's intake\\)."),
    kind: KindChoice = typer.Option(KindChoice.AUTO, "--kind", help="photo or document: treat every image as that. Default: by intake folder (scans, docs: document), else photo."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before moving files."),
) -> None:
    """Process a folder end to end: index, hash, set duplicates aside, preview, check, file, verify."""
    layout = default_layout()
    folder = folder or layout.intake_root
    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    if not folder.resolve().is_relative_to(Path(layout.data_root).resolve()):
        # Duplicates are found among indexed files, and a folder outside the archive isn't indexed.
        dest = free_intake_name(layout.intake_root, folder.resolve().name)
        console.print(f"{folder} is outside this archive ({layout.data_root}).")
        if not (yes or Confirm.ask(f"Copy it to {dest} and process the copy? The originals stay where they are",
                                   default=True)):
            console.print("Nothing done. Copy it into this archive's intake\\ yourself, then run `da run` on it.")
            raise typer.Exit(1)
        copied = copy_into_intake(folder, dest)
        console.print(f"Copied {copied:,} files to {dest}. Delete {folder} yourself once you're happy.")
        folder = dest
    console.print(f"Archive: {layout.data_root}   processing: {folder}")
    record = run_workflow(
        folder,
        DbitService(resolve_database_path()),
        layout,
        kind=None if kind == KindChoice.AUTO else kind.value,
        say=console.print,
        ask=(lambda q: True) if yes else (lambda q: Confirm.ask(q, default=False)),
        progress=ConsoleProgressReporter(console=console, update_every=1000),
    )
    if record.stopped_at_step:
        console.print(f"[yellow]Stopped at {record.stopped_at_step}. Nothing after that step was changed.[/yellow]")
        console.print(f"Record: {record.run_dir}")


def status(title: bool = typer.Option(True, hidden=True)) -> None:
    """Show this archive: name, years, what's waiting in intake, what's filed, and the last run."""
    settings = load_settings()
    layout = default_layout()
    root = get_archive_root() or layout.data_root
    years = settings.archive.years or "any"
    if title:                                       # the menu's box already shows the name and folder
        console.print(f"[bold]{settings.archive.name or root.name}[/bold]   {root}   years: {years}")

    db_path = resolve_database_path()
    counts = _db_counts(db_path, layout) if db_path.exists() else None
    if counts:
        console.print(f"  organized: {counts['photos']:,} photos, {counts['documents']:,} documents   "
                      f"(index from {counts['built'] or '?'}; refresh: da db build)")
    intake = _intake_counts_from_db(db_path, layout) if counts else None
    source = "from the index" if intake is not None else "counted now"
    if intake is None:
        intake = _intake_counts(layout.intake_root)
    total = sum(intake.values())
    console.print(f"  intake: {total:,} files ({source})" + (" - nothing waiting" if not total else ""))
    for top, n in sorted(intake.items(), key=lambda kv: -kv[1])[:10]:
        console.print(f"     {n:>8,}  {top}")
    runs = sorted((layout.output_root / "runs").glob("*-run/summary.json")) if (layout.output_root / "runs").exists() else []
    if runs:
        last = json.loads(runs[-1].read_text(encoding="utf-8"))
        filed = (last.get("steps", {}).get("6_file", {}).get("verify", {}) or {}).get("moved", 0)
        end = "stopped at " + last["stopped_at_step"] if last.get("stopped_at_step") else f"filed {filed:,}"
        console.print(f"  last run: {last.get('started_at')}  {end}")


def _intake_counts(intake: Path) -> dict[str, int]:
    """Count files (not sidecars) under intake by their top-level folder."""
    counts: dict[str, int] = {}
    if not intake.exists():
        return counts
    for dirpath, _dirs, files in os.walk(intake):
        n = sum(1 for f in files if not f.lower().endswith(".meta.json"))
        if n:
            rel = os.path.relpath(dirpath, intake)
            top = "(intake)" if rel == "." else rel.split(os.sep)[0]
            counts[top] = counts.get(top, 0) + n
    return counts


def _intake_counts_from_db(db_path: Path, layout) -> dict[str, int] | None:
    """Count indexed intake files by top-level folder, or None when the index has no intake rows."""
    try:
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute("SELECT folder, COUNT(*) FROM files WHERE area = 'intake' GROUP BY folder").fetchall()
    except sqlite3.Error:
        return None
    if not rows:
        return None
    counts: dict[str, int] = {}
    for folder, n in rows:
        top = (folder or "(intake)").split(os.sep)[0]
        counts[top] = counts.get(top, 0) + n
    return counts


def _db_counts(db_path: Path, layout) -> dict | None:
    try:
        with sqlite3.connect(db_path) as conn:
            rows = dict(conn.execute("SELECT area, COUNT(*) FROM files GROUP BY area").fetchall())
            built = conn.execute(
                "SELECT created_at FROM db_events WHERE event_type = 'db_build' ORDER BY id DESC LIMIT 1").fetchone()
    except sqlite3.Error:
        return None
    return {"photos": rows.get("photos", 0), "documents": rows.get("documents", 0), "built": built[0] if built else None}


# --------------------------------------------------------------------------- contact sheets

def contact_sheets(
    folder: Path = typer.Argument(..., help="A folder; every folder under it with photos gets a sheet."),
    force: bool = typer.Option(False, "--force", help="Make every sheet again, even ones that are up to date."),
    layout: str = typer.Option(None, "--layout", help="Pictures per page, columns x rows: 3x4 (bigger) or 4x5. "
                                                      "Default: the archive's setting, else 3x4."),
) -> None:
    """Make a contact sheet (_contact-sheet.pdf: small pictures of every photo) in each folder with photos."""
    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.services.contactsheet.contact_sheet import (  # pylint: disable=import-outside-toplevel
        SHEET_NAME, folders_with_photos, layout_size, refresh_sheets,
    )

    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    if layout is not None:
        try:
            layout_size(layout)
        except ValueError as error:
            raise typer.BadParameter(str(error)) from error
    folders = folders_with_photos(folder)
    console.print(f"{len(folders):,} folders with photos under {folder}")
    if force:
        for each in folders:
            (each / SHEET_NAME).unlink(missing_ok=True)
    result = refresh_sheets(folders, create=True, version=__version__, layout=layout,
                            progress=lambda m: console.print(f"  {m}"))
    console.print(f"Made or updated {len(result.made):,}; already up to date {result.current:,}"
                  + (f"; failed {len(result.failed)}" if result.failed else ""))
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("contact_sheets", f"contact sheets under {folder}: {len(result.made)} made, {len(result.failed)} failed",
              path=str(folder), made=len(result.made), failed=len(result.failed))
    for path, why in result.failed:
        console.print(f"  [red]{path}: {why}[/red]")


# --------------------------------------------------------------------------- Live Photos and HEIC

def pair_movies(
    folder: Path = typer.Argument(None, help="Where to look for left-behind videos (default: this archive's intake\\)."),
    apply: bool = typer.Option(False, "--apply", help="Move them (without it, only show what would move)."),
) -> None:
    """Find iPhone Live Photo videos (.MOV) left in intake after their photo was filed, and put them beside it."""
    from mindit.services.livephoto.live_photos import (  # pylint: disable=import-outside-toplevel
        apply_pairs, filed_photo_rows, plan_pairs, write_pair_plan,
    )

    layout = default_layout()
    folder = folder or layout.intake_root
    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    db = DbitService(resolve_database_path())
    console.print(f"Looking for Live Photo videos under {folder} ...")
    plan = plan_pairs(folder, filed_photo_rows(db))
    run_dir = layout.run_dir("pair-movies")
    plan_path = write_pair_plan(plan, run_dir / "pairs.csv")
    console.print(f"  {len(plan.pairs):,} videos found their filed photo (list: {plan_path})")
    for pair in plan.pairs[:5]:
        console.print(f"     {Path(pair['movie']).name}  ->  {pair['destination']}")
    if len(plan.pairs) > 5:
        console.print(f"     ... and {len(plan.pairs) - 5:,} more")
    if plan.already_there:
        console.print(f"  {len(plan.already_there):,} are already beside their photo (left alone)")
    if plan.other_copies:
        console.print(f"  {len(plan.other_copies):,} are another copy of a video above (left alone; "
                      "`da run` sets exact copies aside)")
    if plan.unmatched:
        console.print(f"  {len(plan.unmatched):,} have no filed photo yet (left alone; file the photos first)")
    if plan.not_orphans:
        console.print(f"  {plan.not_orphans:,} still have their photo beside them; `da run` files the two together")
    if not plan.pairs:
        return
    if not apply:
        console.print("Nothing moved. To move them: add --apply.")
        return
    stats = apply_pairs(db, plan, run_dir / "pair-movies-moved.csv")
    console.print(f"Moved {stats['moved']:,}" + (f", skipped {stats['skipped']:,}" if stats["skipped"] else "")
                  + f". Undo: da intake undo \"{run_dir / 'pair-movies-moved.csv'}\"")


def heic_to_jpg(
    folder: Path = typer.Argument(..., help="A folder; every HEIC photo in it (and its subfolders) gets a JPG copy."),
    out: Path = typer.Option(None, "--out", help="Where the JPGs go (default: a new folder next to it, <name>-jpg)."),
) -> None:
    """Make JPG copies of iPhone HEIC photos (for sharing); the HEIC originals stay where they are."""
    from mindit.services.livephoto.live_photos import convert_folder, heic_files  # pylint: disable=import-outside-toplevel

    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    folder = folder.resolve()
    out = (out or folder.with_name(f"{folder.name}-jpg")).resolve()
    if out.is_relative_to(folder):
        raise typer.BadParameter("--out can't be inside the folder being converted.")
    count = len(heic_files(folder))
    console.print(f"{count:,} HEIC photos under {folder}; JPG copies go to {out}")
    if not count:
        return
    result = convert_folder(folder, out, progress=lambda m: console.print(f"  {m}"))
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("heic_to_jpg", f"made {len(result.made)} JPG copies of HEIC photos in {out}", path=str(out),
              made=len(result.made), failed=len(result.failed))
    console.print(f"Made {len(result.made):,} JPGs" + (f"; {result.skipped:,} were already done" if result.skipped else "")
                  + (f"; {len(result.failed)} failed" if result.failed else ""))
    for path, why in result.failed[:10]:
        console.print(f"  [red]{path}: {why}[/red]")


# --------------------------------------------------------------------------- history

def history(
    target: str = typer.Argument(None, help="A file (its path now or before), or a name (now or before DA renamed "
                                            "it): its whole story. Nothing: the latest changes."),
    sha: str = typer.Option(None, "--hash", help="A file by its SHA-256 fingerprint (the first 8 or more characters)."),
    duplicates: bool = typer.Option(False, "--duplicates", help="Every copy in _duplicates-holding, and what it's a copy of."),
    everywhere: bool = typer.Option(False, "--everywhere", help="Look in every archive on this PC."),
    kind: str = typer.Option(None, "--kind", help="Only photo, video, document or raw files."),
    since: str = typer.Option(None, "--since", help="Only changes from this date on, e.g. 2026-10-01."),
    limit: int = typer.Option(50, "--limit", help="How many changes (or files) to show."),
    save: bool = typer.Option(True, "--save/--no-save", help="Save the results (CSV + JSON) in output\\runs."),
) -> None:
    """Show what DA did: a file's whole story (by path, name or --hash), every held copy, or the latest changes."""
    from datetime import datetime  # pylint: disable=import-outside-toplevel

    from mindit.services.history import events as ev  # pylint: disable=import-outside-toplevel

    if kind and kind not in ("photo", "video", "document", "raw"):
        raise typer.BadParameter("--kind is photo, video, document or raw")
    if since and not re.match(r"^\d{4}-\d{2}(-\d{2})?$", since):
        raise typer.BadParameter("--since looks like 2026-10-01")
    if sha and (len(sha) < 8 or not re.match(r"^[0-9a-fA-F]+$", sha)):
        raise typer.BadParameter("--hash takes the first 8 or more characters of a SHA-256, e.g. --hash 9b053986")
    layout = default_layout()
    here = (get_archive_root() or layout.data_root).resolve()
    archives = [here] + ([a.resolve() for a in known_archives()
                          if os.path.normcase(str(a.resolve())) != os.path.normcase(str(here))] if everywhere else [])
    console.print("Reading DA's records (only what's new since last time) ...")
    for root in archives:
        read = ev.refresh(root, root / ".da" / "da.sqlite", root / "output", root / "logs" / "da.jsonl",
                          progress=lambda m: console.print(f"  {m}"))
        if sum(read.values()):
            console.print(f"  {root.name}: added {read['moves'] + read['filed']:,} file changes, "
                          f"{read['activity']:,} activity lines")

    result: dict[str, Any] = {"made_at": datetime.now().isoformat(timespec="seconds"),
                              "archives": [str(a) for a in archives]}
    rows: list[list[str]] = []
    if target or sha:
        result["files"] = _history_story(ev, archives, here, target, sha, kind, limit, rows)
    elif duplicates:
        result["duplicates"] = _history_duplicates(ev, archives, limit, rows)
    else:
        result["latest"] = _history_latest(ev, archives, kind, since, limit, rows)
    if save:
        out_dir = layout.output_root / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-history"
        out_dir.mkdir(parents=True, exist_ok=True)
        import csv as csv_module  # pylint: disable=import-outside-toplevel

        with (out_dir / "history.csv").open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv_module.writer(f)
            writer.writerow(["archive", "type", "when", "what", "from", "to", "command", "computer", "note"])
            writer.writerows(rows)
        (out_dir / "history.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
        console.print(f"\nSaved: {out_dir / 'history.csv'} (and history.json)")


def _when(text: str | None) -> str:
    return (text or "").replace("T", " ")[:16]


def _history_latest(ev: Any, archives: list[Path], kind: str | None, since: str | None, limit: int,
                    rows: list[list[str]]) -> list[dict[str, Any]]:
    out = []
    for root in archives:
        activity, files = ev.latest(root / ".da" / "da.sqlite", limit=limit, kind=kind, since=since)
        name = root.name
        console.print(f"\n[bold]What DA did in {name}[/bold] (newest first)")
        if not activity:
            console.print("  Nothing recorded yet.")
        for a in activity:
            message = a["message"].replace(str(root) + os.sep, "").replace(str(root), name)
            console.print(f"  {_when(a['at'])}  {message}" + (f"  [dim]({a['host']})[/dim]" if a["host"] else ""))
            rows.append([name, "activity", a["at"], message, "", "", a["event"], a["host"], ""])
        console.print(f"\n[bold]Files changed[/bold]" + (f" ({kind}s)" if kind else "") + " (newest first)")
        if not files:
            console.print("  None recorded yet.")
        for e in files:
            undone = f"  [yellow](undone {_when(e['undone_at'])})[/yellow]" if e.get("undone_at") else ""
            console.print(f"  {_when(e['at'])}  {e['action']} ({e['command']}){undone}")
            console.print(f"      {ev.shown(e['source'], root)}\n   -> {ev.shown(e['destination'], root)}")
            rows.append([name, "file", e["at"], e["action"], ev.shown(e["source"], root),
                         ev.shown(e["destination"], root), e["command"], "",
                         f"undone {e['undone_at']}" if e.get("undone_at") else e.get("note") or ""])
        out.append({"archive": str(root), "activity": activity, "files": files})
    return out


def _history_story(ev: Any, archives: list[Path], here: Path, target: str | None, sha: str | None, kind: str | None,
                   limit: int, rows: list[list[str]]) -> list[dict[str, Any]]:
    out = []
    for root in archives:
        db = root / ".da" / "da.sqlite"
        found = [f for f in ev.find(db, target, sha, limit) if not kind or f.get("media_type") in (kind, None)]
        if not found:
            continue
        for f in found:
            s = ev.story(db, f)
            now, came = s["now"], s["came_from"]
            console.print(f"\n[bold]{now.get('file_name') or Path(f['path']).name}[/bold]  ({root.name})")
            if s["missing"]:
                console.print(f"  [yellow]Not in the index now[/yellow]; last known at {ev.shown(f['path'], root)}")
            else:
                console.print(f"  Now:      {ev.shown(now['path'], root)}  ({now.get('area')}, {now.get('media_type')}, "
                              f"{(now.get('size_bytes') or 0) / 1e6:,.1f} MB)")
                taken = _when(now.get("captured_at")) + (f"  - {now['date_from']}" if now.get("date_from") else "")
                for label, value in (("Taken", taken), ("Camera", " / ".join(v for v in (now.get("camera"), now.get("owner")) if v)),
                                     ("Place", ", ".join(v for v in (now.get("title"), now.get("city"),
                                                                     (now.get("state_code") or "").upper()) if v)),
                                     ("SHA-256", now.get("sha256") or "")):
                    if value:
                        console.print(f"  {label + ':':9} {value}")
            if came["original_name"] or came["original_path"]:
                console.print(f"  Came from: {came['original_path'] or came['original_name']}")
            console.print("  History:" if s["timeline"] else "  History: nothing DA recorded")
            for e in s["timeline"]:
                undone = f"  [yellow](undone {_when(e['undone_at'])})[/yellow]" if e.get("undone_at") else ""
                console.print(f"    {_when(e['at'])}  {e['action']} ({e['command']}){undone}")
                console.print(f"        {ev.shown(e['source'], root)} -> {ev.shown(e['destination'], root)}")
                rows.append([root.name, "history", e["at"], e["action"], ev.shown(e["source"], root),
                             ev.shown(e["destination"], root), e["command"], "",
                             f"undone {e['undone_at']}" if e.get("undone_at") else ""])
            elsewhere = ev.copies_elsewhere(now.get("sha256") or "", [a for a in archives if a != root], root)
            copies = [{"archive": root.name, **c} for c in s["copies"]] + elsewhere
            if copies:
                console.print(f"  Copies ({len(copies)}):")
                for c in copies[:20]:
                    console.print(f"    {c['archive']}: {ev.shown(c['path'], root)} ({c['area']})")
                    rows.append([c["archive"], "copy", "", c["area"], "", c["path"], "", "", ""])
            out.append({"archive": str(root), **s, "copies": copies})
    if not out:
        console.print(f"\nNothing found for {target or sha}" + ("" if len(archives) > 1 else
                      " in this archive (add --everywhere to look in every archive on this PC)") + ".")
    return out


def _history_duplicates(ev: Any, archives: list[Path], limit: int, rows: list[list[str]]) -> list[dict[str, Any]]:
    out = []
    for root in archives:
        held = ev.duplicates(root / ".da" / "da.sqlite")
        console.print(f"\n[bold]Copies in {root.name}'s _duplicates-holding[/bold]: {len(held):,}"
                      + (f" (showing {limit})" if len(held) > limit else ""))
        for h in held[:limit]:
            console.print(f"  {_when(h['set_aside'])}  {ev.shown(h['held'], root)}")
            console.print(f"      a copy of {ev.shown(h['copy_of'], root) or '(no copy found in the index)'}")
        for h in held:
            rows.append([root.name, "held copy", h["set_aside"], "set aside", ev.shown(h["held"], root),
                         ev.shown(h["copy_of"], root), "", "", h["sha256"]])
        out.append({"archive": str(root), "held": held})
    return out


# --------------------------------------------------------------------------- share

def share(
    folders: list[Path] = typer.Argument(None, help="Filed folders (or photos) to share, e.g. photos\\organized\\2019\\2019-04."),
    to: str = typer.Option(None, "--to", help="Who gets it: a list in da-archive.yaml (share: lists:), or addresses "
                                              "separated by commas."),
    note: str = typer.Option("", "--note", help="A few words for the first page and the email."),
    title: str = typer.Option(None, "--title", help="The sheet's title (default: the folder names)."),
    send: bool = typer.Option(False, "--send", help="Send it (asks first). Without it, only the PDF is made."),
    setup: bool = typer.Option(False, "--setup", help="Sign in to Gmail once (opens the browser)."),
    lists: bool = typer.Option(False, "--lists", help="Show the lists in da-archive.yaml."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before sending."),
) -> None:
    """Email a simple contact sheet (6 big pictures a page, with dates and places) from your Gmail to a list."""
    from datetime import datetime  # pylint: disable=import-outside-toplevel

    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.share import gmail  # pylint: disable=import-outside-toplevel
    from mindit.services.share import sheet as sh  # pylint: disable=import-outside-toplevel

    saved = load_settings().share.lists
    if setup:
        try:
            gmail.credentials(interactive=True)
        except gmail.ShareSetupError as exc:
            console.print(f"[yellow]{exc}[/yellow]")
            raise typer.Exit(1) from None
        console.print(f"Signed in to Gmail (DA may only send). The sign-in is kept in {gmail.token_file()}.")
        return
    if lists or not folders:
        if not saved:
            console.print("No lists yet. Add them to da-archive.yaml:\n  share:\n    lists:\n"
                          "      family: [grandma@example.com, sam@example.com]")
        for name, people in saved.items():
            console.print(f"  {name}: {len(people)} people")
        if not folders:
            console.print("Share a month: da share photos\\organized\\2019\\2019-04 --to family --note \"Easter\"")
        return
    missing = [f for f in folders if not f.exists()]
    if missing:
        console.print("[red]No such folder or file: " + ", ".join(str(m) for m in missing) + "[/red]")
        raise typer.Exit(2)
    recipients = _recipients(to, saved)
    if to and not recipients:
        console.print(f"[red]No list called {to!r}[/red] (lists: {', '.join(saved) or 'none yet'}).")
        raise typer.Exit(2)

    paths, left_out = sh.pictures_in(folders)
    if not paths:
        console.print("No photos there to share.")
        return
    console.print(f"Making the sheet: {len(paths):,} photos" + (f" ({left_out:,} videos and documents left out)"
                                                               if left_out else "") + " ...")
    progress = ConsoleProgressReporter(console=console, update_every=25)
    progress.start(label="Pictures", total=len(paths))
    try:
        pictures = sh.prepare(paths, progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    names = [f.name for f in folders]
    title = title or ", ".join(names)[:60]
    groups = sh.parts(pictures)
    out_dir = default_layout().output_root / "shares" / f"{datetime.now():%Y%m%d-%H%M%S}-{sh.slug(title)}"
    made, first, archive = [], 1, sh.archive_label()
    for i, group in enumerate(groups, 1):                     # frame numbers carry on from one part to the next
        made.append(sh.make_pdf(group, out_dir / (f"{sh.slug(title)}" + (f"-{i}" if len(groups) > 1 else "") + ".pdf"),
                                title=title, note=note, part=(i, len(groups)), folders=[str(f) for f in folders],
                                first_number=first, archive=archive))
        first += len(group)
    (out_dir / "details.txt").write_text(sh.details(pictures), encoding="utf-8")     # what the email lists
    size = sum(p.stat().st_size for p in made)
    console.print(f"  {len(made)} PDF{'s' if len(made) > 1 else ''} ({size / 1e6:,.1f} MB): {out_dir}")
    if not send:
        console.print("Nothing sent." + (f" To send it to {to} ({len(recipients)} people): add --send." if to else
                                         " To send it: --to <list> --send"))
        return
    if not recipients:
        console.print("[red]Say who gets it: --to <list>[/red]")
        raise typer.Exit(2)
    try:
        creds = gmail.credentials(interactive=_interactive())
    except gmail.ShareSetupError as exc:
        console.print(f"[yellow]{exc}[/yellow]")
        raise typer.Exit(1) from None
    question = f"Email {len(made)} message{'s' if len(made) > 1 else ''} to {to} ({len(recipients)} people)?"
    if not yes and not (_interactive() and Confirm.ask(question, default=True)):
        console.print("Nothing sent." + ("" if _interactive() else " (Add --yes to send without asking.)"))
        return
    for i, (pdf, group) in enumerate(zip(made, groups), 1):
        subject = f"Photos: {title}" + (f" ({i} of {len(made)})" if len(made) > 1 else "")
        body = ((note + "\n\n" if note else "") + f"{len(group):,} pictures: {title}, from the archive {archive}"
                + (f" (part {i} of {len(made)})" if len(made) > 1 else "") + ".\n\n"
                + sh.details(group) + "\nSent with DA (Digital Archive).\n")
        try:
            gmail.send_each(recipients, subject, body, [(pdf.name, pdf.read_bytes(), "application/pdf")], creds)
        except gmail.ShareSetupError as exc:
            console.print(f"[red]{exc}[/red]")
            raise typer.Exit(1) from None
        console.print(f"  Sent {subject} to {len(recipients)} {'person' if len(recipients) == 1 else 'people'} "
                      "(each their own email)")
    who = next((name for name in saved if name.lower() == to.strip().lower()), f"{len(recipients)} addresses")
    log_event("share", f"shared {len(pictures)} pictures ({title}) with {who}: {len(made)} emails",   # never addresses
              path=str(out_dir), pictures=len(pictures), emails=len(made), people=len(recipients))


def _recipients(to: str | None, saved: dict[str, list[str]]) -> list[str]:
    """Return the addresses for a list name (any case), or the addresses typed (a@x, b@y)."""
    if not to:
        return []
    for name, people in saved.items():
        if name.lower() == to.strip().lower():
            return [p.strip() for p in people if p.strip()]
    typed = [p.strip() for p in to.split(",") if "@" in p]
    return typed


# --------------------------------------------------------------------------- find

class _LazyOcr:
    """Windows' OCR, started the first time a scan needs reading (and not at all otherwise)."""

    def __init__(self) -> None:
        self.reader = None
        self.unavailable = ""

    def read(self, path: Path) -> dict:
        from mindit.services.ocr.windows_ocr import OcrUnavailable, WindowsOcr  # pylint: disable=import-outside-toplevel

        if self.unavailable:
            return {}
        if self.reader is None:
            try:
                self.reader = WindowsOcr()
                self.reader.start()
            except OcrUnavailable as exc:
                self.unavailable = str(exc)
                return {}
        return self.reader.read(path)

    def close(self) -> None:
        if self.reader is not None:
            self.reader.close()


def find(
    targets: list[Path] = typer.Argument(None, help="Folders or files to look in. None: documents, intake, and "
                                                    "photos already read by da tag ocr."),
    passwords: bool = typer.Option(False, "--passwords", help="Find documents that hold passwords."),
    move: bool = typer.Option(False, "--move", help="Move the ones found to _secure-holding (asks first)."),
    include_weak: bool = typer.Option(False, "--include-weak", help="Move the ones that only mention a password too."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Find things in the archive: --passwords finds documents that hold passwords (and sets them aside)."""
    from datetime import datetime  # pylint: disable=import-outside-toplevel

    from mindit.config.settings import (  # pylint: disable=import-outside-toplevel
        get_intake_path,
        resolve_photoit_organized_path,
        resolve_scanit_organized_path,
    )
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.secure import passwords as pw  # pylint: disable=import-outside-toplevel

    if not passwords:
        console.print("Say what to find: da find --passwords   (to search by name, date or tag: da findit, da db query)")
        raise typer.Exit(2)
    root = get_archive_root() or default_layout().data_root
    photos_root, documents_root, intake = (resolve_photoit_organized_path(), resolve_scanit_organized_path(),
                                           get_intake_path())
    readable = {".pdf"} | pw.OFFICE_SUFFIXES | pw.TEXT_SUFFIXES
    if targets:
        missing = [t for t in targets if not t.exists()]
        if missing:
            console.print("[red]No such folder or file: " + ", ".join(str(m) for m in missing) + "[/red]")
            raise typer.Exit(2)
        everything = pw.files_under(targets, readable | pw.IMAGE_SUFFIXES)
        photos = [p for p in everything if p.suffix.lower() in pw.IMAGE_SUFFIXES and _inside(p, photos_root)]
        documents = [p for p in everything if p not in set(photos)]
    else:
        documents = pw.files_under([t for t in (documents_root, intake) if t.exists()], readable) + \
            pw.files_under([t for t in (documents_root,) if t.exists()], pw.IMAGE_SUFFIXES) + \
            [p for p in pw.files_under([intake], pw.IMAGE_SUFFIXES) if not _inside(p, photos_root)
             and any(part.lower() in ("docs", "scans") for part in p.relative_to(intake).parts[:1])]
        photos = pw.files_under([photos_root], pw.IMAGE_SUFFIXES) if photos_root.exists() else []
    console.print(f"Looking for passwords in {len(documents):,} documents (reading scans with Windows' OCR) and the "
                  f"text already read from {len(photos):,} photos ...")
    reader = _LazyOcr()
    progress = ConsoleProgressReporter(console=console, update_every=100)
    progress.start(label="Looking", total=len(documents) + len(photos))
    try:
        result = pw.scan(documents, photos, reader, progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
        reader.close()
    if reader.unavailable:
        console.print(f"[yellow]Scans weren't read: {reader.unavailable}. Only text already in files was searched.[/yellow]")

    strong = [f for f in result.found if f.level == "strong"]
    weak = [f for f in result.found if f.level == "weak"]
    console.print(f"  {len(strong):,} hold a password (or PIN), {len(weak):,} only mention one; "
                  f"{result.counts['looked at']:,} looked at.")
    for item in strong[:10]:
        console.print(f"    {item.path.name}: {item.snippet}")
    run_dir = default_layout().output_root / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-passwords"
    to_move = strong + (weak if include_weak else [])
    actions: dict[str, tuple[str, str]] = {}
    stats = None
    if move and to_move:
        question = f"Move {len(to_move):,} files (with their sidecars) to {root / pw.HOLDING}?"
        if yes or (_interactive() and Confirm.ask(question, default=True)):
            stats = pw.set_aside(to_move, root, run_dir / "secure-moved.csv", resolve_database_path())
            for item in to_move:
                dest = pw.destination(item.path, root)
                actions[str(item.path)] = ("moved", str(dest)) if dest.exists() else ("not moved", "")
            console.print(f"  Moved {stats['moved']:,} to {root / pw.HOLDING}"
                          + (f"; {stats['skipped'] + stats['failed']:,} not moved" if stats["skipped"] or stats["failed"] else "")
                          + ". Their read text was taken out of DA's records.")
            console.print(f'  Undo: da intake undo "{run_dir / "secure-moved.csv"}"  (then 5 Refresh index)')
        else:
            console.print("  Nothing moved." + ("" if _interactive() else " (Add --yes to move without asking.)"))
    elif to_move:
        console.print("  Nothing moved. To move them to _secure-holding: da find --passwords --move"
                      + ("" if include_weak or not weak else "   (add --include-weak for the ones that only mention one)"))
    report = pw.write_results(result.found, run_dir / "passwords.csv", actions)
    console.print(f"The list (passwords hidden): {report}")
    log_event("find_passwords", f"da find --passwords: {len(strong)} strong, {len(weak)} weak, "
              f"{stats['moved'] if stats else 0} moved", path=str(report))


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


# --------------------------------------------------------------------------- naming

def rename(
    targets: list[Path] = typer.Argument(
        None, help="Folders or files in organized (e.g. photos\\organized\\2021). None: all of organized."),
    pattern: str | None = typer.Option(
        None, "--pattern", help="A name pattern to try instead of da-archive.yaml's, e.g. \"{date_taken:%Y%m%d}_{camera}_{hash:4}\"."),
    folder: str | None = typer.Option(
        None, "--folder", help="A folder pattern to try, e.g. \"{YYYY}\\{owner}\" (default {YYYY}\\{YYYY}-{MM})."),
    kind: str | None = typer.Option(None, "--kind", help="Only photo, video or document files."),
    apply: bool = typer.Option(False, "--apply", help="Rename and move them (asks first; da intake undo puts them back)."),
    save: bool = typer.Option(False, "--save", help="Save --pattern / --folder in da-archive.yaml for --kind (the old ones are kept as notes)."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Show what every filed file would be called, and where it goes, by the patterns; --apply does it, with undo."""
    rename_files(list(targets or []), pattern=pattern, kind=kind, apply=apply, save=save, yes=yes, folder=folder)


def rename_files(targets: list[Path], *, pattern: str | None, kind: str | None, apply: bool, save: bool,
                 yes: bool, folder: str | None = None) -> None:
    """Plan (and with apply, make) the names and folders of the files under targets; with save, keep the patterns."""
    from datetime import datetime  # pylint: disable=import-outside-toplevel

    from mindit.config.settings import (  # pylint: disable=import-outside-toplevel
        get_config_path,
        get_intake_path,
        resolve_photoit_organized_path,
        resolve_scanit_organized_path,
    )
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.naming import rename as rn  # pylint: disable=import-outside-toplevel

    if kind and kind not in rn.MODULES:
        raise typer.BadParameter("--kind is photo, video or document")
    if save and not (pattern or folder):
        raise typer.BadParameter("--save keeps the --pattern or --folder you give: "
                                 "da rename --pattern \"...\" --kind photo --save")
    if (pattern or folder) and (apply or save) and not kind:
        raise typer.BadParameter("Say which files the pattern is for: --kind photo, video or document")
    photos, documents = resolve_photoit_organized_path(), resolve_scanit_organized_path()
    targets = targets or [t for t in (photos, documents) if t.exists()]
    missing = [t for t in targets if not t.exists()]
    if missing:
        console.print("[red]No such folder or file: " + ", ".join(str(m) for m in missing) + "[/red]")
        raise typer.Exit(2)
    intake = os.path.normcase(str(get_intake_path().resolve())) + os.sep
    if any(os.path.normcase(str(t.resolve()) + os.sep).startswith(intake) for t in targets):
        console.print("Files in intake get their names when they're filed: use [bold]da run[/bold].")
        raise typer.Exit(2)

    files = rn.files_to_name(targets)
    names = ", ".join(str(t) for t in targets)
    console.print(f"Working out the names and folders of {len(files):,} files in {names}"
                  + (f" with the pattern {pattern}" if pattern else "")
                  + (f" and the folder pattern {folder}" if folder else "") + " ...")
    progress = ConsoleProgressReporter(console=console, update_every=500)
    progress.start(label="Naming", total=len(files))
    try:
        plan = rn.plan_names(files, pattern=pattern, kind=kind, documents_root=documents, photos_root=photos,
                             folder=folder, progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()

    run_dir = default_layout().output_root / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-rename"
    csv_path = rn.write_plan(plan, run_dir / "rename-plan.csv")
    c = plan.counts
    console.print(f"  {c['rename']:,} would be renamed, {c['move']:,} moved to another folder"
                  + (f" ({c['follows']:,} raw files and Live Photo videos with them)" if c["follows"] else "")
                  + f", {c['unchanged']:,} already named and filed so")
    if c["conflict"]:
        console.print(f"  [yellow]{c['conflict']:,} conflicts[/yellow]: another file has or wants the same name "
                      "(keep {hash} or the time to the second in the pattern); they keep their names")
    if c["no date"] or c["no sidecar"]:
        console.print(f"  Kept as they are, to follow up: {c['no date']:,} with no sure date, "
                      f"{c['no sidecar']:,} with no sidecar")
    for token, count in plan.missing.most_common():
        console.print(f"  {count:,} had nothing for {{{token}}} (left out of their names)")
    console.print(f"The plan, file by file: {csv_path}")

    stats = None
    if apply and plan.renames:
        question = (f"Rename {c['rename']:,} and move {c['move']:,} files"
                    + (f" (and {c['follows']:,} raw/Live Photo files)" if c["follows"] else ""))
        if yes or (_interactive() and Confirm.ask(question + "?", default=False)):
            progress = ConsoleProgressReporter(console=console, update_every=500)
            progress.start(label="Renaming", total=len(plan.renames))
            try:
                stats = rn.apply_names(plan, run_dir / "rename-moved.csv", resolve_database_path(),
                                       progress=lambda i, n: progress.advance(current_item=""),
                                       roots=[photos, documents])
            finally:
                progress.finish()
            console.print(f"  Renamed {stats['moved']:,}"
                          + (f"; {stats['skipped'] + stats['failed']:,} not renamed (see rename-moved.csv)"
                             if stats["skipped"] or stats["failed"] else "") + ".")
            console.print(f"  Undo: da intake undo \"{run_dir / 'rename-moved.csv'}\"")
        else:
            console.print("  Nothing renamed." + ("" if _interactive() else " (Add --yes to rename without asking.)"))
    elif not apply:
        console.print("Nothing changed." + (" To rename and move them: add --apply." if plan.renames else ""))

    if save and kind:
        for key, value in (("pattern", pattern), ("folder", folder)):
            if value:
                _save_pattern(get_config_path(), rn.MODULES[kind], value, yes=yes, key=key)
    log_event("rename", f"da rename {'--apply ' if apply else ''}{names}: {c['rename']} to rename, "
              f"{stats['moved'] if stats else 0} renamed, {c['conflict']} conflicts, {c['no date']} no date",
              path=str(csv_path))


def _save_pattern(archive_file: Path, module: str, pattern: str, *, yes: bool, key: str = "pattern") -> None:
    """Save a name (or folder) pattern in da-archive.yaml (asking first), keeping the old one as a dated note."""
    from mindit.services.naming import patterns as pt  # pylint: disable=import-outside-toplevel

    what = "folder pattern" if key == "folder" else "pattern"
    old = pt.current_pattern(archive_file, module, key)
    if old == pattern:
        console.print(f"  {module} already uses that {what}.")
        return
    if not (yes or (_interactive() and Confirm.ask(f"Save it in da-archive.yaml as the {module} {what}?", default=True))):
        console.print("  Not saved." + ("" if _interactive() else " (Add --yes to save without asking.)"))
        return
    try:
        backup = pt.save_pattern(archive_file, module, pattern, key=key)
    except RuntimeError as exc:
        console.print(f"  [red]{exc}[/red]")
        return
    console.print(f"  Saved: modules.{module}.{key} = {pattern}" + (f" (was {old}, kept as a note)" if old else "")
                  + f". Backup: {backup.name}")


# --------------------------------------------------------------------------- tags

def tag(
    items: list[str] = typer.Argument(
        None, help="Files or folders, then the tags to add to them (e.g. photos\\organized\\2021 beach grandma). "
                   "No files or folders: all of this archive's filed photos."),
    remove: list[str] = typer.Option(None, "--remove", "-x", help="A tag of yours to take off (repeat for more)."),
    cameras: bool = typer.Option(False, "--cameras",
                                 help="List the cameras found and ask who used each (saved in da-archive.yaml)."),
    owner: tuple[str, str] = typer.Option((None, None), "--owner", metavar="CAMERA NAME",
                                          help='Save who used a camera, e.g. --owner "Apple iPhone 8" jane.'),
    refresh: bool = typer.Option(False, "--refresh", help="Read the camera details from each photo again."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before tagging all filed photos."),
    tag_only: bool = typer.Option(False, "--tag-only",
                                  help="da tag ocr: tag the pictures with text (text, document)."),
    tag_and_move: bool = typer.Option(False, "--tag-and-move",
                                      help="da tag ocr: tag them, and move the document ones to documents."),
    again: bool = typer.Option(False, "--again", help="da tag ocr: read pictures read before again."),
) -> None:
    """Tag photos: automatic tags from each photo's camera details, or your own tags on files and folders.

    da tag ocr <folders> reads the text in pictures (preview; --tag-only, --tag-and-move).
    """
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging import tags as tg  # pylint: disable=import-outside-toplevel

    if items and items[0].lower() == "ocr":
        _tag_ocr([Path(i) for i in items[1:]], tag_only=tag_only, tag_and_move=tag_and_move, again=again, yes=yes)
        return
    if tag_only or tag_and_move or again:
        raise typer.BadParameter("--tag-only, --tag-and-move and --again go with da tag ocr <folders>")

    targets, words = [], []
    for item in items or []:
        if not words and Path(item).exists():
            targets.append(Path(item))
        else:
            words.append(item)
    whole_archive = not targets
    if whole_archive:
        targets = [resolve_photoit_organized_path()]
    settings = load_settings()

    if owner[0]:
        if not owner[1] or not owner[1].strip():
            raise typer.BadParameter('Give the camera and the name: --owner "Apple iPhone 8" jane')
        if not _save_owners({owner[0]: owner[1].strip()}):
            raise typer.Exit(1)
        _retag(targets, tg, ask=not yes)
        return

    if cameras:
        photos = tg.files_under(targets, photos_only=True)
        seen = tg.cameras_seen(photos, settings.cameras)
        _list_cameras(seen, tg)
        missing = [cam for cam in seen if not cam.owner]
        if missing and _interactive() and not yes:
            console.print("\nWho used each camera? Type a name, or press Enter to skip.")
            names = {}
            for cam in missing:
                years = tg.camera_years(cam)
                try:
                    answer = Prompt.ask(f"  {cam.key}  ({cam.photos:,} photos{', ' + years if years else ''})",
                                        default="", show_default=False).strip()
                except (EOFError, KeyboardInterrupt):
                    console.print()
                    break
                if answer:
                    names[cam.key] = answer
            if names and _save_owners(names):
                _retag(targets, tg, ask=True)
        return

    if words or remove:
        files = tg.files_under(targets, photos_only=False)
        result = tg.change_user_tags(files, words, remove or [])
        rows = tg.update_index(resolve_database_path(), result.changed)
        console.print(f"Your tags on {len(files):,} files: "
                      + ", ".join([f"+{tg.clean_tag(w)}" for w in words] + [f"-{tg.clean_tag(r)}" for r in remove or []])
                      + f"  (index updated: {rows:,})")
        return

    photos = tg.files_under(targets, photos_only=True)
    where = ", ".join(str(t) for t in targets)
    if whole_archive and not yes and not Confirm.ask(
            f"Read camera details and make automatic tags for {len(photos):,} photos in {where}?", default=True):
        return
    console.print(f"Tagging {len(photos):,} photos in {where} ...")
    progress = ConsoleProgressReporter(console=console, update_every=1000)
    progress.start(label="Tagging", total=len(photos))
    try:
        result = tg.tag_photos(photos, settings.cameras, refresh=refresh,
                               progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    rows = tg.update_index(resolve_database_path(), result.changed)
    console.print(f"Tagged {result.files:,} photos; camera details read from {result.read:,}"
                  + (f"; {len(result.unreadable):,} couldn't be read" if result.unreadable else "")
                  + f"  (index updated: {rows:,})")
    if not settings.cameras:
        console.print("For owner: tags, see who used which camera: da tag --cameras")


def _tag_ocr(targets: list[Path], *, tag_only: bool, tag_and_move: bool, again: bool, yes: bool) -> None:
    """Read the text in the pictures named; preview, tag, or tag and move the document ones."""
    from datetime import datetime  # pylint: disable=import-outside-toplevel

    from mindit.config.settings import (  # pylint: disable=import-outside-toplevel
        get_intake_path,
        resolve_photoit_organized_path,
        resolve_scanit_organized_path,
    )
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.ocr import ocr_tags as ot  # pylint: disable=import-outside-toplevel
    from mindit.services.ocr.windows_ocr import OcrUnavailable, WindowsOcr  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import update_index  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import MediaKind  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.split import intake_folder_for  # pylint: disable=import-outside-toplevel

    if tag_only and tag_and_move:
        raise typer.BadParameter("Choose one: --tag-only or --tag-and-move")
    if not targets:
        console.print("Name the folders (or files) to read, e.g. [bold]da tag ocr photos\\organized\\2020[/bold]")
        raise typer.Exit(2)
    missing = [t for t in targets if not t.exists()]
    if missing:
        console.print("[red]No such folder or file: " + ", ".join(str(m) for m in missing) + "[/red]")
        raise typer.Exit(2)
    mode = "move" if tag_and_move else "tag" if tag_only else "preview"
    layout = default_layout()
    root = get_archive_root() or layout.data_root
    where = ot.Where(photos_organized=resolve_photoit_organized_path(), documents_organized=resolve_scanit_organized_path(),
                     intake=get_intake_path(), intake_documents=intake_folder_for(root, MediaKind.DOCUMENT))
    files = ot.pictures_under(targets)
    names = ", ".join(str(t) for t in targets)
    if not files:
        console.print(f"No pictures in {names}.")
        return
    console.print(f"Reading the text in {len(files):,} pictures in {names}"
                  + {"preview": " (a preview: nothing changes)", "tag": "", "move": ""}[mode] + " ...")
    progress = ConsoleProgressReporter(console=console, update_every=50)
    progress.start(label="Reading", total=len(files))
    try:
        with WindowsOcr() as reader:
            run = ot.run_ocr(files, reader, mode=mode, where=where, again=again,
                             cache=ot.Cache(root / ".da" / "ocr-cache.jsonl"),
                             progress=lambda i, n: progress.advance(current_item=""))
    except OcrUnavailable as exc:
        console.print(f"[red]Can't read text in pictures here: {exc}[/red]")
        raise typer.Exit(1) from None
    finally:
        progress.finish()

    run_dir = layout.output_root / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-ocr"
    to_move = [r for r in run.results if r.get("action") == "move"]
    moved = None
    if to_move:
        if yes or (_interactive() and Confirm.ask(f"Move {len(to_move):,} document pictures (with their sidecars)?",
                                                   default=True)):
            moved = ot.apply_moves(run, run_dir / "ocr-moved.csv", resolve_database_path(), where.documents_organized)
        else:
            for r in to_move:
                r["action"] = "tagged (not moved)"
    rows = update_index(resolve_database_path(), run.changed)
    results = ot.write_results(run, run_dir / "ocr-results.csv")

    c = run.counts
    console.print(f"  {len(files):,} pictures: {c['document']:,} mostly text (document), {c['text']:,} with some "
                  f"text, {c['none']:,} without" + (f", {c['unreadable']:,} couldn't be read" if c["unreadable"] else "")
                  + f"  (read now: {c['read']:,})")
    would_move = sum(1 for r in run.results if r.get("destination") and r.get("action") != "moved")
    if mode == "preview":
        console.print(f"  Nothing changed. {c['document'] + c['text']:,} would be tagged"
                      + (f", {would_move:,} moved to documents" if would_move else "") + ".")
        console.print(f"  To tag them: da tag ocr {names} --tag-only     "
                      f"To tag and move the documents: da tag ocr {names} --tag-and-move")
    else:
        console.print(f"  Tagged {c['document'] + c['text']:,} pictures ({c['document']:,} document, {c['text']:,} text);"
                      f" {len(run.changed):,} sidecars updated  (index updated: {rows:,})")
        if moved is not None:
            console.print(f"  Moved: {moved['moved']:,} document pictures"
                          + (f"; {moved['skipped'] + moved['failed']:,} not moved (see the results)"
                             if moved["skipped"] or moved["failed"] else ""))
            console.print(f"  Undo the moves: da intake undo \"{run_dir / 'ocr-moved.csv'}\"")
    console.print(f"Results, picture by picture: {results}")
    log_event("ocr", f"da tag ocr ({mode}) {names}: {len(files)} pictures, {c['document']} documents, "
              f"{c['text']} with text, {len(run.changed)} tagged, {moved['moved'] if moved else 0} moved",
              path=str(results))


def _interactive() -> bool:
    """Return True when someone is at the keyboard (not a script, and the output isn't captured)."""
    return sys.stdin.isatty() and sys.stdout.isatty()


def _save_owners(owners: dict[str, str]) -> bool:
    """Write camera owners into this archive's da-archive.yaml; say what happened."""
    from mindit.config.settings import ARCHIVE_FILE  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.owners import set_owners  # pylint: disable=import-outside-toplevel

    root = get_archive_root()
    if root is None:
        console.print("[yellow]Not inside an archive, so there's no da-archive.yaml to save owners in.[/yellow]")
        return False
    try:
        backup = set_owners(root / ARCHIVE_FILE, owners)
    except RuntimeError as error:
        console.print(f"[red]{error}[/red]")
        return False
    for camera, name in owners.items():
        console.print(f"  saved: {camera} -> {name}")
    console.print(f"  in {root / ARCHIVE_FILE} (the old one is kept as {backup.name})")
    return True


def _retag(targets: list[Path], tg, *, ask: bool) -> None:
    """Make the automatic tags again so new owners show up (camera details are already kept: quick)."""
    if ask and not Confirm.ask("Update the owner: tags now?", default=True):
        console.print("Later: run `da tag` (only tags change; photos aren't read again).")
        return
    photos = tg.files_under(targets, photos_only=True)
    result = tg.tag_photos(photos, load_settings().cameras)
    rows = tg.update_index(resolve_database_path(), result.changed)
    console.print(f"Tags updated on {result.files:,} photos  (index updated: {rows:,})")


def _list_cameras(seen, tg) -> None:
    if not seen:
        console.print("No camera details yet. Run `da tag` first; it reads them from the photos.")
        return
    table = Table(show_header=True, box=None)
    for column in ("camera", "serial", "photos", "years", "owner"):
        table.add_column(column, justify="right" if column == "photos" else "left")
    for cam in seen:
        table.add_row(cam.name, cam.serial or "", f"{cam.photos:,}", tg.camera_years(cam), cam.owner or "-")
    console.print(table)
    missing = [cam for cam in seen if not cam.owner]
    if missing and not _interactive():
        console.print("\nTo name an owner (saved in da-archive.yaml for you):")
        console.print(f'  da tag --owner "{missing[0].key}" <name>')


# --------------------------------------------------------------------------- split

def split(
    to: Path = typer.Option(None, "--to", help="The archive to move them to; its years pick which files go."),
    years: str = typer.Option(None, "--years", help="Only files taken in these years, e.g. 2000-2004."),
    organized: bool = typer.Option(False, "--organized", help="Filed files too, not only intake (straight into the "
                                   "other archive's organized folders when both lay files out alike)."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before moving."),
) -> int:
    """Move files from other years into the archive for those years (no --to: just show where)."""
    from mindit.config.archive import is_archive  # pylint: disable=import-outside-toplevel
    from mindit.config.settings import resolve_photoit_organized_path, resolve_scanit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import MediaKind  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import split as sp  # pylint: disable=import-outside-toplevel

    here = get_archive_root()
    if here is None:
        console.print("[yellow]Run this inside an archive (the one whose intake holds the files).[/yellow]")
        raise typer.Exit(1)
    given = sp.parse_years(years) if years else None
    if years and not given:
        raise typer.BadParameter(f"--years must look like 2000-2009, not {years!r}")
    here_years = sp.archive_years(here)
    if not here_years and not given and not organized:
        console.print(f"{sp.archive_name(here)} takes any year (no years: in its da-archive.yaml), so nothing in "
                      "its intake belongs elsewhere. To move some anyway, give --years, e.g. --years 2000-2009; "
                      "to split its filed files into the archives for their years: da split --organized")
        return 0

    layout = default_layout()
    db_path = resolve_database_path()
    photos, documents = resolve_photoit_organized_path(), resolve_scanit_organized_path()
    console.print(f"Working out the dates of what's in {layout.intake_root} ...")
    strays, undated = sp.find_strays(layout.intake_root, here_years, intake_names=set(load_settings().intake),
                                     progress=lambda n: console.print(f"  {n:,} files ...", end="\r"))
    filed: list = []
    filed_undated = 0
    if organized:
        console.print("Indexing the archive, so DA knows what's filed ...")
        ArchiveIndexService(DbitService(db_path)).build(default_areas(),
                                                        progress=lambda m: console.print(f"  {m}", end="\r"))
        filed, filed_undated = sp.find_filed(db_path, {MediaKind.PHOTO: photos, MediaKind.DOCUMENT: documents},
                                             here_years)
    if given:
        strays = [s for s in strays if given[0] <= s.year <= given[1]]
        filed = [f for f in filed if given[0] <= f.year <= given[1]]
    where = (f"outside {here_years[0]}-{here_years[1]}" if here_years else
             f"in {given[0]}-{given[1]}" if given else "with a sure date")
    console.print(f"{len(strays):,} files in intake were taken {where}."
                  + (f" ({undated:,} have no sure date and stay; see 3 What needs review.)" if undated else ""))
    if organized:
        console.print(f"{len(filed):,} filed files were taken {where}."
                      + (f" ({filed_undated:,} have no date in the index and stay.)" if filed_undated else ""))
    if not strays and not filed:
        return 0

    if to is None:
        placed, nowhere = sp.by_archive(strays + filed, known_archives(), here)
        for archive, items in placed.items():
            yrs = sp.archive_years(archive)
            console.print(f"  {len(items):,} belong in {sp.archive_name(archive)} ({yrs[0]}-{yrs[1]}):  "
                          f'da split{" --organized" if organized else ""} --to "{archive}"')
        busy = sp.overlapping(known_archives(), here)
        for year_span, names in busy:
            console.print(f"  [yellow]{year_span} is taken by more than one archive ({', '.join(names)}); "
                          "the first listed gets them unless you say --to.[/yellow]")
        decades = Counter(s.year // 10 * 10 for s in nowhere)
        for decade, n in sorted(decades.items()):
            console.print(f"  {n:,} from the {decade}s have no archive on this PC yet. Make one: "
                          f"da setup <folder> --years {decade}-{decade + 9}")
        return len(strays) + len(filed)

    to = to.resolve()
    if not is_archive(to):
        raise typer.BadParameter(f"{to} isn't an archive (no da-archive.yaml). Make it with da setup first.")
    if os.path.normcase(str(to)) == os.path.normcase(str(here.resolve())):
        raise typer.BadParameter("That's this archive. Give the other one.")
    target_years = given or sp.archive_years(to)
    if not target_years:
        console.print(f"[yellow]{sp.archive_name(to)} takes any year, so give the years to move: "
                      "--years 2000-2009.[/yellow]")
        raise typer.Exit(1)
    plan = sp.plan_split(strays, to, here.name, target_years)
    if organized:
        sp.plan_split_organized(filed, to, here.name, target_years, here, plan)
    if not plan.moves:
        console.print(f"None of them were taken in {target_years[0]}-{target_years[1]}."
                      + (" (Run without --to to see where they belong.)" if not given else ""))
        return 0
    other = sp.archive_years(to)
    if given and other and not (other[0] <= given[0] and given[1] <= other[1]):
        console.print(f"[yellow]Note: {sp.archive_name(to)} takes {other[0]}-{other[1]}; files outside that "
                      "will wait in its intake too.[/yellow]")
    console.print(f"\nMove {plan.photos:,} photos and videos and {plan.documents:,} documents taken "
                  f"{target_years[0]}-{target_years[1]} to {sp.archive_name(to)}:")
    if organized:
        later = plan.photos + plan.documents - plan.filed_straight
        console.print(f"  {plan.filed_straight:,} straight into its organized folders (same place as here)"
                      + (f", {later:,} into its intake, to be filed there (1 Process intake)" if later else ""))
    for move in [m for m in plan.moves if m.companion_of is None][:5]:
        console.print(f"  {_shown(move.source, here)}  ->  {move.destination}")
    if plan.photos + plan.documents > 5:
        console.print(f"  ... and {plan.photos + plan.documents - 5:,} more")
    extras = sum(1 for m in plan.moves if m.companion_of)
    if extras:
        console.print(f"  (with {extras:,} raw files and Live Photo videos that go with them; sidecars too)")
    if plan.conflicts:
        console.print(f"[yellow]  {len(plan.conflicts):,} stay: a file with the same name is already there.[/yellow]")
    if not yes and not _interactive():
        console.print("Nothing moved. To move them: add --yes.")
        return 0
    if not yes and not Confirm.ask("Move them?", default=True):
        return 0

    run_dir = layout.run_dir("split")
    log = run_dir / "split-moved.csv"
    stats = sp.apply_split(plan, log, db_path)
    console.print(f"Moved {stats['files']:,} file{'s' if stats['files'] != 1 else ''}"
                  + (f" ({stats['skipped'] + stats['failed']:,} couldn't be moved; see the log)"
                     if stats["skipped"] or stats["failed"] else "") + ".")
    if organized and stats["moved"]:
        from mindit.services.naming.rename import tidy_folders  # pylint: disable=import-outside-toplevel

        moved_from = {m.source.parent for m in plan.moves if not m.source.exists()}
        tidy_folders(set(), moved_from, [photos, documents])           # this archive's sheets; emptied folders go
        console.print(f"Updating {sp.archive_name(to)}: its index and contact sheets ...")
        indexed, made = sp.refresh_target(to, {m.destination.parent for m in plan.moves if m.destination.exists()})
        console.print(f"  {sp.archive_name(to)}: {indexed:,} files indexed, {made:,} contact sheets made.")
    console.print(f'Undo: da intake undo "{log}"  (then choose 5 Refresh index in both archives)')
    if plan.photos + plan.documents > plan.filed_straight:
        console.print(f"Next: open {sp.archive_name(to)} (its Open DA.cmd, or 6 Switch archive in the menu) and "
                      "choose 1 Process intake.")
    return stats["files"]


def _shown(path: Path, root: Path) -> str:
    """Return path relative to the archive when it's in it."""
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


# --------------------------------------------------------------------------- report

def report(
    open_it: bool = typer.Option(False, "--open", help="Open the PDF when it's made."),
    refresh: bool = typer.Option(False, "--refresh", help="Refresh the index first, so the numbers are current."),
) -> None:
    """Make a one-page PDF about this archive (what it holds, by year, cameras, places) in its output folder."""
    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.services.report import archive_report as ar  # pylint: disable=import-outside-toplevel

    settings = load_settings()
    layout = default_layout()
    root = get_archive_root() or layout.data_root
    db_path = resolve_database_path()
    if refresh:
        from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel

        console.print("Refreshing the index ...")
        ArchiveIndexService(DbitService(db_path)).build(default_areas(),
                                                        progress=lambda m: console.print(f"  {m}"))
    console.print("Counting ...")
    data = ar.gather(db_path, name=settings.archive.name or root.name, folder=str(root),
                     years=settings.archive.years or "", output_root=layout.output_root, version=f"v{__version__}")
    path = ar.make_pdf(data, ar.report_path(layout.output_root, data.name, data.made_at))
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("report", f"da report: {path.name}", path=str(path))
    console.print(f"  {data.photos:,} photo{'s' if data.photos != 1 else ''} and {data.documents:,} "
                  f"document{'s' if data.documents != 1 else ''} filed"
                  + (f", taken {data.first_year} to {data.last_year}" if data.first_year else "")
                  + f"; {data.intake:,} waiting in intake.")
    if data.cameras:
        console.print(f"  {data.camera_count:,} cameras; most photos: "
                      + ", ".join(ar.nice_name(c) for c, _ in data.cameras[:3]) + ".")
    console.print("  " + ar.places_sentence(data))
    if not data.indexed:
        console.print("[yellow]  Not indexed yet: run da db build (or menu 5), then make the report again.[/yellow]")
    console.print(f"Report: {path}")
    if open_it:
        try:
            os.startfile(path)  # type: ignore[attr-defined]  # pylint: disable=no-member
        except (AttributeError, OSError):
            pass


# --------------------------------------------------------------------------- dashboard

def dashboard(
    port: int = typer.Option(8765, "--port", help="The port (the next free one is used if it's taken)."),
    open_it: bool = typer.Option(True, "--open/--no-open", help="Open the page in the browser."),
    stop: bool = typer.Option(False, "--stop", help="Stop this archive's dashboard."),
    foreground: bool = typer.Option(False, "--foreground",
                                    help="Run it in this window until Ctrl+C, instead of in the background."),
) -> None:
    """Show this archive's dashboard in the browser (a page on this PC only); it runs in the background."""
    import webbrowser  # pylint: disable=import-outside-toplevel

    from mindit.services.dashboard import background  # pylint: disable=import-outside-toplevel

    root = get_archive_root() or default_layout().data_root
    if stop:
        info = background.stop(root)
        console.print(f"Dashboard stopped ({info['url']})." if info else "No dashboard is running for this archive.")
        return
    if foreground:
        _serve_dashboard(root, port, open_it)
        return
    info = background.running(root)
    if info:
        console.print(f"The dashboard is already running: {info['url']}")
    else:
        console.print("Starting the dashboard ...")
        try:
            info = background.start(root, port)
        except RuntimeError as exc:
            console.print(f"[red]  Couldn't start it: {exc}[/red]")
            raise typer.Exit(1) from None
        console.print(f"Dashboard for this archive: {info['url']}")
        console.print("  It runs in the background (closing this window doesn't stop it); it doesn't change "
                      "your files, and only this PC can open it.")
    console.print("  To stop it: [bold]da dashboard --stop[/bold]  (restarting the PC stops it too)")
    if open_it:
        webbrowser.open(info["url"])


def _serve_dashboard(root: Path, port: int, open_it: bool) -> None:
    """Serve the dashboard from this process until Ctrl+C (or `da dashboard --stop`)."""
    import webbrowser  # pylint: disable=import-outside-toplevel

    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.config.settings import get_logs_root_path  # pylint: disable=import-outside-toplevel
    from mindit.services.dashboard import background  # pylint: disable=import-outside-toplevel
    from mindit.services.dashboard import dashboard as dash  # pylint: disable=import-outside-toplevel

    settings = load_settings()
    layout = default_layout()
    board = dash.Dashboard(dash.Archive(
        name=settings.archive.name or root.name, folder=root, years=settings.archive.years or "",
        db_path=resolve_database_path(), output_root=layout.output_root,
        log_path=get_logs_root_path(settings) / settings.logs.shared_log_name, version=f"v{__version__}"))
    server = dash.make_server(board, port)
    info = background.write_state(root, server.server_address[1])
    board.recount()                                    # years, cameras, places: in the background
    console.print(f"Dashboard for [bold]{board.archive.name}[/bold]: {info['url']}")
    console.print("  It doesn't change your files, and only this PC can open it. Press Ctrl+C to stop it.")
    if open_it:
        webbrowser.open(info["url"])
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        console.print("  Dashboard stopped.")
    finally:
        server.server_close()
        background.clear_state(root, pid=info["pid"])


# --------------------------------------------------------------------------- merge

def merge(
    other: Path = typer.Option(..., "--from", help="The other archive, whose files this one should have too."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before copying."),
) -> None:
    """Copy into this archive what another archive has and this one doesn't (the other is never changed)."""
    from mindit.config.archive import is_archive  # pylint: disable=import-outside-toplevel
    from mindit.services.contactsheet.contact_sheet import refresh_sheets  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import merge as mg  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.split import archive_name  # pylint: disable=import-outside-toplevel

    here = get_archive_root()
    if here is None:
        console.print("[yellow]Run this inside the archive to keep (the one that gets the files).[/yellow]")
        raise typer.Exit(1)
    other = other.resolve()
    if not is_archive(other):
        raise typer.BadParameter(f"{other} isn't an archive (no da-archive.yaml).")
    if os.path.normcase(str(other)) == os.path.normcase(str(here.resolve())):
        raise typer.BadParameter("That's this archive. Give the other one.")

    db = DbitService(resolve_database_path())
    console.print(f"Indexing {archive_name(here)} so DA knows what it has ...")
    ArchiveIndexService(db).build(default_areas(), progress=lambda m: console.print(f"  {m}"))
    with sqlite3.connect(db.db_path) as conn:
        known = {row[0] for row in conn.execute("SELECT sha256 FROM files WHERE sha256 IS NOT NULL")}
        unhashed = [Path(row[0]) for row in conn.execute("SELECT path FROM files WHERE sha256 IS NULL")]
    if unhashed:                                     # e.g. intake files with no sidecar yet
        console.print(f"Fingerprinting {len(unhashed):,} files here that don't have one yet ...")
        known |= {digest for digest in map(mg.file_hash, unhashed) if digest}
    console.print(f"Comparing {archive_name(other)} ({other}) with it, file by file ...")
    plan = mg.plan_merge(here, other, known,
                         progress=lambda n: console.print(f"  {n:,} files looked at ...", end="\r"))
    console.print(f"{plan.looked_at:,} files in {archive_name(other)}: {plan.already_here:,} already here"
                  + (f", {plan.repeats:,} repeated there (copied once)" if plan.repeats else "")
                  + (f", {len(plan.unreadable):,} couldn't be read" if plan.unreadable else "") + ".")
    if not plan.copies:
        console.print(f"Nothing to copy: {archive_name(here)} already has everything {archive_name(other)} has.")
        return
    gb = plan.bytes / 1e9
    console.print(f"\nCopy {len(plan.copies):,} files ({gb:,.1f} GB) into {archive_name(here)}:")
    for reason, n in plan.reasons().most_common():
        where = ("to the same folder and name here" if reason == "filed"
                 else f"to intake\\...\\{mg._from_folder(other)} ({reason}; da run files them)")
        console.print(f"  {n:,} {where}")
    free = shutil.disk_usage(here).free
    if plan.bytes > free * 0.95:
        console.print(f"[red]Not enough room: {gb:,.1f} GB to copy, {free / 1e9:,.1f} GB free on that drive.[/red]")
        raise typer.Exit(1)
    console.print(f"  ({free / 1e9:,.0f} GB free there. {archive_name(other)} isn't changed.)")
    if not yes and not _interactive():
        console.print("Nothing copied. To copy them: add --yes.")
        return
    if not yes and not Confirm.ask("Copy them?", default=True):
        return

    run_dir = default_layout().run_dir("merge")
    log = run_dir / "merge-copied.csv"
    progress = ConsoleProgressReporter(console=console, update_every=200)
    progress.start(label="Copying", total=len(plan.copies))
    try:
        stats = mg.apply_merge(plan, log, progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    filed_folders = {c.destination.parent for c in plan.copies if c.reason == "filed"}
    sheets = refresh_sheets(filed_folders, create=True)
    ArchiveIndexService(db).build(default_areas())
    console.print(f"Copied {stats['copied']:,} files: {stats['filed']:,} filed, {stats['to_intake']:,} to intake"
                  + (f"; {stats['skipped'] + stats['failed']:,} not copied (see the log)"
                     if stats["skipped"] or stats["failed"] else "")
                  + f". {len(sheets.made):,} contact sheets updated.")
    console.print(f'Undo (removes the copies): da intake undo "{log}"')
    if stats["to_intake"]:
        console.print("Next: choose 1 Process intake (or da run) to file what went to intake.")


# --------------------------------------------------------------------------- guide

GUIDE_URL = "https://da.gamenightbymike.com"
GUIDE_PDF_URL = f"{GUIDE_URL}/DA-User-Guide.pdf"


def guide(
    pdf: bool = typer.Option(False, "--pdf", help="Open the PDF version instead of the web page."),
) -> None:
    """Open the DA user guide in your web browser (or its PDF)."""
    import webbrowser  # pylint: disable=import-outside-toplevel

    url = GUIDE_PDF_URL if pdf else GUIDE_URL
    console.print(f"Opening {url}")
    if not webbrowser.open(url):
        console.print("Couldn't open a browser here. Open that address yourself.")


# --------------------------------------------------------------------------- archives / install

def archives(
    ctx: typer.Context,
    open_: int = typer.Option(None, "--open", "-o", help="Open archive number N in its own window."),
) -> None:
    """List the archives set up on this PC; --open N opens one; da archives delete <archive> deletes one safely."""
    if ctx.invoked_subcommand:
        return
    found = known_archives()
    if not found:
        console.print("No archives yet. Create one:  da setup D:\\jane-archive-199x --years 1990-1999")
        return
    if open_:
        if not 1 <= open_ <= len(found):
            raise typer.BadParameter(f"pick 1-{len(found)}")
        launcher = found[open_ - 1] / LAUNCHER
        os.startfile(str(launcher))  # type: ignore[attr-defined]  # Windows
        console.print(f"Opened {launcher}")
        return
    table = Table(title="Archives on this PC")
    for col in ("#", "name", "years", "folder"):
        table.add_column(col)
    for i, folder in enumerate(found, 1):
        name, years = _archive_label(folder)
        table.add_row(str(i), name, years, str(folder))
    console.print(table)
    console.print("Open one:  da archives --open N   (or double-click Open DA.cmd in its folder)")


def archives_delete(
    folder: Path = typer.Argument(..., help="The archive to delete, e.g. D:\\jane-archive-all."),
    also: list[Path] = typer.Option(None, "--also", help="Another folder that holds copies (a backup drive); repeat."),
    forget_only: bool = typer.Option(False, "--forget", help="Only take it off this PC's list; delete nothing."),
    confirm: str = typer.Option(None, "--confirm", help="The archive's name, to delete without being asked."),
) -> None:
    """Delete an archive, only if every photo, video and document in it also exists elsewhere (Recycle Bin)."""
    from datetime import datetime  # pylint: disable=import-outside-toplevel

    from mindit.config.archive import is_archive  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import archive_delete as ad  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.split import archive_name  # pylint: disable=import-outside-toplevel

    folder = folder.resolve()
    if not is_archive(folder):
        raise typer.BadParameter(f"{folder} isn't an archive (no da-archive.yaml).")
    name = archive_name(folder)
    if forget_only:
        console.print(f"Took {name} off this PC's list." if ad.forget(folder) else f"{name} wasn't on this PC's list.")
        console.print("Its files are where they were.")
        return
    here = get_archive_root()
    cwd = Path(os.getcwd()).resolve()
    if (here and os.path.normcase(str(here.resolve())) == os.path.normcase(str(folder))) or \
            os.path.normcase(str(cwd)).startswith(os.path.normcase(str(folder))):
        console.print(f"[yellow]This window is working in {name}. Open a terminal somewhere else (or another "
                      "archive's Open DA.cmd), then run it again.[/yellow]")
        raise typer.Exit(1)
    if os.name != "nt" or not ad.drive_has_recycle_bin(folder):
        console.print(f"[yellow]{folder.drive or folder} has no Recycle Bin (a USB or network drive), so DA won't "
                      "delete it there. Check it below, then delete it in File Explorer yourself.[/yellow]")

    others = [a for a in known_archives() if os.path.normcase(str(a.resolve())) != os.path.normcase(str(folder))]
    console.print(f"Checking that every file in {name} also exists elsewhere: in "
                  + (", ".join(archive_name(a) for a in others) or "no other archive")
                  + (" and " + ", ".join(str(a) for a in also) if also else "") + " ...")
    check = ad.check_delete(folder, others, list(also or []), progress=lambda m: console.print(f"  {m}"))
    report = ad.write_report(check, cwd / f"delete-check-{name}-{datetime.now():%Y%m%d-%H%M%S}.csv")
    console.print(f"  {check.files:,} files ({check.gb:,.1f} GB): {check.found:,} have a copy elsewhere"
                  + (f", {len(check.missing):,} don't" if check.missing else "")
                  + f"; {check.sampled:,} copies re-read" + (f", {check.sample_bad} changed" if check.sample_bad else ""))
    console.print(f"  File by file: {report}")
    if not check.safe:
        console.print(f"[red]Not deleted: {len(check.missing):,} files exist only in {name}.[/red] For example:")
        for path in check.missing[:5]:
            console.print(f"    {path}")
        console.print("  Move or copy them first (da split --organized, or da merge --from in the archive to keep), "
                      "or name a backup that has them with --also, then run it again.")
        raise typer.Exit(1)
    if os.name != "nt" or not ad.drive_has_recycle_bin(folder):
        return

    console.print(f"\nEverything in {name} also exists elsewhere. Deleting sends the whole folder, {folder}, to the "
                  "Recycle Bin. If it's too big for the Recycle Bin, Windows asks first before deleting it for good: "
                  "answer No to keep it.")
    if confirm is None:
        if not _interactive():
            console.print(f"Nothing deleted. To delete it: add --confirm \"{name}\".")
            return
        confirm = Prompt.ask(f"Type the archive's name ({name}) to delete it, or Enter to keep it", default="")
    if confirm.strip() != name:
        console.print("Kept: nothing deleted.")
        return
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    if ad.to_recycle_bin(folder):
        ad.forget(folder)
        console.print(f"Deleted {name}: it's in the Recycle Bin, and off this PC's list. The check is kept in {report}.")
        log_event("archive_delete", f"deleted {folder} to the Recycle Bin ({check.files} files, all elsewhere)",
                  path=str(report))
    else:
        console.print(f"[yellow]{name} wasn't deleted (stopped, or Windows couldn't). It's where it was.[/yellow]")


def archives_move(
    folder: Path = typer.Argument(..., help="The archive to move, e.g. D:\\jane-archive-199x."),
    new: Path = typer.Argument(..., help="Its new place, e.g. E:\\jane-archive-199x (a new or empty folder)."),
    copy: bool = typer.Option(False, "--copy", help="Copy and check even on the same drive (the old copy stays)."),
    full: bool = typer.Option(False, "--full", help="Re-read every copied file in full (slow on a big archive)."),
    remove_old: bool = typer.Option(False, "--remove-old", help="Send the old copy to the Recycle Bin once checked."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Move a whole archive to another drive or folder; DA's index, undo logs and list follow it."""
    from mindit.config.archive import is_archive  # pylint: disable=import-outside-toplevel
    from mindit.services.dashboard import background  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import archive_delete as ad  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import archive_move as am  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.split import archive_name  # pylint: disable=import-outside-toplevel

    folder, new = folder.resolve(), new.resolve()
    if not is_archive(folder):
        raise typer.BadParameter(f"{folder} isn't an archive (no da-archive.yaml).")
    name = archive_name(folder)
    here = get_archive_root()
    cwd = Path(os.getcwd()).resolve()
    if (here and os.path.normcase(str(here.resolve())) == os.path.normcase(str(folder))) or \
            os.path.normcase(str(cwd)).startswith(os.path.normcase(str(folder))):
        console.print(f"[yellow]This window is working in {name}. Close its DA windows, open a terminal somewhere "
                      "else, then run it again.[/yellow]")
        raise typer.Exit(1)
    try:
        files, total = am.check_move(folder, new, copy=copy)
    except am.MoveError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from None
    if background.running(folder):
        background.stop(folder)
        console.print(f"Stopped {name}'s dashboard (start it again from the new place: da dashboard).")
    renaming = not copy and am.same_drive(folder, new)
    console.print(f"Move {name} ({files:,} files, {total / 1e9:,.1f} GB)\n  from {folder}\n  to   {new}\n  "
                  + ("one rename on the same drive: quick." if renaming else
                     "copy, then check every file arrived" + (" (all re-read in full)" if full else "")
                     + "; the old copy stays until you say."))
    console.print("Close every DA window and File Explorer window in it first.")
    if not yes and not _interactive():
        console.print("Nothing moved. To move it: add --yes.")
        return
    if not yes and not Confirm.ask("Move it?", default=True):
        return
    try:
        record = am.move_archive(folder, new, copy=copy, full=full, say=lambda m: console.print(f"  {m}"))
    except am.MoveError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from None
    except OSError as exc:
        console.print(f"[red]Couldn't move it: {exc}[/red] (a file in it is open? Close DA and Explorer windows in "
                      "it.) Nothing was changed.")
        raise typer.Exit(1) from None
    console.print(f"Moved: {record['index_rows']:,} index rows and {record['run_files']:,} undo logs and run records "
                  f"now point at {new}; this PC's list of archives has the new place.")
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    if record["how"] == "copied":
        check = record["check"]
        console.print(f"  The copy is right: {check['files']:,} files, {check['rehashed']:,} re-read in full.")
        remove = remove_old or (not yes and _interactive() and Confirm.ask(
            f"Send the old copy ({folder}) to the Recycle Bin now?", default=False))
        if remove and ad.drive_has_recycle_bin(folder) and ad.to_recycle_bin(folder):
            console.print("  The old copy is in the Recycle Bin.")
        else:
            am.retire(folder, new)
            console.print(f"  The old copy is still at {folder}, no longer an archive (MOVED.txt says where it went). "
                          "Delete it in File Explorer when you're sure.")
    log_event("archive_move", f"moved {folder} -> {new} ({record['how']}, {record['files']} files)",
              path=str(new))
    console.print(f"Open it: double-click {new / LAUNCHER}, or da archives.")


def _archive_label(folder: Path) -> tuple[str, str]:
    import yaml  # pylint: disable=import-outside-toplevel

    try:
        data = yaml.safe_load((folder / "da-archive.yaml").read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        return folder.name, "?"
    archive = data.get("archive") or {}
    return str(archive.get("name") or folder.name), str(archive.get("years") or "any")


PYTHON_REQUIREMENTS_URL = "https://da.gamenightbymike.com/python/requirements.txt"
DA_EXE_URL = "https://github.com/devmukmuk/DA/releases/latest/download/DA.exe"
PYTHON_LAUNCHER = """\
@echo off
rem DA, run by Python ({python}). Made by `da install`. Python is signed, so Windows'
rem Smart App Control runs it even where it blocks the DA.exe download.
"{python}" -m mindit %*
exit /b %ERRORLEVEL%
"""


def install() -> None:
    """Put DA in C:\\Scripts\\DA and on your PATH, so `da` works in any new terminal (and every Open DA.cmd)."""
    from mindit.services.workflow.archive_setup import refresh_launchers  # pylint: disable=import-outside-toplevel

    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    exe = exe_path()
    if exe is not None:                                       # the DA.exe
        target = INSTALL_DIR / "DA.exe"
        if exe != target.resolve():
            shutil.copy2(exe, target)
        _set_aside(INSTALL_DIR / "da.cmd")                    # one DA at a time: the exe now
        installed = f"{target}"
    else:                                                     # DA run by Python
        launcher = INSTALL_DIR / "da.cmd"
        launcher.write_text(PYTHON_LAUNCHER.format(python=Path(sys.executable).resolve()), encoding="utf-8",
                            newline="\r\n")
        # `da` would find DA.exe before da.cmd (Windows tries .exe first), and Smart App Control may block it.
        _set_aside(INSTALL_DIR / "DA.exe")
        installed = f"{launcher} (DA run by Python {sys.version.split()[0]})"
    added = _add_to_user_path(INSTALL_DIR)
    refreshed = refresh_launchers(known_archives())
    console.print(f"Installed {installed}" + (" and added it to your PATH." if added else " (already on your PATH)."))
    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("install", f"da install: DA v{__version__} at {installed}", path=str(INSTALL_DIR))
    if refreshed:
        console.print(f"Updated Open DA.cmd in {len(refreshed)} archive{'s' if len(refreshed) != 1 else ''}.")
    console.print("New terminal windows know `da` from now on. In THIS window, run first:")
    console.print(f"    $env:Path += ';{INSTALL_DIR}'      (PowerShell)    or    set PATH=%PATH%;{INSTALL_DIR}   (cmd)")
    console.print("VS Code's terminals need VS Code restarted. Archives' Open DA.cmd files work either way.")
    _offer_long_paths()


def _offer_long_paths() -> None:
    """Say whether Windows lets DA use paths of 260 characters or more, and offer to turn that on."""
    from mindit.core import long_paths  # pylint: disable=import-outside-toplevel

    if long_paths.enabled():
        console.print("Long paths: on (folders nested deep in intake can be moved).")
        return
    console.print("[yellow]Long paths are off on this PC.[/yellow] Windows then refuses paths of 260 characters "
                  "or more, which deep folders in intake (and their copies in _duplicates-holding) can reach; "
                  "DA skips those files and says so.")
    if _interactive() and Confirm.ask("Turn long paths on now? (Windows asks for permission)", default=True):
        if long_paths.enable():
            console.print("Long paths: on. Open a new DA window for it to take effect.")
            return
        console.print("[red]Long paths are still off[/red] (permission not given?).")
    console.print("To turn them on later: run  da install  again, or in PowerShell as Administrator:")
    console.print(f"    {long_paths.COMMAND}")


def _set_aside(path: Path) -> None:
    """Rename the other kind of DA (path -> path.off), so `da` and Open DA.cmd use the one just installed."""
    if path.exists():
        off = path.with_name(path.name + ".off")
        off.unlink(missing_ok=True)
        path.rename(off)
        console.print(f"Set aside {path.name} (now {off.name}).")


def update(
    check: bool = typer.Option(False, "--check", help="Only say whether a newer DA is out."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Update DA to the newest version: looks for it, downloads and checks it, and puts it in place."""
    import subprocess  # pylint: disable=import-outside-toplevel

    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import updater as up  # pylint: disable=import-outside-toplevel

    console.print(f"This is DA v{__version__}. Looking for a newer one ...")
    try:
        latest = up.latest_release()
    except up.UpdateError as exc:
        console.print(f"[yellow]{exc}.[/yellow] Try again later, or download it: {DA_EXE_URL}")
        raise typer.Exit(1) from None
    if not up.newer(latest.version, __version__):
        console.print(f"You have the newest DA (v{latest.version}).")
        return
    console.print(f"DA v{latest.version} is out.")
    if check:
        console.print("To update: da update")
        return
    if not yes and _interactive() and not Confirm.ask(f"Update to v{latest.version} now?", default=True):
        return

    exe = exe_path()
    if exe is None:                                           # DA run by Python: pip updates it
        command = [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet", "-r", PYTHON_REQUIREMENTS_URL]
        console.print("Downloading and installing it ...")
        done = subprocess.run(command, check=False)
        if done.returncode != 0:
            console.print("[red]The update didn't finish.[/red] Close every DA window and run this in a new one:")
            console.print("    " + " ".join(f'"{c}"' if " " in c else c for c in command))
            raise typer.Exit(1)
        newest = subprocess.run([sys.executable, "-m", "mindit", "version"], capture_output=True, text=True,
                                check=False).stdout.strip() or f"DA v{latest.version}"
    else:                                                     # DA.exe: download, check, swap in
        installed = INSTALL_DIR / "DA.exe" if (INSTALL_DIR / "DA.exe").exists() else exe
        progress = ConsoleProgressReporter(console=console, update_every=10)
        progress.start(label="Downloading", total=max(1, latest.exe_size // (1 << 20)))
        last = [0]

        def advance(got: int, _total: int) -> None:
            while last[0] < got // (1 << 20):
                last[0] += 1
                progress.advance(current_item="")

        try:
            new = up.download(latest, INSTALL_DIR / "updates", progress=advance)
        except up.UpdateError as exc:
            console.print(f"[red]Not updated: {exc}.[/red]")
            raise typer.Exit(1) from None
        finally:
            progress.finish()
        console.print("Downloaded; its size and fingerprint match GitHub's. Checking it starts ...")
        try:
            up.check_runs(new, latest.version)
            up.put_in_place(new, installed)
        except (up.UpdateError, OSError) as exc:
            console.print(f"[red]Not updated: {exc}.[/red] DA v{__version__} is as it was.")
            raise typer.Exit(1) from None
        newest = f"DA v{latest.version}"
        console.print(f"Put in place: {installed}")
        console.print("  Windows already open (and the dashboard) still run the old DA until they're closed: "
                      "for the dashboard, da dashboard --stop, then da dashboard.")
    console.print(f"[green]Updated to {newest}[/green] (was v{__version__}). What's new: "
                  "https://github.com/devmukmuk/DA/blob/main/CHANGELOG.md")
    log_event("update", f"da update: {newest} (was v{__version__})")


def _add_to_user_path(folder: Path) -> bool:
    if sys.platform != "win32":
        return False
    import ctypes  # pylint: disable=import-outside-toplevel
    import winreg  # pylint: disable=import-outside-toplevel

    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE) as key:
        try:
            current, kind = winreg.QueryValueEx(key, "Path")
        except FileNotFoundError:
            current, kind = "", winreg.REG_EXPAND_SZ
        parts = [p for p in current.split(";") if p]
        if any(os.path.normcase(p.rstrip("\\")) == os.path.normcase(str(folder)) for p in parts):
            return False
        winreg.SetValueEx(key, "Path", 0, kind, ";".join(parts + [str(folder)]))
    ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x001A, 0, "Environment", 0x0002, 5000, None)
    return True


# --------------------------------------------------------------------------- check / verify

def check(
    file: Path = typer.Argument(..., help="A set-aside plan (.csv) or a validate report (.json)."),
) -> None:
    """Check a set-aside plan (re-hash a sample) or a validate report (what would move, and any warnings)."""
    result = check_plan(file) if file.suffix.lower() == ".csv" else check_report(load_report(file))
    console.print_json(json.dumps(result, default=str))


def verify(
    report: Path = typer.Argument(..., help="A validate report from a repair run."),
    full: bool = typer.Option(False, "--full", help="Re-read every file and compare its hash (slow on big runs)."),
) -> None:
    """Re-check every file a repair run moved: in place, gone from the source, unchanged (--full: every hash)."""
    console.print("Re-hashing every filed file and comparing it with its sidecar ..." if full else
                  "Checking every filed file (place, size, date) and re-hashing a sample ...")
    result = verify_report(load_report(report), progress=lambda m: console.print(f"  {m}"), full=full)
    console.print_json(json.dumps(result, default=str))
    if not result["ok"]:
        raise typer.Exit(1)
