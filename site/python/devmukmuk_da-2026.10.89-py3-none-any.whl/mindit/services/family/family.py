# src/mindit/services/family/family.py

"""The family: where the household lived when, and everyone's birthday (docs/da-docs/FAMILY-DESIGN.md, phase 1).

One shared folder (da-archive.yaml `family:`) holds three CSV files:

    houses.csv   Date (or from), to, address, city, state, zip - a blank "to" = still there; #yrs etc. ignored
    people.csv   name (or people), birthday, also_known_as ("Jane Doe; Jane D": the names faces carry); birthdays.csv too
    members.csv  optional: name, from, to - when someone lived with the household; without it, everyone born before a
                 move-out counts as living in that house

Dates: m/d/yyyy, m/d/yy (a two-digit year that would be in the future means the 1900s) or yyyy-mm-dd. Moving day
itself doesn't count as living in a house. Houses with the same dates (a mission with several cities) are on purpose.
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

HOUSES = "houses.csv"
PEOPLE = ("people.csv", "birthdays.csv")
MEMBERS = "members.csv"


class FamilyError(Exception):
    """The family folder or one of its files can't be used."""


def parse_date(text: str, today: date | None = None) -> date | None:
    """Return the date in text (blank = None); raise ValueError when it isn't one."""
    text = (text or "").strip()
    if not text:
        return None
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d"):
        try:
            day = datetime.strptime(text, fmt).date()
        except ValueError:
            continue
        if fmt == "%m/%d/%y" and day > (today or date.today()):      # 37 -> 1937, not 2037
            day = day.replace(year=day.year - 100)
        return day
    raise ValueError(f"not a date: {text!r}")


def age_on(born: date, day: date) -> int:
    """Return whole years of age on day."""
    return day.year - born.year - ((day.month, day.day) < (born.month, born.day))


def name_key(name: str) -> str:
    """Return a name as it's compared: case and spacing ignored."""
    return re.sub(r"\s+", " ", (name or "").strip()).casefold()


@dataclass
class House:
    """One place the household lived; end None = still there."""
    start: date
    end: date | None
    address: str
    place: str
    line: int = 0

    def last_day(self, today: date) -> date:
        """Return the move-out day, or today while still there."""
        return self.end or today

    def label(self) -> str:
        """Return '40 Oak Lane, Riverton, UT 84065'."""
        return ", ".join(p for p in (self.address, self.place) if p)


@dataclass
class Person:
    """Someone whose age shows: the name used, the birthday, the other names faces carry."""
    name: str
    born: date | None
    also_known_as: list[str] = field(default_factory=list)
    line: int = 0


@dataclass
class Family:
    """The family folder's houses, people and stays (members.csv), plus what didn't parse."""
    folder: Path
    houses: list[House] = field(default_factory=list)
    people: list[Person] = field(default_factory=list)
    stays: dict[str, list[tuple[date, date]]] = field(default_factory=dict)
    files: list[Path] = field(default_factory=list)
    has_members: bool = False
    problems: list[str] = field(default_factory=list)

    def person(self, name: str) -> Person | None:
        """Return the person a face's name means (name or also_known_as, case and spacing ignored)."""
        key = name_key(name)
        for person in self.people:
            if key == name_key(person.name) or key in {name_key(a) for a in person.also_known_as}:
                return person
        return None

    def homes_on(self, day: date, today: date | None = None) -> list[House]:
        """Return the house(s) the household lived in on day (several only when their dates are the same)."""
        today = today or date.today()
        return [h for h in self.houses if h.start <= day < h.last_day(today) or (h.start == day == h.last_day(today))]

    def age(self, name: str, day: date) -> int | None:
        """Return the age of the person a name means on day (None: not known, or not born yet)."""
        person = self.person(name)
        if person is None or person.born is None or day < person.born:
            return None
        return age_on(person.born, day)


def _column(row: dict, *names: str) -> str:
    for name in names:
        for key, value in row.items():
            if key and key.strip().lower() == name:
                return value or ""
    return ""


def _rows(path: Path) -> list[tuple[int, dict]]:
    with path.open(newline="", encoding="utf-8-sig") as f:
        return [(n, row) for n, row in enumerate(csv.DictReader(f), 2) if any((v or "").strip() for v in row.values()
                                                                              if isinstance(v, str))]


def _date(text: str, where: str, problems: list[str], today: date) -> date | None:
    try:
        return parse_date(text, today)
    except ValueError as exc:
        problems.append(f"{where}: {exc}")
        return None


def read_family(folder: Path, today: date | None = None) -> Family:
    """Read the family folder; raise FamilyError when it or houses.csv / people.csv is missing."""
    today = today or date.today()
    folder = Path(folder)
    if not folder.is_dir():
        raise FamilyError(f"no family folder at {folder}")
    family = Family(folder)
    houses = folder / HOUSES
    people = next((folder / n for n in PEOPLE if (folder / n).exists()), None)
    if not houses.exists() or people is None:
        raise FamilyError(f"{folder} needs {HOUSES} and {PEOPLE[0]}")

    family.files.append(houses)
    for n, row in _rows(houses):
        where = f"{HOUSES} line {n}"
        moved_in = _column(row, "date", "from", "start", "moved_in")
        start = _date(moved_in, where, family.problems, today)
        end = _date(_column(row, "to", "end", "moved_out"), where, family.problems, today)
        if start is None:
            if not moved_in.strip():
                family.problems.append(f"{where}: no move-in date")
            continue
        if end is not None and end < start:
            family.problems.append(f"{where}: moved out ({end:%m/%d/%Y}) before moving in ({start:%m/%d/%Y})")
            continue
        city, state, zip_code = (_column(row, k).strip() for k in ("city", "state", "zip"))
        if state and city.endswith(f", {state}"):               # "Arecibo, PR" already says PR
            state = ""
        place = ", ".join(p for p in (city, " ".join(p for p in (state, zip_code) if p)) if p)
        family.houses.append(House(start, end, _column(row, "address").strip(), place, n))
    family.houses.sort(key=lambda h: (h.start, h.line))

    family.files.append(people)
    for n, row in _rows(people):
        name = _column(row, "name", "people", "person").strip()
        if not name:
            family.problems.append(f"{people.name} line {n}: no name")
            continue
        born = _date(_column(row, "birthday", "born"), f"{people.name} line {n}", family.problems, today)
        others = [a.strip() for a in re.split(r"[;|]", _column(row, "also_known_as", "aka")) if a.strip()]
        family.people.append(Person(name, born, others, n))

    members = folder / MEMBERS
    if members.exists():
        family.files.append(members)
        family.has_members = True
        for n, row in _rows(members):
            name = _column(row, "name", "people", "person").strip()
            where = f"{MEMBERS} line {n}"
            start = _date(_column(row, "from", "date", "start"), where, family.problems, today) or date.min
            end = _date(_column(row, "to", "end"), where, family.problems, today) or date.max
            person = family.person(name)
            if person is None:
                family.problems.append(f"{where}: {name!r} isn't in {people.name}")
                continue
            family.stays.setdefault(person.name, []).append((start, end))
    return family


def check(family: Family, today: date | None = None) -> list[str]:
    """Return what looks wrong besides unreadable lines: overlapping houses, names used twice, missing birthdays."""
    today = today or date.today()
    found: list[str] = []
    houses = family.houses
    for i, house in enumerate(houses):
        for later in houses[i + 1:]:
            same = (later.start, later.end) == (house.start, house.end)
            if not same and later.start < house.last_day(today):
                first, second = sorted((house.line, later.line))
                found.append(f"{HOUSES} lines {first} and {second} overlap: {house.address} until "
                             f"{house.last_day(today):%m/%d/%Y}, {later.address} from {later.start:%m/%d/%Y}")
    open_ended = [h for h in houses if h.end is None]
    if len({(h.start) for h in open_ended}) > 1:
        found.append(f"{HOUSES}: {len(open_ended)} houses have no move-out date (only the last one should)")
    seen: dict[str, str] = {}
    for person in family.people:
        for name in [person.name, *person.also_known_as]:
            key = name_key(name)
            if key in seen and seen[key] != person.name:
                found.append(f"the name {name!r} is used for both {seen[key]} and {person.name}")
            seen.setdefault(key, person.name)
        if person.born is None:
            found.append(f"{person.name} has no birthday (their name shows, without an age)")
    return found


def gaps(family: Family, today: date | None = None) -> list[tuple[date, date]]:
    """Return the stretches between one move-out and the next move-in."""
    today = today or date.today()
    result, last = [], None
    for house in family.houses:
        if last is not None and house.start > last:
            result.append((last, house.start))
        last = max(last or house.last_day(today), house.last_day(today))
    return result


@dataclass
class Resident:
    """Someone in a house: their days there and their ages."""
    name: str
    first: date
    last: date
    age_in: int
    age_out: int
    born_here: bool


def residents(family: Family, house: House, today: date | None = None) -> list[Resident]:
    """Return who lived in a house (born before move-out; with members.csv, only within its stretches), with their ages."""
    today = today or date.today()
    found = []
    end = house.last_day(today)
    for person in family.people:
        if person.born is None:
            continue
        for w_start, w_end in family.stays.get(person.name, []) if family.has_members else [(date.min, date.max)]:
            first = max(house.start, person.born, w_start)
            last = min(end, w_end)
            if first < last or (first == last and house.start == end):      # moving day alone isn't living there
                found.append(Resident(person.name, first, last, age_on(person.born, first), age_on(person.born, last),
                                      house.start < person.born <= end))
                break
    return found


def timeline_rows(family: Family, today: date | None = None) -> list[list[str]]:
    """Return the timeline as CSV rows (header first): a row per person per house."""
    today = today or date.today()
    rows = [["from", "to", "address", "place", "person", "age_min", "age_max", "born_here"]]
    for house in family.houses:
        for r in residents(family, house, today):
            rows.append([house.start.isoformat(), house.end.isoformat() if house.end else "", house.address,
                         house.place, r.name, str(r.age_in), str(r.age_out), "yes" if r.born_here else ""])
    return rows


def write_timeline(family: Family, path: Path, today: date | None = None) -> Path:
    """Write the timeline CSV to path."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(timeline_rows(family, today))
    return path
