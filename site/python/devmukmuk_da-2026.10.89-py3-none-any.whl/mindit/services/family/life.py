# src/mindit/services/family/life.py

"""A dated photo's place in the family's life: the home at the time, each named face's age, at home or away (phase 2).

Kept in the sidecar's `life` block, worked out again whenever the family files or the faces change (never by hand):

    "life": {"date": "1997-07-04", "home": "40 Oak Lane, Riverton, UT 84065", "home_from": "1996-08-01",
             "at_home": true, "ages": [{"name": "Jane Doe", "person": "jane", "age": 35}], "family_fp": "..."}

A date set by hand to a year or a month gives ages as a range (`age_min` / `age_max`) and a home only when one house
(or houses with the same dates) covers all of it; else `homes` lists the ones it could be. At home: the photo's GPS
within HOME_METRES of the home's own position (house-positions.csv in the family folder, from `da family --locate`
or typed in; a row where only the town was found isn't used).
"""

from __future__ import annotations

import calendar
import csv
import hashlib
import math
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

from mindit.services.family.family import Family, House, age_on

BLOCK = "life"
POSITIONS = "house-positions.csv"
HOME_METRES = 300


def family_fp(family: Family) -> str:
    """Return a short fingerprint of the family files (and house positions), so changed files mean new blocks."""
    digest = hashlib.sha256()
    for path in sorted([*family.files, family.folder / POSITIONS]):
        try:
            digest.update(path.name.encode() + b"\0" + path.read_bytes())
        except OSError:
            continue
    return digest.hexdigest()[:16]


# --------------------------------------------------------------------------- house positions

SOURCES = ("found", "you", "town", "missing")   # town / missing rows aren't used for at home or away
RETRY_WAITS = (5, 15, 30)                       # seconds to wait when the lookup service is busy (503)


@dataclass
class Spot:
    """One row of house-positions.csv: a home's position and where it came from."""
    latitude: float | None
    longitude: float | None
    source: str                      # found (by address), you (typed in), town (only the town found), missing
    town: str = ""                   # for a town row: the town's position, as a hint

    def usable(self) -> tuple[float, float] | None:
        """Return (lat, lon) when it's the house's own position (found or typed in), else None."""
        if self.source in ("found", "you") and self.latitude is not None and self.longitude is not None:
            return self.latitude, self.longitude
        return None


def _number(text: str | None) -> float | None:
    try:
        return float(text) if text and text.strip() else None
    except ValueError:
        return None


def read_spots(folder: Path) -> dict[str, Spot]:
    """Return every row of house-positions.csv by house label.

    A row with a position whose source isn't `found` was typed in (source `you`); rows from before the source column
    (all looked up, some only to the town) come back as `old`, to be looked up again.
    """
    path = Path(folder) / POSITIONS
    found: dict[str, Spot] = {}
    if not path.exists():
        return found
    with path.open(newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            label = (row.get("house") or "").strip()
            if not label:
                continue
            lat, lon = _number(row.get("latitude")), _number(row.get("longitude"))
            source = (row.get("source") or "").strip().lower()
            if "source" not in row:
                source = "old"
            elif lat is not None and lon is not None and source != "found":
                source = "you"
            elif source not in SOURCES:
                source = "missing"
            found[label] = Spot(lat, lon, source, (row.get("town") or "").strip())
    return found


def read_positions(folder: Path) -> dict[str, tuple[float, float]]:
    """Return {house label: (lat, lon)} for the homes whose own position is known (found or typed in)."""
    return {label: spot.usable() for label, spot in read_spots(folder).items() if spot.usable()}


def write_spots(folder: Path, spots: dict[str, Spot]) -> Path:
    """Write house-positions.csv (a town row keeps the town's position as a hint, its own position blank)."""
    path = Path(folder) / POSITIONS
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["house", "latitude", "longitude", "source", "town"])
        for label, spot in spots.items():
            writer.writerow([label, "" if spot.latitude is None else f"{spot.latitude:.6f}",
                             "" if spot.longitude is None else f"{spot.longitude:.6f}", spot.source, spot.town])
    tmp.replace(path)
    return path


def address_variants(house: House) -> list[str]:
    """Return what to ask the lookup for a house, best first: as written, then tidied (So -> South, #12 and Apt 12
    left out, no zip)."""
    import re  # pylint: disable=import-outside-toplevel

    address = re.sub(r"\s*(#|\b(apt|unit|suite|ste)\b\.?)\s*\w+$", "", house.address, flags=re.I).strip()
    tidy = re.sub(r"\b(so|no)\b\.?", lambda m: "South" if m.group(1).lower() == "so" else "North", address,
                  flags=re.I)
    town = re.sub(r"\s+\d{5}(-\d{4})?$", "", house.place).strip()
    out = [house.label()]
    for text in (f"{address}, {house.place}", f"{tidy}, {house.place}", f"{tidy}, {town}"):
        if address and text not in out:
            out.append(text)
    return out


def _ask(search: Callable[[str], Any], text: str, wait: Callable[[float], None],
         say: Callable[[str], None] | None) -> Any:
    """Ask the lookup, waiting and asking again while the service is busy; raise when it stays busy."""
    from mindit.services.location.places import LookupUnavailable  # pylint: disable=import-outside-toplevel

    for seconds in (*RETRY_WAITS, None):
        try:
            return search(text)
        except LookupUnavailable:
            if seconds is None:
                raise
            if say:
                say(f"the lookup service is busy; trying again in {seconds} s")
            wait(seconds)
    return None


def locate_houses(family: Family, search: Callable[[str], tuple[Any, float, float] | None], again: bool = False,
                  wait: Callable[[float], None] | None = None,
                  say: Callable[[str], None] | None = None) -> tuple[int, dict[str, str]]:
    """Look up each home's position (search = the geocoder's) and keep it in house-positions.csv, saved home by home.

    Rows found or typed in stay as they are; town / missing rows are asked again only with again. Return (homes
    looked up, {label: source} of the homes with no position of their own).
    """
    import time  # pylint: disable=import-outside-toplevel

    wait = wait or time.sleep
    spots = read_spots(family.folder)
    looked = 0
    for house in family.houses:
        label = house.label()
        old = spots.get(label)
        if old and (old.source in ("found", "you") or (old.source in ("town", "missing") and not again)):
            continue
        looked += 1
        spot = Spot(None, None, "missing")
        for text in address_variants(house):
            hit = _ask(search, text, wait, say)
            if hit:
                spot = Spot(hit[1], hit[2], "found")
                break
        if spot.source == "missing" and house.place:
            hit = _ask(search, house.place, wait, say)
            if hit:
                spot = Spot(None, None, "town", f"{hit[1]:.6f}, {hit[2]:.6f}")
        spots[label] = spot
        write_spots(family.folder, spots)            # saved as it goes: a stop loses nothing
    if not spots:
        write_spots(family.folder, spots)
    labels = {h.label() for h in family.houses}
    return looked, {label: s.source for label, s in spots.items() if label in labels and not s.usable()}


def metres(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Return the distance between two (lat, lon) positions in metres."""
    lat1, lon1, lat2, lon2 = map(math.radians, (*a, *b))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6_371_000 * math.asin(math.sqrt(h))


# --------------------------------------------------------------------------- a photo's dates

@dataclass(frozen=True)
class When:
    """A photo's date: one day, or the first and last day a year or month set by hand could be."""
    first: date
    last: date
    text: str                        # "1997-07-04", "1997-07", "1997"


def when_taken(sidecar: dict[str, Any]) -> When | None:
    """Return the photo's (or video's) date from its sidecar: set by hand (with its precision) first, else the camera's."""
    user = sidecar.get("user") if isinstance(sidecar.get("user"), dict) else {}
    if user.get("captured_at"):
        day = _day(user["captured_at"])
        if day:
            precision = user.get("date_precision")
            if precision == "year":
                return When(date(day.year, 1, 1), date(day.year, 12, 31), f"{day.year}")
            if precision == "month":
                last = calendar.monthrange(day.year, day.month)[1]
                return When(day.replace(day=1), day.replace(day=last), f"{day:%Y-%m}")
            return When(day, day, day.isoformat())
    for block, key in (("photoit", "captured_at"), ("camera", "date_taken"), ("video", "recorded_at")):
        value = sidecar.get(block).get(key) if isinstance(sidecar.get(block), dict) else None
        day = _day(value)
        if day:
            return When(day, day, day.isoformat())
    return None


def _day(value: Any) -> date | None:
    if not value:
        return None
    text = str(value).strip().replace(":", "-", 2) if str(value)[4:5] == ":" else str(value).strip()
    try:
        return datetime.fromisoformat(text[:19]).date()
    except ValueError:
        try:
            return date.fromisoformat(text[:10])
        except ValueError:
            return None


# --------------------------------------------------------------------------- the block

def _homes(family: Family, when: When, today: date) -> list[House]:
    """Return the house(s) the household lived in for all of when (several only with the same dates)."""
    first = family.homes_on(when.first, today)
    if when.first == when.last:
        return first
    last = family.homes_on(when.last, today)
    return first if first and [id(h) for h in first] == [id(h) for h in last] else []


def _could_be(family: Family, when: When, today: date) -> list[House]:
    return [h for h in family.houses if h.start <= when.last and h.last_day(today) > when.first]


def life_of(sidecar: dict[str, Any], family: Family, *, fp: str = "", positions=None,
            today: date | None = None) -> dict[str, Any] | None:
    """Return a photo's `life` block (None: no date, or nothing the family files say about it)."""
    from mindit.services.faces.faces import faces_of, people  # pylint: disable=import-outside-toplevel
    from mindit.services.location.places import position  # pylint: disable=import-outside-toplevel

    today = today or date.today()
    when = when_taken(sidecar)
    if when is None:
        return None
    block: dict[str, Any] = {"date": when.text}
    homes = _homes(family, when, today)
    if homes:
        block["home"] = homes[0].label() if len(homes) == 1 else "; ".join(h.label() for h in homes)
        block["home_from"] = homes[0].start.isoformat()
        spot = position(sidecar)
        spots = [(positions or {}).get(h.label()) for h in homes]
        if spot and any(spots):
            block["at_home"] = any(s and metres(spot, s) <= HOME_METRES for s in spots)
    else:
        could = _could_be(family, when, today)
        if could:
            block["homes"] = [h.label() for h in could]
    ages = []
    for name in people(faces_of(sidecar)):
        person = family.person(name)
        if person is None or person.born is None:
            continue
        if when.last < person.born:
            ages.append({"name": name, "person": person.name, "not_born": True})
            continue
        low, high = age_on(person.born, max(when.first, person.born)), age_on(person.born, when.last)
        ages.append({"name": name, "person": person.name, **({"age": low} if low == high else
                                                            {"age_min": low, "age_max": high})})
    if ages:
        block["ages"] = ages
    if len(block) == 1:
        return None
    block["family_fp"] = fp
    return block


def age_text(entry: dict[str, Any]) -> str:
    """Return an age as shown: '34', '6-7', or '' (not born yet / unknown)."""
    if "age" in entry:
        return str(entry["age"])
    if "age_min" in entry:
        return f"{entry['age_min']}-{entry['age_max']}"
    return ""


def describe(sidecar: dict[str, Any], *, home: bool = True) -> str:
    """Return a photo's life block as one line: 'Jane Doe 35, Sam 6 | 40 Oak Lane, Riverton (at home)'."""
    block = sidecar.get(BLOCK) if isinstance(sidecar.get(BLOCK), dict) else {}
    parts = []
    ages = ", ".join(f"{a['name']} {age_text(a)}" for a in block.get("ages") or [] if age_text(a))
    if ages:
        parts.append(ages)
    if home and block.get("home"):
        where = block["home"].split(",")[0] if "; " not in block["home"] else "one of " + str(
            len(block["home"].split("; "))) + " homes"
        if "at_home" in block:
            where += " (at home)" if block["at_home"] else " (away)"
        parts.append(where)
    return " | ".join(parts)


def labels(sidecar: dict[str, Any]) -> dict[str, str]:
    """Return {face name: 'Jane Doe (35)'} for the faces with an age, for face labels."""
    block = sidecar.get(BLOCK) if isinstance(sidecar.get(BLOCK), dict) else {}
    return {a["name"]: f"{a['name']} ({age_text(a)})" for a in block.get("ages") or [] if age_text(a)}


# --------------------------------------------------------------------------- writing

@dataclass
class LifeResult:
    """What a pass over sidecars did."""
    files: int = 0
    written: int = 0
    removed: int = 0


def load_family() -> tuple[Family | None, str, dict]:
    """Return the archive's family (None when `family:` isn't set or can't be read), its fingerprint and positions."""
    try:
        from mindit.config.settings import get_family_folder  # pylint: disable=import-outside-toplevel
        from mindit.services.family.family import read_family  # pylint: disable=import-outside-toplevel

        folder = get_family_folder()
        if folder is None:
            return None, "", {}
        family = read_family(folder)
    except Exception:  # pylint: disable=broad-except
        return None, "", {}
    return family, family_fp(family), read_positions(family.folder)


def update(data: dict[str, Any], family: Family, fp: str, positions: dict) -> bool:
    """Set or remove a loaded sidecar's life block; return True when it changed."""
    block = life_of(data, family, fp=fp, positions=positions)
    if block == data.get(BLOCK):
        return False
    if block is None:
        data.pop(BLOCK, None)
    else:
        data[BLOCK] = block
    return True


def write_life(paths: list[Path], family: Family | None = None, fp: str = "", positions: dict | None = None,
               progress: Callable[[int, int], None] | None = None) -> LifeResult:
    """Work out each photo's life block again and save the sidecars whose block changed."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    if family is None:
        family, fp, positions = load_family()
    result = LifeResult(files=len(paths))
    if family is None:
        return result
    for i, path in enumerate(paths, 1):
        if not Path(f"{path}.meta.json").exists():
            continue
        data = SidecarService.load(path)
        had = BLOCK in data
        if update(data, family, fp, positions or {}):
            SidecarService.save(path, data)
            if BLOCK in data:
                result.written += 1
            elif had:
                result.removed += 1
        if progress:
            progress(i, len(paths))
    return result
