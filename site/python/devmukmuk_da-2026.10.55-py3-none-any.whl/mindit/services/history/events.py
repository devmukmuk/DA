# src/mindit/services/history/events.py

"""DA's records gathered in one place: the `events` and `activity` tables in the archive's index.

- events: one row per file DA moved, renamed, copied or set aside - from the move logs in output\\runs (every
  set-aside, split, location folder, rename, OCR move, password set-aside, merge copy, Live Photo pairing) and the
  filing reports (validate repairs, da run's filing).
- activity: one row per thing a command did, from logs\\da.jsonl (with the computer that did it); an undo there
  marks the events of the log it undid.
Only new or grown records are read each time (`sources` remembers what was read). Design: HISTORY-DESIGN.md.
"""

from __future__ import annotations

import csv
import json
import os
import re
import sqlite3
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    at TEXT, command TEXT, action TEXT, source TEXT, destination TEXT, sha256 TEXT, kind TEXT,
    run TEXT, log TEXT, note TEXT, undone_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_source ON events(source COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_events_destination ON events(destination COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_events_sha ON events(sha256);
CREATE INDEX IF NOT EXISTS idx_events_at ON events(at);
CREATE TABLE IF NOT EXISTS activity (
    at TEXT, event TEXT, message TEXT, host TEXT, path TEXT, log TEXT, run TEXT, counts TEXT
);
CREATE INDEX IF NOT EXISTS idx_activity_at ON activity(at);
CREATE TABLE IF NOT EXISTS event_sources (path TEXT PRIMARY KEY, size INTEGER, mtime REAL, offset INTEGER);
"""

COMMANDS = {"run": "da run", "set-aside": "da intake set-aside", "split": "da split", "merge": "da merge",
            "location-group": "da location group", "rename": "da rename", "ocr": "da tag ocr",
            "passwords": "da find --passwords", "pair-movies": "da pair-movies", "sidecars": "da sidecar upgrade"}
ACTIONS = {"in_organized": "set aside (a copy of one filed)", "copy_in_intake": "set aside (a copy in intake)",
           "split": "moved to another archive", "location_folder": "moved into a location folder",
           "ocr_document": "moved to documents (OCR)", "secure_hold": "set aside (passwords)",
           "merge": "copied in (merge)", "live_photo_video": "paired with its photo"}
REPAIR_ACTIONS = {"move_file": "filed", "rename_file": "renamed", "move_raw_companion": "filed with its photo"}
SKIPPED_EVENTS = {"command", "menu"}
_RUN = re.compile(r"^(\d{8}-\d{6})-(.+)$")


def connect(db_path: Path) -> sqlite3.Connection:
    """Open the index with the history tables there."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    return conn


def kind_of(path: str) -> str:
    """Return photo, video, document, raw or other for a file name (documents by their folder too)."""
    from mindit.services.validateit.validateit_file_types import (  # pylint: disable=import-outside-toplevel
        DOCUMENT_EXTENSIONS, PHOTO_EXTENSIONS, RAW_EXTENSIONS, VIDEO_EXTENSIONS,
    )

    suffix = os.path.splitext(path)[1].lower()
    lowered = path.lower().replace("/", "\\")
    if suffix in RAW_EXTENSIONS:
        return "raw"
    if suffix in VIDEO_EXTENSIONS:
        return "video"
    if suffix in DOCUMENT_EXTENSIONS and (suffix not in PHOTO_EXTENSIONS or "\\documents\\" in lowered
                                          or "\\docs\\" in lowered or "\\scans\\" in lowered):
        return "document"
    return "photo" if suffix in PHOTO_EXTENSIONS else "other"


def _run_of(path: Path) -> tuple[str, str, str]:
    """Return (run folder name, when, command) for a file in output\\runs\\<ts>-<kind>\\."""
    for part in reversed(path.parts[:-1]):
        m = _RUN.match(part)
        if m:
            when = datetime.strptime(m.group(1), "%Y%m%d-%H%M%S").isoformat(timespec="seconds")
            return part, when, COMMANDS.get(m.group(2), f"da {m.group(2)}")
    return "", "", ""


def _unchanged(conn: sqlite3.Connection, path: Path) -> tuple[bool, int]:
    """Return (already read as it is, offset read up to) for a record file."""
    stat = path.stat()
    row = conn.execute("SELECT size, mtime, offset FROM event_sources WHERE path = ?", (str(path),)).fetchone()
    if row and row[0] == stat.st_size and abs((row[1] or 0) - stat.st_mtime) < 0.001:
        return True, row[2] or 0
    return False, (row[2] or 0) if row and stat.st_size > (row[0] or 0) else 0


def _remember(conn: sqlite3.Connection, path: Path, offset: int = 0) -> None:
    stat = path.stat()
    conn.execute("INSERT OR REPLACE INTO event_sources VALUES (?, ?, ?, ?)",
                 (str(path), stat.st_size, stat.st_mtime, offset))


def _read_move_log(conn: sqlite3.Connection, path: Path) -> int:
    """Add the moves in one move log (the CSV every DA move writes); return how many."""
    run, when, command = _run_of(path)
    if not when:
        when = datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds")
    conn.execute("DELETE FROM events WHERE log = ?", (str(path),))
    rows = []
    with path.open(encoding="utf-8-sig", newline="", errors="replace") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not {"result", "class", "source", "destination"} <= set(reader.fieldnames):
            return 0
        for r in reader:
            if r.get("result") not in ("moved", "copied"):
                continue
            action = ACTIONS.get(r.get("class") or "", r.get("class") or "moved")
            if r.get("class") == "rename":
                same = os.path.normcase(os.path.dirname(r["source"])) == os.path.normcase(os.path.dirname(r["destination"]))
                action = "renamed" if same else "moved (new folder pattern)"
            rows.append((when, command, action, r["source"], r["destination"], r.get("sha256") or None,
                         kind_of(r["destination"] or r["source"]), run, str(path), r.get("note") or "", None))
    conn.executemany("INSERT INTO events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", rows)
    return len(rows)


def _read_report(conn: sqlite3.Connection, path: Path) -> int:
    """Add the files a filing report (a validate repair) moved or renamed; a preview adds nothing."""
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    if report.get("mode") != "repair":
        return 0
    run, when, command = _run_of(path)
    when = when or str(report.get("checked_at") or "")
    command = command or "da validate --mode repair"              # output\validateit: a validate run by hand
    conn.execute("DELETE FROM events WHERE log = ?", (str(path),))
    rows = []
    for a in report.get("repair_actions", []):
        action = REPAIR_ACTIONS.get(a.get("action_type") or "")
        if not action or not a.get("executed") or not a.get("source_path") or not a.get("target_path"):
            continue
        rows.append((when, command, action, a["source_path"], a["target_path"], None, kind_of(a["target_path"]),
                     run, str(path), "", None))
    conn.executemany("INSERT INTO events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", rows)
    return len(rows)


def _read_log(conn: sqlite3.Connection, path: Path, offset: int) -> tuple[int, int]:
    """Add the activity lines of logs\\da.jsonl after offset; mark undone logs. Return (lines added, new offset)."""
    added = 0
    with path.open("rb") as f:
        f.seek(offset)
        data = f.read()
    end = data.rfind(b"\n") + 1                                   # a line still being written waits for next time
    for raw in data[:end].splitlines():
        try:
            line = json.loads(raw)
        except ValueError:
            continue
        event = line.get("event")
        if not event or event in SKIPPED_EVENTS:
            continue
        when = _local(line.get("ts") or "")
        conn.execute("INSERT INTO activity VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                     (when, event, line.get("message") or "", line.get("host") or "", line.get("path") or "",
                      line.get("log") or "", line.get("run") or "", json.dumps(line.get("counts") or {})))
        added += 1
        if event == "undo" and line.get("path"):
            conn.execute("UPDATE events SET undone_at = ? WHERE log = ? COLLATE NOCASE AND undone_at IS NULL",
                         (when, line["path"]))
    return added, offset + end


def _local(ts: str) -> str:
    """Return a log line's time (UTC in the file) as local time, to the second."""
    try:
        moment = datetime.fromisoformat(ts)
    except ValueError:
        return ts[:19]
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone().replace(tzinfo=None).isoformat(timespec="seconds")


def refresh(root: Path, db_path: Path, output_root: Path, log_path: Path,
            progress: Callable[[str], None] | None = None) -> Counter:
    """Read the records new since last time into the index; return how many of each were added."""
    stats: Counter = Counter()
    with connect(db_path) as conn:
        records: list[Path] = []
        for folder in (output_root / "runs", output_root / "validateit"):
            if folder.is_dir():
                records += sorted(p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in (".csv", ".json"))
        for path in records:
            if path.name.endswith("-plan.csv") or path.name in ("plan.csv", "summary.json", "move.json"):
                continue
            seen, _offset = _unchanged(conn, path)
            if seen:
                continue
            if path.suffix.lower() == ".csv":
                stats["moves"] += _read_move_log(conn, path)
            elif path.name.startswith("validateit-report"):
                if progress:
                    progress(f"reading {path.name} ...")
                stats["filed"] += _read_report(conn, path)
            _remember(conn, path)
        if log_path.exists():
            seen, offset = _unchanged(conn, log_path)
            if not seen:
                added, offset = _read_log(conn, log_path, offset)
                stats["activity"] += added
                _remember(conn, log_path, offset)
    return stats


def latest(db_path: Path, *, limit: int = 50, kind: str | None = None, since: str | None = None
           ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Return the newest activity lines and the newest file events (newest first)."""
    with connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        where, args = ["1 = 1"], []
        if since:
            where.append("at >= ?")
            args.append(since)
        activity = [dict(r) for r in conn.execute(
            f"SELECT * FROM activity WHERE {' AND '.join(where)} ORDER BY at DESC, rowid DESC LIMIT ?",  # noqa: S608
            (*args, limit))]
        if kind:
            where.append("kind = ?")
            args.append(kind)
        files = [dict(r) for r in conn.execute(
            f"SELECT * FROM events WHERE {' AND '.join(where)} ORDER BY at DESC, rowid DESC LIMIT ?",  # noqa: S608
            (*args, limit))]
    for row in activity:
        row["counts"] = json.loads(row.get("counts") or "{}")
    return activity, files


def save(out_dir: Path, activity: list[dict[str, Any]], files: list[dict[str, Any]], root: Path) -> tuple[Path, Path]:
    """Write history.csv (one row per line shown) and history.json (everything) into out_dir."""
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path, json_path = out_dir / "history.csv", out_dir / "history.json"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["type", "when", "what", "from", "to", "command", "computer", "run", "note"])
        for a in activity:
            writer.writerow(["activity", a["at"], a["message"], "", "", a["event"], a["host"], a.get("run") or "", ""])
        for e in files:
            writer.writerow(["file", e["at"], e["action"], shown(e["source"], root), shown(e["destination"], root),
                             e["command"], "", e["run"], ("undone " + e["undone_at"]) if e.get("undone_at") else e["note"]])
    json_path.write_text(json.dumps({"archive": str(root), "made_at": datetime.now().isoformat(timespec="seconds"),
                                     "activity": activity, "files": files}, indent=2, default=str), encoding="utf-8")
    return csv_path, json_path


def shown(path: str, root: Path) -> str:
    """Return path relative to the archive when it's inside it."""
    if not path:
        return ""
    try:
        return str(Path(path).relative_to(root))
    except ValueError:
        return path
