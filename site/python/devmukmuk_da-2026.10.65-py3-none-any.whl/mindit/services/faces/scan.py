"""`da facial scan`: find and describe the faces in photos not looked at yet, and take Picasa's names for them."""

from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from mindit.services.faces import store

PICASA_OVERLAP = 0.2                 # a found face and a Picasa box overlapping this much (IoU) are the same face
PHOTO_EXTENSIONS = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".tif", ".tiff", ".bmp", ".webp"}


@dataclass
class ScanResult:
    """What a scan did."""

    photos: int = 0
    faces: int = 0
    unreadable: int = 0
    picasa_names: int = 0


def overlap(a: tuple[float, ...], b: tuple[float, ...]) -> float:
    """Return how much two boxes overlap (intersection over union)."""
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - ix * iy
    return ix * iy / union if union > 0 else 0.0


def photos(db_path: Path, under: list[str] | None = None) -> list[dict[str, Any]]:
    """Return the filed photos (path, sha256) to look at, optionally only under some folders."""
    import sqlite3  # pylint: disable=import-outside-toplevel

    with sqlite3.connect(db_path) as conn:
        rows = [{"path": p, "sha256": s} for p, s in conn.execute(
            "SELECT path, sha256 FROM files WHERE area = 'photos' AND sha256 IS NOT NULL ORDER BY path")]
    rows = [r for r in rows if Path(r["path"]).suffix.lower() in PHOTO_EXTENSIONS]
    if under:
        rows = [r for r in rows if any(r["path"].lower().startswith(u.lower()) for u in under)]
    return rows


def scan(db_path: Path, rows: list[dict[str, Any]], engine: Any,
         progress: Callable[[int, int], None] | None = None) -> ScanResult:
    """Look at each photo not looked at yet (read in threads; the models run one photo at a time)."""
    from mindit.services.faces.engine import read_upright  # pylint: disable=import-outside-toplevel

    result = ScanResult()
    with store.connect(db_path) as conn:
        done = store.scanned(conn)
    todo = list({r["sha256"]: r for r in rows if r["sha256"] not in done}.values())
    with ThreadPoolExecutor(max_workers=4) as pool, store.connect(db_path) as conn:
        for i, (row, image) in enumerate(zip(todo, pool.map(lambda r: read_upright(Path(r["path"])), todo)), 1):
            result.photos += 1
            if image is None:
                result.unreadable += 1
                conn.execute("INSERT OR REPLACE INTO face_scans VALUES (?, 0, NULL)", (row["sha256"],))
            else:
                result.faces += store.add(conn, row["sha256"], engine.faces(image))
            if i % 50 == 0:
                conn.commit()
            if progress and (i % 25 == 0 or i == len(todo)):
                progress(i, len(todo))
    result.picasa_names = take_picasa_names(db_path, rows)
    return result


def take_picasa_names(db_path: Path, rows: list[dict[str, Any]]) -> int:
    """Give each found face the name Picasa gave the face it overlaps (the best overlap); return how many got one."""
    from mindit.services.faces.faces import picasa_faces  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    named = 0
    with store.connect(db_path) as conn:
        for row in rows:
            if not Path(f"{row['path']}.meta.json").exists():
                continue
            picasa = [f for f in picasa_faces(SidecarService.load(Path(row["path"]))) if f.name]
            if not picasa:
                continue
            found = conn.execute("SELECT id, box, status FROM faces WHERE sha256 = ?", (row["sha256"],)).fetchall()
            taken: set[int] = set()
            for face in picasa:
                best = max(found, key=lambda r: overlap(face.box, tuple(json.loads(r["box"]))), default=None)
                if best is None or best["id"] in taken or best["status"] == "confirmed":
                    continue
                if overlap(face.box, tuple(json.loads(best["box"]))) >= PICASA_OVERLAP:
                    taken.add(best["id"])
                    conn.execute("UPDATE faces SET name = ?, status = 'picasa', similarity = NULL WHERE id = ?",
                                 (face.name, best["id"]))
                    named += 1
    return named
