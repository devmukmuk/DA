# src/mindit/commands/run_steps.py

"""Process intake's steps after filing (8-12), each on only the folders just filed, and choosing them.

8 Camera owners (ask who used cameras DA hasn't seen), 9 Tags (automatic tags), 10 Places (look up GPS photos' places,
internet), 11 Location folders (group a month's GPS photos into folders you name), 12 Faces (da facial scan + suggest
on them; you confirm on the dashboard's People page). Owners come before tags so one tagging
pass gets the owner: tags right. 8 and 11 need a person: with --yes or no terminal they say what's waiting instead.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import typer
from rich.console import Console
from rich.prompt import Prompt

console = Console()


@dataclass(frozen=True)
class Step:
    """One step after filing."""

    number: int
    name: str
    title: str
    what: str


STEPS = (
    Step(8, "owners", "Camera owners", "ask who used cameras DA hasn't seen yet"),
    Step(9, "tags", "Tags", "automatic tags for the photos just filed"),
    Step(10, "places", "Places", "look up the places of GPS photos (internet, about one a second)"),
    Step(11, "groups", "Location folders", "group each month's GPS photos into folders you name"),
    Step(12, "faces", "Faces", "find the faces in the photos just filed and suggest names (da facial)"),
)
TOTAL = 12
DEFAULT = ("tags",)


def step_names(words: list[str] | None) -> list[str]:
    """Return the step names in words like 'places,groups' or '10 11' (numbers or names); unknown ones stop."""
    names = []
    for word in re.split(r"[,\s]+", " ".join(words or [])):
        if not word:
            continue
        found = next((s for s in STEPS if word.lower() in (s.name, str(s.number), s.title.lower())), None)
        if found is None:
            raise typer.BadParameter(f"{word!r} isn't a step DA can switch: "
                                     + ", ".join(f"{s.number} {s.name}" for s in STEPS))
        names.append(found.name)
    return names


def chosen(saved: list[str] | None, skip: list[str] | None = None, also: list[str] | None = None) -> list[str]:
    """Return the steps to run, in order: the saved choice (or the default), minus --skip, plus --with."""
    on = set(saved if saved is not None else DEFAULT)
    on -= set(step_names(skip))
    on |= set(step_names(also))
    return [s.name for s in STEPS if s.name in on]


def pick(on: list[str]) -> list[str] | None:
    """Ask which steps after filing to run (a toggle list); return them, or None to go back."""
    on = list(on)
    while True:
        console.print("\n  Always: 1-7  index, hash, duplicates, preview, check, file, refresh")
        console.print("  After filing (type a number to switch it on or off):")
        for s in STEPS:
            mark = "[green][x][/green]" if s.name in on else "[ ]"
            console.print(f"   {mark} {s.number:>2}  {s.title:<17} {s.what}")
        try:
            answer = Prompt.ask("  Enter = start, q = back", default="", show_default=False).strip().lower()
        except (EOFError, KeyboardInterrupt):
            return None
        if not answer:
            return [s.name for s in STEPS if s.name in on]
        if answer in ("q", "b", "back"):
            return None
        try:
            for name in step_names([answer]):
                if name in on:
                    on.remove(name)
                else:
                    on.append(name)
        except typer.BadParameter as exc:
            console.print(f"  [yellow]{exc}[/yellow]")


def after_filing(folders: list[Path], steps: list[str], *, interactive: bool, say: Callable[[str], None]
                 ) -> dict[str, Any]:
    """Run the chosen steps 8-11 on the folders just filed; return what each did (for the run's summary)."""
    done: dict[str, Any] = {}
    folders = sorted({Path(f) for f in folders if Path(f).is_dir()})
    for s in STEPS:
        label = f"{s.number}/{TOTAL} {s.title}"
        if s.name not in steps:
            say(f"{label}: skipped")
            done[s.name] = "skipped"
            continue
        if not folders:
            say(f"{label}: nothing was filed")
            done[s.name] = "nothing filed"
            continue
        try:
            done[s.name] = _STEP[s.name](folders, interactive, lambda m, label=label: say(f"{label}: {m}"))
        except typer.Exit:
            done[s.name] = "stopped"
        except Exception as exc:  # pylint: disable=broad-except
            say(f"{label}: [red]didn't finish: {exc}[/red]")
            done[s.name] = f"error: {exc}"
    return done


def _owners(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.commands.workflow_cli import _save_owners  # pylint: disable=import-outside-toplevel
    from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging import tags as tg  # pylint: disable=import-outside-toplevel

    seen = tg.cameras_seen(tg.files_under(folders, photos_only=True), load_settings().cameras)
    missing = [cam for cam in seen if not cam.owner]
    if not missing:
        say(f"all {len(seen):,} cameras' owners are known" if seen else "no camera details in these photos")
        return {"cameras": len(seen), "new": 0}
    if not interactive:
        say(f"{len(missing):,} cameras with no owner yet: " + ", ".join(c.key for c in missing[:4])
            + (" ..." if len(missing) > 4 else "") + " - name them: da tag --cameras")
        return {"cameras": len(seen), "new": len(missing), "asked": False}
    say("who used each camera? Type a name, or press Enter to skip.")
    names = {}
    for cam in missing:
        years = tg.camera_years(cam)
        try:
            answer = Prompt.ask(f"    {cam.key}  ({cam.photos:,} photos{', ' + years if years else ''})",
                                default="", show_default=False).strip()
        except (EOFError, KeyboardInterrupt):
            break
        if answer:
            names[cam.key] = answer
    if names:
        _save_owners(names)
    return {"cameras": len(seen), "new": len(missing), "named": len(names)}


def _tags(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.config.settings import load_settings, resolve_database_path  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging import tags as tg  # pylint: disable=import-outside-toplevel

    photos = tg.files_under(folders, photos_only=True)
    result = tg.tag_photos(photos, load_settings().cameras)          # owners saved in step 8 count already
    rows = tg.update_index(resolve_database_path(), result.changed)
    say(f"{result.files:,} photos tagged (camera details read from {result.read:,}; index updated: {rows:,})")
    return {"photos": result.files, "read": result.read}


def _places(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.commands.location_cli import lookup  # pylint: disable=import-outside-toplevel

    say("looking up the places of the GPS photos just filed ...")
    lookup(targets=folders, force=False, offline=False, yes=True)       # you switched this step on: no second ask
    return {"folders": len(folders)}


def _months(folders: list[Path]) -> list[str]:
    from mindit.services.location import places as pl  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel

    months = set()
    for folder in folders:
        month = re.search(r"(\d{4}-\d{2})", folder.name)
        if not month or month.group(1) in months:
            continue
        for photo in files_under([folder], photos_only=True):
            if Path(f"{photo}.meta.json").exists() and pl.position(SidecarService.load(photo)):
                months.add(month.group(1))
                break
    return sorted(months)


def _groups(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    months = _months(folders)
    if not months:
        say("no GPS photos filed, nothing to group")
        return {"months": 0}
    if not interactive:
        say(f"{len(months):,} months with GPS photos to put in location folders: "
            + ", ".join(months[:6]) + (" ..." if len(months) > 6 else "") + f" - da location group {months[0]}")
        return {"months": len(months), "asked": False}
    from mindit.commands.location_cli import group  # pylint: disable=import-outside-toplevel

    for month in months:
        say(f"{month}")
        try:
            group(month=Path(month), title=None, hours=6.0, km=2.0, yes=False)
        except typer.Exit:
            continue
    return {"months": len(months)}


def _faces(folders: list[Path], interactive: bool, say: Callable[[str], None]) -> dict[str, Any]:
    from mindit.config.settings import resolve_database_path  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import scan as sc  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import suggest as sg  # pylint: disable=import-outside-toplevel
    from mindit.services.faces.engine import EngineError, FaceEngine  # pylint: disable=import-outside-toplevel

    db_path = resolve_database_path()
    rows = sc.photos(db_path, [str(f.resolve()) for f in folders])
    try:
        engine = FaceEngine(say=say)
    except EngineError as exc:
        say(f"[yellow]{exc}[/yellow]")
        return {"error": str(exc)}
    result = sc.scan(db_path, rows, engine)
    counts = sg.suggest(db_path)
    say(f"{result.photos:,} photos looked at, {result.faces:,} faces ({result.picasa_names:,} with Picasa's names); "
        f"suggested: {counts['probably']:,} probably, {counts['maybe']:,} maybe - confirm them: da dashboard, People")
    return {"photos": result.photos, "faces": result.faces, **counts}


_STEP: dict[str, Callable[[list[Path], bool, Callable[[str], None]], Any]] = {
    "owners": _owners, "tags": _tags, "places": _places, "groups": _groups, "faces": _faces}


def save_choice(archive_file: Path, steps: list[str]) -> Path:
    """Write `run: after_filing: [...]` into da-archive.yaml (a text edit: everything else kept), check it; the backup."""
    import shutil  # pylint: disable=import-outside-toplevel

    import yaml  # pylint: disable=import-outside-toplevel

    text = archive_file.read_text(encoding="utf-8")
    block = ("run:\n  # Process intake's steps after filing, done each time: owners, tags, places, groups, faces.\n"
             f"  after_filing: [{', '.join(steps)}]\n")
    lines = text.splitlines(keepends=True)
    start = next((i for i, line in enumerate(lines) if re.match(r"^run:\s*(#.*)?$", line)), None)
    if start is None:
        new = text + ("" if text.endswith("\n") else "\n") + "\n" + block
    else:
        end = start + 1
        while end < len(lines) and (lines[end].startswith((" ", "\t")) or not lines[end].strip()):
            end += 1
        new = "".join(lines[:start]) + block + ("\n" if end < len(lines) else "") + "".join(lines[end:])
    backup = archive_file.with_name(archive_file.name + ".bak")
    shutil.copy2(archive_file, backup)
    archive_file.write_text(new, encoding="utf-8")
    try:
        loaded = yaml.safe_load(archive_file.read_text(encoding="utf-8")) or {}
        assert (loaded.get("run") or {}).get("after_filing") == steps
    except Exception as exc:  # pylint: disable=broad-except
        shutil.copy2(backup, archive_file)
        raise RuntimeError(f"Couldn't save the steps in {archive_file.name} (put back as it was): {exc}") from exc
    return backup
