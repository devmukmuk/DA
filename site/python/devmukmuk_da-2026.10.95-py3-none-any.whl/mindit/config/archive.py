# src/mindit/config/archive.py

"""Finding the archive DA works in, and the list of archives set up on this PC."""

from __future__ import annotations

import json
import os
import re
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from mindit.config.bootstrap import get_default_user_config_dir
from mindit.config.settings import ARCHIVE_FILE


def is_archive(folder: Path) -> bool:
    """Return True when folder holds a da-archive.yaml."""
    return (Path(folder) / ARCHIVE_FILE).is_file()


def find_archive(start: Path) -> Path | None:
    """Return the nearest folder at or above start that holds a da-archive.yaml, or None."""
    current = Path(start).resolve()
    for folder in (current, *current.parents):
        if is_archive(folder):
            return folder
    return None


def resolve_archive(cli_archive: str | None, cwd: Path, exe_dir: Path | None,
                    targets: list[Path] | tuple[Path, ...] = ()) -> Path | None:
    """Pick the archive: --archive, else a target folder's, else the current folder's, else the exe's."""
    if cli_archive:
        folder = Path(cli_archive).expanduser().resolve()
        if not is_archive(folder):
            raise SystemExit(f"No {ARCHIVE_FILE} in {folder}. Create one with:  da setup \"{folder}\"")
        return folder
    for target in targets:                     # `da validate D:\jane-archive-198x\intake\x` from anywhere
        found = find_archive(target)
        if found:
            return found
    found = find_archive(cwd)
    if found:
        return found
    if exe_dir is not None and is_archive(exe_dir):
        return exe_dir
    return None


# --------------------------------------------------------------------------- known archives

REGISTRY = "archives.json"
OLD_REGISTRY = "archives.txt"                  # one folder per line, before archives.json (2026-10-25)
_OWNER_IN_NAME = re.compile(r"^([A-Za-z]+)-archive\b")      # jane-archive-201x -> jane


def registry_path() -> Path:
    """Return the file listing the archives set up on this PC, with what's known about each."""
    return get_default_user_config_dir().parent / REGISTRY


def _key(folder: Path | str) -> str:
    return os.path.normcase(str(folder))


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def read_registry() -> list[dict[str, Any]]:
    """Return every archive on this PC's list, connected or not (made from archives.txt the first time)."""
    path = registry_path()
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return [e for e in data.get("archives") or [] if isinstance(e, dict) and e.get("path")]
        except (OSError, ValueError, AttributeError):
            os.replace(path, path.with_name(f"{REGISTRY}.bad-{datetime.now():%Y%m%d-%H%M%S}"))   # keep it to look at
    old = path.with_name(OLD_REGISTRY)
    if not old.exists():
        return []
    entries: list[dict[str, Any]] = []
    for line in old.read_text(encoding="utf-8").splitlines():
        folder = line.strip()
        if folder and _key(folder) not in {_key(e["path"]) for e in entries}:
            entries.append(new_entry(Path(folder)))
    try:
        write_registry(entries)
    except OSError:
        pass
    return entries


def write_registry(entries: list[dict[str, Any]]) -> None:
    """Save the list of archives (written beside it first, then swapped in)."""
    path = registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{REGISTRY}.{os.getpid()}.tmp")
    tmp.write_text(json.dumps({"schema": 1, "archives": entries}, indent=2, ensure_ascii=False) + "\n",
                   encoding="utf-8")
    os.replace(tmp, path)


def new_entry(folder: Path) -> dict[str, Any]:
    """Return a new list entry: where the archive is, and the computer and day it was made (its log's first line)."""
    from mindit.core.logging import HOST  # pylint: disable=import-outside-toplevel

    entry: dict[str, Any] = {"name": folder.name, "path": str(folder), "computer": HOST, "created": None,
                             "last_accessed": None}
    try:
        entry["created"] = datetime.fromtimestamp((folder / ARCHIVE_FILE).stat().st_ctime).isoformat(timespec="seconds")
    except OSError:
        pass
    first = _first_log_line(folder)
    if first.get("host"):
        entry["computer"] = first["host"]
    if first.get("ts"):
        try:
            logged = datetime.fromisoformat(first["ts"]).astimezone().replace(tzinfo=None).isoformat(timespec="seconds")
            entry["created"] = min(filter(None, (entry["created"], logged)))
        except ValueError:
            pass
    entry.update(yaml_details(folder))
    return entry


def _first_log_line(folder: Path) -> dict[str, Any]:
    try:
        with (folder / "logs" / "da.jsonl").open(encoding="utf-8") as f:
            line = json.loads(f.readline() or "{}")
        return line if isinstance(line, dict) else {}
    except (OSError, ValueError):
        return {}


def yaml_details(folder: Path) -> dict[str, Any]:
    """Return the name, years and owner da-archive.yaml gives (owner: archive.owner, else <owner>-archive-...)."""
    try:
        data = yaml.safe_load((Path(folder) / ARCHIVE_FILE).read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        return {}
    archive = (data.get("archive") or {}) if isinstance(data, dict) else {}
    name = str(archive.get("name") or Path(folder).name)
    found = _OWNER_IN_NAME.match(name) or _OWNER_IN_NAME.match(Path(folder).name)
    return {"name": name, "years": archive.get("years") or None,
            "owner": archive.get("owner") or (found[1].lower() if found else None),
            "home": str(archive.get("home") or "").strip().upper() or None}


# --------------------------------------------------------------------------- the archive's home PC

_ARCHIVE_SECTION = re.compile(r"^archive:\s*(#.*)?$")
_TOP_LEVEL = re.compile(r"^[^\s#]")
_HOME_LINE = re.compile(r"^\s+home:")
HOME_NOTE = "# the one PC that changes this archive (da archives home)"


def this_computer() -> str:
    """Return this PC's name, as archives' home: lines give it."""
    import socket  # pylint: disable=import-outside-toplevel

    return (os.environ.get("COMPUTERNAME") or socket.gethostname() or "?").upper()


def away_from_home(folder: Path) -> str | None:
    """Return the archive's home PC when this PC isn't it (None at home, or when no home is set)."""
    home = yaml_details(folder).get("home")
    return home if home and home != this_computer() else None


def away_message(home: str, what: str) -> str:
    """Return why `what` can't run here, and what can."""
    return (f"This archive's home is {home}; this PC is {this_computer()}. {what} changes the archive, so it runs "
            f"only on {home} (two copies changed apart can't be put back together).\n"
            "Looking works here: dashboard, history, find, share, report, status. "
            f"To make this PC its home instead: da archives home {this_computer()}")


def set_home(folder: Path, computer: str) -> Path:
    """Set archive.home in folder's da-archive.yaml as text (notes kept); return the backup of the old file."""
    archive_file = Path(folder) / ARCHIVE_FILE
    computer = computer.strip().upper()
    text = archive_file.read_text(encoding="utf-8")
    lines = text.splitlines()
    line = f"  home: {json.dumps(computer)}" + " " * max(1, 28 - len(computer)) + HOME_NOTE
    start = next((i for i, x in enumerate(lines) if _ARCHIVE_SECTION.match(x)), None)
    if start is None:
        lines[0:0] = ["archive:", line, ""]
    else:
        end = next((i for i in range(start + 1, len(lines)) if _TOP_LEVEL.match(lines[i])), len(lines))
        at = next((i for i in range(start + 1, end) if _HOME_LINE.match(lines[i])), None)
        if at is not None:
            lines[at] = line
        else:
            while end > start + 1 and not lines[end - 1].strip():
                end -= 1                                # keep the blank line before the next section
            lines.insert(end, line)

    backup = archive_file.with_name(f"{archive_file.name}.bak-{datetime.now():%Y%m%d-%H%M%S}")
    shutil.copy2(archive_file, backup)
    archive_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        before = yaml.safe_load(text) or {}
        after = yaml.safe_load(archive_file.read_text(encoding="utf-8")) or {}
        expected = {**before, "archive": {**(before.get("archive") or {}), "home": computer}}
        ok = after == expected
    except (yaml.YAMLError, AttributeError):
        ok = False
    if not ok:
        shutil.copy2(backup, archive_file)
        raise RuntimeError(f"Couldn't update {archive_file} safely; it's unchanged. Add  home: {computer}  "
                           "under archive: by hand.")
    return backup


def known_archives() -> list[Path]:
    """Return the registered archives that still exist, in the order they were added."""
    seen, out = set(), []
    for entry in read_registry():
        folder = Path(entry["path"])
        if _key(folder) not in seen and is_archive(folder):
            seen.add(_key(folder))
            out.append(folder)
    return out


def register_archive(folder: Path) -> None:
    """Add folder to the list of archives on this PC (once) and note that it was opened now."""
    folder = Path(folder).resolve()
    entries = read_registry()
    entry = next((e for e in entries if _key(e["path"]) == _key(folder)), None)
    if entry is None:
        entry = new_entry(folder)
        entries.append(entry)
    else:
        entry.update(yaml_details(folder))
    entry["last_accessed"] = _now()
    write_registry(entries)


def forget_archive(folder: Path) -> bool:
    """Take an archive off this PC's list; return True when it was on it."""
    entries = read_registry()
    key = _key(Path(folder).resolve())
    kept = [e for e in entries if _key(Path(e["path"]).resolve()) != key]
    if len(kept) != len(entries):
        write_registry(kept)
    return len(kept) != len(entries)


def move_in_registry(old: Path, new: Path) -> None:
    """Point the old place's entry (and what's known about it) at the new place."""
    entries = read_registry()
    for entry in entries:
        if _key(Path(entry["path"]).resolve()) == _key(Path(old).resolve()):
            entry["path"] = str(Path(new).resolve())
    write_registry(entries)
    register_archive(new)


def update_entry(folder: Path, details: dict[str, Any]) -> bool:
    """Add details to an archive already on the list; return False when it isn't on it."""
    entries = read_registry()
    for entry in entries:
        if _key(Path(entry["path"]).resolve()) == _key(Path(folder).resolve()):
            entry.update(details)
            write_registry(entries)
            return True
    return False


def entry_for(folder: Path) -> dict[str, Any] | None:
    """Return an archive's entry on this PC's list, or None."""
    key = _key(Path(folder).resolve())
    return next((e for e in read_registry() if _key(Path(e["path"]).resolve()) == key), None)
