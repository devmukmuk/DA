# src/mindit/services/history/events.py

"""DA's records gathered in one place: the `events` and `activity` tables in the archive's index.

- events: one row per file DA moved, renamed, copied or set aside - from the move logs in output\\runs (every
  set-aside, split, location folder, rename, OCR move, password set-aside, merge copy, Live Photo pairing) and the
  filing reports (validate repairs, da run's filing).
- activity: one row per thing a command did, from logs\\da.jsonl (with the computer that did it); an undo there
  marks the events of the log it undid.
Only new or grown records are read each time (`sources` remembers what was read). Design: HISTORY-DESIGN.md.
"""

from __future__ import annotations

import csv
import json
import os
import re
import sqlite3
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    at TEXT, command TEXT, action TEXT, source TEXT, destination TEXT, sha256 TEXT, kind TEXT,
    run TEXT, log TEXT, note TEXT, undone_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_events_source ON events(source COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_events_destination ON events(destination COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_events_sha ON events(sha256);
CREATE INDEX IF NOT EXISTS idx_events_at ON events(at);
CREATE TABLE IF NOT EXISTS activity (
    at TEXT, event TEXT, message TEXT, host TEXT, path TEXT, log TEXT, run TEXT, counts TEXT
);
CREATE INDEX IF NOT EXISTS idx_activity_at ON activity(at);
CREATE TABLE IF NOT EXISTS event_sources (path TEXT PRIMARY KEY, size INTEGER, mtime REAL, offset INTEGER);
"""

COMMANDS = {"run": "da run", "set-aside": "da intake set-aside", "split": "da split", "merge": "da merge",
            "location-group": "da location group", "rename": "da rename", "ocr": "da tag ocr",
            "passwords": "da find --passwords", "pair-movies": "da pair-movies", "sidecars": "da sidecar upgrade"}
ACTIONS = {"in_organized": "set aside (a copy of one filed)", "copy_in_intake": "set aside (a copy in intake)",
           "split": "moved to another archive", "location_folder": "moved into a location folder",
           "ocr_document": "moved to documents (OCR)", "secure_hold": "set aside (passwords)",
           "merge": "copied in (merge)", "live_photo_video": "paired with its photo",
           "resized_copy": "set aside (a resized copy)", "resaved_copy": "set aside (a re-saved copy)",
           "voice_note": "voice note put with its photo", "clock_sort": "sorted by camera clock"}
REPAIR_ACTIONS = {"move_file": "filed", "rename_file": "renamed", "move_raw_companion": "filed with its photo"}
SKIPPED_EVENTS = {"command", "menu"}
_RUN = re.compile(r"^(\d{8}-\d{6})-(.+)$")


def connect(db_path: Path) -> sqlite3.Connection:
    """Open the index with the history tables there."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    return conn


def _indexed(conn: sqlite3.Connection) -> bool:
    """Return whether the archive has been indexed (a files table), not just its history read."""
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'files'").fetchone() is not None


def kind_of(path: str) -> str:
    """Return photo, video, document, raw or other for a file name (documents by their folder too)."""
    from mindit.services.validateit.validateit_file_types import (  # pylint: disable=import-outside-toplevel
        DOCUMENT_EXTENSIONS, PHOTO_EXTENSIONS, RAW_EXTENSIONS, VIDEO_EXTENSIONS,
    )

    suffix = os.path.splitext(path)[1].lower()
    lowered = path.lower().replace("/", "\\")
    if suffix in RAW_EXTENSIONS:
        return "raw"
    if suffix in VIDEO_EXTENSIONS:
        return "video"
    if suffix in DOCUMENT_EXTENSIONS and (suffix not in PHOTO_EXTENSIONS or "\\documents\\" in lowered
                                          or "\\docs\\" in lowered or "\\scans\\" in lowered):
        return "document"
    return "photo" if suffix in PHOTO_EXTENSIONS else "other"


def _run_of(path: Path) -> tuple[str, str, str]:
    """Return (run folder name, when, command) for a file in output\\runs\\<ts>-<kind>\\."""
    for part in reversed(path.parts[:-1]):
        m = _RUN.match(part)
        if m:
            when = datetime.strptime(m.group(1), "%Y%m%d-%H%M%S").isoformat(timespec="seconds")
            return part, when, COMMANDS.get(m.group(2), f"da {m.group(2)}")
    return "", "", ""


def _unchanged(conn: sqlite3.Connection, path: Path) -> tuple[bool, int]:
    """Return (already read as it is, offset read up to) for a record file."""
    stat = path.stat()
    row = conn.execute("SELECT size, mtime, offset FROM event_sources WHERE path = ?", (str(path),)).fetchone()
    if row and row[0] == stat.st_size and abs((row[1] or 0) - stat.st_mtime) < 0.001:
        return True, row[2] or 0
    return False, (row[2] or 0) if row and stat.st_size > (row[0] or 0) else 0


def _remember(conn: sqlite3.Connection, path: Path, offset: int = 0) -> None:
    stat = path.stat()
    conn.execute("INSERT OR REPLACE INTO event_sources VALUES (?, ?, ?, ?)",
                 (str(path), stat.st_size, stat.st_mtime, offset))


def _read_move_log(conn: sqlite3.Connection, path: Path) -> int:
    """Add the moves in one move log (the CSV every DA move writes); return how many."""
    run, when, command = _run_of(path)
    if not when:
        when = datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds")
    conn.execute("DELETE FROM events WHERE log = ?", (str(path),))
    rows = []
    with path.open(encoding="utf-8-sig", newline="", errors="replace") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not {"result", "class", "source", "destination"} <= set(reader.fieldnames):
            return 0
        for r in reader:
            if r.get("result") not in ("moved", "copied"):
                continue
            action = ACTIONS.get(r.get("class") or "", r.get("class") or "moved")
            if r.get("class") == "rename":
                same = os.path.normcase(os.path.dirname(r["source"])) == os.path.normcase(os.path.dirname(r["destination"]))
                action = "renamed" if same else "moved (new folder pattern)"
            rows.append((when, command, action, r["source"], r["destination"], r.get("sha256") or None,
                         kind_of(r["destination"] or r["source"]), run, str(path), r.get("note") or "", None))
    conn.executemany("INSERT INTO events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", rows)
    return len(rows)


def _read_report(conn: sqlite3.Connection, path: Path) -> int:
    """Add the files a filing report (a validate repair) moved or renamed; a preview adds nothing."""
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    if report.get("mode") != "repair":
        return 0
    run, when, command = _run_of(path)
    when = when or str(report.get("checked_at") or "")
    command = command or "da validate --mode repair"              # output\validateit: a validate run by hand
    conn.execute("DELETE FROM events WHERE log = ?", (str(path),))
    rows = []
    for a in report.get("repair_actions", []):
        action = REPAIR_ACTIONS.get(a.get("action_type") or "")
        if not action or not a.get("executed") or not a.get("source_path") or not a.get("target_path"):
            continue
        rows.append((when, command, action, a["source_path"], a["target_path"], None, kind_of(a["target_path"]),
                     run, str(path), "", None))
    conn.executemany("INSERT INTO events VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", rows)
    return len(rows)


def _read_log(conn: sqlite3.Connection, path: Path, offset: int) -> tuple[int, int]:
    """Add the activity lines of logs\\da.jsonl after offset; mark undone logs. Return (lines added, new offset)."""
    added = 0
    with path.open("rb") as f:
        f.seek(offset)
        data = f.read()
    end = data.rfind(b"\n") + 1                                   # a line still being written waits for next time
    for raw in data[:end].splitlines():
        try:
            line = json.loads(raw)
        except ValueError:
            continue
        event = line.get("event")
        if not event or event in SKIPPED_EVENTS:
            continue
        when = _local(line.get("ts") or "")
        conn.execute("INSERT INTO activity VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                     (when, event, line.get("message") or "", line.get("host") or "", line.get("path") or "",
                      line.get("log") or "", line.get("run") or "", json.dumps(line.get("counts") or {})))
        added += 1
        if event == "undo" and line.get("path"):
            conn.execute("UPDATE events SET undone_at = ? WHERE log = ? COLLATE NOCASE AND undone_at IS NULL",
                         (when, line["path"]))
    return added, offset + end


def _local(ts: str) -> str:
    """Return a log line's time (UTC in the file) as local time, to the second."""
    try:
        moment = datetime.fromisoformat(ts)
    except ValueError:
        return ts[:19]
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.astimezone().replace(tzinfo=None).isoformat(timespec="seconds")


def refresh(root: Path, db_path: Path, output_root: Path, log_path: Path,
            progress: Callable[[str], None] | None = None) -> Counter:
    """Read the records new since last time into the index; return how many of each were added."""
    stats: Counter = Counter()
    with connect(db_path) as conn:
        records: list[Path] = []
        for folder in (output_root / "runs", output_root / "validateit"):
            if folder.is_dir():
                records += sorted(p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in (".csv", ".json"))
        for path in records:
            if path.name.endswith("-plan.csv") or path.name in ("plan.csv", "summary.json", "move.json"):
                continue
            seen, _offset = _unchanged(conn, path)
            if seen:
                continue
            if path.suffix.lower() == ".csv":
                stats["moves"] += _read_move_log(conn, path)
            elif path.name.startswith("validateit-report"):
                if progress:
                    progress(f"reading {path.name} ...")
                stats["filed"] += _read_report(conn, path)
            _remember(conn, path)
        if log_path.exists():
            seen, offset = _unchanged(conn, log_path)
            if not seen:
                added, offset = _read_log(conn, log_path, offset)
                stats["activity"] += added
                _remember(conn, log_path, offset)
    return stats


def latest(db_path: Path, *, limit: int = 50, kind: str | None = None, since: str | None = None
           ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Return the newest activity lines and the newest file events (newest first)."""
    with connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        where, args = ["1 = 1"], []
        if since:
            where.append("at >= ?")
            args.append(since)
        activity = [dict(r) for r in conn.execute(
            f"SELECT * FROM activity WHERE {' AND '.join(where)} ORDER BY at DESC, rowid DESC LIMIT ?",  # noqa: S608
            (*args, limit))]
        if kind:
            where.append("kind = ?")
            args.append(kind)
        files = [dict(r) for r in conn.execute(
            f"SELECT * FROM events WHERE {' AND '.join(where)} ORDER BY at DESC, rowid DESC LIMIT ?",  # noqa: S608
            (*args, limit))]
    for row in activity:
        row["counts"] = json.loads(row.get("counts") or "{}")
    return activity, files


def save(out_dir: Path, activity: list[dict[str, Any]], files: list[dict[str, Any]], root: Path) -> tuple[Path, Path]:
    """Write history.csv (one row per line shown) and history.json (everything) into out_dir."""
    out_dir.mkdir(parents=True, exist_ok=True)
    csv_path, json_path = out_dir / "history.csv", out_dir / "history.json"
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["type", "when", "what", "from", "to", "command", "computer", "run", "note"])
        for a in activity:
            writer.writerow(["activity", a["at"], a["message"], "", "", a["event"], a["host"], a.get("run") or "", ""])
        for e in files:
            writer.writerow(["file", e["at"], e["action"], shown(e["source"], root), shown(e["destination"], root),
                             e["command"], "", e["run"], ("undone " + e["undone_at"]) if e.get("undone_at") else e["note"]])
    json_path.write_text(json.dumps({"archive": str(root), "made_at": datetime.now().isoformat(timespec="seconds"),
                                     "activity": activity, "files": files}, indent=2, default=str), encoding="utf-8")
    return csv_path, json_path


def shown(path: str, root: Path) -> str:
    """Return path relative to the archive when it's inside it."""
    if not path:
        return ""
    try:
        return str(Path(path).relative_to(root))
    except ValueError:
        return path


# --------------------------------------------------------------------------- a file's story (phase 3)

def _rows(conn: sqlite3.Connection, sql: str, args: tuple) -> list[dict[str, Any]]:
    conn.row_factory = sqlite3.Row
    return [dict(r) for r in conn.execute(sql, args)]


def follow(conn: sqlite3.Connection, path: str) -> str:
    """Return where a file is now, following its moves on from an older path (renames, set-asides, splits)."""
    seen = {path.lower()}
    while True:
        row = conn.execute("SELECT destination FROM events WHERE source = ? COLLATE NOCASE AND undone_at IS NULL "
                           "ORDER BY at DESC, rowid DESC LIMIT 1", (path,)).fetchone()
        if not row or not row[0] or row[0].lower() in seen:
            return path
        path = row[0]
        seen.add(path.lower())


def find(db_path: Path, target: str | None = None, sha: str | None = None, limit: int = 20) -> list[dict[str, Any]]:
    """Return the files (index rows) a path, a name (now or before DA renamed it) or a hash start points at."""
    with connect(db_path) as conn:
        if not _indexed(conn):
            return []
        if sha:
            return _rows(conn, "SELECT * FROM files WHERE sha256 LIKE ? ORDER BY path LIMIT ?", (sha.lower() + "%", limit))
        if not target:
            return []
        resolved = str(Path(target).resolve()) if any(c in target for c in "\\/:") else ""
        candidates: list[str] = []
        if resolved:
            candidates.append(follow(conn, resolved))
        else:
            like = f"%{target}"
            candidates += [r[0] for r in conn.execute(
                "SELECT path FROM files WHERE file_name = ? COLLATE NOCASE OR source_path LIKE ? COLLATE NOCASE "
                "LIMIT ?", (target, like, limit))]
            candidates += [follow(conn, r[0]) for r in conn.execute(
                "SELECT DISTINCT source FROM events WHERE source LIKE ? COLLATE NOCASE LIMIT ?",
                (f"%{os.sep}{target}", limit))]
        out, seen = [], set()
        for path in candidates:
            if path.lower() in seen:
                continue
            seen.add(path.lower())
            rows = _rows(conn, "SELECT * FROM files WHERE path = ? COLLATE NOCASE", (path,))
            out += rows or [{"path": path, "file_name": Path(path).name, "missing": True}]
        return out[:limit]


def _like(text: str) -> str:
    """Return a LIKE pattern for a partial match; spaces, dashes and underscores match any of them."""
    return "%" + re.sub(r"[\s_-]+", "%", text.strip().replace("/", "\\")) + "%"


def search(db_path: Path, came_from: str | None = None, camera: str | None = None, name: str | None = None,
           kind: str | None = None) -> list[dict[str, Any]]:
    """Return the files (index rows) matching every part given, each a partial match, oldest taken first.

    came_from: a folder or name in where the file came from (its path before DA filed or moved it) or where it is now;
    camera: the camera that took it ("powershot", "iphone 12"); name: its file name now or before.
    """
    with connect(db_path) as conn:
        if not _indexed(conn):
            return []
        sets: list[set[str]] = []
        if came_from:
            like = _like(came_from)
            paths = {r[0] for r in conn.execute("SELECT path FROM files WHERE source_path LIKE ? OR path LIKE ?",
                                                (like, like))}
            paths |= {follow(conn, r[0]) for r in conn.execute("SELECT DISTINCT source FROM events WHERE source LIKE ?",
                                                                (like,))}
            sets.append(paths)
        if name:
            like, wanted = _like(name), re.sub(r"[\s_-]+", " ", name.strip().lower())

            def named(path: str | None) -> bool:
                return bool(path) and wanted in re.sub(r"[\s_-]+", " ", Path(path).name.lower())
            paths = {r[0] for r in conn.execute("SELECT path, source_path FROM files WHERE file_name LIKE ? OR "
                                                "source_path LIKE ?", (like, like)) if named(r[0]) or named(r[1])}
            paths |= {follow(conn, r[0]) for r in conn.execute("SELECT DISTINCT source FROM events WHERE source LIKE ?",
                                                                (like,)) if named(r[0])}
            sets.append(paths)
        if camera:
            has_camera = any(r[1] == "camera" for r in conn.execute("PRAGMA table_info(files)"))
            sets.append({r[0] for r in conn.execute("SELECT path FROM files WHERE camera LIKE ?", (_like(camera),))}
                        if has_camera else set())
        if not sets:
            return []
        wanted_paths = {p.lower() for p in set.intersection(*sets)}
        rows = [r for r in _rows(conn, "SELECT * FROM files", ()) if r["path"].lower() in wanted_paths]
    rows = [r for r in rows if not kind or r.get("media_type") == kind]
    return sorted(rows, key=lambda r: (r.get("captured_at") or "", r["path"]))


def cameras_indexed(db_path: Path) -> bool:
    """Return whether the index knows any file's camera (an index built before DA kept cameras doesn't)."""
    with connect(db_path) as conn:
        if not _indexed(conn) or not any(r[1] == "camera" for r in conn.execute("PRAGMA table_info(files)")):
            return False
        return conn.execute("SELECT 1 FROM files WHERE camera IS NOT NULL LIMIT 1").fetchone() is not None


def timeline(conn: sqlite3.Connection, path: str) -> list[dict[str, Any]]:
    """Return every event in a file's past, oldest first, followed back through its moves and renames."""
    found: dict[int, dict[str, Any]] = {}
    paths, todo = set(), [path]
    while todo and len(paths) < 200:
        current = todo.pop()
        if current.lower() in paths:
            continue
        paths.add(current.lower())
        for row in _rows(conn, "SELECT rowid AS id, * FROM events WHERE destination = ? COLLATE NOCASE "
                         "OR source = ? COLLATE NOCASE", (current, current)):
            found[row["id"]] = row
            for other in (row["source"], row["destination"]):
                if other and other.lower() not in paths:
                    todo.append(other)
    return sorted(found.values(), key=lambda r: (r["at"] or "", r["id"]))


def story(db_path: Path, row: dict[str, Any]) -> dict[str, Any]:
    """Return a file's story: what it is now (index + sidecar), where it came from, its past, its copies here."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    path = Path(row["path"])
    data = SidecarService.load(path) if Path(f"{path}.meta.json").exists() else {}
    user = data.get("user") if isinstance(data.get("user"), dict) else {}
    camera = data.get("camera") if isinstance(data.get("camera"), dict) else {}
    photoit = data.get("photoit") if isinstance(data.get("photoit"), dict) else {}
    file_block = data.get("file") if isinstance(data.get("file"), dict) else {}
    now = {k: row.get(k) for k in ("path", "file_name", "media_type", "size_bytes", "sha256", "captured_at", "area",
                                   "tags", "city", "state_code", "country_code", "title")}
    now["date_from"] = ("set by hand" + (f" ({user.get('date_note')})" if user.get("date_note") else "")
                        if user.get("captured_at") else "")
    if camera:
        from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel
        from mindit.services.tagging.tags import owner_for  # pylint: disable=import-outside-toplevel
        from mindit.services.naming.tokens import _cameras  # pylint: disable=import-outside-toplevel

        now["camera"] = camera_name(camera) or ""
        now["owner"] = owner_for(camera, _cameras()) or ""
    came_from = {"original_name": photoit.get("original_file_name") or "",
                 "original_path": file_block.get("source_path") or row.get("source_path") or ""}
    with connect(db_path) as conn:
        past = timeline(conn, str(path))
        copies = _rows(conn, "SELECT path, area FROM files WHERE sha256 = ? AND path <> ? COLLATE NOCASE ORDER BY area, path",
                       (row["sha256"], str(path))) if row.get("sha256") else []
    return {"now": now, "came_from": came_from, "timeline": past, "copies": copies, "missing": bool(row.get("missing"))}


def copies_elsewhere(sha: str, archives: list[Path], here: Path) -> list[dict[str, Any]]:
    """Return the files with this hash in the other archives on this PC (from their indexes)."""
    out = []
    for archive in archives:
        if os.path.normcase(str(Path(archive).resolve())) == os.path.normcase(str(Path(here).resolve())):
            continue
        db = Path(archive) / ".da" / "da.sqlite"
        if not db.exists() or not sha:
            continue
        with sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True) as conn:
            if not _indexed(conn):
                continue
            out += [{"archive": Path(archive).name, "path": p, "area": a}
                    for p, a in conn.execute("SELECT path, area FROM files WHERE sha256 = ?", (sha,))]
    return out


def duplicates(db_path: Path, limit: int = 0) -> list[dict[str, Any]]:
    """Return every copy in _duplicates-holding still there: when it was set aside, and the file it's a copy of."""
    with connect(db_path) as conn:
        held = _rows(conn, "SELECT at, destination, sha256, action, run, note FROM events WHERE action LIKE 'set aside (a%copy%' "
                     "AND undone_at IS NULL ORDER BY at DESC, rowid DESC", ())
        out, indexed = [], _indexed(conn)
        for h in held:
            if not h["destination"] or not Path(h["destination"]).exists():
                continue
            kept = conn.execute("SELECT path FROM files WHERE sha256 = ? AND area IN ('photos', 'documents', 'intake') "
                                "ORDER BY area = 'intake', path LIMIT 1", (h["sha256"],)).fetchone() if indexed and h["sha256"] else None
            from mindit.services.similar.resized import kept_of  # pylint: disable=import-outside-toplevel

            named = kept_of(h["note"])
            copy_of = follow(conn, named) if named else (kept[0] if kept else "")
            kind = "exact" if not named else ("resized" if h["note"].startswith("a resized") else "re-saved")
            out.append({"held": h["destination"], "set_aside": h["at"], "sha256": h["sha256"] or "",
                        "copy_of": copy_of, "run": h["run"], "kind": kind})
            if limit and len(out) >= limit:
                break
    return out
