# src/mindit/services/share/sheet.py

"""`da share`'s contact sheet: a first page with your note, then 6 big pictures a page with the date and place.

Pictures only (videos and documents are left out). Each picture is a JPEG up to 900 px, so a page is about half
a megabyte; a share too big for one email (Gmail takes 25 MB) is made as several PDFs, each with the note page.
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

COLS, ROWS = 2, 3
PICTURE_PX = 900
PART_BYTES = 18_000_000                  # under Gmail's 25 MB once attached (base64 adds a third)


@dataclass
class Picture:
    """One picture to share, made small, with its caption."""

    path: Path
    jpeg: bytes
    caption: str
    when: datetime | None


def pictures_in(folders: Iterable[Path]) -> tuple[list[Path], int]:
    """Return the photos in the folders (name order, so date order), and how many other files were left out."""
    from mindit.services.contactsheet.contact_sheet import IMAGE_EXTENSIONS, photos_in  # pylint: disable=import-outside-toplevel

    photos, left_out = [], 0
    for folder in folders:
        for path in photos_in(folder) if folder.is_dir() else [folder]:
            if path.suffix.lower() in IMAGE_EXTENSIONS:
                photos.append(path)
            else:
                left_out += 1
    return photos, left_out


def caption_of(path: Path) -> tuple[str, datetime | None]:
    """Return 'Sat 20 Apr 2019 - Springfield, IL' from the sidecar (the date the photo was taken, its place)."""
    from mindit.services.location.grouping import taken_at  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    data = SidecarService.load(path) if Path(f"{path}.meta.json").exists() else {}
    when = taken_at(data, path)
    block = data.get("location") if isinstance(data.get("location"), dict) else {}
    place = block.get("place") if isinstance(block.get("place"), dict) else {}
    town = place.get("city") or place.get("county") or ""
    region = (place.get("state_code") or place.get("state") or "") if (place.get("country_code") or "us") == "us" \
        else (place.get("country") or "")
    where = ", ".join(p for p in (town, region.upper() if len(region) == 2 else region) if p)
    text = " - ".join(p for p in ((f"{when:%a %d %b %Y}" if when else ""), where) if p)
    return text, when


def prepare(paths: list[Path], progress: Callable[[int, int], None] | None = None) -> list[Picture]:
    """Make each picture small (turned the right way up) and caption it; pictures that can't be read are dropped."""
    from mindit.services.contactsheet.contact_sheet import _small_copy  # pylint: disable=import-outside-toplevel

    out = []
    for i, path in enumerate(paths, 1):
        if progress:
            progress(i, len(paths))
        small = _small_copy(path, (PICTURE_PX, PICTURE_PX), preview=False)
        if small is None:
            continue
        caption, when = caption_of(path)
        out.append(Picture(path, small.getvalue(), caption, when))
    return out


def parts(pictures: list[Picture], limit: int = PART_BYTES) -> list[list[Picture]]:
    """Split the pictures into groups small enough to email (whole pages, in order)."""
    groups: list[list[Picture]] = [[]]
    size = 0
    for picture in pictures:
        if groups[-1] and size + len(picture.jpeg) > limit and len(groups[-1]) % (COLS * ROWS) == 0:
            groups.append([])
            size = 0
        groups[-1].append(picture)
        size += len(picture.jpeg)
    return [g for g in groups if g]


def _wrap(text: str, width: int) -> list[str]:
    lines = []
    for paragraph in text.splitlines() or [""]:
        words, line = paragraph.split(), ""
        for word in words:
            if len(line) + len(word) + 1 > width:
                lines.append(line)
                line = word
            else:
                line = f"{line} {word}".strip()
        lines.append(line)
    return lines


def make_pdf(pictures: list[Picture], target: Path, *, title: str, note: str = "", part: tuple[int, int] = (1, 1),
             folders: list[str] | None = None) -> Path:
    """Write one share PDF: the note page, then the pictures, 6 a page."""
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    width, height = letter
    margin = 36
    target.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(target), pagesize=letter)
    pdf.setTitle(title)
    dated = [p.when for p in pictures if p.when]

    y = height - 90
    pdf.setFont("Helvetica-Bold", 24)
    pdf.drawString(margin, y, title[:60])
    y -= 26
    pdf.setFont("Helvetica", 12)
    span = (f"{min(dated):%d %b %Y}" + (f" - {max(dated):%d %b %Y}" if max(dated).date() != min(dated).date() else "")
            if dated else "")
    line = f"{len(pictures):,} pictures" + (f", {span}" if span else "") + \
        (f"   (part {part[0]} of {part[1]})" if part[1] > 1 else "")
    pdf.drawString(margin, y, line)
    y -= 34
    pdf.setFont("Helvetica", 13)
    for text in _wrap(note, 80):
        pdf.drawString(margin, y, text)
        y -= 18
    if folders:
        y -= 10
        pdf.setFont("Helvetica", 9)
        pdf.setFillGray(0.4)
        for name in folders[:12]:
            pdf.drawString(margin, y, name[:110])
            y -= 12
        pdf.setFillGray(0)
    pdf.showPage()

    cell_w = (width - 2 * margin) / COLS
    cell_h = (height - 2 * margin) / ROWS
    for start in range(0, len(pictures), COLS * ROWS):
        for i, picture in enumerate(pictures[start:start + COLS * ROWS]):
            col, row = i % COLS, i // COLS
            x = margin + col * cell_w
            top = height - margin - row * cell_h
            box_w, box_h = cell_w - 12, cell_h - 30
            image = ImageReader(io.BytesIO(picture.jpeg))
            iw, ih = image.getSize()
            scale = min(box_w / iw, box_h / ih)
            dw, dh = iw * scale, ih * scale
            bottom = top - 6 - dh
            pdf.drawImage(image, x + 6 + (box_w - dw) / 2, bottom, dw, dh)
            pdf.setFont("Helvetica", 9)
            pdf.drawCentredString(x + cell_w / 2, bottom - 13, picture.caption[:70])     # right under it
        pdf.showPage()
    pdf.save()
    return target


def slug(text: str) -> str:
    """Return a file-name-friendly form of text."""
    return re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()[:50] or "share"
