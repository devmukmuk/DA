# src/mindit/services/dashboard/page.py

"""The dashboard's one HTML page (kept in Python so the exe and the wheel carry it without data files)."""

PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DA Dashboard</title>
<style>
:root {
  --bg: #f5f6f8; --card: #ffffff; --ink: #1d2330; --muted: #667085; --line: #e3e6eb;
  --accent: #2563eb; --accent-soft: #dbe7fe; --warn: #b45309; --warn-soft: #fef3c7; --ok: #15803d; --bad: #b91c1c;
}
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    --bg: #12151b; --card: #1b2029; --ink: #e6e9ef; --muted: #98a2b3; --line: #2b313c;
    --accent: #6ea0ff; --accent-soft: #1e2d4d; --warn: #f5b454; --warn-soft: #3a2c12; --ok: #4ade80; --bad: #f87171;
  }
}
* { box-sizing: border-box; }
body { margin: 0; background: var(--bg); color: var(--ink);
       font: 15px/1.45 "Segoe UI", system-ui, -apple-system, sans-serif; }
header { padding: 18px 16px 6px; max-width: 1180px; margin: 0 auto; display: flex; flex-wrap: wrap;
         gap: 6px 16px; align-items: baseline; }
header h1 { margin: 0; font-size: 22px; }
header .sub { color: var(--muted); font-size: 13px; overflow-wrap: anywhere; }
header .right { margin-left: auto; color: var(--muted); font-size: 13px; }
main { max-width: 1180px; margin: 0 auto; padding: 10px 16px 32px; display: grid; gap: 14px;
       grid-template-columns: repeat(auto-fit, minmax(min(330px, 100%), 1fr)); }
.card { background: var(--card); border: 1px solid var(--line); border-radius: 10px; padding: 14px 16px; min-width: 0; }
.card.wide { grid-column: 1 / -1; }
.card h2 { margin: 0 0 10px; font-size: 13px; text-transform: uppercase; letter-spacing: .06em; color: var(--muted); }
.big { font-size: 30px; font-weight: 600; line-height: 1.1; }
.note { color: var(--muted); font-size: 13px; }
.stats { display: flex; flex-wrap: wrap; gap: 8px 22px; margin-top: 6px; }
.stats div span { display: block; font-size: 12px; color: var(--muted); }
.stats div b { font-size: 18px; }
.bars { display: grid; gap: 5px; }
.bar { display: grid; grid-template-columns: minmax(80px, 40%) 1fr auto; gap: 8px; align-items: center; font-size: 13px; }
.bar .name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bar .track { height: 9px; background: var(--accent-soft); border-radius: 5px; overflow: hidden; }
.bar .fill { height: 100%; background: var(--accent); border-radius: 5px; }
.bar .n { font-variant-numeric: tabular-nums; color: var(--muted); }
table { width: 100%; border-collapse: collapse; font-size: 13px; }
td, th { text-align: left; padding: 5px 6px; border-bottom: 1px solid var(--line); vertical-align: top;
         overflow-wrap: anywhere; }
th { color: var(--muted); font-weight: 600; }
td.n { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
td.when { white-space: nowrap; color: var(--muted); }
.working { background: var(--warn-soft); color: var(--warn); border-radius: 8px; padding: 8px 10px; margin-bottom: 6px; }
.status-ok { color: var(--ok); } .status-bad { color: var(--bad); }
button { font: inherit; font-size: 13px; padding: 5px 12px; border-radius: 6px; border: 1px solid var(--line);
         background: var(--card); color: var(--ink); cursor: pointer; }
button:hover { border-color: var(--accent); }
.scroll { max-height: 330px; overflow: auto; }
.error { color: var(--bad); }
@media (max-width: 520px) { main { grid-template-columns: minmax(0, 1fr); } .big { font-size: 26px; }
  td.when { white-space: normal; } }

.pics-bar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; margin-bottom: 10px; }
.pics-bar select { font: inherit; padding: 4px 6px; border: 1px solid var(--line); border-radius: 6px;
                   background: var(--card); color: var(--ink); max-width: 100%; }
.pics { display: grid; gap: 8px; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); }
.pic { position: relative; aspect-ratio: 4 / 3; border-radius: 6px; overflow: hidden; cursor: pointer;
       background: var(--accent-soft); border: 1px solid var(--line); padding: 0; color: var(--ink); }
.pic img { width: 100%; height: 100%; object-fit: cover; display: block; }
.pic .kind { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
             font-size: 13px; color: var(--muted); text-align: center; padding: 6px; overflow-wrap: anywhere; }
.pic .cap { position: absolute; left: 0; right: 0; bottom: 0; font-size: 11px; padding: 2px 5px;
            background: rgba(0, 0, 0, .55); color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.pic:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; }
#viewer { position: fixed; inset: 0; background: rgba(0, 0, 0, .86); display: none; z-index: 10;
          flex-direction: column; align-items: center; justify-content: center; padding: 12px; gap: 10px; }
#viewer.open { display: flex; }
#viewer .stage { flex: 1; min-height: 0; width: 100%; display: flex; align-items: center; justify-content: center; }
#viewer .stage img, #viewer .stage video { max-width: 100%; max-height: 100%; object-fit: contain; }
#viewer .stage iframe { width: min(1000px, 100%); height: 100%; border: 0; background: #fff; }
#viewer .tools { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; justify-content: center; color: #fff; }
#viewer .tools button { font: inherit; padding: 6px 12px; border-radius: 6px; border: 1px solid #ffffff55;
                        background: #ffffff1a; color: #fff; cursor: pointer; }
#viewer .tools button:disabled { opacity: .45; cursor: default; }
#viewer .said { color: #fff; font-size: 13px; min-height: 1.2em; }
</style>
</head>
<body>
<header>
  <h1 id="name">DA</h1>
  <span class="sub" id="where"></span>
  <span class="right"><span id="updated">Loading...</span> &nbsp; <span id="offline" class="error"></span></span>
</header>
<main>
  <section class="card">
    <h2>Filed</h2>
    <div class="big" id="filed">-</div>
    <div class="stats" id="filed-stats"></div>
    <p class="note" id="index-note"></p>
  </section>
  <section class="card">
    <h2>Waiting in intake</h2>
    <div class="big" id="intake">-</div>
    <div class="bars" id="intake-bars" style="margin-top:10px"></div>
  </section>
  <section class="card">
    <h2>Needs review</h2>
    <div id="review"></div>
  </section>
  <section class="card">
    <h2>Happening now</h2>
    <div id="working"></div>
  </section>
  <section class="card">
    <h2>Latest runs</h2>
    <div class="scroll"><table id="runs"></table></div>
  </section>
  <section class="card">
    <h2>Activity</h2>
    <div class="scroll"><table id="activity"></table></div>
  </section>
  <section class="card wide">
    <h2>In the archive <button id="recount" style="float:right">Recount</button></h2>
    <div id="details-note" class="note"></div>
    <div style="display:grid;gap:18px;grid-template-columns:repeat(auto-fit,minmax(min(260px,100%),1fr));margin-top:8px">
      <div><b>By year</b><div class="bars scroll" id="years" style="margin-top:6px"></div></div>
      <div><b>Cameras</b><div class="bars" id="cameras" style="margin-top:6px"></div></div>
      <div><b>Places</b><div class="bars" id="places" style="margin-top:6px"></div></div>
    </div>
  </section>
  <section class="card wide">
    <h2>Pictures</h2>
    <div class="pics-bar">
      <label for="pick-folder" class="note">Show</label>
      <select id="pick-folder"><option value="">Latest filed</option></select>
      <span class="note" id="pics-note"></span>
    </div>
    <div class="pics" id="pics"></div>
  </section>
</main>
<div id="viewer" role="dialog" aria-modal="true" aria-label="Picture">
  <div class="stage" id="stage"></div>
  <div class="tools">
    <span id="viewer-name"></span>
    <button id="v-prev" title="Previous (left arrow)">&#8592;</button>
    <button id="v-next" title="Next (right arrow)">&#8594;</button>
    <button id="v-desktop">Set as desktop</button>
    <button id="v-folder">Open its folder</button>
    <button id="v-share" title="Email it to a share list (da share)">Share</button>
    <button id="v-close" title="Close (Esc)">Close</button>
  </div>
  <div class="said" id="viewer-said"></div>
</div>
<script>
(function () {
  "use strict";
  var REFRESH_SECONDS = 10;
  function $(id) { return document.getElementById(id); }
  function fmt(n) { return (n || 0).toLocaleString(); }
  function el(tag, text, cls) {
    var e = document.createElement(tag);
    if (text !== undefined && text !== null) e.textContent = text;
    if (cls) e.className = cls;
    return e;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
  function bars(node, rows, empty) {
    clear(node);
    if (!rows || !rows.length) { node.appendChild(el("div", empty || "Nothing yet.", "note")); return; }
    var top = Math.max.apply(null, rows.map(function (r) { return r[1]; })) || 1;
    rows.forEach(function (r) {
      var row = el("div", null, "bar"), track = el("div", null, "track"), fill = el("div", null, "fill");
      var name = el("span", r[0], "name"); name.title = r[0];
      fill.style.width = Math.max(2, Math.round(100 * r[1] / top)) + "%";
      track.appendChild(fill);
      row.appendChild(name); row.appendChild(track); row.appendChild(el("span", fmt(r[1]), "n"));
      node.appendChild(row);
    });
  }
  function table(node, head, rows) {
    clear(node);
    if (!rows.length) { var tr = el("tr"); tr.appendChild(el("td", "Nothing yet.", "note")); node.appendChild(tr); return; }
    var h = el("tr");
    head.forEach(function (t) { h.appendChild(el("th", t)); });
    node.appendChild(h);
    rows.forEach(function (cells) {
      var tr = el("tr");
      cells.forEach(function (c) { tr.appendChild(el("td", c[0], c[1])); });
      node.appendChild(tr);
    });
  }
  var KINDS = { photo: "photos", document: "documents", video: "videos", raw: "raw files", other: "other" };

  function show(s) {
    var a = s.archive, c = s.counts;
    document.title = "DA - " + a.name;
    $("name").textContent = "DA - " + a.name;
    $("where").textContent = a.folder + "   years: " + a.years + (a.version ? "   DA " + a.version : "");
    $("updated").textContent = "Updated " + s.updated.slice(11);

    var filed = c.filed || {}, total = 0;
    Object.keys(filed).forEach(function (k) { total += filed[k]; });
    $("filed").textContent = fmt(total) + " files";
    var stats = clear($("filed-stats"));
    ["photo", "document", "video", "raw", "other"].forEach(function (k) {
      if (!filed[k]) return;
      var d = el("div"); d.appendChild(el("span", KINDS[k])); d.appendChild(el("b", fmt(filed[k]))); stats.appendChild(d);
    });
    var size = el("div"); size.appendChild(el("span", "size")); size.appendChild(el("b", c.gigabytes + " GB"));
    stats.appendChild(size);
    $("index-note").textContent = c.error ? c.error : !c.indexed
      ? "Not indexed yet: choose 1 Process intake (or 5 Refresh index) in the menu."
      : "From the index, last refreshed " + (c.index_built || "?").replace("T", " ").slice(0, 16)
        + ". Menu 5 refreshes it.";

    $("intake").textContent = fmt(c.intake) + " files";
    bars($("intake-bars"), (c.intake_folders || []).slice(0, 12), c.indexed ? "Nothing waiting." : "Not indexed yet.");

    var rv = clear($("review"));
    if (!s.review.run) rv.appendChild(el("p", "No run yet.", "note"));
    else if (!s.review.rows.length) rv.appendChild(el("p", "Nothing left to review from the last run.", "note"));
    else {
      bars(rv, s.review.rows);
      rv.appendChild(el("p", "From the last run (" + (s.review.folder || "") + "). Menu 3 lists the files.", "note"));
    }

    var w = clear($("working"));
    if (!s.activity.working.length) w.appendChild(el("p", "Nothing running.", "note"));
    s.activity.working.forEach(function (j) {
      w.appendChild(el("div", j.command + " - started " + j.since + " (" + j.minutes + " min ago)", "working"));
    });

    table($("runs"), ["When", "What", ""], s.runs.map(function (r) {
      return [[r.when, "when"], [r.kind], [r.detail, "note"]];
    }));
    table($("activity"), ["When", "What"], s.activity.recent.map(function (e) {
      var cls = e.level === "ERROR" ? "status-bad" : (e.status === "ok" ? "" : "");
      return [[e.when, "when"], [e.message, cls]];
    }));

    var d = s.details, note = $("details-note");
    $("recount").disabled = !!s.counting;
    if (s.counting && !d) note.textContent = "Counting years, cameras and places (a minute on a very big archive) ...";
    else if (d && d.error) note.textContent = d.error;
    else if (d) {
      note.textContent = (s.counting ? "Recounting ... " : "Counted " + d.made_at + ". ") + d.places_sentence;
      bars($("years"), d.years || []);
      bars($("cameras"), d.cameras || [], "No camera details yet (da tag).");
      bars($("places"), d.places || [], "No places yet (da location lookup).");
    }
  }

  function refresh() {
    fetch("/api/status", { cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (s) { $("offline").textContent = ""; show(s); })
      .catch(function () { $("offline").textContent = "DA dashboard stopped (start it again with da dashboard)"; });
  }
  $("recount").addEventListener("click", function () {
    fetch("/api/recount", { cache: "no-store" }).then(refresh);
  });
  refresh();
  setInterval(refresh, REFRESH_SECONDS * 1000);

  // ----------------------------------------------------------------- pictures
  var TOKEN = "__DA_TOKEN__", shown = [], at = -1;
  function loadFolders() {
    fetch("/api/folders", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (rows) {
      var pick = $("pick-folder");
      rows.forEach(function (f) {
        var o = el("option", (f.area === "documents" ? "Documents " : "") + (f.folder || "(top)") + "  (" + fmt(f.count) + ")");
        o.value = f.area + "|" + f.folder;
        pick.appendChild(o);
      });
    });
  }
  function loadPictures() {
    var v = $("pick-folder").value, q = "";
    if (v) { var i = v.indexOf("|"); q = "?area=" + encodeURIComponent(v.slice(0, i)) + "&folder=" + encodeURIComponent(v.slice(i + 1)); }
    fetch("/api/pictures" + q, { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (rows) {
      shown = rows;
      var grid = clear($("pics"));
      $("pics-note").textContent = rows.length ? fmt(rows.length) + (v ? " in this folder" : " filed most recently") : "";
      if (!rows.length) { grid.appendChild(el("p", "Nothing filed yet.", "note")); return; }
      rows.forEach(function (p, n) {
        var b = el("button", null, "pic");
        b.title = p.name + (p.when ? "  " + p.when : "");
        b.appendChild(el("span", p.kind === "video" ? "\u25B6 video" : p.kind === "document" ? "document" : "", "kind"));
        if (p.kind !== "video") {
          var img = el("img"); img.loading = "lazy"; img.alt = p.name; img.src = "/thumb/" + p.id;
          img.onerror = function () { img.remove(); };
          b.appendChild(img);
        }
        b.appendChild(el("span", p.name, "cap"));
        b.addEventListener("click", function () { openAt(n); });
        grid.appendChild(b);
      });
    });
  }
  function openAt(n) {
    if (n < 0 || n >= shown.length) return;
    at = n;
    var p = shown[n], stage = clear($("stage")), src = "/file/" + p.id, lower = p.name.toLowerCase();
    if (p.kind === "video") { var v = el("video"); v.controls = true; v.autoplay = true; v.src = src; stage.appendChild(v); }
    else if (lower.slice(-4) === ".pdf") { var f = el("iframe"); f.src = src; f.title = p.name; stage.appendChild(f); }
    else if (/\.(docx?|xlsx?|pptx?|txt|rtf|csv)$/.test(lower)) { stage.appendChild(el("p", "No preview for " + p.name + ": use Open its folder.", "note")); }
    else { var i = el("img"); i.src = src; i.alt = p.name; stage.appendChild(i); }
    $("viewer-name").textContent = p.name + (p.when ? "  -  " + p.when : "");
    $("v-desktop").disabled = p.kind !== "photo";
    $("v-share").disabled = p.kind !== "photo";
    $("viewer-said").textContent = "";
    $("viewer").classList.add("open");
    $("v-close").focus();
  }
  function closeViewer() { $("viewer").classList.remove("open"); clear($("stage")); at = -1; }
  function act(action, extra) {
    if (at < 0) return;
    $("viewer-said").textContent = "...";
    var ask = { token: TOKEN, action: action, id: shown[at].id };
    if (extra) Object.keys(extra).forEach(function (k) { ask[k] = extra[k]; });
    fetch("/api/action", { method: "POST", headers: { "Content-Type": "application/json" },
                           body: JSON.stringify(ask) })
      .then(function (r) { return r.json(); })
      .then(function (r) { $("viewer-said").textContent = r.message || (r.ok ? "Done." : "Didn't work."); })
      .catch(function () { $("viewer-said").textContent = "The dashboard didn't answer."; });
  }
  $("pick-folder").addEventListener("change", loadPictures);
  $("v-close").addEventListener("click", closeViewer);
  $("v-prev").addEventListener("click", function () { openAt(at - 1); });
  $("v-next").addEventListener("click", function () { openAt(at + 1); });
  $("v-desktop").addEventListener("click", function () { act("desktop"); });
  $("v-folder").addEventListener("click", function () { act("folder"); });
  $("v-share").addEventListener("click", function () {
    fetch("/api/share-lists", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (names) {
      if (!names.length) { $("viewer-said").textContent = "No share lists yet: add them to da-archive.yaml (share: lists:)."; return; }
      var pick = names.length === 1 ? names[0] : window.prompt("Send it to which list? " + names.join(", "), names[0]);
      if (!pick) return;
      if (names.length === 1 && !window.confirm("Email this photo to " + pick + "?")) return;
      act("share", { list: pick });
    });
  });
  $("viewer").addEventListener("click", function (e) { if (e.target.id === "viewer" || e.target.id === "stage") closeViewer(); });
  document.addEventListener("keydown", function (e) {
    if (at < 0) return;
    if (e.key === "Escape") closeViewer();
    else if (e.key === "ArrowLeft") openAt(at - 1);
    else if (e.key === "ArrowRight") openAt(at + 1);
  });
  loadFolders();
  loadPictures();
})();
</script>
</body>
</html>
"""
