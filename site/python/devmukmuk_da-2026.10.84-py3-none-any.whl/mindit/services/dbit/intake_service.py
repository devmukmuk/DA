# src/mindit/services/dbit/intake_service.py

"""Intake workflow on top of the DA database: status, hash what could be a copy, set copies aside."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit.core.long_paths import TOO_LONG, too_long
from mindit.services.dbit.dbit_service import DbitService

SIDECAR_SUFFIX = ".meta.json"
PLAN_FIELDS = ["class", "source", "destination", "size_bytes", "sha256", "kept", "source_mtime", "note"]
LOG_FIELDS = ["result", "class", "source", "destination", "size_bytes", "sha256", "kept",
              "sidecar_source", "sidecar_destination", "note"]


@dataclass(frozen=True)
class Layout:
    """Where things are: the data root, the intake root, and where runs and set-asides go."""

    data_root: Path
    intake_root: Path
    output_root: Path

    @property
    def holding_root(self) -> Path:
        return self.data_root / "_duplicates-holding" / datetime.now().strftime("%Y-%m-%d")

    def run_dir(self, step: str) -> Path:
        """Return a new output/runs/<timestamp>-<step> folder for one run's records."""
        path = self.output_root / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-{step}"
        path.mkdir(parents=True, exist_ok=True)
        return path


def default_layout(settings: Any | None = None) -> Layout:
    """Return the layout from the active profile."""
    from mindit.config.settings import (  # pylint: disable=import-outside-toplevel
        get_data_root_path,
        load_settings,
        resolve_data_path,
    )

    loaded = settings or load_settings()
    return Layout(
        data_root=get_data_root_path(loaded),
        intake_root=resolve_data_path(loaded.paths.intake, loaded),
        output_root=resolve_data_path(loaded.paths.output, loaded),
    )


def folder_prefix(layout: Layout, folder: str | None) -> str:
    """Return the path prefix for an intake subfolder given relative to intake (or absolute)."""
    if not folder:
        return str(layout.intake_root) + os.sep
    path = Path(folder)
    if not path.is_absolute():
        path = layout.intake_root / path
    return str(path.resolve()) + os.sep


# --------------------------------------------------------------------------- status

def intake_status(db: DbitService, layout: Layout, depth: int = 2) -> list[dict[str, Any]]:
    """Return one row per intake folder (depth levels deep) with its progress through the workflow."""
    root = str(layout.intake_root) + os.sep
    db.initialize(log=False)
    with db.connect() as conn:
        organized = {r[0] for r in conn.execute(
            "SELECT DISTINCT sha256 FROM files WHERE area IN ('photos', 'documents') AND sha256 IS NOT NULL")}
        rows = conn.execute(
            "SELECT path, media_type, size_bytes, sha256 FROM files WHERE area = 'intake'").fetchall()

    seen_in_intake: Counter = Counter(r["sha256"] for r in rows if r["sha256"] and r["sha256"] not in organized)
    folders: dict[str, Counter] = defaultdict(Counter)
    for r in rows:
        rel = r["path"][len(root):] if r["path"].startswith(root) else r["path"]
        parts = rel.split(os.sep)[:-1]
        key = os.sep.join(parts[:depth]) or "(intake root)"
        f = folders[key]
        f["files"] += 1
        f["gb"] += r["size_bytes"] or 0
        f[r["media_type"]] += 1
        if r["sha256"]:
            f["hashed"] += 1
            if r["sha256"] in organized:
                f["in_organized"] += 1
            elif seen_in_intake[r["sha256"]] > 1:
                f["copies_in_intake"] += 1
    out = []
    for name, f in sorted(folders.items(), key=lambda kv: -kv[1]["files"]):
        out.append({
            "folder": name, "files": f["files"], "gb": round(f["gb"] / 1e9, 1),
            "photo": f["photo"], "raw": f["raw"], "document": f["document"], "video_other": f["video"] + f["other"],
            "hashed": f["hashed"], "in_organized": f["in_organized"], "copies_in_intake": f["copies_in_intake"],
        })
    return out


# --------------------------------------------------------------------------- hash

def hash_candidates(db: DbitService, prefix: str, progress: Callable[[str], None] | None = None) -> dict[str, Any]:
    """Hash intake files under prefix that could be copies: same size as an organized or another intake file.

    A file whose size matches nothing can't be a byte-identical copy, so it isn't read at all. Organized
    files with no recorded hash whose size matches one of those intake files are hashed too, since a copy
    of an unhashed organized file would otherwise go unnoticed.
    """
    start = time.time()
    db.initialize(log=False)
    with db.connect() as conn:
        organized_sizes = {r[0] for r in conn.execute(
            "SELECT DISTINCT size_bytes FROM files WHERE area IN ('photos', 'documents')")}
        intake_sizes = Counter(r[0] for r in conn.execute(
            "SELECT size_bytes FROM files WHERE area = 'intake'"))
        todo = [dict(r) for r in conn.execute(
            "SELECT path, size_bytes FROM files WHERE area = 'intake' AND sha256 IS NULL "
            "AND substr(path, 1, ?) = ? ORDER BY path", (len(prefix), prefix))]
        prefix_sizes = {r[0] for r in conn.execute(
            "SELECT DISTINCT size_bytes FROM files WHERE area = 'intake' AND substr(path, 1, ?) = ?",
            (len(prefix), prefix))}
        organized_gaps = [dict(r) for r in conn.execute(
            "SELECT path, size_bytes FROM files WHERE area IN ('photos', 'documents') AND sha256 IS NULL ORDER BY path")]

    candidates = [r for r in todo if r["size_bytes"] in organized_sizes or intake_sizes[r["size_bytes"]] > 1]
    organized_gaps = [r for r in organized_gaps if r["size_bytes"] in prefix_sizes]
    stats = Counter(unhashed=len(todo), candidates=len(candidates), organized_unhashed=len(organized_gaps))
    candidates = organized_gaps + candidates
    updates: list[tuple[str | None, str, str]] = []
    for i, r in enumerate(candidates, 1):
        try:
            sha = _sha256(Path(r["path"]))
            updates.append((sha, "computed", r["path"]))
            stats["hashed"] += 1
            stats["bytes"] += r["size_bytes"]
        except OSError:
            updates.append((None, "unreadable", r["path"]))
            stats["unreadable"] += 1
        if len(updates) >= 1000:
            _write_hashes(db, updates)
            updates.clear()
        if progress and i % 2000 == 0:
            progress(f"{i:,}/{len(candidates):,} hashed ({stats['bytes'] / 1e9:,.1f} GB, {time.time() - start:.0f}s)")
    _write_hashes(db, updates)
    stats["seconds"] = round(time.time() - start)
    db.log_event("intake_hash", json.dumps({"prefix": prefix, **stats}))
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("hash", f"fingerprinted {stats.get('hashed', 0):,} files that could be copies", path=prefix,
              hashed=stats.get("hashed", 0), unreadable=stats.get("unreadable", 0))
    return dict(stats)


def _write_hashes(db: DbitService, updates: list[tuple[str | None, str, str]]) -> None:
    if updates:
        with db.connect() as conn:
            conn.executemany("UPDATE files SET sha256 = ?, hash_status = ? WHERE path = ?", updates)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------- set aside

def plan_set_aside(db: DbitService, layout: Layout, prefix: str) -> list[dict[str, Any]]:
    """Plan moving intake copies under prefix into holding: copies of organized files, and extra intake copies.

    Among intake files with the same content and no organized copy, the first by path stays (to be filed).
    """
    holding = layout.holding_root
    db.initialize(log=False)
    with db.connect() as conn:
        organized = {}
        for r in conn.execute(
            "SELECT sha256, path FROM files WHERE area IN ('photos', 'documents') AND sha256 IS NOT NULL ORDER BY path"
        ):
            organized.setdefault(r["sha256"], r["path"])
        intake = [dict(r) for r in conn.execute(
            "SELECT path, size_bytes, sha256 FROM files WHERE area = 'intake' AND sha256 IS NOT NULL ORDER BY path")]

    first_in_intake: dict[str, str] = {}
    for r in intake:
        first_in_intake.setdefault(r["sha256"], r["path"])

    plan = []
    for r in intake:
        if not r["path"].startswith(prefix):
            continue
        if r["sha256"] in organized:
            cls, kept = "in_organized", organized[r["sha256"]]
        elif first_in_intake[r["sha256"]] != r["path"]:
            cls, kept = "copy_in_intake", first_in_intake[r["sha256"]]
        else:
            continue
        src = Path(r["path"])
        try:
            mtime = src.stat().st_mtime
        except OSError:
            continue
        plan.append({
            "class": cls, "source": r["path"],
            "destination": str(holding / src.relative_to(layout.data_root)),
            "size_bytes": r["size_bytes"], "sha256": r["sha256"], "kept": kept, "source_mtime": mtime,
        })
    return plan


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> Path:
    """Write rows to a CSV and return its path."""
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    return path


def apply_set_aside(db: DbitService, plan: list[dict[str, Any]], log_path: Path) -> Counter:
    """Move each planned file (and sidecar) into holding after re-checking it; log every row; update the db."""
    stats: Counter = Counter()
    moved_rows: list[tuple[str, str]] = []
    try:
        with log_path.open("w", newline="", encoding="utf-8") as f:
            log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
            log.writeheader()
            for p in plan:
                src, dst = Path(p["source"]), Path(p["destination"])
                kept = Path(p["kept"]) if p["kept"] else None     # junk set aside (mac_metadata) keeps nothing
                note = _blocker(src, dst, kept, int(p["size_bytes"]), float(p["source_mtime"]))
                entry = {k: p[k] for k in ("class", "source", "destination", "size_bytes", "sha256", "kept")}
                entry.update(sidecar_source="", sidecar_destination="", note=note or p.get("note") or "")
                if note:
                    entry["result"] = "skipped"
                    stats["skipped: " + note] += 1
                    log.writerow(entry)
                    continue
                try:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    os.rename(src, dst)                   # same drive; fails rather than overwrite
                except OSError as error:                  # one file can't stop the rest
                    entry["result"], entry["note"] = "failed", str(error)
                    stats["failed"] += 1
                    log.writerow(entry)
                    continue
                side_src, side_dst = Path(f"{src}{SIDECAR_SUFFIX}"), Path(f"{dst}{SIDECAR_SUFFIX}")
                if side_src.exists() and not side_dst.exists():
                    try:
                        os.rename(side_src, side_dst)
                        entry["sidecar_source"], entry["sidecar_destination"] = str(side_src), str(side_dst)
                    except OSError as error:
                        entry["note"] = f"sidecar not moved: {error}"
                entry["result"] = "moved"
                stats["moved"] += 1
                stats["bytes"] += int(p["size_bytes"])
                moved_rows.append((str(dst), p["source"]))
                log.writerow(entry)
    finally:                                               # what moved is recorded, whatever happens
        if moved_rows:
            with db.connect() as conn:
                conn.executemany(
                    "UPDATE files SET path = ?, area = 'holding', sidecar_path = NULL WHERE path = ?", moved_rows)
        db.log_event("intake_set_aside", json.dumps({"log": str(log_path), **stats}))
        from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

        log_event("set_aside", f"set aside {stats['moved']:,} duplicates in _duplicates-holding (undo: {log_path})",
                  log=str(log_path), moved=stats["moved"], failed=stats["failed"])
    return stats


def _blocker(src: Path, dst: Path, kept: Path | None, size: int, mtime: float) -> str:
    """Return why a planned move must not happen now, or ''."""
    try:
        st = src.stat()
    except FileNotFoundError:
        return "source missing"
    if kept is not None and not kept.exists():
        return "kept file missing"
    if st.st_size != size or st.st_mtime != mtime:
        return "changed since plan"
    if dst.exists():
        return "destination exists"
    if too_long(dst, f"{dst}{SIDECAR_SUFFIX}"):
        return TOO_LONG
    return ""


def _area_of(path: str) -> str:
    """Return the index area a path going back belongs to (a set-aside resized copy may come from organized)."""
    parts = [p.lower() for p in Path(path).parts]
    for area, top in (("photos", "photos"), ("documents", "documents")):
        if any(a == top and b == "organized" for a, b in zip(parts, parts[1:])):
            return area
    return "intake"


def undo_set_aside(db: DbitService, log_path: Path) -> Counter:
    """Move everything a set-aside log moved back, and point the db rows back at intake."""
    db.initialize(log=False)                                # an archive never indexed has no tables yet
    stats: Counter = Counter()
    back: list[tuple[str, str]] = []
    with log_path.open(encoding="utf-8", newline="") as f:
        copied = [r for r in csv.DictReader(f) if r["result"] == "copied" and r["class"] == "merge"]
    if copied:                                             # a merge copied these: remove the copies
        from mindit.services.workflow.merge import undo_copies  # pylint: disable=import-outside-toplevel

        stats = undo_copies(copied)
        if db.db_path.exists():
            with db.connect() as conn:
                conn.executemany("DELETE FROM files WHERE path = ?", [(r["destination"],) for r in copied])
        db.log_event("intake_undo", json.dumps({"log": str(log_path), **stats}))
        return stats
    with log_path.open(encoding="utf-8", newline="") as f:
        rows = [r for r in csv.DictReader(f) if r["result"] == "moved"]
    for r in reversed(rows):                                 # last first: a name freed later is back first
        pairs = [(r["destination"], r["source"])]
        if r["sidecar_destination"]:
            pairs.append((r["sidecar_destination"], r["sidecar_source"]))
        for held, original in pairs:
            if Path(held).exists() and not Path(original).exists():
                Path(original).parent.mkdir(parents=True, exist_ok=True)
                shutil.move(held, original)                 # da split can move across drives
                stats["restored"] += 1
            else:
                stats["skipped"] += 1
        if r["class"] not in ("location_folder", "ocr_document", "rename", "secure_hold"):   # put right below / not indexed
            back.append((r["source"], r["destination"]))
    renamed = [r for r in rows if r["class"] == "rename"]
    if renamed:                                             # `da rename --apply`: the old names again
        from mindit.services.naming.rename import undo_rows as undo_names  # pylint: disable=import-outside-toplevel

        undo_names(db.db_path, renamed)
    located = [r for r in rows if r["class"] == "location_folder"]
    if located:
        from mindit.services.location.grouping import undo_rows  # pylint: disable=import-outside-toplevel

        undo_rows(db.db_path, located)
    documents = [r for r in rows if r["class"] == "ocr_document"]
    if documents:                                           # `da tag ocr --tag-and-move`: photos again
        from mindit.services.ocr.ocr_tags import undo_rows as undo_documents  # pylint: disable=import-outside-toplevel

        undo_documents(db.db_path, documents)
    if back:
        with db.connect() as conn:
            conn.executemany("UPDATE files SET path = ?, area = ? WHERE path = ?",
                             [(src, _area_of(src), dst) for src, dst in back])
    db.log_event("intake_undo", json.dumps({"log": str(log_path), **stats}))
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("undo", f"undo of {log_path}: {stats['restored']} restored, {stats['skipped']} skipped",
              path=str(log_path))
    return stats
