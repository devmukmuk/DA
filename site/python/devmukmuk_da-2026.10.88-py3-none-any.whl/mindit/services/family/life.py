# src/mindit/services/family/life.py

"""A dated photo's place in the family's life: the home at the time, each named face's age, at home or away (phase 2).

Kept in the sidecar's `life` block, worked out again whenever the family files or the faces change (never by hand):

    "life": {"date": "1997-07-04", "home": "40 Oak Lane, Riverton, UT 84065", "home_from": "1996-08-01",
             "at_home": true, "ages": [{"name": "Jane Doe", "person": "jane", "age": 35}], "family_fp": "..."}

A date set by hand to a year or a month gives ages as a range (`age_min` / `age_max`) and a home only when one house
(or houses with the same dates) covers all of it; else `homes` lists the ones it could be. At home: the photo's GPS
within HOME_METRES of the home's position (house-positions.csv in the family folder, from `da family --locate`).
"""

from __future__ import annotations

import calendar
import csv
import hashlib
import math
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable

from mindit.services.family.family import Family, House, age_on

BLOCK = "life"
POSITIONS = "house-positions.csv"
HOME_METRES = 300


def family_fp(family: Family) -> str:
    """Return a short fingerprint of the family files (and house positions), so changed files mean new blocks."""
    digest = hashlib.sha256()
    for path in sorted([*family.files, family.folder / POSITIONS]):
        try:
            digest.update(path.name.encode() + b"\0" + path.read_bytes())
        except OSError:
            continue
    return digest.hexdigest()[:16]


# --------------------------------------------------------------------------- house positions

def read_positions(folder: Path) -> dict[str, tuple[float, float] | None]:
    """Return {house label: (lat, lon), or None when it wasn't found} from house-positions.csv."""
    path = Path(folder) / POSITIONS
    found: dict[str, tuple[float, float] | None] = {}
    if not path.exists():
        return found
    with path.open(newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            label = (row.get("house") or "").strip()
            try:
                found[label] = (float(row["latitude"]), float(row["longitude"]))
            except (KeyError, TypeError, ValueError):
                found[label] = None
    return found


def locate_houses(family: Family, search: Callable[[str], tuple[Any, float, float] | None],
                  again: bool = False) -> tuple[int, list[str]]:
    """Look up each house's position once (search = the geocoder's), keep them in house-positions.csv.

    Return (houses looked up, labels not found). Rows typed or corrected by hand stay as they are.
    """
    known = read_positions(family.folder)
    looked, missing = 0, []
    for house in family.houses:
        label = house.label()
        if label in known and (known[label] is not None or not again):
            if known[label] is None:
                missing.append(label)
            continue
        hit = search(label) or (search(house.place) if house.place else None)
        looked += 1
        known[label] = (hit[1], hit[2]) if hit else None
        if hit is None:
            missing.append(label)
    path = family.folder / POSITIONS
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["house", "latitude", "longitude"])
        for label, spot in known.items():
            writer.writerow([label, *(f"{v:.6f}" for v in spot)] if spot else [label, "", ""])
    return looked, missing


def metres(a: tuple[float, float], b: tuple[float, float]) -> float:
    """Return the distance between two (lat, lon) positions in metres."""
    lat1, lon1, lat2, lon2 = map(math.radians, (*a, *b))
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6_371_000 * math.asin(math.sqrt(h))


# --------------------------------------------------------------------------- a photo's dates

@dataclass(frozen=True)
class When:
    """A photo's date: one day, or the first and last day a year or month set by hand could be."""
    first: date
    last: date
    text: str                        # "1997-07-04", "1997-07", "1997"


def when_taken(sidecar: dict[str, Any]) -> When | None:
    """Return the photo's (or video's) date from its sidecar: set by hand (with its precision) first, else the camera's."""
    user = sidecar.get("user") if isinstance(sidecar.get("user"), dict) else {}
    if user.get("captured_at"):
        day = _day(user["captured_at"])
        if day:
            precision = user.get("date_precision")
            if precision == "year":
                return When(date(day.year, 1, 1), date(day.year, 12, 31), f"{day.year}")
            if precision == "month":
                last = calendar.monthrange(day.year, day.month)[1]
                return When(day.replace(day=1), day.replace(day=last), f"{day:%Y-%m}")
            return When(day, day, day.isoformat())
    for block, key in (("photoit", "captured_at"), ("camera", "date_taken"), ("video", "recorded_at")):
        value = sidecar.get(block).get(key) if isinstance(sidecar.get(block), dict) else None
        day = _day(value)
        if day:
            return When(day, day, day.isoformat())
    return None


def _day(value: Any) -> date | None:
    if not value:
        return None
    text = str(value).strip().replace(":", "-", 2) if str(value)[4:5] == ":" else str(value).strip()
    try:
        return datetime.fromisoformat(text[:19]).date()
    except ValueError:
        try:
            return date.fromisoformat(text[:10])
        except ValueError:
            return None


# --------------------------------------------------------------------------- the block

def _homes(family: Family, when: When, today: date) -> list[House]:
    """Return the house(s) the household lived in for all of when (several only with the same dates)."""
    first = family.homes_on(when.first, today)
    if when.first == when.last:
        return first
    last = family.homes_on(when.last, today)
    return first if first and [id(h) for h in first] == [id(h) for h in last] else []


def _could_be(family: Family, when: When, today: date) -> list[House]:
    return [h for h in family.houses if h.start <= when.last and h.last_day(today) > when.first]


def life_of(sidecar: dict[str, Any], family: Family, *, fp: str = "", positions=None,
            today: date | None = None) -> dict[str, Any] | None:
    """Return a photo's `life` block (None: no date, or nothing the family files say about it)."""
    from mindit.services.faces.faces import faces_of, people  # pylint: disable=import-outside-toplevel
    from mindit.services.location.places import position  # pylint: disable=import-outside-toplevel

    today = today or date.today()
    when = when_taken(sidecar)
    if when is None:
        return None
    block: dict[str, Any] = {"date": when.text}
    homes = _homes(family, when, today)
    if homes:
        block["home"] = homes[0].label() if len(homes) == 1 else "; ".join(h.label() for h in homes)
        block["home_from"] = homes[0].start.isoformat()
        spot = position(sidecar)
        spots = [(positions or {}).get(h.label()) for h in homes]
        if spot and any(spots):
            block["at_home"] = any(s and metres(spot, s) <= HOME_METRES for s in spots)
    else:
        could = _could_be(family, when, today)
        if could:
            block["homes"] = [h.label() for h in could]
    ages = []
    for name in people(faces_of(sidecar)):
        person = family.person(name)
        if person is None or person.born is None:
            continue
        if when.last < person.born:
            ages.append({"name": name, "person": person.name, "not_born": True})
            continue
        low, high = age_on(person.born, max(when.first, person.born)), age_on(person.born, when.last)
        ages.append({"name": name, "person": person.name, **({"age": low} if low == high else
                                                            {"age_min": low, "age_max": high})})
    if ages:
        block["ages"] = ages
    if len(block) == 1:
        return None
    block["family_fp"] = fp
    return block


def age_text(entry: dict[str, Any]) -> str:
    """Return an age as shown: '34', '6-7', or '' (not born yet / unknown)."""
    if "age" in entry:
        return str(entry["age"])
    if "age_min" in entry:
        return f"{entry['age_min']}-{entry['age_max']}"
    return ""


def describe(sidecar: dict[str, Any], *, home: bool = True) -> str:
    """Return a photo's life block as one line: 'Jane Doe 35, Sam 6 | 40 Oak Lane, Riverton (at home)'."""
    block = sidecar.get(BLOCK) if isinstance(sidecar.get(BLOCK), dict) else {}
    parts = []
    ages = ", ".join(f"{a['name']} {age_text(a)}" for a in block.get("ages") or [] if age_text(a))
    if ages:
        parts.append(ages)
    if home and block.get("home"):
        where = block["home"].split(",")[0] if "; " not in block["home"] else "one of " + str(
            len(block["home"].split("; "))) + " homes"
        if "at_home" in block:
            where += " (at home)" if block["at_home"] else " (away)"
        parts.append(where)
    return " | ".join(parts)


def labels(sidecar: dict[str, Any]) -> dict[str, str]:
    """Return {face name: 'Jane Doe (35)'} for the faces with an age, for face labels."""
    block = sidecar.get(BLOCK) if isinstance(sidecar.get(BLOCK), dict) else {}
    return {a["name"]: f"{a['name']} ({age_text(a)})" for a in block.get("ages") or [] if age_text(a)}


# --------------------------------------------------------------------------- writing

@dataclass
class LifeResult:
    """What a pass over sidecars did."""
    files: int = 0
    written: int = 0
    removed: int = 0


def load_family() -> tuple[Family | None, str, dict]:
    """Return the archive's family (None when `family:` isn't set or can't be read), its fingerprint and positions."""
    try:
        from mindit.config.settings import get_family_folder  # pylint: disable=import-outside-toplevel
        from mindit.services.family.family import read_family  # pylint: disable=import-outside-toplevel

        folder = get_family_folder()
        if folder is None:
            return None, "", {}
        family = read_family(folder)
    except Exception:  # pylint: disable=broad-except
        return None, "", {}
    return family, family_fp(family), read_positions(family.folder)


def update(data: dict[str, Any], family: Family, fp: str, positions: dict) -> bool:
    """Set or remove a loaded sidecar's life block; return True when it changed."""
    block = life_of(data, family, fp=fp, positions=positions)
    if block == data.get(BLOCK):
        return False
    if block is None:
        data.pop(BLOCK, None)
    else:
        data[BLOCK] = block
    return True


def write_life(paths: list[Path], family: Family | None = None, fp: str = "", positions: dict | None = None,
               progress: Callable[[int, int], None] | None = None) -> LifeResult:
    """Work out each photo's life block again and save the sidecars whose block changed."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    if family is None:
        family, fp, positions = load_family()
    result = LifeResult(files=len(paths))
    if family is None:
        return result
    for i, path in enumerate(paths, 1):
        if not Path(f"{path}.meta.json").exists():
            continue
        data = SidecarService.load(path)
        had = BLOCK in data
        if update(data, family, fp, positions or {}):
            SidecarService.save(path, data)
            if BLOCK in data:
                result.written += 1
            elif had:
                result.removed += 1
        if progress:
            progress(i, len(paths))
    return result
