# src/mindit/services/dbit/archive_index_service.py

"""Index every file in the Digital Archive (organized trees, intake, holding) into the DA database."""

from __future__ import annotations

import json
import os
import re
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit import __version__
from mindit.services.contactsheet.contact_sheet import SHEET_NAME
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.validateit.validateit_file_types import (
    DOCUMENT_ONLY_EXTENSIONS,
    PHOTO_EXTENSIONS,
    RAW_EXTENSIONS,
    VIDEO_EXTENSIONS,
)
from mindit.utils.timestamps import safe_iso_timestamp

SIDECAR_SUFFIX = ".meta.json"
SKIP_DIRS = {"$RECYCLE.BIN", "System Volume Information", ".validateit-quarantine", ".da", ".mindit"}
BATCH_SIZE = 5000
_PHOTO_NAME = re.compile(r"^(?:photo|video)_(\d{8})_(\d{6})_")
_DOC_NAME = re.compile(r"^doc_(\d{6})_(\d{6})_")


@dataclass(frozen=True)
class Area:
    """One indexed tree: its name ('photos', 'documents', 'intake', 'holding') and root folder."""

    name: str
    root: Path


@dataclass
class IndexResult:
    """What one build indexed."""

    files: Counter = field(default_factory=Counter)          # (area, kind) -> count
    bytes: Counter = field(default_factory=Counter)          # area -> bytes
    no_sidecar: Counter = field(default_factory=Counter)     # area -> count
    no_hash: Counter = field(default_factory=Counter)        # area -> count
    removed: int = 0
    outside: list[str] = field(default_factory=list)   # rows for files outside the archive (it was moved)
    seconds: float = 0.0
    read: int = 0                                      # new or changed: sidecar read, row written
    unchanged: int = 0                                 # same stamp as its row: nothing read or written

    def count(self, area: str, kind: str | None, size: int | None, sidecar: str | None, sha256: str | None) -> None:
        self.files[(area, kind)] += 1
        self.bytes[area] += size or 0
        if not sidecar:
            self.no_sidecar[area] += 1
        if not sha256:
            self.no_hash[area] += 1

    def as_dict(self) -> dict[str, Any]:
        """Return a JSON-friendly summary."""
        areas = sorted({a for a, _ in self.files})
        return {
            "areas": {
                a: {
                    "files": sum(n for (x, _), n in self.files.items() if x == a),
                    "by_kind": {k: n for (x, k), n in sorted(self.files.items()) if x == a},
                    "gb": round(self.bytes[a] / 1e9, 2),
                    "no_sidecar": self.no_sidecar[a],
                    "no_hash": self.no_hash[a],
                }
                for a in areas
            },
            "removed_missing": self.removed,
            "removed_outside": len(self.outside),
            "read": self.read,
            "unchanged": self.unchanged,
            "seconds": round(self.seconds, 1),
        }


def default_areas(settings: Any | None = None) -> list[Area]:
    """Return the archive's areas from the active profile: both organized trees, intake, holding."""
    from mindit.config.settings import (  # pylint: disable=import-outside-toplevel
        get_data_root_path,
        load_settings,
        resolve_data_path,
        resolve_photoit_organized_path,
        resolve_scanit_organized_path,
    )

    loaded = settings or load_settings()
    data_root = get_data_root_path(loaded)
    return [
        Area("photos", resolve_photoit_organized_path(loaded)),
        Area("documents", resolve_scanit_organized_path(loaded)),
        Area("intake", resolve_data_path(loaded.paths.intake, loaded)),
        Area("holding", data_root / "_duplicates-holding"),
    ]


class ArchiveIndexService:
    """Walk each area, read each file's sidecar, and keep the files table in step with the disk."""

    def __init__(self, db_service: DbitService) -> None:
        self.db = db_service

    def build(self, areas: list[Area], progress: Callable[[str], None] | None = None, *,
              full: bool = False) -> IndexResult:
        """Index the files under the given areas and drop rows for files that are gone.

        Only new or changed files are read: a file whose index_stamp (DA version, the file's size and modified time,
        its sidecar's size and modified time, all from the folder listing) matches its row keeps that row, so its
        sidecar isn't opened and nothing is written. full=True reads every file again.
        """
        start = time.time()
        started_at = datetime.now().isoformat(timespec="microseconds")  # rows older than this are gone
        self.db.initialize()
        result = IndexResult()
        known = {} if full else self.db.index_stamps()
        batch: list[dict[str, Any]] = []
        seen = 0

        for area in areas:
            if not area.root.is_dir():
                # The folder was removed (e.g. _duplicates-holding emptied by hand): its rows are stale. Only when
                # the folder above it is there, so an unplugged drive or share never empties the index.
                if area.root.parent.is_dir():
                    result.removed += self.db.delete_missing(str(area.root) + os.sep, started_at)
                continue
            listed: set[str] = set()
            for dirpath, entries in _listing(str(area.root)):
                sidecars = {e.name[: -len(SIDECAR_SUFFIX)].lower(): e for e in entries
                            if e.name.lower().endswith(SIDECAR_SUFFIX)}
                for entry in entries:
                    low = entry.name.lower()
                    if low.endswith(SIDECAR_SUFFIX) or low == SHEET_NAME:
                        continue
                    try:
                        stat = entry.stat()                     # from the listing on Windows: no extra disk read
                        sidecar = sidecars.get(low)
                        sidecar_stat = sidecar.stat() if sidecar else None
                    except OSError:
                        continue
                    stamp = index_stamp(stat, sidecar_stat)
                    seen += 1
                    listed.add(entry.path)
                    old = known.get(entry.path)
                    if old is not None and old[5] == stamp and old[0] == area.name:
                        result.unchanged += 1
                        result.count(area.name, old[1], old[2], old[3], old[4])
                        continue
                    record = self._record(area, Path(dirpath, entry.name), started_at, stat=stat,
                                          has_sidecar=sidecar is not None, stamp=stamp)
                    if record is None:
                        continue
                    record["path"] = entry.path                 # the same key the next build looks it up by
                    result.read += 1
                    result.count(area.name, record["media_type"], record["size_bytes"], record["sidecar_path"],
                                 record["sha256"])
                    batch.append(record)
                    if len(batch) >= BATCH_SIZE:
                        self.db.upsert_files(batch)
                        batch.clear()
                        if progress:
                            progress(f"{seen:,} files looked at, {result.read:,} read ({time.time() - start:.0f}s)")
            self.db.upsert_files(batch)
            batch.clear()
            # Gone: rows under this area whose file wasn't listed (full: every listed row was just rewritten, so the
            # rows older than this build are the gone ones).
            prefix = str(area.root) + os.sep
            if full:
                result.removed += self.db.delete_missing(prefix, started_at)
            else:
                result.removed += self.db.delete_paths(
                    [p for p in known if p.startswith(prefix) and p not in listed])

        if self.db.db_path.parent.name == ".da":         # <archive>\.da\da.sqlite: rows outside it are stale
            result.outside = self.db.delete_outside(self.db.db_path.parent.parent)
            if result.outside and progress:
                progress(f"{len(result.outside):,} rows were for files outside this archive (where it used to be, "
                         f"e.g. {result.outside[0]}) - removed")
        result.seconds = time.time() - start
        self.db.log_event("db_build", json.dumps(result.as_dict()))
        return result

    def _record(self, area: Area, path: Path, now: str, *, stat: os.stat_result | None = None,
                has_sidecar: bool | None = None, stamp: str | None = None) -> dict[str, Any] | None:
        if stat is None:
            try:
                stat = path.stat()
            except OSError:
                return None
        sidecar_path = Path(f"{path}{SIDECAR_SUFFIX}")
        meta = None if has_sidecar is False else _load_json(sidecar_path)
        file_block = _block(meta, "file")
        quarantine = _block(meta, "quarantine")
        classification = _block(meta, "classification")
        validation = _block(meta, "validation")
        photoit = _block(meta, "photoit")
        scanit = _block(meta, "scanit")
        user = _block(meta, "user")
        location = _block(meta, "location")
        place = location.get("place") if isinstance(location.get("place"), dict) else {}

        kind = _kind(path, area.name)
        rel_parent = os.path.relpath(path.parent, area.root)
        problem_count = validation.get("problem_count")
        return {
            "path": str(path),
            "area": area.name,
            "folder": "" if rel_parent == "." else rel_parent,
            "module": classification.get("module") or {"photo": "photoit", "raw": "photoit", "document": "scanit"}.get(kind),
            "media_type": kind,
            "file_name": path.name,
            "extension": path.suffix.lower(),
            "size_bytes": stat.st_size,
            "modified_at": _iso_mtime(stat.st_mtime),
            "sha256": _sha256(file_block, quarantine, stat.st_size, stat.st_mtime),
            "sidecar_path": str(sidecar_path) if meta is not None else None,
            "sidecar_schema_version": _block(meta, "schema").get("version"),
            "captured_at": (user.get("captured_at") or photoit.get("captured_at") or _block(meta, "video").get("recorded_at")
                            or scanit.get("document_date") or _name_date(path.name)),
            "tags": _tags(photoit, scanit, user, _block(meta, "auto_tags")),
            "gps_present": _gps_present(meta),
            "validation_status": None if problem_count is None else ("ok" if problem_count == 0 else "problems"),
            "validation_problem_count": problem_count or 0,
            "hash_status": quarantine.get("hash_status"),
            "duplicate_status": quarantine.get("duplicate_status"),
            "source_path": file_block.get("source_path"),
            "city": place.get("city"),
            "state_code": place.get("state_code"),
            "country_code": place.get("country_code"),
            "title": location.get("title"),
            "camera": _camera(_block(meta, "camera")),
            "origin": _origin(meta),
            "indexed_at": now,
            "index_stamp": stamp,
        }


def index_stamp(stat: os.stat_result, sidecar_stat: os.stat_result | None) -> str:
    """What a file and its sidecar look like now, plus the DA version that read them: equal stamps, same row."""
    side = f"{sidecar_stat.st_size}:{sidecar_stat.st_mtime_ns}" if sidecar_stat is not None else "-"
    return f"{__version__}|{stat.st_size}:{stat.st_mtime_ns}|{side}"


def _listing(top: str):
    """Yield (folder, its files as os.DirEntry) for every folder under top, leaving out SKIP_DIRS.

    os.scandir carries each file's size and modified time on Windows, so nothing else is read from the disk.
    """
    stack = [top]
    while stack:
        folder = stack.pop()
        try:
            with os.scandir(folder) as it:
                entries = list(it)
        except OSError:
            continue
        files = []
        for entry in entries:
            try:
                if entry.is_dir():
                    if entry.name not in SKIP_DIRS and not entry.is_symlink():
                        stack.append(entry.path)
                elif entry.is_file():
                    files.append(entry)
            except OSError:
                continue
        yield folder, files


def _camera(camera: dict[str, Any]) -> str | None:
    """Return the camera that took it ("Canon PowerShot A80"), from the sidecar's camera block."""
    from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel

    return camera_name(camera) if camera else None


def _origin(meta: dict[str, Any] | None) -> str | None:
    """Return the folders it came in from, top first, joined by backslashes ("Jones Family Photos\\Scans")."""
    from mindit.services.sidecar.origin import levels  # pylint: disable=import-outside-toplevel

    return "\\".join(levels(meta)) or None


def _gps_present(meta: dict[str, Any] | None) -> int:
    """Return 1 when the sidecar holds a real position (the same test `da location lookup` uses), else 0.

    An empty `"gps": {"latitude": null, ...}` block isn't one: it once counted, so the report promised places to look up.
    """
    from mindit.services.location.places import manual_position, position  # pylint: disable=import-outside-toplevel

    return int(bool(meta) and (position(meta) is not None or manual_position(meta) is not None))


def _iso_mtime(mtime: float) -> str | None:
    """Return the modified time as ISO text, or None for a timestamp Windows can't convert (pre-1970 etc.)."""
    return safe_iso_timestamp(mtime)


def _load_json(path: Path) -> dict[str, Any] | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _block(meta: dict[str, Any] | None, name: str) -> dict[str, Any]:
    value = (meta or {}).get(name)
    return value if isinstance(value, dict) else {}


def _kind(path: Path, area: str) -> str:
    """Return photo, document, raw, video or other; an image under the documents tree is a document."""
    ext = path.suffix.lower()
    if ext in RAW_EXTENSIONS:
        return "raw"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    if ext in DOCUMENT_ONLY_EXTENSIONS:
        return "document"
    if ext in PHOTO_EXTENSIONS:
        return "document" if area == "documents" else "photo"
    return "other"


def _sha256(file_block: dict[str, Any], quarantine: dict[str, Any], size: int, mtime: float) -> str | None:
    """Return the sidecar's recorded sha256 for the file as it is now.

    Validate's quarantine hash carries the size and modified time it was computed for, so when both still
    match it wins; an older tool's file.sha256 can be stale after an edit that kept the size.
    """
    if quarantine.get("hash_sha256") and quarantine.get("file_size") == size and quarantine.get("file_modified_at") == mtime:
        return quarantine["hash_sha256"]
    if file_block.get("sha256") and file_block.get("size_bytes") in (None, size):
        return file_block["sha256"]
    if quarantine.get("hash_sha256") and quarantine.get("file_size") in (None, size):
        return quarantine["hash_sha256"]
    return None


def _name_date(name: str) -> str | None:
    """Return the date+time a DA name carries (photo_YYYYMMDD_HHMMSS_ / doc_YYMMDD_HHMMSS_)."""
    m = _PHOTO_NAME.match(name)
    if m:
        return datetime.strptime(m[1] + m[2], "%Y%m%d%H%M%S").isoformat()
    m = _DOC_NAME.match(name)
    if m:
        return datetime.strptime(m[1] + m[2], "%y%m%d%H%M%S").isoformat()
    return None


def _tags(*blocks: dict[str, Any]) -> str | None:
    """Return the union of the blocks' tag lists as a JSON array, or None."""
    tags: list[str] = []
    for block in blocks:
        for tag in block.get("tags") or []:
            if isinstance(tag, str) and tag.strip() and tag.strip() not in tags:
                tags.append(tag.strip())
    return json.dumps(tags) if tags else None
