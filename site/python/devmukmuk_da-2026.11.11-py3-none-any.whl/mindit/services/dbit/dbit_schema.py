BASE_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS schema_version (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    version INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL UNIQUE,
    module TEXT,
    media_type TEXT,
    file_name TEXT NOT NULL,
    extension TEXT,
    size_bytes INTEGER,
    modified_at TEXT,
    sha256 TEXT,
    sidecar_path TEXT,
    sidecar_schema_version INTEGER,
    captured_at TEXT,
    tags TEXT,
    gps_present INTEGER DEFAULT 0,
    validation_status TEXT,
    validation_problem_count INTEGER DEFAULT 0,
    hash_status TEXT,
    duplicate_status TEXT,
    indexed_at TEXT NOT NULL,
    area TEXT,
    folder TEXT,
    source_path TEXT,
    city TEXT,
    state_code TEXT,
    country_code TEXT,
    title TEXT,
    camera TEXT,
    origin TEXT,
    index_stamp TEXT
);

CREATE TABLE IF NOT EXISTS db_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    message TEXT,
    created_at TEXT NOT NULL
);
"""

INDEX_SCHEMA_SQL = """
CREATE INDEX IF NOT EXISTS idx_files_module ON files(module);
CREATE INDEX IF NOT EXISTS idx_files_media_type ON files(media_type);
CREATE INDEX IF NOT EXISTS idx_files_extension ON files(extension);
CREATE INDEX IF NOT EXISTS idx_files_sha256 ON files(sha256);
CREATE INDEX IF NOT EXISTS idx_files_validation_status ON files(validation_status);
CREATE INDEX IF NOT EXISTS idx_files_duplicate_status ON files(duplicate_status);
CREATE INDEX IF NOT EXISTS idx_files_gps_present ON files(gps_present);
CREATE INDEX IF NOT EXISTS idx_files_area ON files(area);
CREATE INDEX IF NOT EXISTS idx_files_folder ON files(folder);
CREATE INDEX IF NOT EXISTS idx_files_captured_at ON files(captured_at);
CREATE INDEX IF NOT EXISTS idx_files_city ON files(city);
CREATE INDEX IF NOT EXISTS idx_files_title ON files(title);
CREATE INDEX IF NOT EXISTS idx_files_camera ON files(camera);
"""
