from __future__ import annotations

import os
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.dbit.dbit_schema import BASE_SCHEMA_SQL, INDEX_SCHEMA_SQL


DB_SCHEMA_VERSION = 7
# How long to wait for another DA (e.g. the hidden `archives details` reader) to let go of the index, in seconds.
# sqlite3's 5 s default is shorter than one read of a big index, so the next command failed with "database is locked".
BUSY_TIMEOUT = 60


class DbitService:
    def __init__(self, db_path: Path) -> None:
        self.db_path = Path(db_path)

    def connect(self) -> sqlite3.Connection:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        conn = sqlite3.connect(self.db_path, timeout=BUSY_TIMEOUT)
        conn.row_factory = sqlite3.Row
        return conn

    def initialize(self, log: bool = True) -> None:
        """Create or migrate the schema; log a db_initialized event unless log is False."""
        now = datetime.now().isoformat(timespec="seconds")

        with self.connect() as conn:
            conn.executescript(BASE_SCHEMA_SQL)

            current_version = self._get_schema_version(conn)

            if current_version < 2:
                self._migrate_to_v2(conn)
            if current_version < 3:
                self._migrate_to_v3(conn)
            if current_version < 4:
                self._migrate_to_v4(conn)
            if current_version < 5:
                self._ensure_column(conn, "files", "camera", "camera TEXT")
            if current_version < 6:
                self._ensure_column(conn, "files", "origin", "origin TEXT")
            if current_version < 7:      # what the file and its sidecar looked like when the row was read
                self._ensure_column(conn, "files", "index_stamp", "index_stamp TEXT")

            conn.executescript(INDEX_SCHEMA_SQL)

            conn.execute(
                """
                INSERT INTO schema_version (id, version, updated_at)
                VALUES (1, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    version = excluded.version,
                    updated_at = excluded.updated_at
                """,
                (DB_SCHEMA_VERSION, now),
            )

            if log:
                conn.execute(
                    """
                    INSERT INTO db_events (event_type, message, created_at)
                    VALUES (?, ?, ?)
                    """,
                    ("db_initialized", "SQLite database initialized", now),
                )

    def inspect(self) -> dict[str, Any]:
        with self.connect() as conn:
            tables = conn.execute(
                """
                SELECT name
                FROM sqlite_master
                WHERE type = 'table'
                ORDER BY name
                """
            ).fetchall()

            version = conn.execute(
                """
                SELECT version, updated_at
                FROM schema_version
                WHERE id = 1
                """
            ).fetchone()

            return {
                "db_path": str(self.db_path),
                "schema_version": dict(version) if version else None,
                "tables": [row["name"] for row in tables],
            }

    def query(self, sql: str) -> list[dict[str, Any]]:
        statement = sql.strip().lower()

        if not statement.startswith("select"):
            raise ValueError("Only SELECT queries are allowed from the CLI query command.")

        with self.connect() as conn:
            rows = conn.execute(sql).fetchall()
            return [dict(row) for row in rows]

    def upsert_file(self, record: dict[str, Any]) -> None:
        self.upsert_files([record])

    def upsert_files(self, records: list[dict[str, Any]]) -> None:
        """Insert or update many file rows in one transaction."""
        if not records:
            return
        with self.connect() as conn:
            conn.executemany(
                """
                INSERT INTO files (
                    path,
                    module,
                    media_type,
                    file_name,
                    extension,
                    size_bytes,
                    modified_at,
                    sha256,
                    sidecar_path,
                    sidecar_schema_version,
                    captured_at,
                    tags,
                    gps_present,
                    validation_status,
                    validation_problem_count,
                    hash_status,
                    duplicate_status,
                    indexed_at,
                    area,
                    folder,
                    source_path,
                    city,
                    state_code,
                    country_code,
                    title,
                    camera,
                    origin,
                    index_stamp
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(path) DO UPDATE SET
                    module = excluded.module,
                    media_type = excluded.media_type,
                    file_name = excluded.file_name,
                    extension = excluded.extension,
                    size_bytes = excluded.size_bytes,
                    modified_at = excluded.modified_at,
                    -- keep a hash computed earlier (e.g. by `da intake hash`) while the file is unchanged
                    sha256 = COALESCE(excluded.sha256, CASE WHEN files.size_bytes = excluded.size_bytes
                        AND files.modified_at IS excluded.modified_at THEN files.sha256 END),
                    sidecar_path = excluded.sidecar_path,
                    sidecar_schema_version = excluded.sidecar_schema_version,
                    captured_at = excluded.captured_at,
                    tags = excluded.tags,
                    gps_present = excluded.gps_present,
                    validation_status = excluded.validation_status,
                    validation_problem_count = excluded.validation_problem_count,
                    hash_status = COALESCE(excluded.hash_status, CASE WHEN files.size_bytes = excluded.size_bytes
                        AND files.modified_at IS excluded.modified_at THEN files.hash_status END),
                    duplicate_status = excluded.duplicate_status,
                    indexed_at = excluded.indexed_at,
                    area = excluded.area,
                    folder = excluded.folder,
                    source_path = excluded.source_path,
                    city = excluded.city,
                    state_code = excluded.state_code,
                    country_code = excluded.country_code,
                    title = excluded.title,
                    camera = excluded.camera,
                    origin = excluded.origin,
                    index_stamp = excluded.index_stamp
                """,
                [(
                    record["path"],
                    record["module"],
                    record.get("media_type"),
                    record["file_name"],
                    record["extension"],
                    record["size_bytes"],
                    record["modified_at"],
                    record.get("sha256"),
                    record.get("sidecar_path"),
                    record.get("sidecar_schema_version"),
                    record.get("captured_at"),
                    record.get("tags"),
                    record.get("gps_present", 0),
                    record.get("validation_status"),
                    record.get("validation_problem_count", 0),
                    record.get("hash_status"),
                    record.get("duplicate_status"),
                    record["indexed_at"],
                    record.get("area"),
                    record.get("folder"),
                    record.get("source_path"),
                    record.get("city"),
                    record.get("state_code"),
                    record.get("country_code"),
                    record.get("title"),
                    record.get("camera"),
                    record.get("origin"),
                    record.get("index_stamp"),     # None from other writers: the next build reads the file again
                ) for record in records],
            )

    def index_stamps(self) -> dict[str, tuple[Any, ...]]:
        """Return path -> (area, media_type, size_bytes, sidecar_path, sha256, index_stamp) for every row."""
        with self.connect() as conn:
            conn.row_factory = None
            return {row[0]: row[1:] for row in conn.execute(
                "SELECT path, area, media_type, size_bytes, sidecar_path, sha256, index_stamp FROM files")}

    def delete_paths(self, paths: list[str]) -> int:
        """Delete the rows for these paths; return how many went."""
        if not paths:
            return 0
        with self.connect() as conn:
            before = conn.total_changes
            conn.executemany("DELETE FROM files WHERE path = ?", [(p,) for p in paths])
            return conn.total_changes - before

    def delete_missing(self, path_prefix: str, indexed_before: str) -> int:
        """Delete rows under path_prefix not re-indexed since indexed_before (the file is gone)."""
        with self.connect() as conn:
            cursor = conn.execute(
                "DELETE FROM files WHERE substr(path, 1, ?) = ? AND indexed_at < ?",
                (len(path_prefix), path_prefix, indexed_before),
            )
            return cursor.rowcount

    def delete_outside(self, root: Path) -> list[str]:
        """Delete rows whose file isn't inside root (left from where the archive used to be); return their paths."""
        prefix = str(root).rstrip("\\/") + os.sep
        with self.connect() as conn:
            gone = [p for (p,) in conn.execute("SELECT path FROM files")
                    if not os.path.normcase(p).startswith(os.path.normcase(prefix))]
            conn.executemany("DELETE FROM files WHERE path = ?", [(p,) for p in gone])
        return gone

    def log_event(self, event_type: str, message: str) -> None:
        """Record one line in db_events."""
        with self.connect() as conn:
            conn.execute(
                "INSERT INTO db_events (event_type, message, created_at) VALUES (?, ?, ?)",
                (event_type, message, datetime.now().isoformat(timespec="seconds")),
            )

    def _get_schema_version(self, conn: sqlite3.Connection) -> int:
        row = conn.execute(
            """
            SELECT version
            FROM schema_version
            WHERE id = 1
            """
        ).fetchone()

        if row is None:
            return 0

        return int(row["version"])

    def _ensure_column(
        self,
        conn: sqlite3.Connection,
        table_name: str,
        column_name: str,
        column_definition: str,
    ) -> None:
        existing_columns = {
            row["name"]
            for row in conn.execute(f"PRAGMA table_info({table_name})")
        }

        if column_name not in existing_columns:
            conn.execute(
                f"ALTER TABLE {table_name} ADD COLUMN {column_definition}"
            )

    def _migrate_to_v4(self, conn: sqlite3.Connection) -> None:
        for column in ("city", "state_code", "country_code", "title"):
            self._ensure_column(conn, "files", column, f"{column} TEXT")

    def _migrate_to_v3(self, conn: sqlite3.Connection) -> None:
        self._ensure_column(conn, "files", "area", "area TEXT")
        self._ensure_column(conn, "files", "folder", "folder TEXT")
        self._ensure_column(conn, "files", "source_path", "source_path TEXT")

    def _migrate_to_v2(self, conn: sqlite3.Connection) -> None:
        self._ensure_column(conn, "files", "module", "module TEXT")
        self._ensure_column(conn, "files", "media_type", "media_type TEXT")
        self._ensure_column(conn, "files", "file_name", "file_name TEXT")
        self._ensure_column(conn, "files", "extension", "extension TEXT")
        self._ensure_column(conn, "files", "size_bytes", "size_bytes INTEGER")
        self._ensure_column(conn, "files", "modified_at", "modified_at TEXT")
        self._ensure_column(conn, "files", "sha256", "sha256 TEXT")
        self._ensure_column(conn, "files", "sidecar_path", "sidecar_path TEXT")
        self._ensure_column(
            conn,
            "files",
            "sidecar_schema_version",
            "sidecar_schema_version INTEGER",
        )
        self._ensure_column(conn, "files", "captured_at", "captured_at TEXT")
        self._ensure_column(conn, "files", "tags", "tags TEXT")
        self._ensure_column(
            conn,
            "files",
            "gps_present",
            "gps_present INTEGER DEFAULT 0",
        )
        self._ensure_column(
            conn,
            "files",
            "validation_status",
            "validation_status TEXT",
        )
        self._ensure_column(
            conn,
            "files",
            "validation_problem_count",
            "validation_problem_count INTEGER DEFAULT 0",
        )
        self._ensure_column(conn, "files", "hash_status", "hash_status TEXT")
        self._ensure_column(
            conn,
            "files",
            "duplicate_status",
            "duplicate_status TEXT",
        )
        self._ensure_column(conn, "files", "indexed_at", "indexed_at TEXT")
