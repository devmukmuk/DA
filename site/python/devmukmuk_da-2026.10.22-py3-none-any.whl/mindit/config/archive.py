# src/mindit/config/archive.py

"""Finding the archive DA works in, and the list of archives set up on this PC."""

from __future__ import annotations

import os
from pathlib import Path

from mindit.config.bootstrap import get_default_user_config_dir
from mindit.config.settings import ARCHIVE_FILE


def is_archive(folder: Path) -> bool:
    """Return True when folder holds a da-archive.yaml."""
    return (Path(folder) / ARCHIVE_FILE).is_file()


def find_archive(start: Path) -> Path | None:
    """Return the nearest folder at or above start that holds a da-archive.yaml, or None."""
    current = Path(start).resolve()
    for folder in (current, *current.parents):
        if is_archive(folder):
            return folder
    return None


def resolve_archive(cli_archive: str | None, cwd: Path, exe_dir: Path | None,
                    targets: list[Path] | tuple[Path, ...] = ()) -> Path | None:
    """Pick the archive: --archive, else a target folder's, else the current folder's, else the exe's."""
    if cli_archive:
        folder = Path(cli_archive).expanduser().resolve()
        if not is_archive(folder):
            raise SystemExit(f"No {ARCHIVE_FILE} in {folder}. Create one with:  da setup \"{folder}\"")
        return folder
    for target in targets:                     # `da validate D:\jane-archive-198x\intake\x` from anywhere
        found = find_archive(target)
        if found:
            return found
    found = find_archive(cwd)
    if found:
        return found
    if exe_dir is not None and is_archive(exe_dir):
        return exe_dir
    return None


# --------------------------------------------------------------------------- known archives

def registry_path() -> Path:
    """Return the file listing the archives set up on this PC (one folder per line)."""
    return get_default_user_config_dir().parent / "archives.txt"


def known_archives() -> list[Path]:
    """Return the registered archives that still exist, in the order they were added."""
    path = registry_path()
    if not path.exists():
        return []
    seen, out = set(), []
    for line in path.read_text(encoding="utf-8").splitlines():
        folder = Path(line.strip())
        key = os.path.normcase(str(folder))
        if line.strip() and key not in seen and is_archive(folder):
            seen.add(key)
            out.append(folder)
    return out


def register_archive(folder: Path) -> None:
    """Add folder to the list of archives on this PC (once)."""
    folder = Path(folder).resolve()
    existing = {os.path.normcase(str(p)) for p in known_archives()}
    if os.path.normcase(str(folder)) in existing:
        return
    path = registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(f"{folder}\n")
