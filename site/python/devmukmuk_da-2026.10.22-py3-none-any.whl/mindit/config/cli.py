"""
Configuration CLI commands for DA.
# src/mindit/config/cli.py

This module provides commands to:
- View configuration
- Modify configuration
- Manage profiles
- Validate configuration
- Manage provider-specific config operations

Design goals:
- Safe defaults
- Clear UX
- Extensible structure
"""

from typing import Optional

import typer
from rich import print  # pylint: disable=W0622

from mindit.config.settings import (
    get_config_path,
    load_settings,
    validate_key,
    get_field_type,
    flatten_model,
    flatten_dict,
    cast_value,
    load_yaml,
    get_nested,
    set_nested,
    unset_nested,
    save_yaml,
    get_profiles_dir,
    get_profile_path,
    get_active_profile_name,
    set_active_profile_name,
    reset_profile,
    validate_profile_name,
)
from mindit.config.settings import AppSettings
from mindit.core.logging import get_context_logger


app = typer.Typer(help="Configuration commands.")
logger = get_context_logger(__name__, app="config")


# -----------------------------------------------------------------------------
# Core Read Commands
# -----------------------------------------------------------------------------


@app.command("show")
def show() -> None:
    """
    Display the full active configuration.
    """
    settings = load_settings()
    cmd_logger = get_context_logger(__name__, app="config", command="show")
    cmd_logger.info("Showing active configuration", extra={"event": "config.show"})
    print(settings.model_dump())


@app.command("path")
def show_path() -> None:
    """
    Show the path to the active profile config file.
    """
    print(str(get_config_path()))


@app.command("active")
def active() -> None:
    """
    Show the active configuration profile.
    """
    profile_name = get_active_profile_name()
    print(f"profile = {profile_name}")
    print(f"path = {get_config_path()}")


@app.command("get")
def get(key: str) -> None:
    """
    Retrieve a specific configuration value.
    """
    valid, suggestions = validate_key(AppSettings, key)

    if not valid:
        print(f"[red]Invalid key:[/red] {key}")
        if suggestions:
            print(f"Did you mean: {suggestions}")
        raise typer.Exit(code=1)

    data = load_settings().model_dump()

    try:
        value = get_nested(data, key)
        print(value)
    except KeyError:
        print("[yellow]Key not set in config (using default)[/yellow]")


@app.command("values")
def values() -> None:
    """
    List all current config values (flattened).
    """
    current_data = load_settings().model_dump()
    flat_values = flatten_dict(current_data)

    for key, value in flat_values.items():
        print(f"{key} = {value}")


@app.command("keys")
def keys() -> None:
    """
    List all valid configuration keys.
    """
    flat_schema = flatten_model(AppSettings)

    for key in sorted(flat_schema.keys()):
        print(key)


@app.command("defaults")
def defaults() -> None:
    """
    Show default configuration values.
    """
    try:
        default_data = AppSettings().model_dump()
    except TypeError as exc:
        print(f"[red]Unable to construct default AppSettings:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    flat_defaults = flatten_dict(default_data)

    for key, value in flat_defaults.items():
        print(f"{key} = {value}")


@app.command("profiles")
def profiles() -> None:
    """
    List all available configuration profiles.
    """
    active_profile = get_active_profile_name()
    profiles_dir = get_profiles_dir()

    profile_names = sorted(profile_file.stem for profile_file in profiles_dir.glob("*.yaml"))

    if not profile_names:
        print("[yellow]No profiles found.[/yellow]")
        return

    for profile_name in profile_names:
        suffix = " (active)" if profile_name == active_profile else ""
        print(f"{profile_name}{suffix}")


# -----------------------------------------------------------------------------
# Core Write Commands
# -----------------------------------------------------------------------------


@app.command("set")
def set_value(key: str, value: str) -> None:
    """
    Set a configuration value with schema validation.
    """
    cmd_logger = get_context_logger(__name__, app="config", command="set")
    cmd_logger.info(
        "Setting configuration value",
        extra={"event": "config.set", "key": key},
    )

    valid, suggestions = validate_key(AppSettings, key)

    if not valid:
        cmd_logger.warning(
            "Invalid configuration key",
            extra={"event": "config.set.invalid_key", "key": key},
        )
        print(f"[red]Invalid key:[/red] {key}")
        if suggestions:
            print(f"Did you mean: {suggestions}")
        raise typer.Exit(code=1)

    expected_type = get_field_type(AppSettings, key)
    typed_value = cast_value(value, expected_type)

    config_path = get_config_path()
    data = load_yaml(config_path)

    set_nested(data, key, typed_value)
    save_yaml(config_path, data)

    try:
        load_settings()
    except Exception as exc:
        cmd_logger.exception(
            "Config became invalid after set",
            extra={"event": "config.set.failed", "key": key},
        )
        print(f"[red]Invalid config after set:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    cmd_logger.info(
        "Configuration value updated",
        extra={"event": "config.set.ok", "key": key},
    )
    print(f"[green]Set {key} = {typed_value}[/green]")

    show_profile_summary()


@app.command("unset")
def unset(key: str) -> None:
    """
    Remove a configuration value from the active profile.
    """
    valid, suggestions = validate_key(AppSettings, key)

    if not valid:
        print(f"[red]Invalid key:[/red] {key}")
        if suggestions:
            print(f"Did you mean: {suggestions}")
        raise typer.Exit(code=1)

    config_path = get_config_path()
    data = load_yaml(config_path)

    try:
        unset_nested(data, key)
        save_yaml(config_path, data)
        print(f"[green]Unset {key}[/green]")
    except KeyError:
        print("[yellow]Key not set[/yellow]")

    show_profile_summary()


@app.command("create")
def create(name: str) -> None:
    """
    Create a new configuration profile from the current active config.
    """
    validate_profile_name(name)

    profile_path = get_profile_path(name)

    if profile_path.exists():
        print(f"[red]Profile already exists:[/red] {name}")
        raise typer.Exit(code=1)

    current_data = load_settings().model_dump()
    current_data["profile"] = name
    save_yaml(profile_path, current_data)

    print(f"[green]Created profile:[/green] {name}")

    show_profile_summary()


@app.command("load")
def load(name: str) -> None:
    """
    Load a configuration profile as the active profile.
    """
    validate_profile_name(name)

    profile_path = get_profile_path(name)

    if not profile_path.exists():
        print(f"[red]Profile not found:[/red] {name}")
        raise typer.Exit(code=1)

    set_active_profile_name(name)
    print(f"[green]Loaded profile:[/green] {name}")

    show_profile_summary()


@app.command("remove")
def remove(name: str) -> None:
    """
    Remove a configuration profile.
    """
    validate_profile_name(name)

    active_profile = get_active_profile_name()

    if name == "default":
        print("[red]Cannot remove the default profile.[/red]")
        raise typer.Exit(code=1)

    if name == active_profile:
        print("[red]Cannot remove the active profile.[/red]")
        raise typer.Exit(code=1)

    profile_path = get_profile_path(name)

    if not profile_path.exists():
        print(f"[red]Profile not found:[/red] {name}")
        raise typer.Exit(code=1)

    if not typer.confirm(f"Remove profile '{name}'?"):
        raise typer.Exit()

    profile_path.unlink()
    print(f"[green]Removed profile:[/green] {name}")

    show_profile_summary()


# -----------------------------------------------------------------------------
# Reset / Initialization Commands
# -----------------------------------------------------------------------------


@app.command("reset")
def reset(name: Optional[str] = None) -> None:
    """
    Reset a profile to schema defaults.

    If no name is provided, resets the active profile.
    If a name is provided, resets that named profile.
    """
    target_profile = name or get_active_profile_name()

    validate_profile_name(target_profile)

    profile_path = get_profile_path(target_profile)
    if not profile_path.exists():
        print(f"[red]Profile not found:[/red] {target_profile}")
        raise typer.Exit(code=1)

    if name is None:
        confirm_message = (
            f"Reset active profile '{target_profile}' to defaults?"
        )
    else:
        confirm_message = (
            f"Reset profile '{target_profile}' to defaults?"
        )

    if not typer.confirm(confirm_message):
        raise typer.Exit()

    reset_profile(target_profile)
    print(f"[green]Reset profile:[/green] {target_profile}")


# -----------------------------------------------------------------------------
# Validation / Debug Commands
# -----------------------------------------------------------------------------


@app.command("diff")
def diff() -> None:
    """
    Show configuration values that differ from defaults.
    """
    current_values = flatten_dict(load_settings().model_dump())

    try:
        default_values = flatten_dict(AppSettings().model_dump())
    except TypeError as exc:
        print(f"[red]Unable to construct default AppSettings:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    changes: dict[str, tuple[object, object]] = {}

    all_keys = sorted(set(default_values.keys()) | set(current_values.keys()))
    for key in all_keys:
        default_value = default_values.get(key)
        current_value = current_values.get(key)

        if current_value != default_value:
            changes[key] = (default_value, current_value)

    if not changes:
        print("[green]No config differences from defaults.[/green]")
        return

    for key, (default_value, current_value) in changes.items():
        print(f"[bold]{key}[/bold]")
        print(f"  default = {default_value}")
        print(f"  current = {current_value}")
        print()


@app.command("validate")
def validate() -> None:
    """
    Validate the current configuration against the schema.
    """
    raise NotImplementedError("config validate not yet implemented")


# -----------------------------------------------------------------------------
# Provider Commands (Sub-App)
# -----------------------------------------------------------------------------


provider_app = typer.Typer(help="Provider configuration management.")


@provider_app.command("list")
def providers_list() -> None:
    """
    List all available providers.
    """
    raise NotImplementedError("config provider list not yet implemented")


@provider_app.command("enable")
def providers_enable(name: str) -> None:
    """
    Enable a provider.

    Args:
        name: Provider name
    """
    raise NotImplementedError("config provider enable not yet implemented")


@provider_app.command("disable")
def providers_disable(name: str) -> None:
    """
    Disable a provider.

    Args:
        name: Provider name
    """
    raise NotImplementedError("config provider disable not yet implemented")


@provider_app.command("show")
def providers_show(name: str) -> None:
    """
    Show configuration for a specific provider.

    Args:
        name: Provider name
    """
    raise NotImplementedError("config provider show not yet implemented")


@provider_app.command("test")
def provider_test(name: Optional[str] = None) -> None:
    """
    Test provider connectivity.

    Args:
        name: Optional provider name
    """
    raise NotImplementedError("config provider test not yet implemented")


app.add_typer(provider_app, name="provider")

def show_profile_summary() -> None:
    """
    Show available profiles and current config differences.
    """
    print()
    print("[bold]Profiles[/bold]")
    profiles()

    print()
    print("[bold]Diff[/bold]")
    diff()
