"""Config settings."""
# src/mindit/config/settings.py

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple, Type, Literal

import typer
import yaml
from pydantic import BaseModel, ConfigDict, Field, ValidationError


# =============================================================================
# bootstrap config root handling
# =============================================================================

from mindit.config.bootstrap import get_default_user_config_dir, get_env_config_dir  # noqa: E402
_CONFIG_ROOT_OVERRIDE: Path | None = None

# The archive DA is working in: a folder holding da-archive.yaml (see mindit.config.archive). When set,
# that file is the whole config and its folder is the data root; profiles aren't used.
ARCHIVE_FILE = "da-archive.yaml"
_ARCHIVE_ROOT: Path | None = None


def set_archive_root(path: str | Path | None) -> Path | None:
    """Make the archive at path (a folder holding da-archive.yaml) the active config, or clear it."""
    global _ARCHIVE_ROOT  # pylint: disable=global-statement
    _ARCHIVE_ROOT = Path(path).expanduser().resolve() if path else None
    return _ARCHIVE_ROOT


def get_archive_root() -> Path | None:
    """Return the active archive folder, or None when DA runs on a profile."""
    return _ARCHIVE_ROOT


# True when the old profile config was chosen on purpose (--config-dir, DA_CONFIG_DIR, a bootstrap ini).
# Without that and without an archive, archive commands refuse to run rather than guess.
_PROFILE_CHOSEN = False


def set_profile_chosen(value: bool) -> None:
    """Record whether the profile config was chosen explicitly."""
    global _PROFILE_CHOSEN  # pylint: disable=global-statement
    _PROFILE_CHOSEN = bool(value)


def is_profile_chosen() -> bool:
    """Return True when the profile config was chosen explicitly."""
    return _PROFILE_CHOSEN


def set_config_root(path: str | Path) -> Path:
    """
    Set the config root explicitly for the current process.

    This should be called very early during startup, before load_settings().

    Args:
        path: Root directory that will contain:
            - active_profile.txt
            - profiles/

    Returns:
        Resolved config root path.
    """
    global _CONFIG_ROOT_OVERRIDE  # pylint: disable=global-statement
    _CONFIG_ROOT_OVERRIDE = Path(path).expanduser().resolve()
    return _CONFIG_ROOT_OVERRIDE


def clear_config_root_override() -> None:
    """
    Clear the in-process config root override.
    """
    global _CONFIG_ROOT_OVERRIDE  # pylint: disable=global-statement
    _CONFIG_ROOT_OVERRIDE = None


def get_default_config_root() -> Path:
    """
    Return the default root directory for DA user config.

    Windows:
        %LOCALAPPDATA%/DA/user-config-dir (or the older %LOCALAPPDATA%/MindIt/user-config-dir
        while only that one exists)

    Fallback:
        ~/.da/user-config-dir
    """
    return get_default_user_config_dir()


def get_config_root() -> Path:
    """
    Return the root directory for DA user config.

    Resolution order:
        1. in-process override set by set_config_root()
        2. environment variable DA_CONFIG_DIR (or the older MINDIT_CONFIG_DIR)
        3. default OS/user location
    """
    if _CONFIG_ROOT_OVERRIDE is not None:
        return _CONFIG_ROOT_OVERRIDE

    env_value = get_env_config_dir()
    if env_value:
        return Path(env_value).expanduser().resolve()

    return get_default_config_root().resolve()


def get_profiles_dir() -> Path:
    """
    Return the directory that stores profile YAML files.
    """
    profiles_dir = get_config_root() / "profiles"
    profiles_dir.mkdir(parents=True, exist_ok=True)
    return profiles_dir


def get_active_profile_pointer_path() -> Path:
    """
    Return the file that stores the active profile name.
    """
    return get_config_root() / "active_profile.txt"


def get_profile_path(name: str) -> Path:
    """
    Return the YAML path for a named profile.
    """
    validate_profile_name(name)
    return get_profiles_dir() / f"{name}.yaml"


def get_active_profile_path() -> Path:
    """
    Return the active profile pointer path.

    Kept for backward compatibility with older callers.
    """
    return get_active_profile_pointer_path()


def get_active_profile_name() -> str:
    """
    Return the currently active profile name.
    """
    ensure_config_system()

    pointer_path = get_active_profile_pointer_path()
    profile_name = pointer_path.read_text(encoding="utf-8").strip()
    return profile_name or "default"


def set_active_profile_name(name: str) -> None:
    """
    Persist the currently active profile name.
    """
    validate_profile_name(name)

    pointer_path = get_active_profile_pointer_path()
    pointer_path.parent.mkdir(parents=True, exist_ok=True)
    pointer_path.write_text(name, encoding="utf-8")


def get_config_path() -> Path:
    """
    Return the active config YAML: the archive's da-archive.yaml, else the active profile.
    """
    if _ARCHIVE_ROOT is not None:
        return _ARCHIVE_ROOT / ARCHIVE_FILE
    active_name = get_active_profile_name()
    return get_profile_path(active_name)


def get_config_dir() -> Path:
    """
    Return the directory containing the active config file.
    """
    return get_config_path().parent


def validate_profile_name(name: str) -> None:
    """
    Validate profile name.

    Args:
        name: Candidate profile name.

    Raises:
        ValueError: If the name contains invalid characters.
    """
    if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
        raise ValueError(
            "Profile names may contain only letters, numbers, '-' and '_'."
        )

# =============================================================================
# module-specific resolved path helpers
# =============================================================================

def get_documents_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved documents root path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.paths.documents, loaded)

def get_rename_pattern(module_name: str, settings: AppSettings | None = None) -> str:
    """
    Return the rename pattern for a given module.

    Example:
        "{date_taken:%Y%m%d}_{hash:8}"
    """
    loaded = settings or load_settings()
    module_settings = getattr(loaded.modules, module_name, None)

    if not module_settings:
        raise ValueError(f"No settings found for module: {module_name}")

    return getattr(module_settings, "pattern", "{date_taken:%Y%m%d}_{hash:8}")

# ---------------------------------------------------------------------------
# DA path helpers
# ---------------------------------------------------------------------------
def resolve_database_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved DA SQLite database path.

    Expected:
        <data_root>/.da/da.sqlite
    Example:
        D:/jane-archive/.da/da.sqlite
    """
    loaded = settings or load_settings()
    data_root_path = get_data_root_path(loaded)

    return (data_root_path / ".da" / "da.sqlite").resolve()


# Older name, kept for existing callers.
resolve_mindit_database_path = resolve_database_path

# ---------------------------------------------------------------------------
# ScanIt path helpers
# ---------------------------------------------------------------------------

def resolve_scanit_intake_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved ScanIt input scans path.

    Expected model:
        paths.intake + modules.scanit.intake_root
    Example:
        intake + scans -> D:/jane-archive/intake/scans
    """
    loaded = settings or load_settings()
    intake_path = get_intake_path(loaded)
    return (intake_path / loaded.modules.scanit.intake_root).resolve()


def resolve_scanit_organized_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved ScanIt organized documents path.

    Expected model:
        paths.documents + modules.scanit.organized_root
    Example:
        documents + organized -> D:/jane-archive/documents/organized
    """
    loaded = settings or load_settings()
    documents_path = get_documents_path(loaded)
    return (documents_path / loaded.modules.scanit.organized_root).resolve()


def resolve_scanit_quarantine_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved ScanIt quarantine documents path.

    Expected model:
        paths.documents + modules.scanit.quarantine_root
    Example:
        documents + quarantine -> D:/jane-archive/documents/quarantine
    """
    loaded = settings or load_settings()
    documents_path = get_documents_path(loaded)
    return (documents_path / loaded.modules.scanit.quarantine_root).resolve()


def resolve_scanit_output_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved ScanIt output path.

    Expected model:
        modules.scanit.output_root relative to data_root
    Example:
        output/scanit-out -> D:/jane-archive/output/scanit-out
    """
    loaded = settings or load_settings()
    documents_path = get_documents_path(loaded)
    return (documents_path / loaded.modules.scanit.output_root).resolve()



# ---------------------------------------------------------------------------
# PhotoIt path helpers
# ---------------------------------------------------------------------------

def resolve_photoit_intake_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PhotoIt intake path.

    Preferred model:
        paths.intake + modules.photoit.intake_root
    Example:
        intake + scanit -> D:/jane-archive/intake/scans
    """
    loaded = settings or load_settings()
    intake_path = get_intake_path(loaded)
    return (intake_path / loaded.modules.photoit.intake_root).resolve()
    


def resolve_photoit_organized_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PhotoIt organized photos path.

    Expected model:
        paths.photos + modules.photoit.organized_root
    Example:
        photos + organized -> D:/jane-archive/photos/organized
    """
    loaded = settings or load_settings()
    photos_path = get_photos_path(loaded)
    return (photos_path / loaded.modules.photoit.organized_root).resolve()


def resolve_photoit_quarantine_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PhotoIt quarantine photos path.

    Expected model:
        paths.photos + modules.photoit.quarantine_root
    Example:
        photos + quarantine -> D:/jane-archive/photos/quarantine
    """
    loaded = settings or load_settings()
    photos_path = get_photos_path(loaded)
    return (photos_path / loaded.modules.photoit.quarantine_root).resolve()


def resolve_photoit_output_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PhotoIt output path.

    Expected model:
        modules.photoit.output_root relative to data_root
    Example:
        output/photoit-out -> D:/jane-archive/output/photoit-out
    """
    loaded = settings or load_settings()
    photos_path = get_photos_path(loaded)
    return (photos_path / loaded.modules.photoit.output_root).resolve()


# ---------------------------------------------------------------------------
# PackIt path helpers
# ---------------------------------------------------------------------------

def resolve_packit_rooms_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PackIt rooms path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.modules.packit.rooms_root, loaded)


def resolve_packit_reports_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PackIt reports path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.modules.packit.reports_root, loaded)


def resolve_packit_qr_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PackIt QR output path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.modules.packit.qr_root, loaded)


def resolve_packit_output_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved PackIt output path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.modules.packit.output_root, loaded)


# =============================================================================
# pydantic settings models
# =============================================================================

class GeneralSettings(BaseModel):
    """General application settings."""
    model_config = ConfigDict(extra="forbid")

    debug: bool = False
    datetime_format: str = "%y%m%d_%H%M%S"


class PathSettings(BaseModel):
    """Shared filesystem path configuration."""
    model_config = ConfigDict(extra="forbid")

    # Canonical base for operational data.
    # All relative module/log/output paths should resolve from here.
    data_root: str = "."

    # Shared logical roots under data_root.
    metadata: str = "metadata"
    photos: str = "photos"
    documents: str = "documents"
    intake: str = "intake"
    exports: str = "exports"
    logs: str = "logs"
    output: str = "output"
    
class FeedbackSettings(BaseModel):
    """User feedback settings."""
    model_config = ConfigDict(extra="forbid")
    
    enabled: bool = True
    chime_start: bool = True
    chime_done: bool = True


class LogSettings(BaseModel):
    """Logging configuration."""
    model_config = ConfigDict(extra="forbid")

    root: str = "logs"
    level: str = "INFO"

    console_enabled: bool = True
    json_enabled: bool = True

    shared_log_enabled: bool = True
    shared_log_name: str = "da.jsonl"

    per_app_logs_enabled: bool = False

    rotate_enabled: bool = True
    rotate_when: Literal["size", "daily"] = "size"
    rotate_max_bytes: int = 5_000_000
    rotate_backup_count: int = 10

    archive_dir: str = "logs/archive"
    archive_timestamp_format: str = "%Y%m%d-%H%M%S"


class WatchSettings(BaseModel):
    """Filesystem watch configuration."""
    model_config = ConfigDict(extra="forbid")

    roots: list[str] = ["D:/mindit"]


class LocalProviderSettings(BaseModel):
    """Local provider settings."""
    model_config = ConfigDict(extra="forbid")

    # When blank, callers should fall back to paths.data_root.
    root: str = ""


class GoogleDriveSettings(BaseModel):
    """Settings for the Google Drive storage provider."""
    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    root_folder_id: str = ""
    credentials_file: str = ".secrets/credentials.json"
    service_account_file: str = ".secrets/service_account.json"
    token_file: str = ".secrets/token.pickle"


class GooglePhotosSettings(BaseModel):
    """Google Photos settings."""
    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    album_base: str = "mindit"


class StorageSettings(BaseModel):
    """Storage settings."""
    model_config = ConfigDict(extra="forbid")

    default_read: str = "local"
    default_write: str = "local"


class ProviderSettings(BaseModel):
    """Provider configuration settings."""
    model_config = ConfigDict(extra="forbid")

    local: LocalProviderSettings = Field(default_factory=LocalProviderSettings)
    google_drive: GoogleDriveSettings = Field(default_factory=GoogleDriveSettings)
    google_photos: GooglePhotosSettings = Field(default_factory=GooglePhotosSettings)


class BoxSettings(BaseModel):
    """PackIt box template, validation, and export settings."""
    model_config = ConfigDict(extra="forbid")

    template_version: str = "R2"
    template_id: str = "1b7ddjnYonf6-DZI1dbkbK4IPcDytAGS3wM9n-ggjDhk"
    contents_table_name: str = "Contents"
    metadata_marker: str = "Metadata:"
    parent_folder_delimiter: str = "-"
    parent_folder_room_index: int = 0
    parent_folder_abbr_index: int = 1
    parent_folder_tape_index: int = 2
    heavy_threshold: float = 20.0
    updated_format: str = "%y%m%d_%H%M"
    required_metadata_fields: list[str] = [
        "Room",
        "Abbr",
        "Box#",
        "Template",
        "Tape",
        "Fragile",
        "Heavy",
        "Updated",
    ]


class PackItSettings(BaseModel):
    """PackIt module settings."""
    model_config = ConfigDict(extra="forbid")

    rooms_root: str = "packit/rooms"
    reports_root: str = "packit/reports"
    qr_root: str = "packit/qrcodes"
    output_root: str = "packit/output"

    box: BoxSettings = Field(default_factory=BoxSettings)


class ScanItSettings(BaseModel):
    """ScanIt module settings."""
    model_config = ConfigDict(extra="forbid")

    intake_root: str = "scans"
    organized_root: str = "organized"
    quarantine_root: str = "quarantine"
    output_root: str = "documents"
    metadata_marker: str = "Metadata:"
    required_metadata_fields: list[str] = [
        "Name",
        "Date",
        "Tags",
    ]
    updated_format: str = "%y%m%d_%H%M"
    quarantine_duplicates: bool = True
    pattern: str = "{date_taken:%Y%m%d}_{hash:8}"


class PhotoItSettings(BaseModel):
    """PhotoIt module settings."""
    model_config = ConfigDict(extra="forbid")

    intake_root: str = "scans"
    organized_root: str = "organized"
    quarantine_root: str = "quarantine"
    output_root: str = "photos"
    metadata_marker: str = "Metadata:"
    required_metadata_fields: list[str] = [
        "Name",
        "Date",
        "Tags",
    ]
    updated_format: str = "%y%m%d_%H%M"
    quarantine_duplicates: bool = True
    pattern: str = "{date_taken:%Y%m%d}_{hash:8}"


class ArchiveSettings(BaseModel):
    """Who and what an archive is for."""
    model_config = ConfigDict(extra="forbid")

    name: str = ""
    # Capture years this archive takes, e.g. "1990-1999"; photos dated outside stay in intake.
    years: str | None = None


class LocationSettings(BaseModel):
    """Places for GPS photos (`da location`)."""
    model_config = ConfigDict(extra="forbid")

    # "nominatim" looks places up with OpenStreetMap (only a rounded spot is sent); "off" never does.
    lookup: Literal["nominatim", "off"] = "nominatim"
    # How location folders are named (`da location group`, coming soon).
    folder: str = "{YYYY}-{MM} {title} ({place})"
    # Rounding for the spot cache: 3 decimals is about 100 m.
    spot_digits: int = Field(default=3, ge=2, le=5)


# The folders under intake\ and what DA files from each: a scanned .jpg in intake\scans is a document.
DEFAULT_INTAKE_FOLDERS: dict[str, str] = {"photos": "photo", "docs": "document", "scans": "document"}


class ModulesSettings(BaseModel):
    """Modules settings."""
    model_config = ConfigDict(extra="forbid")

    packit: PackItSettings = Field(default_factory=PackItSettings)
    scanit: ScanItSettings = Field(default_factory=ScanItSettings)
    photoit: PhotoItSettings = Field(default_factory=PhotoItSettings)


class AppSettings(BaseModel):
    """Root configuration model for DA."""
    model_config = ConfigDict(extra="forbid")

    profile: str = "default"

    archive: ArchiveSettings = Field(default_factory=ArchiveSettings)
    # Folder under intake\ -> "photo" or "document".
    intake: dict[str, Literal["photo", "document"]] = Field(default_factory=lambda: dict(DEFAULT_INTAKE_FOLDERS))
    # Who owned each camera, for owner: tags: "Apple iPhone 12 Pro": jane, or one body "Nikon D90 #3012345": sam.
    cameras: dict[str, str] = Field(default_factory=dict)
    location: LocationSettings = Field(default_factory=LocationSettings)
    general: GeneralSettings = Field(default_factory=GeneralSettings)
    feedback: FeedbackSettings = Field(default_factory=FeedbackSettings)
    paths: PathSettings = Field(default_factory=PathSettings)
    logs: LogSettings = Field(default_factory=LogSettings)
    watch: WatchSettings = Field(default_factory=WatchSettings)

    agents: dict[str, str] = Field(
        default_factory=lambda: {
            "intake/documents": "DocumentAgent",
            "intake/camera": "CameraAgent",
            "intake/downloads": "DownloadsAgent",
            "intake/phone": "PhoneAgent",
            "intake/scanner": "ScannerAgent",
        }
    )

    storage: StorageSettings = Field(default_factory=StorageSettings)
    providers: ProviderSettings = Field(default_factory=ProviderSettings)
    modules: ModulesSettings = Field(default_factory=ModulesSettings)


# =============================================================================
# path resolution helpers
# =============================================================================

def _resolve_relative_to(base: Path, value: str | Path) -> Path:
    """
    Resolve value against a base path unless value is already absolute.
    """
    candidate = Path(value).expanduser()
    if candidate.is_absolute():
        return candidate.resolve()
    return (base / candidate).resolve()


def resolve_config_relative_path(path_str: str | Path) -> Path:
    """
    Resolve a path relative to the active config directory.

    Use this for:
        - credentials files
        - token files
        - profile-adjacent artifacts
        - .secrets/*
    """
    return _resolve_relative_to(get_config_dir(), path_str)


def get_data_root_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved operational data root.

    Resolution:
        - absolute paths.data_root -> use directly
        - relative paths.data_root -> resolve relative to config dir
    """
    loaded = settings or load_settings()
    return resolve_config_relative_path(loaded.paths.data_root)


def resolve_data_path(
    path_str: str | Path,
    settings: AppSettings | None = None,
) -> Path:
    """
    Resolve an operational data path relative to paths.data_root.

    Use this for:
        - inbox
        - processed
        - exports
        - logs
        - module roots
        - output folders
        - quarantine folders
    """
    candidate = Path(path_str).expanduser()
    if candidate.is_absolute():
        return candidate.resolve()

    data_root = get_data_root_path(settings=settings)
    return (data_root / candidate).resolve()


def get_local_provider_root_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved local provider root.

    If providers.local.root is blank, fall back to paths.data_root.
    If providers.local.root is relative, resolve it relative to config dir.
    """
    loaded = settings or load_settings()
    configured = loaded.providers.local.root.strip()

    if not configured:
        return get_data_root_path(loaded)

    return resolve_config_relative_path(configured)


def get_logs_root_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved logs root path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.logs.root, loaded)


def get_logs_archive_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved logs archive path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.logs.archive_dir, loaded)


def get_intake_folders(settings: AppSettings | None = None) -> dict[Path, str]:
    """Return each configured intake folder's resolved path and the kind of file it holds."""
    loaded = settings or load_settings()
    intake = get_intake_path(loaded)
    return {(intake / name).resolve(): kind for name, kind in loaded.intake.items()}


def get_intake_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved shared intake path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.paths.intake, loaded)




def get_metadata_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved metadata path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.paths.metadata, loaded)


def get_photos_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved photos path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.paths.photos, loaded)


def get_exports_path(settings: AppSettings | None = None) -> Path:
    """
    Return the resolved exports path.
    """
    loaded = settings or load_settings()
    return resolve_data_path(loaded.paths.exports, loaded)


# =============================================================================
# schema / flatten helpers
# =============================================================================

def flatten_dict(data: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    """
    Flatten a nested dictionary into dot-notation keys.
    """
    result: dict[str, Any] = {}

    for key, value in data.items():
        new_key = f"{prefix}.{key}" if prefix else key

        if isinstance(value, dict):
            result.update(flatten_dict(value, new_key))
        else:
            result[new_key] = value

    return result


def flatten_model(model: Type[BaseModel], prefix: str = "") -> Dict[str, Any]:
    """
    Flatten a Pydantic model into dot-notation keys.

    Returns:
        Dictionary mapping dot-notation key to field info.
    """
    result: dict[str, Any] = {}

    for name, field in model.model_fields.items():
        key = f"{prefix}.{name}" if prefix else name
        field_type = field.annotation

        if hasattr(field_type, "model_fields"):
            result.update(flatten_model(field_type, key))  # type: ignore[arg-type]
        else:
            result[key] = field

    return result


def validate_key(model: Type[BaseModel], key: str) -> Tuple[bool, List[str]]:
    """
    Validate a dot-notation key against schema.

    Returns:
        Tuple of (is_valid, suggestions)
    """
    flat = flatten_model(model)

    if key in flat:
        return True, []

    suggestions = [
        candidate
        for candidate in flat
        if key in candidate or candidate.endswith(key.split(".")[-1])
    ]
    return False, suggestions[:5]


def get_field_type(model: Type[BaseModel], key: str) -> Any:
    """
    Get expected Python type for a dot-notation key.
    """
    flat = flatten_model(model)
    field = flat.get(key)

    if not field:
        return None

    return field.annotation


def cast_value(value: str, expected_type: Any) -> Any:
    """
    Cast string input to the schema-defined type.
    """
    try:
        if expected_type is bool:
            return value.lower() in {"true", "1", "yes"}

        if expected_type is int:
            return int(value)

        if expected_type is float:
            return float(value)

        if expected_type is list[str]:
            return [item.strip() for item in value.split(",") if item.strip()]

    except (ValueError, TypeError, ValidationError) as exc:
        print(f"[red]Invalid config after set:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    return value


def infer_type(value: str) -> Any:
    """
    Convert string input into an appropriate Python type.
    """
    lowered = value.lower()

    if lowered in {"true", "false"}:
        return lowered == "true"

    if lowered in {"none", "null"}:
        return None

    try:
        return int(value)
    except ValueError:
        pass

    try:
        return float(value)
    except ValueError:
        pass

    return value


# =============================================================================
# yaml helpers
# =============================================================================

def load_yaml(path: Path) -> Dict[str, Any]:
    """
    Load YAML file into a dictionary.

    Returns:
        Empty dict if file does not exist.
    """
    if not path.exists():
        return {}

    with path.open("r", encoding="utf-8") as file:
        return yaml.safe_load(file) or {}


def save_yaml(path: Path, data: Dict[str, Any]) -> None:
    """
    Save a dictionary to YAML file.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8") as file:
        yaml.safe_dump(data, file, sort_keys=False)


# =============================================================================
# nested dict helpers
# =============================================================================

def get_nested(data: Dict[str, Any], key: str) -> Any:
    """
    Retrieve a value using a dot-notation key.

    Example:
        get_nested(data, "a.b.c")
    """
    keys = key.split(".")
    current: Any = data

    for part in keys:
        if not isinstance(current, dict) or part not in current:
            raise KeyError(f"Key not found: {key}")
        current = current[part]

    return current


def set_nested(data: Dict[str, Any], key: str, value: Any) -> None:
    """
    Set a value using a dot-notation key.

    Creates nested dictionaries as needed.
    """
    keys = key.split(".")
    current = data

    for part in keys[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]

    current[keys[-1]] = value


def unset_nested(data: Dict[str, Any], key: str) -> None:
    """
    Remove a key using dot-notation.
    """
    keys = key.split(".")
    current = data

    for part in keys[:-1]:
        if part not in current:
            raise KeyError(f"Key not found: {key}")
        current = current[part]

    if keys[-1] not in current:
        raise KeyError(f"Key not found: {key}")

    del current[keys[-1]]


# =============================================================================
# profile / settings loading
# =============================================================================

def write_default_profile(name: str = "default") -> Path:
    """
    Create a default profile YAML if it does not exist.
    """
    profile_path = get_profile_path(name)

    if not profile_path.exists():
        config = AppSettings(profile=name)
        save_yaml(profile_path, config.model_dump())

    return profile_path


def ensure_profile_exists(name: str) -> Path:
    """
    Ensure a profile YAML exists. If missing, create it from defaults.
    """
    profile_path = get_profile_path(name)

    if not profile_path.exists():
        default_data = AppSettings(profile=name).model_dump()
        save_yaml(profile_path, default_data)

    return profile_path


def ensure_config_system() -> None:
    """
    Ensure the DA config root, profiles directory, active profile
    pointer, and default profile all exist.
    """
    config_root = get_config_root()
    profiles_dir = get_profiles_dir()

    config_root.mkdir(parents=True, exist_ok=True)
    profiles_dir.mkdir(parents=True, exist_ok=True)

    pointer_path = get_active_profile_pointer_path()
    if not pointer_path.exists():
        pointer_path.write_text("default", encoding="utf-8")

    default_profile_path = get_profile_path("default")
    if not default_profile_path.exists():
        default_settings = AppSettings(profile="default")
        save_yaml(default_profile_path, default_settings.model_dump())


def _apply_backward_compatibility_defaults(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize older profile layouts to the newer path model.

    This keeps existing configs working while introducing:
        - paths.data_root
        - paths.logs
        - modules.photoit.intake_root

    Rules:
        - if paths.data_root is missing:
            prefer providers.local.root when set,
            otherwise default to "."
        - if paths.logs is missing:
            derive from logs.root when present, else "logs"
        - if modules.photoit.intake_root is missing:
            copy from paths.camera_inbox when present
    """
    normalized = dict(data)

    paths = dict(normalized.get("paths", {}) or {})
    providers = dict(normalized.get("providers", {}) or {})
    logs = dict(normalized.get("logs", {}) or {})
    modules = dict(normalized.get("modules", {}) or {})

    local_provider = dict(providers.get("local", {}) or {})
    photoit = dict(modules.get("photoit", {}) or {})

    if "data_root" not in paths:
        local_root = str(local_provider.get("root", "")).strip()
        paths["data_root"] = local_root if local_root else "."

    if "logs" not in paths:
        logs_root = str(logs.get("root", "")).strip()
        paths["logs"] = logs_root if logs_root else "logs"

    if "intake_root" not in photoit:
        camera_inbox = str(paths.get("camera_inbox", "inbox/camera")).strip()
        photoit["intake_root"] = camera_inbox if camera_inbox else "inbox/camera"

    modules["photoit"] = photoit
    normalized["paths"] = paths
    normalized["modules"] = modules

    return normalized


def load_settings() -> AppSettings:
    """
    Load settings from the active profile YAML.

    Auto-creates config folders and default profile if missing. In an archive, da-archive.yaml is
    the whole config and its folder is the data root.
    """
    if _ARCHIVE_ROOT is not None:
        archive_file = _ARCHIVE_ROOT / ARCHIVE_FILE
        try:
            data = load_yaml(archive_file)
            data.setdefault("paths", {})["data_root"] = "."
            data["profile"] = (data.get("archive") or {}).get("name") or _ARCHIVE_ROOT.name
            return AppSettings.model_validate(data)
        except yaml.YAMLError as error:          # a hand edit broke it: say where, not a traceback
            mark = getattr(error, "problem_mark", None)
            where = f"line {mark.line + 1}" if mark else "somewhere"
            problem = getattr(error, "problem", None) or "it isn't valid YAML"
            raise SystemExit(f"{archive_file} can't be read ({where}: {problem}). Fix that line - keep the "
                             "spaces at the start of each line as they were - or put back your copy.") from None
        except (AttributeError, ValidationError) as error:
            detail = "; ".join(f"{'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in error.errors()) \
                if isinstance(error, ValidationError) else "its layout isn't what DA expects"
            raise SystemExit(f"{archive_file} has a setting DA doesn't understand ({detail}). "
                             "Fix it, or put back your copy.") from None

    ensure_config_system()

    active_name = get_active_profile_name()
    profile_path = get_profile_path(active_name)

    if not profile_path.exists():
        default_settings = AppSettings(profile=active_name)
        save_yaml(profile_path, default_settings.model_dump())

    data = load_yaml(profile_path)
    #data = _apply_backward_compatibility_defaults(data)
    data["profile"] = active_name

    return AppSettings.model_validate(data)


def reset_profile(name: str) -> Path:
    """
    Reset a profile to schema defaults.
    """
    validate_profile_name(name)

    profile_path = get_profile_path(name)
    data = AppSettings(profile=name).model_dump()
    save_yaml(profile_path, data)

    return profile_path
