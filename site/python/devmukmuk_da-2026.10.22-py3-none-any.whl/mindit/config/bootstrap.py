# src/mindit/config/bootstrap.py

from __future__ import annotations

import os
import sys
from configparser import ConfigParser
from pathlib import Path


APP_NAME = "DA"
# Names from before the MindIt -> DA rename, still honored so existing installs keep working.
LEGACY_APP_NAME = "MindIt"
ENV_VARS = ("DA_CONFIG_DIR", "MINDIT_CONFIG_DIR")
BOOTSTRAP_FILES = (("da-bootstrap.ini", "da"), ("mindit-bootstrap.ini", "mindit"))


def get_app_base_dir() -> Path:
    """
    Return the directory where the app is running from.
    Works for both dev and frozen exe.
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent

    return Path.cwd().resolve()


def get_default_user_config_dir() -> Path:
    """
    Default long-term config location.
    Windows example:
        C:/Users/<user>/AppData/Local/DA/user-config-dir
    An existing .../MindIt/user-config-dir is used when the DA one doesn't exist yet.
    """
    local_appdata = os.environ.get("LOCALAPPDATA", "").strip()
    base = Path(local_appdata) if local_appdata else Path.home()

    def location(name: str) -> Path:
        return (base / name if local_appdata else base / f".{name.lower()}") / "user-config-dir"

    current, legacy = location(APP_NAME), location(LEGACY_APP_NAME)
    if not current.exists() and legacy.exists():
        return legacy
    return current


def get_env_config_dir() -> str:
    """Return the config dir from DA_CONFIG_DIR (or the older MINDIT_CONFIG_DIR), or ''."""
    for name in ENV_VARS:
        value = os.environ.get(name, "").strip()
        if value:
            return value
    return ""


def get_bootstrap_file_path() -> Path:
    """
    Look for a bootstrap file next to the exe or current run location:
    da-bootstrap.ini, else the older mindit-bootstrap.ini.
    """
    base = get_app_base_dir()
    for file_name, _section in BOOTSTRAP_FILES:
        if (base / file_name).exists():
            return base / file_name
    return base / BOOTSTRAP_FILES[0][0]


def read_bootstrap_config_dir() -> Path | None:
    """
    Read config_dir from da-bootstrap.ini (or mindit-bootstrap.ini) if present.

    Example file:
        [da]
        config_dir = D:/jane-archive/config
    """
    path = get_bootstrap_file_path()
    if not path.exists():
        return None

    parser = ConfigParser()
    parser.read(path, encoding="utf-8")

    raw = ""
    for _file_name, section in BOOTSTRAP_FILES:
        raw = parser.get(section, "config_dir", fallback="").strip()
        if raw:
            break
    if not raw:
        return None

    return Path(raw).expanduser().resolve()


def resolve_user_config_dir(cli_config_dir: str | None = None) -> Path:
    """
    Resolve the user-config-dir using precedence:
    CLI > ENV > bootstrap ini > default
    """
    if cli_config_dir:
        return Path(cli_config_dir).expanduser().resolve()

    env_value = get_env_config_dir()
    if env_value:
        return Path(env_value).expanduser().resolve()

    bootstrap_value = read_bootstrap_config_dir()
    if bootstrap_value:
        return bootstrap_value

    return get_default_user_config_dir()
