"""Storage provider abstract base classes."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ItemRef:
    """
    Reference to a storage item.
    """
    id: str
    name: str
    path: str
    is_folder: bool


@dataclass(frozen=True)
class ItemCountRef(ItemRef):
    """
    Reference to a storage item with an associated child count.
    """
    count: int = 0


class StorageProvider(ABC):
    """
    Abstract storage provider interface.
    """

    @abstractmethod
    def ensure_folder(self, path: str) -> ItemRef:
        """
        Ensure a folder exists and return a reference to it.
        """

    @abstractmethod
    def test_connection(self) -> dict[str, Any]:
        """
        Verify provider connectivity and return diagnostic details.
        """

    @abstractmethod
    def list_items(self, path: str) -> list[ItemRef]:
        """
        List items directly under a folder.
        """

    @abstractmethod
    def list_items_with_counts(self, path: str) -> list[ItemCountRef]:
        """
        List items directly under a folder, including child counts for folders.
        """

    @abstractmethod
    def write_text(self, path: str, content: str) -> None:
        """
        Write a text file.
        """

    @abstractmethod
    def read_text(self, path: str) -> str:
        """
        Read a text file.
        """
