"""registry"""
# src/mindit/providers/registry.py

from mindit.config.settings import load_settings
from mindit.providers.local_fs import LocalFileSystemProvider
from mindit.providers.base import StorageProvider

def get_storage_provider(name: str | None = None) -> StorageProvider:
    """get provider based on settings"""
    settings = load_settings()
    provider_name = name or settings.storage.default_read

    if provider_name == "local":
        return LocalFileSystemProvider(settings.providers.local.root)

    if provider_name == "google_drive":
        # Google's libraries are an extra (pip install devmukmuk-da[google]): load them only when asked for.
        from mindit.providers.google.clients import get_drive_service  # pylint: disable=import-outside-toplevel
        from mindit.providers.google_drive import GoogleDriveProvider  # pylint: disable=import-outside-toplevel

        service_drive = get_drive_service(auth_type="oauth")
        return GoogleDriveProvider(
            service_drive,
            settings.providers.google_drive.root_folder_id,
        )

    raise ValueError(f"Unsupported provider: {provider_name}")
