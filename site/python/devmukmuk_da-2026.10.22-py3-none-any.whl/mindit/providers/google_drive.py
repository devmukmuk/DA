"""Google Drive storage provider."""
# src/mindit/providers/google_drive.py

from __future__ import annotations

import io
from dataclasses import dataclass
from typing import Any, Optional

from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload, MediaInMemoryUpload

from mindit.providers.base import ItemCountRef, ItemRef, StorageProvider


FOLDER_MIME = "application/vnd.google-apps.folder"
BOX_MIME_TYPE = "application/vnd.google-apps.spreadsheet"
TEXT_MIME = "text/plain"


class GoogleDriveProviderError(RuntimeError):
    """Raised when a Google Drive provider operation fails."""


@dataclass(slots=True)
class _DriveNode:
    """Internal representation of a resolved Drive item."""

    id: str
    name: str
    mime_type: str
    parents: list[str]

    @property
    def is_folder(self) -> bool:
        """_summary_

        Returns:
            bool: _description_
        """
        return self.mime_type == FOLDER_MIME


class GoogleDriveProvider(StorageProvider):
    """
    Google Drive-backed implementation of StorageProvider.
    """

    def __init__(self, service, root_folder_id: str):
        self.service = service
        self.root_folder_id = root_folder_id

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    def ensure_folder(self, path: str) -> ItemRef:
        """
        Ensure a folder path exists under the provider root.
        """
        if not path or path.strip("/") == "":
            root = self._get_item(self.root_folder_id)
            return self._to_item_ref(root, full_path="")

        parts = self._split_path(path)
        parent_id = self.root_folder_id
        current: Optional[_DriveNode] = None

        for part in parts:
            current = self._find_child_by_name(parent_id=parent_id, name=part)
            if current is None:
                current = self._create_folder(parent_id=parent_id, name=part)
            elif not current.is_folder:
                raise GoogleDriveProviderError(
                    f"Path component '{part}' exists but is not a folder."
                )
            parent_id = current.id

        if current is None:
            raise GoogleDriveProviderError(f"Failed to ensure folder: {path}")

        return self._to_item_ref(current, full_path=path)

    def test_connection(self) -> dict[str, Any]:
        """
        Verify Google Drive API access and validate configured root folder.
        """
        result: dict[str, Any] = {
            "provider": "google_drive",
            "connected": False,
            "root_folder_id": self.root_folder_id,
        }

        try:
            about = (
                self.service.about()
                .get(fields="user(displayName,emailAddress), storageQuota(limit,usage)")
                .execute()
            )

            result["account"] = about.get("user", {})
            result["storage_quota"] = about.get("storageQuota", {})

            if self.root_folder_id == "root":
                root_meta = (
                    self.service.files()
                    .get(fileId="root", fields="id,name,mimeType")
                    .execute()
                )
            else:
                root_meta = (
                    self.service.files()
                    .get(
                        fileId=self.root_folder_id,
                        fields="id,name,mimeType,parents",
                        supportsAllDrives=True,
                    )
                    .execute()
                )

            result["root"] = root_meta
            result["connected"] = True
            result["root_valid"] = True
            result["root_is_folder"] = root_meta.get("mimeType") == FOLDER_MIME
            return result

        except HttpError as exc:
            result["error"] = str(exc)
            return result
        except Exception as exc:  # pylint: disable=broad-exception-caught
            result["error"] = str(exc)
            return result

    def list_items(self, path: str) -> list[ItemRef]:
        """
        List items under a folder.
        """
        folder = self._resolve_folder(path) if path else self._get_item(self.root_folder_id)

        if not folder.is_folder:
            raise GoogleDriveProviderError(f"Path '{path}' is not a folder.")

        results = (
            self.service.files()
            .list(
                q=f"'{folder.id}' in parents and trashed = false",
                spaces="drive",
                fields="files(id,name,mimeType,parents)",
                orderBy="name_natural",
                pageSize=1000,
                supportsAllDrives=True,
                includeItemsFromAllDrives=True,
            )
            .execute()
        )

        items: list[ItemRef] = []
        base_path = "/".join(self._split_path(path)) if path else ""

        for file in results.get("files", []):
            node = _DriveNode(
                id=file["id"],
                name=file["name"],
                mime_type=file["mimeType"],
                parents=file.get("parents", []),
            )
            item_path = f"{base_path}/{node.name}" if base_path else node.name
            items.append(self._to_item_ref(node, full_path=item_path))

        return items

    def list_items_with_counts(self, path: str) -> list[ItemCountRef]:
        """
        List items under a folder with child counts for folder items.
        """
        folder = self._resolve_folder(path) if path else self._get_item(self.root_folder_id)

        if not folder.is_folder:
            raise GoogleDriveProviderError(f"Path '{path}' is not a folder.")

        results = (
            self.service.files()
            .list(
                q=f"'{folder.id}' in parents and trashed = false",
                spaces="drive",
                fields="files(id,name,mimeType,parents)",
                orderBy="name_natural",
                pageSize=1000,
                supportsAllDrives=True,
                includeItemsFromAllDrives=True,
            )
            .execute()
        )

        items: list[ItemCountRef] = []
        base_path = "/".join(self._split_path(path)) if path else ""

        for file in results.get("files", []):
            node = _DriveNode(
                id=file["id"],
                name=file["name"],
                mime_type=file["mimeType"],
                parents=file.get("parents", []),
            )
            item_path = f"{base_path}/{node.name}" if base_path else node.name

            count = 0
            if node.is_folder:
                child_results = (
                    self.service.files()
                    .list(
                        q=(
                            f"'{node.id}' in parents and "
                            f"trashed = false and "
                            f"mimeType = '{BOX_MIME_TYPE}'"
                        ),
                        spaces="drive",
                        fields="files(id)",
                        pageSize=1000,
                        supportsAllDrives=True,
                        includeItemsFromAllDrives=True,
                    )
                    .execute()
                )
                count = len(child_results.get("files", []))

            items.append(
                self._to_item_count_ref(
                    node=node,
                    full_path=item_path,
                    count=count,
                )
            )

        return items

    def write_text(self, path: str, content: str) -> None:
        """
        Write a UTF-8 text file to Google Drive.
        """
        parts = self._split_path(path)
        if not parts:
            raise GoogleDriveProviderError("File path cannot be empty.")

        filename = parts[-1]
        folder_path = "/".join(parts[:-1])

        parent_ref = (
            self.ensure_folder(folder_path)
            if folder_path
            else self._to_item_ref(self._get_item(self.root_folder_id), full_path="")
        )
        parent_id = parent_ref.id

        existing = self._find_child_by_name(parent_id=parent_id, name=filename)
        media = MediaInMemoryUpload(
            content.encode("utf-8"),
            mimetype=TEXT_MIME,
            resumable=False,
        )

        if existing is not None:
            if existing.is_folder:
                raise GoogleDriveProviderError(
                    f"Cannot write file '{path}': a folder with that name already exists."
                )
            self.service.files().update(fileId=existing.id, media_body=media).execute()
            return

        metadata = {
            "name": filename,
            "parents": [parent_id],
            "mimeType": TEXT_MIME,
        }

        self.service.files().create(
            body=metadata,
            media_body=media,
            fields="id",
            supportsAllDrives=True,
        ).execute()

    def read_text(self, path: str) -> str:
        """
        Read a UTF-8 text file from Google Drive.
        """
        node = self._resolve_file(path)

        request = self.service.files().get_media(fileId=node.id)
        buffer = io.BytesIO()
        downloader = MediaIoBaseDownload(buffer, request)

        done = False
        while not done:
            _, done = downloader.next_chunk()

        return buffer.getvalue().decode("utf-8")

    # -------------------------------------------------------------------------
    # Internal helpers
    # -------------------------------------------------------------------------

    def _split_path(self, path: str) -> list[str]:
        return [part for part in path.strip("/").split("/") if part]

    def _escape_query_value(self, value: str) -> str:
        return value.replace("\\", "\\\\").replace("'", "\\'")

    def _get_item(self, file_id: str) -> _DriveNode:
        data = (
            self.service.files()
            .get(
                fileId=file_id,
                fields="id,name,mimeType,parents",
                supportsAllDrives=True,
            )
            .execute()
        )
        return _DriveNode(
            id=data["id"],
            name=data["name"],
            mime_type=data["mimeType"],
            parents=data.get("parents", []),
        )

    def _find_child_by_name(self, parent_id: str, name: str) -> Optional[_DriveNode]:
        safe_name = self._escape_query_value(name)
        result = (
            self.service.files()
            .list(
                q=(
                    f"'{parent_id}' in parents and "
                    f"name = '{safe_name}' and "
                    f"trashed = false"
                ),
                spaces="drive",
                fields="files(id,name,mimeType,parents)",
                pageSize=10,
                supportsAllDrives=True,
                includeItemsFromAllDrives=True,
            )
            .execute()
        )

        files = result.get("files", [])
        if not files:
            return None

        file = files[0]
        return _DriveNode(
            id=file["id"],
            name=file["name"],
            mime_type=file["mimeType"],
            parents=file.get("parents", []),
        )

    def _create_folder(self, parent_id: str, name: str) -> _DriveNode:
        created = (
            self.service.files()
            .create(
                body={
                    "name": name,
                    "mimeType": FOLDER_MIME,
                    "parents": [parent_id],
                },
                fields="id,name,mimeType,parents",
                supportsAllDrives=True,
            )
            .execute()
        )

        return _DriveNode(
            id=created["id"],
            name=created["name"],
            mime_type=created["mimeType"],
            parents=created.get("parents", []),
        )

    def _resolve_folder(self, path: str) -> _DriveNode:
        node = self._resolve_path(path)
        if not node.is_folder:
            raise GoogleDriveProviderError(f"'{path}' is not a folder.")
        return node

    def _resolve_file(self, path: str) -> _DriveNode:
        node = self._resolve_path(path)
        if node.is_folder:
            raise GoogleDriveProviderError(f"'{path}' is a folder, not a file.")
        return node

    def _resolve_path(self, path: str) -> _DriveNode:
        parts = self._split_path(path)
        if not parts:
            return self._get_item(self.root_folder_id)

        current = self._get_item(self.root_folder_id)
        for part in parts:
            child = self._find_child_by_name(parent_id=current.id, name=part)
            if child is None:
                raise GoogleDriveProviderError(f"Path not found: '{path}'")
            current = child

        return current

    def _to_item_ref(self, node: _DriveNode, full_path: Optional[str] = None) -> ItemRef:
        return ItemRef(
            id=node.id,
            name=node.name,
            path=full_path or node.name,
            is_folder=node.is_folder,
        )

    def _to_item_count_ref(
        self,
        node: _DriveNode,
        count: int,
        full_path: Optional[str] = None,
    ) -> ItemCountRef:
        return ItemCountRef(
            id=node.id,
            name=node.name,
            path=full_path or node.name,
            is_folder=node.is_folder,
            count=count,
        )
