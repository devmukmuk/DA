"""Storage provider CLI commands."""

import typer
from rich import print # pylint: disable=W0622

from mindit.providers.registry import get_storage_provider

app = typer.Typer(help="Storage provider commands.")

@app.command("test-local-connection")
def test_local() -> None:
    """Verify local storage provider connection."""
    provider = get_storage_provider("local")
    print(provider.test_connection())


@app.command("test-google-drive-connection")
def test_google() -> None:
    """Verify Google Drive provider connection."""
    provider = get_storage_provider("google_drive")
    print(provider.test_connection())


@app.command("test-google-drive-write")
def test_google_write() -> None:
    """Verify Google Drive write access by ensuring a healthcheck folder exists."""
    provider = get_storage_provider("google_drive")
    folder = provider.ensure_folder("healthcheck")
    print({
        "provider": "google_drive",
        "connected": True,
        "write_access": True,
        "healthcheck_folder": folder.path,
    })
