"""Google authentication helpers for Drive and Sheets services."""
# src/mindit/providers/google/auth_service.py

from __future__ import annotations

from pathlib import Path
from typing import Iterable

from google.auth.transport.requests import Request
from google.oauth2 import credentials as oauth_credentials
from google.oauth2 import service_account
from google_auth_oauthlib.flow import InstalledAppFlow


from mindit.config.settings import get_config_path, load_settings


DRIVE_SCOPE = "https://www.googleapis.com/auth/drive"
SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets"

DEFAULT_SCOPES = [DRIVE_SCOPE, SHEETS_SCOPE]


def resolve_config_relative_path(path_str: str) -> Path:
    """
    Resolve a path relative to the active config.yaml location.

    Absolute paths are returned unchanged. Relative paths are resolved
    relative to the directory containing the active config file.

    Args:
        path_str: Path string from configuration.

    Returns:
        Resolved absolute Path.
    """
    path = Path(path_str)

    if path.is_absolute():
        return path

    return (get_config_path().parent / path).resolve()


def get_google_secret_paths() -> dict[str, Path]:
    """
    Return resolved Google credential file paths from configuration.

    Expected config keys:
        settings.providers.google_drive.credentials_file
        settings.providers.google_drive.service_account_file
        settings.providers.google_drive.token_file

    Returns:
        Dictionary containing resolved credential file paths.
    """
    settings = load_settings()
    google_cfg = settings.providers.google_drive

    return {
        "credentials_file": resolve_config_relative_path(
            google_cfg.credentials_file
        ),
        "service_account_file": resolve_config_relative_path(
            google_cfg.service_account_file
        ),
        "token_file": resolve_config_relative_path(
            google_cfg.token_file
        ),
    }


def get_service_account_credentials(
    scopes: Iterable[str] | None = None,
):
    """
    Return Google service account credentials from config settings.

    Args:
        scopes: Optional iterable of OAuth scopes.

    Raises:
        FileNotFoundError: If the configured service account JSON file is missing.

    Returns:
        google.oauth2.service_account.Credentials
    """
    paths = get_google_secret_paths()
    service_account_path = paths["service_account_file"]

    if not service_account_path.exists():
        raise FileNotFoundError(
            f"Service account JSON not found: {service_account_path}"
        )

    return service_account.Credentials.from_service_account_file(
        str(service_account_path),
        scopes=list(scopes) if scopes is not None else None,
    )


def get_oauth_credentials(
    scopes: Iterable[str] | None = None,
):
    """
    Return Google OAuth user credentials from config settings.

    This will:
        1. Load cached token credentials if available.
        2. Refresh expired credentials when possible.
        3. Launch the OAuth browser flow if no valid token exists.
        4. Save the refreshed/new token back to disk.

    Args:
        scopes: Optional iterable of OAuth scopes.

    Raises:
        FileNotFoundError: If the configured OAuth client credentials JSON is missing.

    Returns:
        google.oauth2.credentials.Credentials
    """
    paths = get_google_secret_paths()
    scopes_list = list(scopes or DEFAULT_SCOPES)

    credentials_path = paths["credentials_file"]
    token_path = paths["token_file"]

    creds = None

    if token_path.exists():
        creds = oauth_credentials.Credentials.from_authorized_user_file(
            str(token_path),
            scopes_list,
        )

    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())

    if not creds or not creds.valid:
        if not credentials_path.exists():
            raise FileNotFoundError(
                f"OAuth credentials file not found: {credentials_path}"
            )

        flow = InstalledAppFlow.from_client_secrets_file(
            str(credentials_path),
            scopes_list,
        )
        creds = flow.run_local_server(port=0)

        token_path.parent.mkdir(parents=True, exist_ok=True)
        token_path.write_text(creds.to_json(), encoding="utf-8")

    return creds


def get_google_credentials(
    auth_type: str = "oauth",
    scopes: Iterable[str] | None = None,
):
    """
    Return Google credentials based on the requested authentication mode.

    Supported auth types:
        - 'oauth'
        - 'service-account'

    Args:
        auth_type: Authentication mode to use.
        scopes: Optional iterable of OAuth scopes.

    Raises:
        ValueError: If auth_type is not supported.

    Returns:
        Google credentials object.
    """
    scopes_list = list(scopes or DEFAULT_SCOPES)

    if auth_type == "oauth":
        return get_oauth_credentials(scopes=scopes_list)

    if auth_type == "service-account":
        return get_service_account_credentials(scopes=scopes_list)

    raise ValueError(f"Unsupported auth_type: {auth_type}")



