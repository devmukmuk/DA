"""Google client services."""
# src/mindit/providers/google/clients.py

from googleapiclient.discovery import build
from mindit.providers.google.auth_service import get_google_credentials

DRIVE_SCOPE = "https://www.googleapis.com/auth/drive"
SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets"

DEFAULT_SCOPES = [DRIVE_SCOPE, SHEETS_SCOPE]

def get_drive_service(auth_type: str = "oauth"):
    """
    Return an authenticated Google Drive API service.

    Args:
        auth_type: Authentication mode to use.

    Returns:
        googleapiclient.discovery.Resource
    """
    creds = get_google_credentials(auth_type=auth_type, scopes=DEFAULT_SCOPES)
    return build("drive", "v3", credentials=creds)


def get_sheets_service(auth_type: str = "oauth"):
    """
    Return an authenticated Google Sheets API service.

    Args:
        auth_type: Authentication mode to use.

    Returns:
        googleapiclient.discovery.Resource
    """
    creds = get_google_credentials(auth_type=auth_type, scopes=DEFAULT_SCOPES)
    return build("sheets", "v4", credentials=creds)