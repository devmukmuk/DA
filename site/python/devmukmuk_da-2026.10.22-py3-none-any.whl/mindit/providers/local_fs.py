"""class LocalFileSystemProvider - Windows."""

from pathlib import Path
from typing import Any

from mindit.providers.base import ItemRef, StorageProvider

class LocalFileSystemProvider(StorageProvider):
    """_summary_

    Args:
        StorageProvider (_type_): _description_
    """
    def __init__(self, root: str):
        self.root = Path(root)

    def _resolve(self, path: str) -> Path:
        return self.root / path

    def ensure_folder(self, path: str) -> ItemRef:
        p = self._resolve(path)
        p.mkdir(parents=True, exist_ok=True)
        return ItemRef(id=str(p), name=p.name, path=str(p), is_folder=True)

    def list_items(self, path: str) -> list[ItemRef]:
        p = self._resolve(path)
        if not p.exists():
            return []
        return [
            ItemRef(
                id=str(child),
                name=child.name,
                path=str(child),
                is_folder=child.is_dir(),
            )
            for child in sorted(p.iterdir(), key=lambda x: x.name.lower())
        ]

    def write_text(self, path: str, content: str) -> None:
        p = self._resolve(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")

    def read_text(self, path: str) -> str:
        return self._resolve(path).read_text(encoding="utf-8")
    
    def test_connection(self) -> dict[str, Any]:
        exists = self.root.exists()
        is_dir = self.root.is_dir()

        return {
            "provider": "local",
            "connected": exists and is_dir,
            "root": str(self.root),
            "exists": exists,
            "is_dir": is_dir,
        }
