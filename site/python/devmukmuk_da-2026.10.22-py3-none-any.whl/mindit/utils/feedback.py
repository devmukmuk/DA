# src/mindit/utils/feedback.py

from __future__ import annotations

import sys
import time


def _beep(freq: int = 1000, duration: int = 150) -> None:
    """Play a short chime, best-effort -- a missing/unavailable audio device should never crash a run."""
    if sys.platform.startswith("win"):
        import winsound
        try:
            winsound.Beep(freq, duration)
        except RuntimeError:
            pass
    else:
        print("\a", end="", flush=True)


def chime_start(enabled: bool = True) -> None:
    if not enabled:
        return
    _beep(900, 120)


def chime_done(enabled: bool = True) -> None:
    if not enabled:
        return
    _beep(900, 120)
    time.sleep(0.12)
    _beep(1200, 180)
