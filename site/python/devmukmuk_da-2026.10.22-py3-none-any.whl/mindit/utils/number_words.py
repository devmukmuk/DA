""" test converting number to words"""
# codeit/utils/number_words.py

ONES = [
    "ZERO", "ONE", "TWO", "THREE", "FOUR",
    "FIVE", "SIX", "SEVEN", "EIGHT", "NINE"
]


def digits_to_words(num_str: str) -> str:
    """
    Convert a string of digits into space-separated word digits.
    Example: "2048" -> "TWO ZERO FOUR EIGHT"
    """
    return " ".join(ONES[int(d)] for d in num_str)



def convert_numbers_to_words(message: str) -> str:
    """_summary_

    Args:
        message (str): _description_

    Returns:
        str: _description_
    """
    tokens = message.split()
    expanded = []

    for token in tokens:
        if token.isdigit():
            expanded.append(digits_to_words(token))
        else:
            expanded.append(token)

    return " ".join(expanded)
