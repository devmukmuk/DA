# src/mindit/utils/windows_dialog.py

from tkinter import Tk, filedialog
from pathlib import Path

def select_folder_dialog(
    title: str = "Select folder",
    initial_dir: str | None = None,
) -> str | None:
    try:
        root = Tk()
        root.withdraw()
        root.attributes("-topmost", True)

        # Normalize initial dir (important)
        if initial_dir:
            initial_dir = str(Path(initial_dir).expanduser())
            if not Path(initial_dir).exists():
                initial_dir = None  # fallback if invalid

        folder = filedialog.askdirectory(
            title=title,
            initialdir=initial_dir
        )

        root.destroy()
        return folder or None

    except Exception:
        return None
