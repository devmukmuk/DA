# cli/utils/file_utils.py

import re
from pathlib import Path
from typing import Any


# =============================================================================
# empty folder cleanup helpers
# =============================================================================
def _remove_empty_folders(root: Path, dry_run: bool = True) -> list[str]:
    """
    Remove empty folders under the given root.

    Notes:
        - walks deepest folders first
        - never removes the root folder itself
        - only removes directories that are truly empty
    """
    removed: list[str] = []

    if not root.exists() or not root.is_dir():
        return removed

    all_dirs = sorted(
        [path for path in root.rglob("*") if path.is_dir()],
        key=lambda item: len(item.parts),
        reverse=True,
    )

    for folder in all_dirs:
        try:
            if any(folder.iterdir()):
                continue

            if not dry_run:
                folder.rmdir()

            removed.append(str(folder))
        except OSError:
            # folder was not empty anymore or could not be removed
            continue

    return removed


# =============================================================================
# empty folder cleanup workflow
# =============================================================================
def remove_empty_folders_workflow(
    folder: str,
    dry_run: bool = False,
) -> dict[str, Any]:
    """
    Remove empty folders under a root folder.

    Intended use:
        - after moving/quarantining files
        - to clean up empty source directory trees
    """
    root = Path(folder).expanduser().resolve()

    if not root.exists():
        raise FileNotFoundError(f"Folder not found: {root}")

    if not root.is_dir():
        raise NotADirectoryError(f"Not a directory: {root}")

    removed = _remove_empty_folders(root=root, dry_run=dry_run)

    return {
        "folder": str(root),
        "dry_run": dry_run,
        "removed_count": len(removed),
        "removed": removed,
    }




def sanitize_filename(name: str) -> str:
    """
    Remove illegal characters and normalize spacing.
    Safe for Windows, macOS, and Linux.
    """
    name = name.strip()

    # Remove illegal filesystem characters
    name = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "", name)

    # Normalize whitespace
    name = re.sub(r"\s+", " ", name)

    return name


def sanitize_foldername(name: str) -> str:
    """
    Sanitize folder names (slightly stricter).
    """
    name = sanitize_filename(name)
    return name.replace(" ", "_")


def ensure_unique_path(path: Path) -> Path:
    """
    Ensure file path does not collide by appending _1, _2, etc.
    """

    if not path.exists():
        return path

    stem = path.stem
    suffix = path.suffix
    parent = path.parent

    counter = 1

    while True:
        candidate = parent / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            return candidate

        counter += 1


def safe_mkdir(path: Path) -> Path:
    """
    Ensure a directory exists and return it.
    """
    path.mkdir(parents=True, exist_ok=True)
    return path