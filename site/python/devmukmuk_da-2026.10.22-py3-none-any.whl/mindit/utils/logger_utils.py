# logger_utils.py
import logging
from typing import Optional

def get_logger(name: str, level: int = logging.INFO, logfile: Optional[str] = None) -> logging.Logger:
    """
    Returns a configured logger.
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Add StreamHandler if not already added
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        ch = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s")
        ch.setFormatter(formatter)
        logger.addHandler(ch)

    # Add FileHandler if requested and not already present
    if logfile and not any(isinstance(h, logging.FileHandler) for h in logger.handlers):
        fh = logging.FileHandler(logfile)
        fh.setFormatter(logging.Formatter("%(asctime)s | %(name)s | %(levelname)s | %(message)s"))
        logger.addHandler(fh)

    return logger

def log_exception(logger: logging.Logger, msg: str, exc: Exception):
    """
    Logs an exception with traceback at ERROR level.
    """
    logger.exception(f"{msg}: {exc}")
