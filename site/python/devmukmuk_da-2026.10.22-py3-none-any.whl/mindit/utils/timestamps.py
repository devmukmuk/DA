# src/mindit/utils/timestamps.py

"""File timestamps that can't always be converted to a datetime."""

from __future__ import annotations

from datetime import datetime

# Stand-in for a file time Windows can't convert (before 1970, or absurdly far in the future).
UNREADABLE_FILE_TIME = datetime(1970, 1, 1)


def safe_fromtimestamp(timestamp: float) -> datetime | None:
    """Return datetime.fromtimestamp(timestamp), or None when the OS can't convert it."""
    try:
        return datetime.fromtimestamp(timestamp)
    except (OSError, OverflowError, ValueError):
        return None


def safe_iso_timestamp(timestamp: float) -> str | None:
    """Return the timestamp as ISO text to the second, or None when the OS can't convert it."""
    value = safe_fromtimestamp(timestamp)
    return value.isoformat(timespec="seconds") if value else None
