# src/mindit/reporting/engine.py
from pathlib import Path
from rich import print


def run_report(generator, data_file: str) -> None:
    """Shared report runner for all modules."""
    path = Path(data_file)
    data = generator.load_data(path)
    report = generator.build_report(data)
    output = generator.render_text(report)
    print(output)