# src/mindit/reporting/base.py
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any


class ReportGenerator(ABC):
    """Base interface for module report generators."""

    @abstractmethod
    def load_data(self, data_path: Path) -> Any:
        """Load and validate input data."""
        raise NotImplementedError

    @abstractmethod
    def build_report(self, data: Any) -> dict[str, Any]:
        """Transform input data into a standard report structure."""
        raise NotImplementedError

    @abstractmethod
    def render_text(self, report: dict[str, Any]) -> str:
        """Render report as terminal-friendly text."""
        raise NotImplementedError
