class minditError(Exception):
    pass

class ProviderError(minditError):
    pass
