# src/mindit/core/feedback.py

from contextlib import contextmanager
from typing import Iterator, Any

from mindit.utils.feedback import chime_start, chime_done


@contextmanager
def cli_feedback(settings: Any) -> Iterator[None]:
    feedback = getattr(settings, "feedback", None)

    enabled = getattr(feedback, "enabled", False)
    use_start = getattr(feedback, "chime_start", False)
    use_done = getattr(feedback, "chime_done", False)

    if enabled and use_start:
        chime_start()

    try:
        yield
    finally:
        if enabled and use_done:
            chime_done()