from __future__ import annotations

from dataclasses import dataclass
from time import monotonic
from typing import Protocol


@dataclass(frozen=True)
class ProgressState:
    label: str
    current: int
    total: int | None = None
    current_item: str | None = None
    elapsed_seconds: float = 0.0

    @property
    def percent_complete(self) -> float | None:
        if self.total is None or self.total <= 0:
            return None
        return min(100.0, (self.current / self.total) * 100.0)


class ProgressReporter(Protocol):
    def start(self, label: str, total: int | None = None) -> None:
        ...

    def advance(self, current_item: str | None = None, step: int = 1) -> None:
        ...

    def finish(self) -> None:
        ...


class NullProgressReporter:
    def start(self, label: str, total: int | None = None) -> None:
        return None

    def advance(self, current_item: str | None = None, step: int = 1) -> None:
        return None

    def finish(self) -> None:
        return None


class TrackingProgressReporter:
    def __init__(self) -> None:
        self.labels: list[str] = []
        self.label = ""
        self.total: int | None = None
        self.current = 0
        self.started_at: float | None = None
        self.finished = False
        self.states: list[ProgressState] = []

    def start(self, label: str, total: int | None = None) -> None:
        self.label = label
        self.labels.append(label)
        self.total = total
        self.current = 0
        self.started_at = monotonic()
        self.finished = False
        self._record_state()

    def advance(self, current_item: str | None = None, step: int = 1) -> None:
        self.current += step
        self._record_state(current_item=current_item)

    def finish(self) -> None:
        self.finished = True
        self._record_state()

    def _record_state(self, current_item: str | None = None) -> None:
        elapsed = 0.0
        if self.started_at is not None:
            elapsed = monotonic() - self.started_at

        self.states.append(
            ProgressState(
                label=self.label,
                current=self.current,
                total=self.total,
                current_item=current_item,
                elapsed_seconds=elapsed,
            )
        )
