# src/mindit/models/photoit_validation.py

from __future__ import annotations

from dataclasses import dataclass, field


# =============================================================================
# original data models validation for photo references, used in the early stages of development.
# =============================================================================

@dataclass(frozen=True)
class ValidationIssue:
    code: str
    message: str
    severity: str = "error"


@dataclass(frozen=True)
class DuplicateMatch:
    duplicate_type: str
    matched_path: str
    reason: str


@dataclass(frozen=True)
class PhotoValidationState:
    is_valid: bool
    has_metadata_json: bool = False
    duplicate_matches: list[DuplicateMatch] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class PhotoWorkflowResult:
    source_path: str
    final_path: str | None = None
    metadata_path: str | None = None
    duplicate_action: str | None = None
    validation: PhotoValidationState | None = None


# =============================================================================
# new data models validations for photo references, designed to be more flexible and extensible, used in later stages of development.
# to be used in upcoming interactive photo management features, such as batch processing, metadata extraction, and integration with external services.
# there is a duplicate between the PhotoFileRef and PhotoRef models, and may need to be consolidated.
# =============================================================================

@dataclass(frozen=True)
class BatchPhotoState:
    discovered: bool = False
    metadata_found: bool = False
    preview_ready: bool = False
    renamed: bool = False
    moved: bool = False
    duplicate: bool = False
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

@dataclass(frozen=True)
class BatchJobState:
    is_valid: bool
    total_photos: int = 0
    selected_count: int = 0
    processed_count: int = 0
    success_count: int = 0
    failed_count: int = 0
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
