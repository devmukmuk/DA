# src/mindit/models/quarantine_state.py

"""Shared quarantine state models for duplicate detection workflows."""

from __future__ import annotations

from dataclasses import dataclass, field

HASH_STATUS_MISSING = "missing"
HASH_STATUS_FRESH = "fresh"
HASH_STATUS_STALE = "stale"
HASH_STATUS_COMPUTED = "computed"

DUPLICATE_STATUS_UNKNOWN = "unknown"
DUPLICATE_STATUS_UNIQUE = "unique"
DUPLICATE_STATUS_DUPLICATE = "duplicate"
DUPLICATE_STATUS_PRIMARY = "primary"
DUPLICATE_STATUS_QUARANTINED = "quarantined"
DUPLICATE_STATUS_REMOVED = "removed"

@dataclass(frozen=True)
class QuarantineState:
    """Duplicate/quarantine state for one file."""

    file_path: str
    sidecar_path: str | None
    file_size: int
    hash_sha256: str | None
    hash_status: str  # missing | fresh | stale | computed
    duplicate_status: str  # unknown | unique | duplicate | primary | quarantined | removed
    duplicate_group_id: str | None = None
    duplicate_of: str | None = None
    duplicate_paths: list[str] = field(default_factory=list)
    checked_at: str | None = None

    def __post_init__(self) -> None:
        valid_hash_status = {
            HASH_STATUS_MISSING,
            HASH_STATUS_FRESH,
            HASH_STATUS_STALE,
            HASH_STATUS_COMPUTED,
        }

        valid_duplicate_status = {
            DUPLICATE_STATUS_UNKNOWN,
            DUPLICATE_STATUS_UNIQUE,
            DUPLICATE_STATUS_DUPLICATE,
            DUPLICATE_STATUS_PRIMARY,
            DUPLICATE_STATUS_QUARANTINED,
            DUPLICATE_STATUS_REMOVED,
        }

        if self.hash_status not in valid_hash_status:
            raise ValueError(f"Invalid hash_status: {self.hash_status}")

        if self.duplicate_status not in valid_duplicate_status:
            raise ValueError(f"Invalid duplicate_status: {self.duplicate_status}")
