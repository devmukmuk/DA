"""ScanIt validation helpers."""
# src/model/scanit_validation.py

from __future__ import annotations

import re
from pathlib import Path

from mindit.models.scanit_refs import ScannerRef

# Canonical set lives with ValidateIt so every module agrees on what a document is.
from mindit.services.validateit.validateit_file_types import DOCUMENT_EXTENSIONS


class ScanItValidationError(Exception):
    """Base ScanIt validation error."""


def normalize_extensions(extensions: list[str] | None) -> set[str]:
    """
    Normalize file extensions.

    Examples:
        ["pdf", ".tif"] -> {".pdf", ".tif"}
    """
    if not extensions:
        return set(DOCUMENT_EXTENSIONS)

    normalized = set()
    for ext in extensions:
        ext = ext.strip().lower()
        if not ext:
            continue
        if not ext.startswith("."):
            ext = f".{ext}"
        normalized.add(ext)

    return normalized or set(DOCUMENT_EXTENSIONS)


def ensure_folder_exists(folder: Path) -> None:
    """Ensure folder exists and is a directory."""
    if not folder.exists():
        raise ScanItValidationError(f"Folder does not exist: {folder}")
    if not folder.is_dir():
        raise ScanItValidationError(f"Path is not a folder: {folder}")


def is_allowed_document(file_path: Path, allowed_extensions: set[str] | None = None) -> bool:
    """Check whether a file is an allowed document."""
    allowed = allowed_extensions or set(DOCUMENT_EXTENSIONS)

    if file_path.name.endswith(".meta.json"):
        return False

    return file_path.suffix.lower() in allowed


def get_default_metadata_path(file_path: Path) -> Path:
    """
    Return sidecar metadata JSON path.

    Example:
        report.pdf -> report.pdf.meta.json
    """
    return file_path.with_name(f"{file_path.name}.meta.json")


def validate_scanner_ref(scanner_ref: ScannerRef) -> None:
    """Validate required fields on ScannerRef."""
    if not scanner_ref.doc_id:
        raise ScanItValidationError("ScannerRef.doc_id is required.")

    if not scanner_ref.doc_name:
        raise ScanItValidationError("ScannerRef.doc_name is required.")

    if not scanner_ref.location_folder:
        raise ScanItValidationError("ScannerRef.location_folder is required.")


def sanitize_filename_part(value: str) -> str:
    """
    Convert text into a filesystem-safe filename fragment.
    """
    cleaned = value.strip()
    cleaned = re.sub(r"[<>:\"/\\|?*]+", "_", cleaned)
    cleaned = re.sub(r"\s+", "_", cleaned)
    cleaned = re.sub(r"_+", "_", cleaned)
    cleaned = cleaned.strip("._")
    return cleaned or "document"
