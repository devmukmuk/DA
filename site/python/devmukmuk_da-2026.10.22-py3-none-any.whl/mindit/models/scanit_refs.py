"""ScanIt data references."""
# src/mindit/models/scanit_refs.py

from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass
class MetaRef:
    """Metadata sidecar reference for a scanned document."""

    metadata_file: str
    file_extension: str
    file_size: int
    created_at: str
    modified_at: str
    scanned_at: str
    original_folder: str
    original_filename: str
    current_folder: str
    current_filename: str

    def to_dict(self) -> dict:
        """Convert MetaRef to dictionary."""
        return asdict(self)


@dataclass
class ScannerRef:
    """Reference to a scanned document."""

    doc_id: str
    doc_name: str
    location_folder: str
    hash: str
    meta_ref: MetaRef | None = None

    def to_dict(self) -> dict:
        """Convert ScannerRef to dictionary."""
        payload = asdict(self)
        if self.meta_ref is not None:
            payload["meta_ref"] = self.meta_ref.to_dict()
        return payload
