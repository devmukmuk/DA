"""PackIt validation and workflow result data classes.

File:
    src/mindit/models/packit_validation.py

Purpose:
    Defines immutable validation/result objects used by PackIt services
    and workflows.

What belongs here:
    - validation status
    - validation issues
    - derived box state such as template match, heavy, fragile
    - combined ref + validation result objects

What does NOT belong here:
    - Google API clients
    - resolver logic
    - file export logic
    - mutable command state

Layer guidance:
    Resolver layer:
        Returns reference objects from packit_refs.py.

    Validation/export/service layer:
        Produces the validation state objects defined in this file.

    Workflow layer:
        Combines refs, validation, export paths, and QR results into
        higher-level workflow result objects.

Recommended usage:
    - BoxRef answers "what box is this?"
    - BoxValidationState answers "is it valid?" and "why?"
    - BoxValidationRecord answers both together.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from mindit.models.packit_refs import (
    BoxRef,
    RoomRef,
    TemplateRef,
    HouseRef
)


@dataclass(frozen=True)
class ValidationIssue:
    """A single validation issue."""

    code: str
    message: str
    severity: str = "error"
    field_name: str | None = None
    expected: Any | None = None
    actual: Any | None = None


@dataclass(frozen=True)
class ValidationSummary:
    """Shared validation summary shape."""

    is_valid: bool
    issues: list[ValidationIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class BoxValidationState:
    """Validation state for a PackIt box."""

    is_valid: bool
    template_ref: TemplateRef | None = None
    is_heavy: bool = False
    is_fragile: bool = False
    issues: list[ValidationIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    metadata_updates: dict[str, Any] | None = None
    parent_folder_name: str | None = None
    sheet_title: str | None = None
    table_name: str | None = None


@dataclass(frozen=True)
class RoomValidationState:
    """Validation summary for a room and its boxes."""

    is_valid: bool
    total_boxes: int = 0
    valid_boxes: int = 0
    invalid_boxes: int = 0
    issues: list[ValidationIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

@dataclass(frozen=True)
class HouseValidationState:
    """Validation summary for a house and its rooms."""

    is_valid: bool
    total_rooms: int = 0
    valid_rooms: int = 0
    invalid_rooms: int = 0
    total_boxes: int = 0
    valid_boxes: int = 0
    invalid_boxes: int = 0
    issues: list[ValidationIssue] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

@dataclass(frozen=True)
class BoxValidationRecord:
    """Reference plus validation state for one box."""

    box_ref: BoxRef
    validation: BoxValidationState


@dataclass(frozen=True)
class RoomValidationRecord:
    """Reference plus validation state for one room."""

    room_ref: RoomRef
    validation: RoomValidationState
    box_records: list[BoxValidationRecord] = field(default_factory=list)

@dataclass(frozen=True)
class HouseValidationRecord:
    """Reference plus validation state for one house."""

    house_ref: HouseRef
    validation: HouseValidationState
    room_records: list[RoomValidationRecord] = field(default_factory=list)

@dataclass(frozen=True)
class BoxWorkflowResult:
    """Workflow result for single-box operations."""

    box_ref: BoxRef
    validation: BoxValidationState
    export_json_path: str | None = None
    qr_path: str | None = None
    qr_created: bool = False


@dataclass(frozen=True)
class RoomWorkflowResult:
    """Workflow result for room-level operations."""

    room_ref: RoomRef
    validation: RoomValidationState
    box_results: list[BoxWorkflowResult] = field(default_factory=list)


@dataclass(frozen=True)
class HouseWorkflowResult:
    """Workflow result for house-level operations."""

    house_ref: HouseRef
    validation: HouseValidationState
    room_results: list[RoomWorkflowResult] = field(default_factory=list)
