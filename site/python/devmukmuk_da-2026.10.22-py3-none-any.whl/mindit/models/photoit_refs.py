# src/mindit/models/photoit_refs.py

from __future__ import annotations

from dataclasses import dataclass



# =============================================================================
# original data models for photo references, used in the early stages of development.
# =============================================================================

@dataclass(frozen=True)
class PhotoRootRef:
    root_path: str


@dataclass(frozen=True)
class PhotoFileRef:
    file_id: str
    file_name: str
    file_ext: str
    abs_path: str
    rel_path: str
    folder_path: str
    size_bytes: int
    modified_ts: float
    created_ts: float | None
    root_ref: PhotoRootRef
  

# =============================================================================
# new data models for photo references, designed to be more flexible and extensible, used in later stages of development.
# to be used in upcoming interactive photo management features, such as batch processing, metadata extraction, and integration with external services.
# there is a duplicate between the PhotoFileRef and PhotoRef models, and may need to be consolidated.
# =============================================================================
  
@dataclass(frozen=True)
class PhotoRef:
    photo_id: str
    file_path: str
    file_name: str
    extension: str

@dataclass(frozen=True)
class MetadataRef:
    metadata_path: str | None

@dataclass(frozen=True)
class BatchJobRef:
    batch_id: str
    batch_name: str
    intake_folder: str
    created_at: str

