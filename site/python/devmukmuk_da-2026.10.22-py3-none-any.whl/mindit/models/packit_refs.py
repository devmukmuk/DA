"""PackIt reference data classes.

File:
    src/mindit/models/packit_refs.py

Purpose:
    Defines lightweight immutable reference objects used across PackIt
    resolver, service, and workflow layers.

What belongs here:
    - stable identifiers
    - canonical names
    - parsed naming components
    - parent/child relationships via nested refs

What does NOT usually belong here:
    - validation results
    - export payloads
    - mutable workflow state
    - derived content details
    - transient flags produced by validation or reporting

Layer guidance:
    Resolver layer:
        Builds and returns these refs from Google Drive / Sheets structure.

    Service layer:
        Accepts refs as inputs for validation, export, QR generation,
        reporting, and processing.

    Workflow layer:
        Composes refs together with validation/export results into
        richer workflow result objects.

Recommended usage:
    - Use HouseRef / RoomRef / BoxRef to identify "what thing is this?"
    - Use separate validation/result dataclasses to answer
      "is this thing valid?" and "why?"

Example:
    BoxRef identifies box "LR-01" in room "LIVINGROOM-LR-YELLOW".
    A separate BoxValidationState can describe whether that box is valid,
    whether it uses the expected template, and which issues were found.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class HouseRef:
    """Reference to the PackIt household/root."""

    house_id: str
    house_name: str


@dataclass(frozen=True)
class RoomRef:
    """Reference to a PackIt room folder."""

    room_id: str
    room_folder_name: str
    room_name: str
    room_abbr: str
    room_tape: str
    house_ref: HouseRef


@dataclass(frozen=True)
class TemplateRef:
    """Reference to a box template source."""

    template_id: str
    template_name: str


@dataclass(frozen=True)
class BoxRef:
    """Reference to a PackIt box sheet."""

    box_id: str
    box_name: str
    box_number: int | None
    room_ref: RoomRef