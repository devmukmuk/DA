from __future__ import annotations

from pathlib import Path
from typing import Any
from collections import Counter


from mindit.services.sidecar import SidecarService


def find_tag_workflow(
    folder: str | Path,
    recursive: bool = True,
    require_tags: list[str] | None = None,
    exclude_tags: list[str] | None = None,
    date_prefix: str | None = None,
    name_contains: str | None = None,
    require_gps: bool = False,
    module: str | None = None,
    media_type: str | None = None,
    file_exists_only: bool = False,
) -> dict[str, Any]:
    """
    Find files by metadata sidecar filters.

    Sidecar-first search:
        - scans *.meta.json files
        - reads metadata without mutating or normalizing sidecars
        - resolves the referenced file from standard sidecar fields
    """
    folder_path = Path(folder)

    normalized_require = _normalize_tags(require_tags)
    normalized_exclude = _normalize_tags(exclude_tags)
    normalized_date_prefix = date_prefix.strip() if date_prefix else None
    normalized_name_contains = name_contains.strip().lower() if name_contains else None
    normalized_module = module.strip().lower() if module else None
    normalized_media_type = media_type.strip().lower() if media_type else None

    sidecar_paths = (
        folder_path.rglob("*.meta.json")
        if recursive
        else folder_path.glob("*.meta.json")
    )

    matches: list[dict[str, Any]] = []
    sidecar_count = 0
    metadata_read_count = 0
    metadata_error_count = 0

    for metadata_path in sidecar_paths:
        sidecar_count += 1

        metadata = SidecarService.load_sidecar_path(metadata_path)
        if metadata is None:
            metadata_error_count += 1
            continue

        metadata_read_count += 1

        metadata_module = _normalize_optional_text(
            _metadata_value(metadata, "classification.module")
            or _metadata_value(metadata, "module")
        )

        if normalized_module and metadata_module != normalized_module:
            continue

        metadata_media_type = _normalize_optional_text(
            _metadata_value(metadata, "classification.media_type")
            or _metadata_value(metadata, "media_type")
        )

        if normalized_media_type and metadata_media_type != normalized_media_type:
            continue

        file_path = _resolve_file_path(metadata_path, metadata)
        file_exists = file_path.exists()

        if file_exists_only and not file_exists:
            continue

        file_name = _resolve_file_name(file_path, metadata)

        if normalized_name_contains and normalized_name_contains not in file_name.lower():
            continue

        existing_tags = _extract_tags(metadata, metadata_module)
        normalized_tags = _normalize_tags(existing_tags)
        tag_set = set(normalized_tags)

        if normalized_require and not all(tag in tag_set for tag in normalized_require):
            continue

        if normalized_exclude and any(tag in tag_set for tag in normalized_exclude):
            continue

        gps = _extract_gps(metadata, metadata_module)

        gps_present = (
            gps.get("latitude") is not None
            or gps.get("longitude") is not None
        )

        if require_gps and not gps_present:
            continue

        captured_at = _extract_date_text(metadata, metadata_module)

        if normalized_date_prefix and not captured_at.startswith(normalized_date_prefix):
            continue

        matches.append(
            {
                "file_path": str(file_path),
                "metadata_path": str(metadata_path),
                "sidecar_exists": metadata_path.exists(),
                "file_exists": file_exists,
                "file_name": file_name,
                "tags": normalized_tags,
                "tag_count": len(normalized_tags),
                "gps_present": gps_present,
                "gps": {
                    "latitude": gps.get("latitude"),
                    "longitude": gps.get("longitude"),
                },
                "captured_at": captured_at or None,
                "module": metadata_module,
                "media_type": metadata_media_type,
            }
        )

    return {
        "folder": str(folder_path),
        "recursive": recursive,
        "sidecar_count": sidecar_count,
        "metadata_read_count": metadata_read_count,
        "metadata_error_count": metadata_error_count,
        "require_tags": normalized_require,
        "exclude_tags": normalized_exclude,
        "date_prefix": normalized_date_prefix,
        "name_contains": normalized_name_contains,
        "require_gps": require_gps,
        "module": normalized_module,
        "media_type": normalized_media_type,
        "file_exists_only": file_exists_only,
        "match_count": len(matches),
        "matches": matches,
    }


def _metadata_value(metadata: dict[str, Any], dotted_key: str) -> Any:
    current: Any = metadata

    for part in dotted_key.split("."):
        if not isinstance(current, dict):
            return None
        current = current.get(part)

    return current


def _normalize_optional_text(value: Any) -> str | None:
    if value is None:
        return None

    text = str(value).strip().lower()
    return text or None


def _normalize_tags(tags: list[str] | None) -> list[str]:
    if not tags:
        return []

    return sorted(
        {
            str(tag).strip().lower()
            for tag in tags
            if str(tag).strip()
        }
    )


def _coerce_tags(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item) for item in value]

    if isinstance(value, str):
        return [
            item.strip()
            for item in value.split(",")
            if item.strip()
        ]

    return []


def _extract_tags(metadata: dict[str, Any], module: str | None) -> list[str]:
    # da tag keeps automatic tags in "auto_tags" and yours in "user"; older sidecars may also have
    # tags in their module block. All of them count.
    combined: list[str] = []
    for source in (
        _metadata_value(metadata, "auto_tags.tags"),
        _metadata_value(metadata, "user.tags"),
        _legacy_tags(metadata, module),
    ):
        for tag in _coerce_tags(source):
            if tag not in combined:
                combined.append(tag)
    return combined


def _legacy_tags(metadata: dict[str, Any], module: str | None) -> list[str]:
    if module:
        module_tags = _metadata_value(metadata, f"{module}.tags")
        coerced_module_tags = _coerce_tags(module_tags)
        if coerced_module_tags:
            return coerced_module_tags

    classification_module = _normalize_optional_text(
        _metadata_value(metadata, "classification.module")
    )

    if classification_module:
        module_tags = _metadata_value(metadata, f"{classification_module}.tags")
        coerced_module_tags = _coerce_tags(module_tags)
        if coerced_module_tags:
            return coerced_module_tags

    return _coerce_tags(
        _metadata_value(metadata, "tags")
        or _metadata_value(metadata, "photoit.tags")
        or _metadata_value(metadata, "scanit.tags")
    )


def _extract_gps(metadata: dict[str, Any], module: str | None) -> dict[str, Any]:
    gps: Any = None

    if module:
        gps = _metadata_value(metadata, f"{module}.gps")

    if gps is None:
        gps = (
            _metadata_value(metadata, "photoit.gps")
            or _metadata_value(metadata, "gps")
            or {}
        )

    if isinstance(gps, dict):
        return gps

    return {}


def _extract_date_text(metadata: dict[str, Any], module: str | None) -> str:
    value: Any = None

    if module:
        value = (
            _metadata_value(metadata, f"{module}.captured_at")
            or _metadata_value(metadata, f"{module}.document_date")
        )

    if value is None:
        value = (
            _metadata_value(metadata, "photoit.captured_at")
            or _metadata_value(metadata, "scanit.document_date")
            or _metadata_value(metadata, "file.modified_at")
            or _metadata_value(metadata, "captured_at")
        )

    return str(value or "").strip()


def _resolve_file_path(metadata_path: Path, metadata: dict[str, Any]) -> Path:
    for key in (
        "file.current_path",
        "current_path",
        "file_path",
        "source_path",
        "file.source_path",
        "doc_id",
    ):
        value = _metadata_value(metadata, key)
        if isinstance(value, str) and value.strip():
            return Path(value)

    sidecar_name = metadata_path.name
    if sidecar_name.endswith(".meta.json"):
        return metadata_path.with_name(sidecar_name.removesuffix(".meta.json"))

    return metadata_path


def _resolve_file_name(file_path: Path, metadata: dict[str, Any]) -> str:
    for key in (
        "file.file_name",
        "doc_name",
        "scanit.doc_name",
        "meta_ref.current_filename",
    ):
        value = _metadata_value(metadata, key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    return file_path.name

def find_summary_workflow(
    folder: str | Path,
    recursive: bool = True,
) -> dict[str, Any]:
    """
    Summarize metadata sidecars in a folder.

    This is diagnostic-oriented and helps explain what FindIt sees
    before tag filters are applied.
    """
    folder_path = Path(folder)

    sidecar_paths = (
        folder_path.rglob("*.meta.json")
        if recursive
        else folder_path.glob("*.meta.json")
    )

    sidecar_count = 0
    metadata_read_count = 0
    metadata_error_count = 0
    file_exists_count = 0
    missing_file_count = 0
    tagged_count = 0
    untagged_count = 0

    module_counts: Counter[str] = Counter()
    media_type_counts: Counter[str] = Counter()
    status_counts: Counter[str] = Counter()
    extension_counts: Counter[str] = Counter()
    validation_status_counts: Counter[str] = Counter()
    hash_status_counts: Counter[str] = Counter()
    duplicate_status_counts: Counter[str] = Counter()

    for metadata_path in sidecar_paths:
        sidecar_count += 1

        metadata = SidecarService.load_sidecar_path(metadata_path)
        if metadata is None:
            metadata_error_count += 1
            continue

        metadata_read_count += 1

        metadata_module = (
            _normalize_optional_text(
                _metadata_value(metadata, "classification.module")
                or _metadata_value(metadata, "module")
            )
            or "unknown"
        )

        metadata_media_type = (
            _normalize_optional_text(
                _metadata_value(metadata, "classification.media_type")
                or _metadata_value(metadata, "media_type")
            )
            or "unknown"
        )

        metadata_status = (
            _normalize_optional_text(
                _metadata_value(metadata, "classification.status")
            )
            or "unknown"
        )

        validation_status = (
            _normalize_optional_text(
                _metadata_value(metadata, "validation.status")
            )
            or "unknown"
        )

        hash_status = (
            _normalize_optional_text(
                _metadata_value(metadata, "quarantine.hash_status")
            )
            or "unknown"
        )

        duplicate_status = (
            _normalize_optional_text(
                _metadata_value(metadata, "quarantine.duplicate_status")
            )
            or "unknown"
        )

        extension = (
            _normalize_optional_text(
                _metadata_value(metadata, "file.extension")
            )
            or "unknown"
        )

        file_path = _resolve_file_path(metadata_path, metadata)
        if file_path.exists():
            file_exists_count += 1
        else:
            missing_file_count += 1

        tags = _extract_tags(metadata, metadata_module)
        if tags:
            tagged_count += 1
        else:
            untagged_count += 1

        module_counts[metadata_module] += 1
        media_type_counts[metadata_media_type] += 1
        status_counts[metadata_status] += 1
        extension_counts[extension] += 1
        validation_status_counts[validation_status] += 1
        hash_status_counts[hash_status] += 1
        duplicate_status_counts[duplicate_status] += 1

    return {
        "folder": str(folder_path),
        "recursive": recursive,
        "sidecar_count": sidecar_count,
        "metadata_read_count": metadata_read_count,
        "metadata_error_count": metadata_error_count,
        "file_exists_count": file_exists_count,
        "missing_file_count": missing_file_count,
        "tagged_count": tagged_count,
        "untagged_count": untagged_count,
        "module_counts": dict(sorted(module_counts.items())),
        "media_type_counts": dict(sorted(media_type_counts.items())),
        "status_counts": dict(sorted(status_counts.items())),
        "extension_counts": dict(sorted(extension_counts.items())),
        "validation_status_counts": dict(sorted(validation_status_counts.items())),
        "hash_status_counts": dict(sorted(hash_status_counts.items())),
        "duplicate_status_counts": dict(sorted(duplicate_status_counts.items())),
    }
