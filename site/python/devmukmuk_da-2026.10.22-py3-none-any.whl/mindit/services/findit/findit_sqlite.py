from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from typer import params


def find_sqlite_summary_workflow(
    db_path: str | Path,
    folder: str | Path | None = None,
) -> dict[str, Any]:
    db_path = Path(db_path)

    if not db_path.exists():
        raise FileNotFoundError(f"SQLite database not found: {db_path}")

    where_clauses: list[str] = []
    params: list[Any] = []

    if folder is not None:
        folder_text = str(Path(folder))
        where_clauses.append("path LIKE ?")
        params.append(f"{folder_text}%")

    where_sql = ""
    if where_clauses:
        where_sql = "WHERE " + " AND ".join(where_clauses)

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row

        total = _scalar(
            conn,
            f"SELECT COUNT(*) FROM files {where_sql}",
            params,
        )

        module_counts = _count_by(conn, "module", where_sql, params)
        media_type_counts = _count_by(conn, "media_type", where_sql, params)
        extension_counts = _count_by(conn, "extension", where_sql, params)
        validation_status_counts = _count_by(conn, "validation_status", where_sql, params)
        hash_status_counts = _count_by(conn, "hash_status", where_sql, params)
        duplicate_status_counts = _count_by(conn, "duplicate_status", where_sql, params)

        gps_where_sql = where_sql
        gps_params = list(params)

        if gps_where_sql:
            gps_where_sql = f"{gps_where_sql} AND gps_present = 1"
        else:
            gps_where_sql = "WHERE gps_present = 1"

        gps_files = _scalar(
            conn,
            f"SELECT COUNT(*) FROM files {gps_where_sql}",
            gps_params,
        )

    return {
        "backend": "sqlite",
        "db_path": str(db_path),
        "folder": str(folder) if folder is not None else None,
        "file_count": total,
        "gps_files": gps_files,
        "module_counts": module_counts,
        "media_type_counts": media_type_counts,
        "extension_counts": extension_counts,
        "validation_status_counts": validation_status_counts,
        "hash_status_counts": hash_status_counts,
        "duplicate_status_counts": duplicate_status_counts,
    }


def _scalar(
    conn: sqlite3.Connection,
    sql: str,
    params: list[Any],
) -> int:
    row = conn.execute(sql, params).fetchone()
    if row is None:
        return 0

    return int(row[0] or 0)


def _count_by(
    conn: sqlite3.Connection,
    column: str,
    where_sql: str,
    params: list[Any],
) -> dict[str, int]:
    rows = conn.execute(
        f"""
        SELECT COALESCE({column}, 'unknown') AS value, COUNT(*) AS count
        FROM files
        {where_sql}
        GROUP BY COALESCE({column}, 'unknown')
        ORDER BY value
        """,
        params,
    ).fetchall()

    return {str(row["value"]): int(row["count"]) for row in rows}
