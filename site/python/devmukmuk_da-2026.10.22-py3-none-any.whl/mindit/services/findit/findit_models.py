from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class FindItMatch:
    file_path: Path
    metadata_path: Path
    sidecar_exists: bool
    tags: list[str]
    captured_at: str | None
    module: str | None
    metadata: dict[str, Any]
