# src/mindit/services/workflow/merge.py

"""`da merge --from <other archive>`: copy into this archive everything the other one has that this one doesn't.

Nothing in the other archive is moved, changed or deleted. Files are matched by content (sha256): what this
archive already has, anywhere, is skipped. A filed photo or document keeps its place
(organized\\YYYY\\YYYY-MM\\<name>, location folders included) when that path is free here, its year fits this
archive's years, and both archives name files the same way; anything else goes to this archive's intake
(intake\\photos\\from-<other>\\...) for `da run` to file by this archive's rules. Every copy is logged; `da
intake undo <log>` removes the copies again.
"""

from __future__ import annotations

import csv
import hashlib
import os
import re
import shutil
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from mindit.services.dbit.archive_index_service import _block, _load_json, _sha256
from mindit.services.dbit.intake_service import LOG_FIELDS
from mindit.services.workflow.split import archive_settings, archive_years

SIDECAR_SUFFIX = ".meta.json"
LOG_CLASS = "merge"
SKIP_NAMES = {"_contact-sheet.pdf", "desktop.ini", "thumbs.db"}
SKIP_DIRS = {"$RECYCLE.BIN", "System Volume Information", ".validateit-quarantine", ".da", ".mindit"}


@dataclass(frozen=True)
class Layout:
    """Where an archive keeps its filed photos, filed documents and intake."""

    root: Path
    photos: Path
    documents: Path
    intake: Path
    photo_pattern: str
    document_pattern: str


def layout_of(root: Path) -> Layout:
    """Return an archive's folders and naming patterns from its da-archive.yaml (DA's defaults otherwise)."""
    data = archive_settings(root)
    paths = data.get("paths") or {}
    modules = data.get("modules") or {}
    photoit, scanit = modules.get("photoit") or {}, modules.get("scanit") or {}
    root = Path(root)
    return Layout(
        root=root,
        photos=root / str(paths.get("photos") or "photos") / str(photoit.get("organized_root") or "organized"),
        documents=root / str(paths.get("documents") or "documents") / str(scanit.get("organized_root") or "organized"),
        intake=root / str(paths.get("intake") or "intake"),
        photo_pattern=str(photoit.get("pattern") or ""),
        document_pattern=str(scanit.get("pattern") or ""),
    )


def file_hash(path: Path) -> str | None:
    """Return a file's sha256: from its sidecar when that's still current, else worked out now."""
    try:
        stat = path.stat()
    except OSError:
        return None
    meta = _load_json(Path(f"{path}{SIDECAR_SUFFIX}"))
    known = _sha256(_block(meta, "file"), _block(meta, "quarantine"), stat.st_size, stat.st_mtime)
    if known:
        return known
    digest = hashlib.sha256()
    try:
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError:
        return None
    return digest.hexdigest()


def _walk(folder: Path):
    if not folder.is_dir():
        return
    for dirpath, dirnames, filenames in os.walk(folder):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for name in sorted(filenames):
            if name.lower().endswith(SIDECAR_SUFFIX) or name.lower() in SKIP_NAMES:
                continue
            yield Path(dirpath, name)


# --------------------------------------------------------------------------- planning

@dataclass
class Copy:
    """One file to copy, and why it goes where it goes."""

    source: Path
    destination: Path
    size: int
    reason: str                       # "filed" (same place), or why it goes to intake


@dataclass
class MergePlan:
    """What a merge will copy."""

    here: Path
    other: Path
    copies: list[Copy] = field(default_factory=list)
    already_here: int = 0             # same content already in this archive
    repeats: int = 0                  # the other archive holds the same content twice: copied once
    unreadable: list[Path] = field(default_factory=list)
    looked_at: int = 0

    @property
    def bytes(self) -> int:
        """Return how much the copies take."""
        return sum(c.size for c in self.copies)

    def reasons(self) -> Counter:
        """Return how many copies go where, by reason."""
        return Counter(c.reason for c in self.copies)


def _year_of(relative: Path) -> int | None:
    first = relative.parts[0] if relative.parts else ""
    return int(first) if re.fullmatch(r"\d{4}", first) else None


def _from_folder(other: Path) -> str:
    return "from-" + (re.sub(r"[^A-Za-z0-9._-]+", "-", other.name).strip("-") or "other-archive")


def plan_merge(here: Path, other: Path, known: set[str], *,
               progress: Callable[[int], None] | None = None) -> MergePlan:
    """Return what to copy from the other archive, given the sha256s this archive already holds."""
    mine, theirs = layout_of(here), layout_of(other)
    years = archive_years(here)
    from_folder = _from_folder(other)
    intake_photos = mine.intake / "photos" / from_folder
    intake_docs = mine.intake / "docs" / from_folder
    plan = MergePlan(here, other)
    seen = set(known)
    taken: set[str] = set()                                      # destinations planned already

    trees = [(theirs.photos, mine.photos, mine.photo_pattern == theirs.photo_pattern, intake_photos, "organized"),
             (theirs.documents, mine.documents, mine.document_pattern == theirs.document_pattern, intake_docs,
              "organized-documents"),
             (theirs.intake, None, False, mine.intake, None)]
    for source_root, target_root, same_names, fallback, label in trees:
        for path in _walk(source_root):
            plan.looked_at += 1
            if progress and plan.looked_at % 500 == 0:
                progress(plan.looked_at)
            digest = file_hash(path)
            if digest is None:
                plan.unreadable.append(path)
                continue
            if digest in seen:
                if digest in known:
                    plan.already_here += 1
                else:
                    plan.repeats += 1
                continue
            seen.add(digest)
            relative = path.relative_to(source_root)
            size = path.stat().st_size
            if target_root is None:                               # the other archive's intake
                parts = relative.parts
                destination = (mine.intake / parts[0] / from_folder / Path(*parts[1:]) if len(parts) > 1
                                else mine.intake / from_folder / relative)
                reason = "their intake"
            else:
                destination, reason = target_root / relative, "filed"
                year = _year_of(relative)
                if not same_names:
                    reason = "named differently there"
                elif years and (year is None or not years[0] <= year <= years[1]):
                    reason = "outside this archive's years"
                elif destination.exists() or os.path.normcase(str(destination)) in taken:
                    reason = "a different file has that name here"
                if reason != "filed":
                    destination = fallback / label / relative
            key = os.path.normcase(str(destination))
            n = 2
            while destination.exists() or key in taken:          # never overwrite; keep both
                destination = destination.with_name(f"{destination.stem}-{n}{destination.suffix}")
                key = os.path.normcase(str(destination))
                n += 1
            taken.add(key)
            plan.copies.append(Copy(path, destination, size, reason))
    return plan


# --------------------------------------------------------------------------- copying

def _copy(src: Path, dst: Path) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    if dst.stat().st_size != src.stat().st_size:
        dst.unlink(missing_ok=True)
        raise OSError(f"copy of {src} came out a different size")


def apply_merge(plan: MergePlan, log_path: Path, *, progress: Callable[[int, int], None] | None = None) -> Counter:
    """Copy each file (and its sidecar); log every copy so `da intake undo` can remove them again."""
    stats: Counter = Counter()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", newline="", encoding="utf-8") as f:
        log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        log.writeheader()
        for i, item in enumerate(plan.copies, 1):
            if progress:
                progress(i, len(plan.copies))
            entry = {"class": LOG_CLASS, "source": str(item.source), "destination": str(item.destination),
                     "size_bytes": str(item.size), "sha256": "", "kept": "", "sidecar_source": "",
                     "sidecar_destination": "", "note": item.reason}
            if item.destination.exists() or not item.source.exists():
                entry["result"] = "skipped"
                stats["skipped"] += 1
                log.writerow(entry)
                continue
            try:
                _copy(item.source, item.destination)
                side_src, side_dst = Path(f"{item.source}{SIDECAR_SUFFIX}"), Path(f"{item.destination}{SIDECAR_SUFFIX}")
                if side_src.exists() and not side_dst.exists():
                    _copy(side_src, side_dst)
                    entry["sidecar_source"], entry["sidecar_destination"] = str(side_src), str(side_dst)
            except OSError as error:
                entry["result"], entry["note"] = "skipped", str(error)
                stats["failed"] += 1
                log.writerow(entry)
                continue
            entry["result"] = "copied"
            stats["copied"] += 1
            stats["filed" if item.reason == "filed" else "to_intake"] += 1
            log.writerow(entry)
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("merge", f"copied {stats['copied']} files from {plan.other} ({stats['filed']} filed, "
              f"{stats['to_intake']} to intake; undo: {log_path})", path=str(log_path))
    return stats


def undo_copies(rows: list[dict[str, str]]) -> Counter:
    """Remove the copies a merge made (only those still the size they were copied at), and emptied folders."""
    stats: Counter = Counter()
    folders = set()
    for r in rows:
        for copied in (r["destination"], r["sidecar_destination"]):
            if not copied:
                continue
            path = Path(copied)
            if not path.exists():
                stats["skipped"] += 1
                continue
            if copied == r["destination"] and r.get("size_bytes") and str(path.stat().st_size) != r["size_bytes"]:
                stats["skipped"] += 1                          # changed since: leave it
                continue
            path.unlink()
            stats["restored"] += 1
            folders.add(path.parent)
    for folder in sorted(folders, key=lambda p: -len(p.parts)):
        while _removable(folder):                      # the month, then its year (or a from-... folder) when empty
            try:
                rest = [p for p in folder.iterdir() if p.name.lower() != "_contact-sheet.pdf"]
                if rest:
                    break
                (folder / "_contact-sheet.pdf").unlink(missing_ok=True)
                folder.rmdir()
            except OSError:
                break
            folder = folder.parent
    return stats


def _removable(folder: Path) -> bool:
    """Return True for a folder a merge may have made: a year, a month (or location) folder, or under from-..."""
    return folder.is_dir() and (bool(re.match(r"^\d{4}(-\d{2})?( |$|-\d{2})", folder.name))
                                or any(part.startswith("from-") for part in folder.parts))
