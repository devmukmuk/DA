# src/mindit/services/workflow/split.py

"""`da split`: move what this archive's intake holds from other years into the archive for those years.

An archive with `archive.years` (e.g. 1990-1999) leaves photos and documents taken in other years in
intake. Split works out each one's date the way `da run` does, picks those inside the other archive's years
(or --years), and moves them - with sidecars, raw files and Live Photo videos - into that archive's
intake (intake\\photos\\from-<this archive>\\..., keeping the folders they were in). Every move is logged
like a set-aside, so `da intake undo <log>` brings them back.
"""

from __future__ import annotations

import csv
import os
import re
import shutil
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from mindit.services.dbit.intake_service import LOG_FIELDS
from mindit.services.validateit.validateit_file_types import (
    DOCUMENT_EXTENSIONS,
    PHOTO_EXTENSIONS,
    MediaKind,
    companions,
)

SIDECAR_SUFFIX = ".meta.json"
LOG_CLASS = "split"
SKIP_NAMES = {"_contact-sheet.pdf", "desktop.ini", "thumbs.db"}
_YEARS = re.compile(r"^\s*(\d{4})\s*-\s*(\d{4})\s*$")


def parse_years(text: str | None) -> tuple[int, int] | None:
    """Return (first, last) from "2000-2009", or None."""
    m = _YEARS.match(text or "")
    if not m or int(m[1]) > int(m[2]):
        return None
    return int(m[1]), int(m[2])


def archive_settings(folder: Path) -> dict:
    """Return an archive's da-archive.yaml as a dict ({} when unreadable)."""
    import yaml  # pylint: disable=import-outside-toplevel

    try:
        data = yaml.safe_load((Path(folder) / "da-archive.yaml").read_text(encoding="utf-8"))
    except (OSError, ValueError, yaml.YAMLError):
        return {}
    return data if isinstance(data, dict) else {}


def archive_years(folder: Path) -> tuple[int, int] | None:
    """Return the years an archive takes, or None when it takes any year."""
    return parse_years(str((archive_settings(folder).get("archive") or {}).get("years") or ""))


def archive_name(folder: Path) -> str:
    """Return an archive's name (its folder's name when it has none)."""
    return str((archive_settings(folder).get("archive") or {}).get("name") or Path(folder).name)


def intake_folder_for(archive: Path, kind: MediaKind) -> Path:
    """Return the intake folder an archive files this kind from: intake\\photos or intake\\docs by default."""
    from mindit.config.settings import DEFAULT_INTAKE_FOLDERS  # pylint: disable=import-outside-toplevel

    data = archive_settings(archive)
    intake = Path(archive) / str((data.get("paths") or {}).get("intake") or "intake")
    folders = data.get("intake") or DEFAULT_INTAKE_FOLDERS
    for name, folder_kind in folders.items():
        if folder_kind == kind.value:
            return intake / name
    return intake / ("photos" if kind == MediaKind.PHOTO else "docs")


# --------------------------------------------------------------------------- finding

@dataclass
class Stray:
    """A file in intake taken outside this archive's years."""

    path: Path
    kind: MediaKind
    year: int
    relative: Path                     # where it sits under intake (kept in the other archive)


def _is_companion_name(path: Path) -> bool:
    """Return True for a raw file or a video: they travel with a photo, never on their own."""
    suffix = path.suffix.lower()
    return suffix not in PHOTO_EXTENSIONS and suffix not in DOCUMENT_EXTENSIONS


def find_strays(intake: Path, years: tuple[int, int] | None, *, intake_names: set[str] | None = None,
                progress: Callable[[int], None] | None = None) -> tuple[list[Stray], int]:
    """Return intake's files with a sure date outside `years` (all dated files when None), and how many had no sure date."""
    from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.scanit_repair_provider import ScanItRepairProvider  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.validateit_file_types import MediaClassifier  # pylint: disable=import-outside-toplevel

    from mindit.config.settings import DEFAULT_INTAKE_FOLDERS  # pylint: disable=import-outside-toplevel

    names = {n.lower() for n in (intake_names or DEFAULT_INTAKE_FOLDERS)}
    classifier = MediaClassifier(default_kind=MediaKind.PHOTO)
    providers = {MediaKind.PHOTO: PhotoItRepairProvider(), MediaKind.DOCUMENT: ScanItRepairProvider()}
    strays: list[Stray] = []
    undated = seen = 0
    for dirpath, dirnames, filenames in os.walk(intake):
        dirnames[:] = [d for d in dirnames if not d.startswith(".")]
        for name in sorted(filenames):
            path = Path(dirpath, name)
            if name.lower().endswith(SIDECAR_SUFFIX) or name.lower() in SKIP_NAMES or _is_companion_name(path):
                continue
            kind = classifier.kind(path)
            if kind is None:
                continue
            seen += 1
            if progress and seen % 200 == 0:
                progress(seen)
            try:
                capture = providers[kind].capture_date(path)
            except Exception:  # pylint: disable=broad-except
                undated += 1
                continue
            if not capture.certain or capture.value is None:
                undated += 1
                continue
            year = capture.value.year
            if years and years[0] <= year <= years[1]:
                continue
            relative = path.relative_to(intake)
            if len(relative.parts) > 1 and relative.parts[0].lower() in names:   # intake\photos\a.jpg -> a.jpg
                relative = Path(*relative.parts[1:])
            strays.append(Stray(path, kind, year, relative))
    return strays, undated


def by_archive(strays: list[Stray], archives: list[Path], here: Path) -> tuple[dict[Path, list[Stray]], list[Stray]]:
    """Return the strays grouped by the registered archive whose years take them, and those no archive takes."""
    ranges = [(a, archive_years(a)) for a in archives
              if os.path.normcase(str(Path(a).resolve())) != os.path.normcase(str(Path(here).resolve()))]
    placed: dict[Path, list[Stray]] = {}
    nowhere: list[Stray] = []
    for stray in strays:
        home = next((a for a, yrs in ranges if yrs and yrs[0] <= stray.year <= yrs[1]), None)
        if home is None:
            nowhere.append(stray)
        else:
            placed.setdefault(home, []).append(stray)
    return placed, nowhere


# --------------------------------------------------------------------------- moving

@dataclass
class SplitMove:
    """One file going to the other archive."""

    source: Path
    destination: Path
    companion_of: Path | None = None


@dataclass
class SplitPlan:
    """What moves where."""

    target: Path
    moves: list[SplitMove] = field(default_factory=list)
    conflicts: list[Path] = field(default_factory=list)
    photos: int = 0
    documents: int = 0


def _on_disk(path: Path) -> Path:
    """Return the path spelled as it is on disk (a case-insensitive drive finds IMG_1.MOV as IMG_1.mov)."""
    wanted = path.name.lower()
    for entry in os.scandir(path.parent):
        if entry.name.lower() == wanted:
            return path.with_name(entry.name)
    return path


def plan_split(strays: list[Stray], target: Path, from_name: str, years: tuple[int, int]) -> SplitPlan:
    """Return the moves for the strays taken in `years`, into target's intake\\<kind folder>\\from-<name>\\."""
    plan = SplitPlan(target)
    from_folder = "from-" + re.sub(r"[^A-Za-z0-9._-]+", "-", from_name).strip("-")
    for stray in strays:
        if not years[0] <= stray.year <= years[1]:
            continue
        base = intake_folder_for(target, stray.kind) / from_folder / stray.relative.parent
        files = [stray.path] + [_on_disk(c) for c in companions(stray.path)]
        targets = [base / f.name for f in files]
        if any(t.exists() for t in targets):
            plan.conflicts.append(stray.path)
            continue
        for i, (src, dst) in enumerate(zip(files, targets)):
            plan.moves.append(SplitMove(src, dst, None if i == 0 else stray.path))
        if stray.kind == MediaKind.PHOTO:
            plan.photos += 1
        else:
            plan.documents += 1
    return plan


def _move(src: Path, dst: Path) -> None:
    """Move a file, also to another drive (copy, check the size, then remove the original)."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.rename(src, dst)
        return
    except OSError:
        pass
    shutil.copy2(src, dst)
    if dst.stat().st_size != src.stat().st_size:
        dst.unlink(missing_ok=True)
        raise OSError(f"copy of {src} came out a different size")
    src.unlink()


def apply_split(plan: SplitPlan, log_path: Path, db_path: Path | None = None) -> Counter:
    """Move the files and their sidecars; log every move so `da intake undo` reverses it."""
    stats: Counter = Counter()
    gone: list[str] = []
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", newline="", encoding="utf-8") as f:
        log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        log.writeheader()
        for move in plan.moves:
            src, dst = move.source, move.destination
            entry = {"class": LOG_CLASS, "source": str(src), "destination": str(dst), "size_bytes": "",
                     "sha256": "", "kept": str(move.companion_of or ""), "sidecar_source": "",
                     "sidecar_destination": "", "note": str(plan.target)}
            if not src.exists() or dst.exists():
                entry["result"] = "skipped"
                stats["skipped"] += 1
                log.writerow(entry)
                continue
            entry["size_bytes"] = str(src.stat().st_size)
            try:
                _move(src, dst)
            except OSError as error:
                entry["result"], entry["note"] = "skipped", str(error)
                stats["failed"] += 1
                log.writerow(entry)
                continue
            side_src, side_dst = Path(f"{src}{SIDECAR_SUFFIX}"), Path(f"{dst}{SIDECAR_SUFFIX}")
            if side_src.exists() and not side_dst.exists():
                _move(side_src, side_dst)
                entry["sidecar_source"], entry["sidecar_destination"] = str(side_src), str(side_dst)
            entry["result"] = "moved"
            stats["moved"] += 1
            if move.companion_of is None:
                stats["files"] += 1
            gone.append(str(src))
            log.writerow(entry)
    if db_path and Path(db_path).exists() and gone:
        import sqlite3  # pylint: disable=import-outside-toplevel

        with sqlite3.connect(db_path) as conn:                     # they're the other archive's now
            conn.executemany("DELETE FROM files WHERE path = ?", [(p,) for p in gone])
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("split", f"moved {stats['files']} files to {plan.target}"
              f" ({stats['skipped'] + stats['failed']} not moved; undo: {log_path})", path=str(log_path))
    return stats
