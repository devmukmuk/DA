"""QR code generation helpers for PackIt box sheets."""
# src/mindit/services/packit_qrcode_service.py

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

from PIL import Image, ImageDraw, ImageFont
from qrcode import QRCode
from qrcode.constants import ERROR_CORRECT_L
from qrcode.image.pil import PilImage

from mindit import __version__
from mindit.config.settings import load_settings
from mindit.services.packit.packit_resolver_service import split_room_folder_name


COLOR_MAP: dict[str, Tuple[int, int, int]] = {
    "RED": (220, 20, 60),
    "BLUE": (30, 144, 255),
    "GREEN": (34, 139, 34),
    "YELLOW": (255, 215, 0),
    "ORANGE": (255, 140, 0),
    "PURPLE": (138, 43, 226),
    "BLACK": (0, 0, 0),
    "WHITE": (255, 255, 255),
    "GRAY": (128, 128, 128),
    "GREY": (128, 128, 128),
    "BROWN": (139, 69, 19),
    "PINK": (255, 105, 180),
}


def build_drive_link(file_id: str, file_type: str) -> str:
    """
    Build a Google Drive URL for the given file type.

    Args:
        file_id: Google file identifier.
        file_type: Logical file type such as "sheet", "doc", or "pdf".

    Returns:
        A shareable Google URL appropriate for the file type.
    """
    normalized = file_type.strip().lower()

    if normalized == "sheet":
        return f"https://docs.google.com/spreadsheets/d/{file_id}"

    if normalized == "doc":
        return f"https://docs.google.com/document/d/{file_id}"

    return f"https://drive.google.com/file/d/{file_id}/preview"


def get_box_qrcode_filename(room_abbr: str, box_number: Optional[int]) -> str:
    """
    Return the expected QR code filename for a box.
    """
    return (
        f"{room_abbr}-{box_number:02d}.png"
        if box_number is not None
        else f"{room_abbr}.png"
    )


def _load_font(font_name: str, size: int):
    """
    Try to load a TrueType font and fall back to the default PIL font.
    """
    try:
        return ImageFont.truetype(font_name, size)
    except OSError:
        return ImageFont.load_default()


def _is_dark_color(rgb: Tuple[int, int, int]) -> bool:
    """
    Return True if a color is dark enough that white text is preferable.
    """
    red, green, blue = rgb
    luminance = (red * 0.299) + (green * 0.587) + (blue * 0.114)
    return luminance < 186


def _resolve_tape_colors(
    tape: str,
) -> tuple[Tuple[int, int, int] | None, Tuple[int, int, int] | None]:
    """
    Resolve tape color text into one or two RGB colors.

    Supported examples:
        RED -> (RED, None)
        REDBLACK -> (RED, BLACK)
        BLUEYELLOW -> (BLUE, YELLOW)

    Fallback behavior:
        - If exact single color exists, return it as the primary color.
        - If exactly two known colors concatenate to the input, return both.
        - If the input starts with a known color, return that as primary only.
        - Otherwise return (None, None).
    """
    if not tape:
        return None, None

    normalized = (
        tape.strip()
        .upper()
        .replace("-", "")
        .replace("_", "")
        .replace(" ", "")
    )
    if not normalized:
        return None, None

    if normalized in COLOR_MAP:
        return COLOR_MAP[normalized], None

    color_names = sorted(COLOR_MAP.keys(), key=len, reverse=True)

    for first_name in color_names:
        if not normalized.startswith(first_name):
            continue

        remainder = normalized[len(first_name):]
        if remainder in COLOR_MAP:
            return COLOR_MAP[first_name], COLOR_MAP[remainder]

    for first_name in color_names:
        if normalized.startswith(first_name):
            return COLOR_MAP[first_name], None

    return None, None


def _draw_box_label_background(
    draw: ImageDraw.ImageDraw,
    text_x: int,
    text_y: int,
    box_label: str,
    box_font,
    primary_color: Tuple[int, int, int] | None,
    secondary_color: Tuple[int, int, int] | None,
) -> tuple[int, int, int, int]:
    """
    Draw a solid or split-color rectangle behind the main box label.

    Returns:
        The rectangle bounds as (x1, y1, x2, y2).
    """
    bbox = draw.textbbox((0, 0), box_label, font=box_font)
    text_width = int(bbox[2] - bbox[0])
    text_height = int(bbox[3] - bbox[1])

    padding_x = 40
    padding_y = 20

    rect_x1 = int(text_x - padding_x)
    rect_y1 = int(text_y - padding_y)
    rect_x2 = int(text_x + text_width + padding_x)
    rect_y2 = int(text_y + text_height + padding_y)

    if primary_color:
        if secondary_color:
            mid_x = (rect_x1 + rect_x2) // 2
            draw.rectangle(
                [(rect_x1, rect_y1), (mid_x, rect_y2)],
                fill=primary_color,
            )
            draw.rectangle(
                [(mid_x, rect_y1), (rect_x2, rect_y2)],
                fill=secondary_color,
            )
        else:
            draw.rectangle(
                [(rect_x1, rect_y1), (rect_x2, rect_y2)],
                fill=primary_color,
            )

    return rect_x1, rect_y1, rect_x2, rect_y2


def _choose_label_text_color(
    primary_color: Tuple[int, int, int] | None,
    secondary_color: Tuple[int, int, int] | None,
) -> str:
    """
    Choose a readable text color for the box label.

    For split colors, if either side is dark, use white.
    """
    if not primary_color:
        return "black"

    if secondary_color:
        return (
            "white"
            if (_is_dark_color(primary_color) or _is_dark_color(secondary_color))
            else "black"
        )

    return "white" if _is_dark_color(primary_color) else "black"


def delete_box_qrcode(
    room_abbr: str,
    box_number: Optional[int],
    state: dict,
) -> Optional[str]:
    """
    Delete the expected QR code file for a box if it exists.
    """
    output_dir = state["qrcodes_dir"] if "qrcodes_dir" in state else state["output_dir"]
    filename = (
        f"{room_abbr}-{box_number}.png"
        if box_number is not None
        else f"{room_abbr}.png"
    )
    path = os.path.join(output_dir, filename)

    if os.path.exists(path):
        os.remove(path)
        return path

    return None


def get_pdf_qrcode_filename(pdf_name: str) -> str:
    """
    Return the expected QR code filename for a PDF.
    """
    safe_name = "".join(
        ch if ch.isalnum() or ch in ("-", "_") else "_"
        for ch in Path(pdf_name).stem
    ).strip("_")

    return f"{safe_name or 'document'}.png"

def create_qrcode_for_box(
    sheet_id: str,
    room_abbr: str,
    room_folder_name: str,
    household_name: str,
    output_dir: str,
    box_number: Optional[int] = None,
    version: str = __version__,
    timestamp: Optional[str] = None,
    back_color: Tuple[int, int, int] = (255, 255, 255),
) -> str:
    """
    Generate a QR code PNG for a box Google Sheet.
    """
    url = build_drive_link(sheet_id, "sheet")
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    settings = load_settings()

    if timestamp is None:
        timestamp = datetime.now().strftime(settings.general.datetime_format)

    qr = QRCode(
        version=1,
        error_correction=ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    qr_img: Image.Image = qr.make_image(
        image_factory=PilImage,
        fill_color=(0, 0, 0),
        back_color=back_color,
    ).convert("RGB")

    qr_size = 700
    qr_img = qr_img.resize((qr_size, qr_size))

    width = 1600
    height = 900
    img = Image.new("RGB", (width, height), color=back_color)
    img.paste(qr_img, (40, 50))

    draw = ImageDraw.Draw(img)

    household_font = _load_font("arialbd.ttf", 50)
    box_font = _load_font("arialbd.ttf", 280)
    room_font = _load_font("arialbd.ttf", 50)
    meta_font = _load_font("arialbd.ttf", 50)

    if box_number is not None:
        box_label = f"{room_abbr}-{box_number}"
    else:
        box_label = room_abbr

    room_name, room_abbr, room_tape = split_room_folder_name(room_folder_name)
    household_text = household_name.strip() if household_name else "Unknown Household"
    room_name_text = room_name.strip() if room_folder_name else "Unknown Room"
    room_tape_text = room_tape.strip() if room_tape else ""
    meta_text_generated = f"Generated: {timestamp}"
    meta_text_version = f"DA v{version}"

    tape_primary, tape_secondary = _resolve_tape_colors(room_tape_text)
    label_text_color = _choose_label_text_color(tape_primary, tape_secondary)

    text_x = 750
    box_y = 280

    draw.text((text_x, 70), household_text, fill="black", font=household_font)
    draw.text((text_x, 120), room_name_text, fill="black", font=room_font)

    if room_tape_text:
        draw.text((text_x, 180), room_tape_text, fill="black", font=room_font)

    rect_x1, rect_y1, rect_x2, rect_y2 = _draw_box_label_background(
        draw=draw,
        text_x=text_x,
        text_y=box_y,
        box_label=box_label,
        box_font=box_font,
        primary_color=tape_primary,
        secondary_color=tape_secondary,
    )

    rect_center_x = (rect_x1 + rect_x2) // 2
    rect_center_y = (rect_y1 + rect_y2) // 2

    draw.text(
        (rect_center_x, rect_center_y),
        box_label,
        fill=label_text_color,
        font=box_font,
        stroke_width=8 if label_text_color == "white" else 0,
        stroke_fill="black",
        anchor="mm",
    )

    draw.text((text_x, 590), meta_text_generated, fill="black", font=meta_font)
    draw.text((text_x, 640), meta_text_version, fill="black", font=meta_font)

    filename = get_box_qrcode_filename(room_abbr, box_number)
    path = os.path.join(output_dir, filename)
    img.save(path)

    return path



def create_qrcode_for_pdf(
    file_id: str,
    pdf_name: str,
    output_dir: str,
    version: str = __version__,
    timestamp: Optional[str] = None,
    back_color: Tuple[int, int, int] = (255, 255, 255),
) -> str:
    """
    Generate a QR code PNG for a PDF stored in Google Drive.

    Args:
        file_id: Google Drive file ID for the PDF.
        pdf_name: Display name for the PDF and base filename for the QR image.
        output_dir: Folder where the QR image will be written.
        version: DA version string.
        timestamp: Optional generated timestamp. If omitted, use settings format.
        back_color: RGB background color for the label image.

    Returns:
        Full path to the saved QR code PNG.
    """
    url = build_drive_link(file_id, "pdf")
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    settings = load_settings()

    if timestamp is None:
        timestamp = datetime.now().strftime(settings.general.datetime_format)

    qr = QRCode(
        version=1,
        error_correction=ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    qr_img: Image.Image = qr.make_image(
        image_factory=PilImage,
        fill_color=(0, 0, 0),
        back_color=back_color,
    ).convert("RGB")

    qr_size = 700
    qr_img = qr_img.resize((qr_size, qr_size))

    width = 1600
    height = 900
    img = Image.new("RGB", (width, height), color=back_color)
    img.paste(qr_img, (40, 50))

    draw = ImageDraw.Draw(img)

    title_font = _load_font("arialbd.ttf", 72)
    name_font = _load_font("arialbd.ttf", 54)
    meta_font = _load_font("arialbd.ttf", 50)

    title_text = "Google Drive PDF"
    pdf_text = pdf_name.strip() if pdf_name else "Unknown PDF"
    meta_text_generated = f"Generated: {timestamp}"
    meta_text_version = f"DA v{version}"

    text_x = 750

    draw.text((text_x, 70), title_text, fill="black", font=title_font)
    draw.text((text_x, 180), pdf_text, fill="black", font=name_font)
    draw.text((text_x, 590), meta_text_generated, fill="black", font=meta_font)
    draw.text((text_x, 640), meta_text_version, fill="black", font=meta_font)

    safe_name = "".join(
        ch if ch.isalnum() or ch in ("-", "_") else "_"
        for ch in Path(pdf_text).stem
    ).strip("_")

    filename = f"{safe_name or 'document'}.png"
    path = os.path.join(output_dir, filename)
    img.save(path)

    return path
