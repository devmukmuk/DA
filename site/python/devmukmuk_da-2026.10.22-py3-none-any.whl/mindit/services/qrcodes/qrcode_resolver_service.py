"""Resolver helpers for locating PDF files in Google Drive folders."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from googleapiclient.discovery import Resource

from mindit.providers.google.clients import get_drive_service


PDF_MIMETYPE = "application/pdf"
FOLDER_MIMETYPE = "application/vnd.google-apps.folder"


@dataclass(slots=True)
class PdfFileRef:
    """
    Reference data for a PDF file discovered in Google Drive.

    Args:
        file_id: Google Drive file identifier.
        file_name: Google Drive file name.
        parent_id: Parent folder identifier if known.
        parent_path: Logical parent path accumulated during recursive traversal.
    """

    file_id: str
    file_name: str
    parent_id: str | None = None
    parent_path: str = ""


def _list_drive_children(
    drive_service: Resource,
    folder_id: str,
) -> list[dict[str, Any]]:
    """
    List all immediate children for a Google Drive folder.

    Args:
        drive_service: Authenticated Google Drive service resource.
        folder_id: Google Drive folder identifier.

    Returns:
        List of child file dictionaries.
    """
    results: list[dict[str, Any]] = []
    page_token: str | None = None

    while True:
        response = (
            drive_service.files()
            .list(
                q=f"'{folder_id}' in parents and trashed = false",
                spaces="drive",
                fields=(
                    "nextPageToken, "
                    "files(id, name, mimeType, parents)"
                ),
                orderBy="name_natural",
                pageSize=1000,
                pageToken=page_token,
            )
            .execute()
        )

        results.extend(response.get("files", []))
        page_token = response.get("nextPageToken")

        if not page_token:
            break

    return results


def get_pdf_refs_from_folder(
    root_id: str,
    recursive: bool = False,
) -> list[PdfFileRef]:
    """
    Resolve PDF files from a Google Drive folder.

    Args:
        root_id: Google Drive folder identifier to scan.
        recursive: Whether to recurse into child folders.

    Returns:
        List of PDF file references sorted in natural Drive order.
    """
    drive_service = get_drive_service()
    pdf_refs: list[PdfFileRef] = []

    def _walk(folder_id: str, parent_path: str = "") -> None:
        children = _list_drive_children(
            drive_service=drive_service,
            folder_id=folder_id,
        )

        for item in children:
            item_id = str(item.get("id", "")).strip()
            item_name = str(item.get("name", "")).strip()
            mime_type = str(item.get("mimeType", "")).strip()
            parents = item.get("parents", [])
            parent_id = str(parents[0]).strip() if parents else None

            if not item_id or not item_name:
                continue

            if mime_type == PDF_MIMETYPE:
                pdf_refs.append(
                    PdfFileRef(
                        file_id=item_id,
                        file_name=item_name,
                        parent_id=parent_id,
                        parent_path=parent_path,
                    )
                )
                continue

            if recursive and mime_type == FOLDER_MIMETYPE:
                child_path = f"{parent_path}/{item_name}" if parent_path else item_name
                _walk(item_id, child_path)

    _walk(root_id)
    return pdf_refs
