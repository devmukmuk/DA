"""Workflow helpers for generating QR codes for Google Drive PDFs."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mindit import __version__
from mindit.services.qrcodes.qrcode_resolver_service import PdfFileRef, get_pdf_refs_from_folder
from mindit.services.qrcodes.qrcode_service import create_qrcode_for_pdf, get_pdf_qrcode_filename


def _build_pdf_output_path(
    output_dir: str,
    pdf_ref: PdfFileRef,
    preserve_tree: bool = False,
) -> Path:
    """
    Build the expected output path for a PDF QR code image.

    Args:
        output_dir: Base output directory.
        pdf_ref: PDF file reference.
        preserve_tree: Whether to preserve the discovered Drive folder path.

    Returns:
        Expected output path for the QR code PNG file.
    """
    base_dir = Path(output_dir)

    if preserve_tree and pdf_ref.parent_path:
        base_dir = base_dir / pdf_ref.parent_path

    return base_dir / get_pdf_qrcode_filename(pdf_ref.file_name)


def create_pdf_qrcodes_from_folder_workflow(
    root_id: str,
    output_dir: str,
    recursive: bool = False,
    overwrite: bool = False,
    preserve_tree: bool = False,
    limit: int | None = None,
    version: str = __version__,
) -> dict[str, Any]:
    """
    Create QR code images for all PDF files discovered in a Drive folder.

    Args:
        root_id: Google Drive folder identifier to scan.
        output_dir: Local output directory for QR code images.
        recursive: Whether to recurse into child folders.
        overwrite: Whether to overwrite existing QR code images.
        preserve_tree: Whether to preserve the discovered folder structure locally.
        limit: Optional maximum number of PDFs to process.
        version: Application version string.

    Returns:
        Structured workflow summary.
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    pdf_refs = get_pdf_refs_from_folder(
        root_id=root_id,
        recursive=recursive,
    )

    if limit is not None:
        pdf_refs = pdf_refs[:limit]

    generated: list[dict[str, str]] = []
    skipped: list[dict[str, str]] = []
    failed: list[dict[str, str]] = []

    for pdf_ref in pdf_refs:
        expected_output_path = _build_pdf_output_path(
            output_dir=output_dir,
            pdf_ref=pdf_ref,
            preserve_tree=preserve_tree,
        )

        expected_output_path.parent.mkdir(parents=True, exist_ok=True)

        if expected_output_path.exists() and not overwrite:
            skipped.append(
                {
                    "file_id": pdf_ref.file_id,
                    "file_name": pdf_ref.file_name,
                    "reason": "QR code already exists",
                    "qrcode_path": str(expected_output_path),
                }
            )
            continue

        try:
            output_path = create_qrcode_for_pdf(
                file_id=pdf_ref.file_id,
                pdf_name=pdf_ref.file_name,
                output_dir=str(expected_output_path.parent),
                version=version,
            )

            generated.append(
                {
                    "file_id": pdf_ref.file_id,
                    "file_name": pdf_ref.file_name,
                    "parent_path": pdf_ref.parent_path,
                    "qrcode_path": output_path,
                }
            )
        except Exception as exc:  # pylint: disable=broad-exception-caught
            failed.append(
                {
                    "file_id": pdf_ref.file_id,
                    "file_name": pdf_ref.file_name,
                    "parent_path": pdf_ref.parent_path,
                    "reason": str(exc),
                }
            )

    return {
        "root_id": root_id,
        "output_dir": str(Path(output_dir).resolve()),
        "recursive": recursive,
        "overwrite": overwrite,
        "preserve_tree": preserve_tree,
        "limit": limit,
        "pdf_count": len(pdf_refs),
        "generated_count": len(generated),
        "skipped_count": len(skipped),
        "failed_count": len(failed),
        "generated": generated,
        "skipped": skipped,
        "failed": failed,
    }
