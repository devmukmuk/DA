"""iPhone Live Photos (pairing their videos) and HEIC photos (JPG copies)."""
