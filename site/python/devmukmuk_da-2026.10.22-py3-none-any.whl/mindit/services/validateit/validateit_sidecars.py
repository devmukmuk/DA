from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mindit.services.validateit.validateit_models import (
    ValidationProblem,
    ValidationSeverity,
    ValidationState,
)
from mindit.services.sidecar import SidecarService


def load_sidecar(sidecar_path: Path) -> dict[str, Any]:
    if not sidecar_path.exists():
        return {}

    try:
        return json.loads(sidecar_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def write_validation_block(
    sidecar_path: Path,
    state: ValidationState,
    problems: list[ValidationProblem],
) -> str:
    file_path = Path(str(sidecar_path).removesuffix(".meta.json"))
    was_created = not sidecar_path.exists()

    data = SidecarService.load(file_path)

    new_validation = {
        "checked_at": state.checked_at,
        "status": _status_from_problems(problems),
        "problem_count": len(problems),
        "problems": [
            {
                "code": problem.code.value,
                "severity": problem.severity.value,
                "message": problem.message,
                "repairable": problem.repairable,
                "repaired": problem.repaired,
            }
            for problem in problems
        ],
    }

    existing_validation = data.get("validation")

    if existing_validation:
        existing_no_time = dict(existing_validation)
        existing_no_time.pop("checked_at", None)

        new_no_time = dict(new_validation)
        new_no_time.pop("checked_at", None)

        if existing_no_time == new_no_time:
            return "skipped"

    SidecarService.update_block(
        file_path,
        "validation",
        new_validation,
    )

    return "created" if was_created else "updated"


def _status_from_problems(problems: list[ValidationProblem]) -> str:

    if not problems:
        return "ok"
    
    severities = {problem.severity for problem in problems}

    if ValidationSeverity.ERROR in severities:
        return "error"

    if ValidationSeverity.WARNING in severities:
        return "warning"

    if ValidationSeverity.INFO in severities:
        return "info"

    return "ok"
