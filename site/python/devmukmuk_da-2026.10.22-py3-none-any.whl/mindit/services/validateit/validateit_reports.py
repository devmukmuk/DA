from __future__ import annotations

import json
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.validateit.validateit_models import ValidationState


def write_validation_report(
    state: ValidationState,
    output_root: Path,
) -> Path:
    output_root.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    report_path = output_root / f"validateit-report-{timestamp}.json"

    report = build_validation_report(state)

    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    return report_path


def build_validation_report(state: ValidationState) -> dict[str, Any]:
    problem_counts = state.problem_summary
    severity_counts = Counter(problem.severity.value for problem in state.problems)

    return {
        "module": "validateit",
        "target_folder": state.target_folder,
        "mode": state.mode.value,
        "checked_at": state.checked_at,
        "problem_count": state.problem_count,
        "problem_summary": dict(sorted(problem_counts.items())),
        "severity_summary": dict(sorted(severity_counts.items())),
        "sidecar_writeback": {
            "created": state.sidecars_created,
            "updated": state.sidecars_updated,
            "skipped": state.sidecars_skipped,
            "created_count": len(state.sidecars_created),
            "updated_count": len(state.sidecars_updated),
            "skipped_count": len(state.sidecars_skipped),
        },
        "folder_writeback": {
            "removed": state.removed_folders,
            "review": state.review_folders,
            "removed_count": len(state.removed_folders),
            "review_count": len(state.review_folders),
        },
        "hash_summary": state.hash_summary,
        "duplicates": {
            "note": "Report only. ValidateIt never moves or deletes duplicate files.",
            "group_count": len(state.duplicate_groups),
            "duplicate_file_count": state.duplicate_file_count,
            "groups": state.duplicate_groups,
        },
        "problems": [
            {
                "code": problem.code.value,
                "severity": problem.severity.value,
                "message": problem.message,
                "file_path": problem.file_path,
                "sidecar_path": problem.sidecar_path,
                "repairable": problem.repairable,
                "repaired": problem.repaired,
            }
            for problem in state.problems
        ],
        "repair_actions": [
            {
                "action_type": action.action_type.value,
                "problem_code": action.problem_code.value,
                "description": action.description,
                "source_path": action.source_path,
                "target_path": action.target_path,
                "safe_auto": action.safe_auto,
                "executed": action.executed,
            }
            for action in state.repair_actions
        ],
        "repair_action_summary": {
            "total": state.repair_action_count,
            "pending": state.pending_repair_action_count,
        },
    }
