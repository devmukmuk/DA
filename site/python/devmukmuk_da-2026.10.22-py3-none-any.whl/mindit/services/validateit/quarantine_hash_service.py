# src/mindit/services/validateit/quarantine_hash_service.py

"""Hash computation for ValidateIt's quarantine/duplicate sidecar block."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from pathlib import Path

from mindit.models.quarantine_state import (
    DUPLICATE_STATUS_UNKNOWN,
    HASH_STATUS_COMPUTED,
    HASH_STATUS_FRESH,
    HASH_STATUS_MISSING,
    HASH_STATUS_STALE,
    QuarantineState,
)
from mindit.services.sidecar import SidecarService


def _compute_sha256(file_path: Path) -> str:
    """Compute the sha256 digest of a file, reading it in chunks."""
    hasher = hashlib.sha256()

    with file_path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            hasher.update(chunk)

    return hasher.hexdigest()


def ensure_file_hash(file_path: str, sidecar_path: str) -> QuarantineState:
    """Ensure a file's sidecar has a fresh sha256, recomputing it if missing or stale.

    Reads and writes through SidecarService's "quarantine" block so this stays consistent
    with the rest of ValidateIt's sidecar writeback.
    """
    file = Path(file_path)
    sidecar = Path(sidecar_path)

    stat = file.stat()
    file_size = stat.st_size
    file_modified = stat.st_mtime

    data = SidecarService.load(file)
    quarantine = data.get("quarantine", {})

    existing_hash = quarantine.get("hash_sha256")
    existing_size = quarantine.get("file_size")
    existing_modified = quarantine.get("file_modified_at")
    existing_duplicate_status = quarantine.get("duplicate_status") or DUPLICATE_STATUS_UNKNOWN

    if not existing_hash:
        needs_hash = True
    elif existing_size != file_size or existing_modified != file_modified:
        needs_hash = True
    else:
        needs_hash = False

    if not needs_hash:
        return QuarantineState(
            file_path=str(file),
            sidecar_path=str(sidecar),
            file_size=file_size,
            hash_sha256=existing_hash,
            hash_status=HASH_STATUS_FRESH,
            duplicate_status=existing_duplicate_status,
            checked_at=quarantine.get("checked_at"),
        )

    previous_status = HASH_STATUS_MISSING if not existing_hash else HASH_STATUS_STALE
    new_hash = _compute_sha256(file)
    checked_at = datetime.now(UTC).isoformat(timespec="seconds")

    SidecarService.update_quarantine_block(
        file,
        {
            "hash_sha256": new_hash,
            "file_size": file_size,
            "file_modified_at": file_modified,
            "hash_status": HASH_STATUS_COMPUTED,
            "checked_at": checked_at,
        },
    )

    return QuarantineState(
        file_path=str(file),
        sidecar_path=str(sidecar),
        file_size=file_size,
        hash_sha256=new_hash,
        hash_status=HASH_STATUS_COMPUTED,
        duplicate_status=existing_duplicate_status,
        checked_at=checked_at,
    )


def compute_sha256(file_path: Path) -> str:
    """Compute a file's sha256 digest."""
    return _compute_sha256(file_path)


def record_file_hash(file_path: Path, sha256: str) -> None:
    """Record an already-computed sha256 with the file's size and mtime in its quarantine block.

    The file block's sha256/size_bytes are set to the same values, so a stale hash left there by an
    older tool can't disagree with the one just computed.
    """
    stat = file_path.stat()

    SidecarService.update_quarantine_block(
        file_path,
        {
            "hash_sha256": sha256,
            "file_size": stat.st_size,
            "file_modified_at": stat.st_mtime,
            "hash_status": HASH_STATUS_COMPUTED,
            "checked_at": datetime.now(UTC).isoformat(timespec="seconds"),
        },
    )
    file_block = dict(SidecarService.get_block(file_path, "file"))
    if file_block.get("sha256") != sha256 or file_block.get("size_bytes") != stat.st_size:
        file_block.update(sha256=sha256, size_bytes=stat.st_size)
        SidecarService.update_block(file_path, "file", file_block)


def stored_or_computed_sha256(file_path: Path) -> str:
    """Return the sidecar's sha256 if it still matches the file, else compute it."""
    quarantine = SidecarService.get_block(file_path, "quarantine")
    stat = file_path.stat()

    if (
        quarantine.get("hash_sha256")
        and quarantine.get("file_size") == stat.st_size
        and quarantine.get("file_modified_at") == stat.st_mtime
    ):
        return quarantine["hash_sha256"]

    return _compute_sha256(file_path)
