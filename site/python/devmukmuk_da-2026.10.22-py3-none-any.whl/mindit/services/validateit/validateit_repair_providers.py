from __future__ import annotations

from pathlib import Path
from typing import Protocol


class ValidationRepairProvider(Protocol):
    name: str
    media_kind: str

    def supports(self, path: Path) -> bool:
        ...

    def expected_name(self, path: Path) -> str | None:
        ...

    def expected_folder(self, path: Path) -> Path | None:
        ...
        
    def create_or_refresh_sidecar(self, path: Path, sha256: str | None = None) -> bool:
        ...
        
class RepairProviderRegistry:
    def __init__(self, providers: list[ValidationRepairProvider] | None = None) -> None:
        self.providers = providers or []

    def provider_for(self, path: Path, kind: str | None = None) -> ValidationRepairProvider | None:
        """Return the first provider supporting path, restricted to kind when one is given."""
        for provider in self.providers:
            if not provider.supports(path):
                continue
            if kind is not None and getattr(provider, "media_kind", kind) != kind:
                continue
            return provider
        return None