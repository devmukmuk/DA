# src/mindit/services/quarantine_workflows.py

"""Deprecated standalone quarantine hash/duplicate workflows; use ValidateItService.validate_folder."""

from __future__ import annotations

import warnings
from pathlib import Path

from collections import defaultdict

from dataclasses import asdict


from mindit.models.quarantine_state import (
    DUPLICATE_STATUS_DUPLICATE,
    DUPLICATE_STATUS_PRIMARY,
    DUPLICATE_STATUS_UNIQUE,
    QuarantineState,
)
from mindit.services.validateit.quarantine_hash_service import ensure_file_hash
from mindit.services.sidecar import SidecarService

HASH_COMMAND_DEPRECATION = (
    "Deprecated: use `da validateit validate`, which creates missing sidecars, hashes each "
    "file once, and reports duplicate groups without moving anything."
)


def _warn_deprecated(name: str) -> None:
    """Emit a DeprecationWarning pointing callers at ValidateItService.validate_folder."""
    warnings.warn(
        f"{name} is deprecated; use ValidateItService.validate_folder, which hashes files "
        "and detects duplicates.",
        DeprecationWarning,
        stacklevel=3,
    )


def update_sidecar_quarantine_state(state: QuarantineState) -> bool:
    """Write duplicate/quarantine state back to the file sidecar."""
    if not state.sidecar_path:
        return False

    SidecarService.update_quarantine_block(
        Path(state.file_path),
        {
            "hash_sha256": state.hash_sha256,
            "file_size": state.file_size,
            "hash_status": state.hash_status,
            "duplicate_status": state.duplicate_status,
            "duplicate_group_id": state.duplicate_group_id,
            "duplicate_of": state.duplicate_of,
            "duplicate_paths": state.duplicate_paths,
            "checked_at": state.checked_at,
        },
    )

    return True

def detect_and_write_duplicates_workflow(
    root_folder: str | Path,
    extensions: set[str],
    recursive: bool = True,
) -> list[QuarantineState]:
    """Detect duplicates and write duplicate status to sidecars."""
    _warn_deprecated("detect_and_write_duplicates_workflow")
    states = _detect_duplicates(
        root_folder=root_folder,
        extensions=extensions,
        recursive=recursive,
    )

    write_duplicate_state_workflow(states)

    return states

def write_duplicate_state_workflow(states: list[QuarantineState]) -> int:
    """Write duplicate state to sidecars and return updated count."""
    updated_count = 0

    for state in states:
        if update_sidecar_quarantine_state(state):
            updated_count += 1

    return updated_count

def detect_duplicate_states(
    states: list[QuarantineState],
) -> list[QuarantineState]:
    """Mark states as unique, primary, or duplicate based on hash."""
    groups: dict[str, list[QuarantineState]] = defaultdict(list)

    for state in states:
        if state.hash_sha256:
            groups[state.hash_sha256].append(state)

    results: list[QuarantineState] = []

    for hash_value, group in groups.items():
        sorted_group = sorted(group, key=lambda item: item.file_path)

        if len(sorted_group) == 1:
            state = sorted_group[0]
            results.append(
                QuarantineState(
                    **{
                        **state.__dict__,
                        "duplicate_status": DUPLICATE_STATUS_UNIQUE,
                    }
                )
            )
            continue

        primary = sorted_group[0]
        duplicate_paths = [state.file_path for state in sorted_group[1:]]
        group_id = f"sha256:{hash_value}"

        results.append(
            QuarantineState(
                **{
                    **primary.__dict__,
                    "duplicate_status": DUPLICATE_STATUS_PRIMARY,
                    "duplicate_group_id": group_id,
                    "duplicate_paths": duplicate_paths,
                }
            )
        )

        for duplicate in sorted_group[1:]:
            results.append(
                QuarantineState(
                    **{
                        **duplicate.__dict__,
                        "duplicate_status": DUPLICATE_STATUS_DUPLICATE,
                        "duplicate_group_id": group_id,
                        "duplicate_of": primary.file_path,
                    }
                )
            )

    return sorted(results, key=lambda item: item.file_path)

def detect_duplicates_workflow(
    root_folder: str | Path,
    extensions: set[str],
    recursive: bool = True,
) -> list[QuarantineState]:
    """
    Hash files, then detect duplicates by hash.

    This does not move or delete files.
    """
    _warn_deprecated("detect_duplicates_workflow")
    return _detect_duplicates(root_folder, extensions, recursive)


def _detect_duplicates(
    root_folder: str | Path,
    extensions: set[str],
    recursive: bool = True,
) -> list[QuarantineState]:
    """Hash files, then mark duplicates by hash."""
    return detect_duplicate_states(_hash_folder(root_folder, extensions, recursive))

def get_default_sidecar_path(file_path: Path) -> Path:
    """Return the default sidecar path for a file."""
    return file_path.with_name(f"{file_path.name}.meta.json")


def iter_quarantine_files(
    root_folder: str | Path,
    extensions: set[str],
    recursive: bool = True,
) -> list[Path]:
    """Find files under root_folder matching the given extensions."""
    root = Path(root_folder)
    normalized_extensions = {ext.lower() for ext in extensions}

    pattern = "**/*" if recursive else "*"

    return [
        path
        for path in root.glob(pattern)
        if path.is_file()
        and path.suffix.lower() in normalized_extensions
        and not path.name.endswith(".meta.json")
    ]


def hash_folder_workflow(
    root_folder: str | Path,
    extensions: set[str],
    recursive: bool = True,
) -> list[QuarantineState]:
    """
    Hash all matching files in a folder and update their sidecars.

    This does not detect duplicates yet.
    """
    _warn_deprecated("hash_folder_workflow")
    return _hash_folder(root_folder, extensions, recursive)


def _hash_folder(
    root_folder: str | Path,
    extensions: set[str],
    recursive: bool = True,
) -> list[QuarantineState]:
    """Hash matching files and update their sidecars."""
    states: list[QuarantineState] = []

    for file_path in iter_quarantine_files(
        root_folder=root_folder,
        extensions=extensions,
        recursive=recursive,
    ):
        sidecar_path = get_default_sidecar_path(file_path)

        state = ensure_file_hash(
            file_path=str(file_path),
            sidecar_path=str(sidecar_path),
        )

        states.append(state)

    return states
