# src/mindit/services/validateit/validateit_models.py

from __future__ import annotations
from collections import Counter

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from pathlib import Path


class ValidationMode(StrEnum):
    PREVIEW = "preview"
    REPAIR = "repair"


class ValidationProblemCode(StrEnum):
    DOCUMENT_SHOULD_BE_PHOTO = "document_should_be_photo"
    PHOTO_SHOULD_BE_DOCUMENT = "photo_should_be_document"
    DOCUMENT_IN_PHOTOS_FOLDER = "document_in_photos_folder"
    PHOTO_IN_DOCUMENTS_FOLDER = "photo_in_documents_folder"
    WRONG_NAME = "wrong_name"
    WRONG_FOLDER_LOCATION = "wrong_folder_location"
    CAPTURE_DATE_UNCERTAIN = "capture_date_uncertain"
    NAME_DATE_DIFFERS_FROM_EXIF = "name_date_differs_from_exif"
    OUTSIDE_ARCHIVE_YEARS = "outside_archive_years"
    NOT_BACKED_UP_SINCE = "not_backed_up_since"
    FILE_MISSING_SIDECAR = "file_missing_sidecar"
    SIDECAR_MISSING_FILE = "sidecar_missing_file"
    WRONG_ORIENTATION = "wrong_orientation"
    WRONG_RESOLUTION = "wrong_resolution"
    WRONG_PHOTO_SIZE = "wrong_photo_size"
    IGNORED_FILE_PRESENT = "ignored_file_present"

    EMPTY_FOLDER = "empty_folder"
    NESTED_EMPTY_FOLDERS = "nested_empty_folders"
    EMPTY_FOLDER_AFTER_REPAIR = "empty_folder_after_repair"
    EMPTY_FOLDER_REVIEW_REQUIRED = "empty_folder_review_required"

    DUPLICATE_FILE = "duplicate_file"
    DUPLICATE_PRIMARY = "duplicate_primary"

    HASH_MISSING = "hash_missing"
    HASH_STALE = "hash_stale"
    HASH_COMPUTED = "hash_computed"

    HASH_REVIEW_REQUIRED = "hash_review_required"

    QUARANTINE_METADATA_MISSING = "quarantine_metadata_missing"


class ValidationSeverity(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


@dataclass(slots=True)
class ValidationProblem:
    code: ValidationProblemCode
    severity: ValidationSeverity
    message: str
    file_path: str | None = None
    sidecar_path: str | None = None
    repairable: bool = False
    repaired: bool = False


@dataclass(slots=True)
class ValidationState:
    target_folder: str
    checked_at: str
    mode: ValidationMode
    problems: list[ValidationProblem] = field(default_factory=list)
    sidecars_created: list[str] = field(default_factory=list)
    sidecars_updated: list[str] = field(default_factory=list)
    sidecars_skipped: list[str] = field(default_factory=list)
    repair_actions: list[RepairAction] = field(default_factory=list)
    removed_folders: list[str] = field(default_factory=list)
    review_folders: list[str] = field(default_factory=list)
    hash_summary: dict[str, int] = field(default_factory=dict)
    duplicate_groups: list[dict] = field(default_factory=list)

    @property
    def duplicate_file_count(self) -> int:
        return sum(len(group["duplicates"]) for group in self.duplicate_groups)

    @property
    def problem_count(self) -> int:
        return len(self.problems)
    
    @property
    def problem_summary(self) -> dict[str, int]:
        counts = Counter(problem.code.value for problem in self.problems)
        return dict(sorted(counts.items(), key=lambda x: -x[1]))
    
    @property
    def severity_summary(self) -> dict[str, int]:
        counts = Counter(problem.severity.value for problem in self.problems)
        return dict(sorted(counts.items()))
    
    @property
    def repaired_problem_count(self) -> int:
        return sum(1 for problem in self.problems if problem.repaired)


    @property
    def remaining_problem_count(self) -> int:
        return sum(1 for problem in self.problems if not problem.repaired)
    
    @property
    def remaining_problem_summary(self) -> dict[str, int]:
        counts = Counter(
            problem.code.value
            for problem in self.problems
            if not problem.repaired
        )
        return dict(sorted(counts.items(), key=lambda item: -item[1]))
    
    @property
    def repair_action_count(self) -> int:
        return len(self.repair_actions)


    @property
    def pending_repair_action_count(self) -> int:
        return sum(1 for action in self.repair_actions if not action.executed)
    


class RepairActionType(StrEnum):
    CREATE_SIDECAR = "create_sidecar"
    UPDATE_SIDECAR = "update_sidecar"
    RENAME_FILE = "rename_file"
    MOVE_FILE = "move_file"
    MOVE_RAW_COMPANION = "move_raw_companion"
    REVIEW_REQUIRED = "review_required"
    CLEANUP_IGNORED_FILE = "cleanup_ignored_file"
    REMOVE_EMPTY_FOLDER = "remove_empty_folder"

    
@dataclass(slots=True)
class RepairAction:
    action_type: RepairActionType
    problem_code: ValidationProblemCode
    description: str
    source_path: str | None = None
    target_path: str | None = None
    safe_auto: bool = False
    executed: bool = False
