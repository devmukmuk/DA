# src/mindit/services/dbit/archive_stats.py

"""Summaries of the DA database: what's where, what's missing, and what intake already has."""

from __future__ import annotations

import os
from typing import Any

from mindit.services.dbit.dbit_service import DbitService


def archive_stats(db: DbitService) -> dict[str, Any]:
    """Return counts by area and kind, by year, gaps, and per-intake-folder progress."""
    db.initialize(log=False)                 # an archive never indexed: empty tables, not a crash
    with db.connect() as conn:
        by_area = [dict(r) for r in conn.execute(
            """
            SELECT area, media_type AS kind, COUNT(*) AS files, ROUND(SUM(size_bytes) / 1e9, 2) AS gb,
                   SUM(sidecar_path IS NULL) AS no_sidecar, SUM(sha256 IS NULL) AS no_hash
            FROM files GROUP BY area, media_type ORDER BY area, files DESC
            """
        )]
        by_year = [dict(r) for r in conn.execute(
            """
            SELECT substr(captured_at, 1, 4) AS year, area, COUNT(*) AS files
            FROM files WHERE area IN ('photos', 'documents') AND captured_at IS NOT NULL
            GROUP BY year, area ORDER BY year, area
            """
        )]
        intake = [dict(r) for r in conn.execute(
            """
            WITH organized AS (
                SELECT DISTINCT sha256 FROM files
                WHERE area IN ('photos', 'documents') AND sha256 IS NOT NULL
            )
            SELECT f.folder, f.sha256 IN organized AS in_organized, f.sha256 IS NULL AS no_hash
            FROM files f WHERE f.area = 'intake'
            """
        )]
        last_build = conn.execute(
            "SELECT created_at, message FROM db_events WHERE event_type = 'db_build' ORDER BY id DESC LIMIT 1"
        ).fetchone()

    folders: dict[str, dict[str, int]] = {}
    for row in intake:
        top = (row["folder"] or "(intake root)").split(os.sep)[0]
        f = folders.setdefault(top, {"files": 0, "already_in_organized": 0, "not_hashed": 0})
        f["files"] += 1
        f["already_in_organized"] += int(bool(row["in_organized"]))
        f["not_hashed"] += int(bool(row["no_hash"]))
    for f in folders.values():
        f["to_check_or_file"] = f["files"] - f["already_in_organized"]

    return {
        "last_build": dict(last_build)["created_at"] if last_build else None,
        "by_area": by_area,
        "by_year": by_year,
        "intake_folders": dict(sorted(folders.items(), key=lambda kv: -kv[1]["files"])),
    }
