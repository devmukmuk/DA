# src/mindit/services/dbit/photoit_index_service.py

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.dbit.dbit_service import DbitService
from mindit.services.sidecar import SidecarService
from mindit.services.validateit.validateit_file_types import PHOTO_EXTENSIONS
from mindit.utils.timestamps import safe_iso_timestamp


class PhotoItIndexService:
    def __init__(self, db_service: DbitService) -> None:
        self.db_service = db_service

    def index_folder(self, folder: Path) -> dict[str, Any]:
        folder = folder.resolve()
        self.db_service.initialize()

        files_scanned = 0
        indexed = 0
        sidecars_found = 0
        missing_sidecars = 0

        for path in folder.rglob("*"):
            if not path.is_file():
                continue

            if path.name.endswith(".meta.json"):
                continue

            if path.suffix.lower() not in PHOTO_EXTENSIONS:
                continue

            files_scanned += 1

            sidecar_path = SidecarService.sidecar_path_for(path)
            sidecar_exists = sidecar_path.exists()
            sidecar_data = SidecarService.load(path)

            if sidecar_exists:
                sidecars_found += 1
            else:
                missing_sidecars += 1

            stat = path.stat()
            now = datetime.now().isoformat(timespec="seconds")

            schema = self._block(sidecar_data, "schema")
            photoit = self._block(sidecar_data, "photoit")
            classification = self._block(sidecar_data, "classification")
            validation = self._block(sidecar_data, "validation")
            quarantine = self._block(sidecar_data, "quarantine")

            record = {
                "path": str(path),
                "module": classification.get("module") or "photoit",
                "media_type": classification.get("media_type") or "photo",
                "file_name": path.name,
                "extension": path.suffix.lower(),
                "size_bytes": stat.st_size,
                "modified_at": safe_iso_timestamp(stat.st_mtime),
                "sha256": SidecarService.extract_sha256(sidecar_data),
                "sidecar_path": str(sidecar_path) if sidecar_exists else None,
                "sidecar_schema_version": schema.get("version"),
                "captured_at": photoit.get("captured_at"),
                "tags": self._serialize_tags(photoit.get("tags")),
                "gps_present": self._gps_present(photoit.get("gps")),
                "validation_status": validation.get("status"),
                "validation_problem_count": validation.get("problem_count", 0),
                "hash_status": quarantine.get("hash_status"),
                "duplicate_status": quarantine.get("duplicate_status"),
                "indexed_at": now,
            }

            self.db_service.upsert_file(record)
            indexed += 1

        return {
            "module": "photoit",
            "folder": str(folder),
            "files_scanned": files_scanned,
            "indexed": indexed,
            "sidecars_found": sidecars_found,
            "missing_sidecars": missing_sidecars,
            "db_path": str(self.db_service.db_path),
        }

    @staticmethod
    def _block(data: dict[str, Any], name: str) -> dict[str, Any]:
        value = data.get(name)

        if isinstance(value, dict):
            return value

        return {}

    @staticmethod
    def _serialize_tags(value: Any) -> str | None:
        if isinstance(value, list):
            tags = [str(item).strip() for item in value if str(item).strip()]
            return ",".join(tags) if tags else None

        if isinstance(value, str):
            value = value.strip()
            return value or None

        return None

    @staticmethod
    def _gps_present(value: Any) -> int:
        if not isinstance(value, dict):
            return 0

        return int(
            value.get("latitude") is not None
            or value.get("longitude") is not None
        )