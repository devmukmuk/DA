# src/mindit/services/photoit/photoit_context.py

"""PhotoIt context and initialization helpers.

Description:
    Provides a shared context object used across PhotoIt services and workflows.
    This centralizes:
        - settings

Design:
    - Built once per CLI command
    - Passed into all services/workflows    
    - Avoids repeated setup logic across modules
    
"""

from __future__ import annotations

from dataclasses import dataclass

from mindit.config.settings import load_settings, AppSettings



@dataclass
class PhotoItContext:
    """Shared PhotoIt execution context."""

    settings: AppSettings



def build_context() -> PhotoItContext:
    """
    Build a PhotoItContext.


    Returns:
        Fully initialized PhotoItContext
    """
    settings = load_settings()


    return PhotoItContext(
        settings=settings,

    )
