# src/mindit/services/photoit/photoit_tag_service.py



# =============================================================================
# photoit_tag_service.py - Tag management for PhotoIt
# rename phase 3
# =============================================================================

def _normalize_tags(tags: list[str] | None) -> list[str]:
    if not tags:
        return []

    normalized: list[str] = []
    seen: set[str] = set()

    for tag in tags:
        text = str(tag).strip().lower()
        if not text:
            continue
        if text not in seen:
            seen.add(text)
            normalized.append(text)

    return normalized

def _merge_tags(
    existing_tags: list[str] | None,
    add_tags: list[str] | None = None,
    remove_tags: list[str] | None = None,
    replace_tags: list[str] | None = None,
) -> list[str]:
    if replace_tags is not None:
        return _normalize_tags(replace_tags)

    tags = _normalize_tags(existing_tags)

    if add_tags:
        for tag in _normalize_tags(add_tags):
            if tag not in tags:
                tags.append(tag)

    if remove_tags:
        remove_set = set(_normalize_tags(remove_tags))
        tags = [tag for tag in tags if tag not in remove_set]

    return tags