# src/mindit/services/photoit/photoit_dashboard_service.py

from __future__ import annotations

from datetime import datetime
import json
from pathlib import Path
from typing import Any
import webbrowser

from mindit.config.settings import load_settings


def _get_dashboard_root() -> Path:
    settings = load_settings()
    base = Path(settings.logs.root).expanduser().resolve().parent
    path = base / "photoit" / "dashboard"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_dashboard_snapshot_path() -> Path:
    return _get_dashboard_root() / "snapshot.json"


def write_dashboard_snapshot(snapshot: dict[str, Any]) -> Path:
    path = get_dashboard_snapshot_path()

    enriched = {
        "updated_at": datetime.now().isoformat(),
        **snapshot,
    }

    path.write_text(json.dumps(enriched, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def build_dashboard_snapshot_from_batch(batch: dict[str, Any]) -> dict[str, Any]:
    return {
        "batch_id": batch.get("batch_id"),
        "batch_name": batch.get("batch_name"),
        "intake_folder": batch.get("intake_folder"),
        "organized_folder": batch.get("organized_folder"),
        "quarantine_folder": batch.get("quarantine_folder"),
        "selection_count": batch.get("selection_count"),
        "recursive": batch.get("recursive"),
        "dry_run": batch.get("dry_run"),
        "convert_heic": batch.get("convert_heic"),
        "refresh_existing": batch.get("refresh_existing"),
        "status": batch.get("status", {}),
        "selected_files": batch.get("selected_files", []),
        "last_result_summary": batch.get("last_result_summary"),
    }


def open_dashboard_snapshot_in_browser() -> Path:
    path = get_dashboard_snapshot_path()
    if not path.exists():
        write_dashboard_snapshot({"message": "No dashboard snapshot yet."})

    webbrowser.open(path.as_uri())
    return path
