# src/mindit/services/photoit/batch_job_store.py

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
import json
from pathlib import Path
from typing import Any
from uuid import uuid4

from mindit.config.settings import (
    load_settings,
    resolve_photoit_intake_path,
    resolve_photoit_organized_path,
    resolve_photoit_quarantine_path,
)
from mindit.models.photoit_refs import BatchJobRef


def _get_batch_root() -> Path:
    settings = load_settings()
    base = Path(settings.logs.root).expanduser().resolve().parent
    path = base / "photoit" / "batches"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _get_batch_file(batch_id: str) -> Path:
    return _get_batch_root() / f"{batch_id}.json"


def _get_active_batch_file() -> Path:
    return _get_batch_root() / "active_batch.txt"


def list_batch_jobs() -> list[dict[str, Any]]:
    jobs: list[dict[str, Any]] = []

    for path in sorted(_get_batch_root().glob("*.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            jobs.append(payload)
        except Exception:
            continue

    jobs.sort(key=lambda item: item.get("created_at", ""), reverse=True)
    return jobs


def get_batch_job(batch_id: str) -> dict[str, Any] | None:
    path = _get_batch_file(batch_id)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def create_batch_job(
    batch_name: str,
    intake_folder: str | None = None,
    organized_folder: str | None = None,
    quarantine_folder: str | None = None,
    selection_count: int = 25,
) -> dict[str, Any]:
    settings = load_settings()
    created_at = datetime.now().isoformat()
    batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid4().hex[:6]}"

    intake = intake_folder or str(resolve_photoit_intake_path(settings))
    organized = organized_folder or str(resolve_photoit_organized_path(settings))
    quarantine = quarantine_folder or str(resolve_photoit_quarantine_path(settings))

    ref = BatchJobRef(
        batch_id=batch_id,
        batch_name=batch_name,
        intake_folder=intake,
        created_at=created_at,
    )

    payload: dict[str, Any] = {
        **asdict(ref),
        "organized_folder": organized,
        "quarantine_folder": quarantine,
        "selection_count": selection_count,
        "recursive": True,
        "dry_run": True,
        "convert_heic": True,
        "refresh_existing": True,
        "status": {
            "state": "idle",
            "discovered": 0,
            "processed": 0,
            "success": 0,
            "failed": 0,
            "last_run_at": None,
        },
        "selected_files": [],
        "last_result_summary": None,
    }

    save_batch_job(payload)
    return payload


def save_batch_job(payload: dict[str, Any]) -> Path:
    batch_id = str(payload["batch_id"])
    path = _get_batch_file(batch_id)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def update_batch_job(batch_id: str, updates: dict[str, Any]) -> dict[str, Any]:
    payload = get_batch_job(batch_id)
    if not payload:
        raise ValueError(f"Batch job not found: {batch_id}")

    payload.update(updates)
    save_batch_job(payload)
    return payload


def delete_batch_job(batch_id: str) -> None:
    path = _get_batch_file(batch_id)
    if path.exists():
        path.unlink()

    active_id = get_active_batch_id()
    if active_id == batch_id:
        clear_active_batch()


def set_active_batch(batch_id: str) -> None:
    if not get_batch_job(batch_id):
        raise ValueError(f"Batch job not found: {batch_id}")

    _get_active_batch_file().write_text(batch_id, encoding="utf-8")


def get_active_batch_id() -> str | None:
    path = _get_active_batch_file()
    if not path.exists():
        return None

    value = path.read_text(encoding="utf-8").strip()
    return value or None


def get_active_batch_job() -> dict[str, Any] | None:
    batch_id = get_active_batch_id()
    if not batch_id:
        return None
    return get_batch_job(batch_id)


def clear_active_batch() -> None:
    path = _get_active_batch_file()
    if path.exists():
        path.unlink()
