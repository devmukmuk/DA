from __future__ import annotations

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.validateit.validateit_file_types import PHOTO_EXTENSIONS


def _file_hash(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as file:
        while chunk := file.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def build_organized_folder_report(
    organized_folder: str | Path,
    recursive: bool = True,
    include_files: bool = True,
) -> dict[str, Any]:
    root = Path(organized_folder).resolve()
    if not root.exists():
        raise FileNotFoundError(f"Organized folder not found: {root}")

    pattern = "**/*" if recursive else "*"
    photo_paths = [
        path for path in root.glob(pattern)
        if path.is_file() and path.suffix.lower() in PHOTO_EXTENSIONS
    ]

    hash_map: dict[str, list[str]] = {}
    missing_meta: list[str] = []

    for photo_path in photo_paths:
        meta_path = Path(f"{photo_path}.meta.json")

        if not meta_path.exists():
            missing_meta.append(str(photo_path))

        file_hash = _file_hash(photo_path)
        hash_map.setdefault(file_hash, []).append(str(photo_path))

    duplicate_groups = [
        paths for paths in hash_map.values()
        if len(paths) > 1
    ]

    duplicate_photo_count = sum(len(group) for group in duplicate_groups)

    report: dict[str, Any] = {
        "module": "photoit",
        "report_type": "organized_folder_summary",
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "organized_folder": str(root),
        "recursive": recursive,
        "summary": {
            "photo_count": len(photo_paths),
            "duplicate_group_count": len(duplicate_groups),
            "duplicate_photo_count": duplicate_photo_count,
            "missing_meta_json_count": len(missing_meta),
        },
    }

    if include_files:
        report["duplicate_groups"] = duplicate_groups
        report["missing_meta_json_files"] = missing_meta

    return report


def write_organized_folder_report(
    organized_folder: str | Path,
    output_dir: str | Path,
    recursive: bool = True,
    include_files: bool = True,
) -> Path:
    report = build_organized_folder_report(
        organized_folder=organized_folder,
        recursive=recursive,
        include_files=include_files,
    )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = Path(output_dir).resolve()
    output_path.mkdir(parents=True, exist_ok=True)

    report_path = output_path / f"photoit_organized_report_{timestamp}.json"
    report_path.write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    return report_path
