"""PhotoIt services.

Description:
    High-level PhotoIt workflows built from smaller reusable service functions.

Design:
    This module should contain orchestration logic only. Each workflow should:
    - accept a shared PhotoItContext
    - call smaller resolver / validation / export / QR services
    - return structured data
    - avoid printing directly

Layering:
    1. Context layer
        - build_photoit_context()
        - PhotoItContext

    2. Resolver layer
        - resolve_photo_metadata()
        - find_duplicate_photos()
        - determine_photo_movements()   

    3. Primitive service layer
        - move_photo_file()
        - rename_photo_file()
        - extract_photo_metadata()
        - create_photo_qrcode() 

    4. Workflow layer
        - scan_photos_workflow()
        - detect_duplicates_workflow()
        - move_photos_workflow()
        - rename_photos_workflow()
        - create_metadata_workflow()
        - quarantine_duplicates_workflow()
        - remove_empty_folders_workflow()
        - repair_jpeg_from_heic_workflow()
"""
