"""Contact sheets: a PDF of small pictures of every photo in a folder."""
