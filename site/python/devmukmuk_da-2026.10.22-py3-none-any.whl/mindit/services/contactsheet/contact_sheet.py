# src/mindit/services/contactsheet/contact_sheet.py

"""A folder's contact sheet: `_contact-sheet.pdf`, small pictures of every photo in the folder.

The PDF records a fingerprint of the photos it shows (their names and sizes) in its Subject, so
DA can tell when the folder has changed and the sheet needs making again. `da run` makes one for
each folder it files photos into; `da validate` remakes any sheet whose folder has changed; and
`da contact-sheets <folder>` makes them for a whole tree.
"""

from __future__ import annotations

import hashlib
import io
import os
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

SHEET_NAME = "_contact-sheet.pdf"
SUBJECT_PREFIX = "da-contact-sheet "

# What Pillow can draw (camera raw files and videos aren't shown).
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".tif", ".tiff", ".bmp", ".gif"}

COLUMNS, ROWS = 4, 5
_NAME_DATE = re.compile(r"(?:photo|doc)_(\d{4}|\d{2})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})")

try:  # iPhone HEIC photos
    from pillow_heif import register_heif_opener

    register_heif_opener()
except ImportError:  # pragma: no cover - pillow-heif is in requirements
    pass


@dataclass
class SheetResult:
    """What a refresh did."""

    made: list[Path] = field(default_factory=list)
    removed: list[Path] = field(default_factory=list)
    current: int = 0
    failed: list[tuple[Path, str]] = field(default_factory=list)

    def as_dict(self) -> dict:
        """Return counts and the paths made, for run records."""
        return {"made": len(self.made), "removed": len(self.removed), "current": self.current,
                "failed": [f"{p}: {why}" for p, why in self.failed], "sheets": [str(p) for p in self.made]}


def is_sheet(path: Path) -> bool:
    """Return True for a contact sheet file (never validated, indexed or filed)."""
    return path.name.lower() == SHEET_NAME


def photos_in(folder: Path) -> list[Path]:
    """Return the pictures directly in folder, in name order (that's date order for filed photos)."""
    try:
        entries = [e for e in folder.iterdir() if e.is_file() and e.suffix.lower() in IMAGE_EXTENSIONS]
    except OSError:
        return []
    return sorted(entries, key=lambda p: p.name.lower())


def fingerprint(photos: Iterable[Path]) -> str:
    """Return a short fingerprint of the photos' names and sizes."""
    digest = hashlib.sha1()
    for photo in photos:
        try:
            size = photo.stat().st_size
        except OSError:
            size = -1
        digest.update(f"{photo.name.lower()}\t{size}\n".encode("utf-8"))
    return digest.hexdigest()[:16]


def recorded_fingerprint(sheet: Path) -> str | None:
    """Return the fingerprint stored in a sheet, or None when it has none or can't be read."""
    try:
        from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

        subject = str((PdfReader(sheet, strict=False).metadata or {}).get("/Subject") or "")
    except Exception:  # pylint: disable=broad-except
        return None
    return subject[len(SUBJECT_PREFIX):].strip() if subject.startswith(SUBJECT_PREFIX) else None


def is_current(folder: Path) -> bool:
    """Return True when folder's sheet exists and shows exactly the photos there now."""
    sheet = folder / SHEET_NAME
    return sheet.exists() and recorded_fingerprint(sheet) == fingerprint(photos_in(folder))


def caption_date(name: str) -> str:
    """Return 'YYYY-MM-DD HH:MM' from a DA name (photo_19980704_101500_ab12.jpg), else ''."""
    m = _NAME_DATE.search(name)
    if not m:
        return ""
    year = m.group(1) if len(m.group(1)) == 4 else f"20{m.group(1)}"
    return f"{year}-{m.group(2)}-{m.group(3)} {m.group(4)}:{m.group(5)}"


def _thumbnail(photo: Path, box: tuple[int, int]):
    """Return a reportlab ImageReader of a small copy of photo, or None when it can't be read."""
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel

    try:
        with Image.open(photo) as img:
            if img.format == "JPEG":
                img.draft("RGB", (box[0] * 2, box[1] * 2))       # decode at reduced size: much faster
            img = ImageOps.exif_transpose(img)
            img.thumbnail((box[0] * 2, box[1] * 2))
            out = io.BytesIO()
            img.convert("RGB").save(out, "JPEG", quality=80)
        out.seek(0)
        return ImageReader(out)
    except Exception:  # pylint: disable=broad-except
        return None


def make_sheet(folder: Path, *, title: str | None = None, version: str = "") -> Path | None:
    """Write folder's contact sheet; with no photos left, remove an old sheet. Return the sheet or None."""
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    sheet = folder / SHEET_NAME
    photos = photos_in(folder)
    if not photos:
        sheet.unlink(missing_ok=True)
        return None

    width, height = letter
    margin, header, footer = 36, 34, 18
    cell_w = (width - 2 * margin) / COLUMNS
    cell_h = (height - 2 * margin - header - footer) / ROWS
    thumb_w, thumb_h = cell_w - 10, cell_h - 30
    per_page = COLUMNS * ROWS
    pages = (len(photos) + per_page - 1) // per_page
    label = title or folder.name

    tmp = sheet.with_name(sheet.name + ".tmp")
    pdf = canvas.Canvas(str(tmp), pagesize=letter)
    pdf.setTitle(f"Contact sheet: {label}")
    pdf.setSubject(SUBJECT_PREFIX + fingerprint(photos))
    pdf.setCreator(f"DA v{version}" if version else "DA")
    made_on = datetime.now().strftime("%Y-%m-%d %H:%M")

    for page in range(pages):
        top = height - margin
        pdf.setFont("Helvetica-Bold", 13)
        pdf.drawString(margin, top - 14, label)
        pdf.setFont("Helvetica", 9)
        pdf.drawRightString(width - margin, top - 13, f"{len(photos):,} photos  -  page {page + 1} of {pages}")
        pdf.setStrokeGray(0.7)
        pdf.line(margin, top - header + 8, width - margin, top - header + 8)

        for i, photo in enumerate(photos[page * per_page:(page + 1) * per_page]):
            col, row = i % COLUMNS, i // COLUMNS
            x = margin + col * cell_w
            y = top - header - (row + 1) * cell_h
            image = _thumbnail(photo, (int(thumb_w), int(thumb_h)))
            if image is not None:
                iw, ih = image.getSize()
                scale = min(thumb_w / iw, thumb_h / ih)
                dw, dh = iw * scale, ih * scale
                pdf.drawImage(image, x + (cell_w - dw) / 2, y + 26 + (thumb_h - dh) / 2, dw, dh)
            else:
                pdf.setFillGray(0.9)
                pdf.rect(x + 5, y + 26, thumb_w, thumb_h, stroke=0, fill=1)
                pdf.setFillGray(0.4)
                pdf.setFont("Helvetica", 8)
                pdf.drawCentredString(x + cell_w / 2, y + 26 + thumb_h / 2, "(can't show this one)")
            pdf.setFillGray(0)
            pdf.setFont("Helvetica", 7)
            name = photo.name if len(photo.name) <= 34 else photo.name[:31] + "..."
            pdf.drawCentredString(x + cell_w / 2, y + 16, name)
            when = caption_date(photo.name)
            if when:
                pdf.setFillGray(0.35)
                pdf.drawCentredString(x + cell_w / 2, y + 7, when)
                pdf.setFillGray(0)

        pdf.setFont("Helvetica", 7)
        pdf.setFillGray(0.45)
        pdf.drawString(margin, margin - 6, f"Made by DA{' v' + version if version else ''} on {made_on}")
        pdf.setFillGray(0)
        pdf.showPage()
    pdf.save()
    os.replace(tmp, sheet)
    return sheet


def refresh_sheets(folders: Iterable[Path], *, create: bool, version: str = "",
                   progress: Callable[[str], None] | None = None) -> SheetResult:
    """Make sheets for folders whose photos changed; create=False only updates sheets that exist."""
    result = SheetResult()
    for folder in sorted(set(folders)):
        sheet = folder / SHEET_NAME
        if not create and not sheet.exists():
            continue
        if is_current(folder):
            result.current += 1
            continue
        try:
            made = make_sheet(folder, version=version)
        except Exception as exc:  # pylint: disable=broad-except
            result.failed.append((folder, f"{type(exc).__name__}: {exc}"))
            continue
        if made is None:
            result.removed.append(sheet)
        else:
            result.made.append(made)
            if progress:
                progress(f"contact sheet: {made}")
    return result


def folders_with_photos(root: Path) -> list[Path]:
    """Return root and every folder under it that has photos directly in it."""
    found = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d != "_duplicates-holding"]
        if any(Path(f).suffix.lower() in IMAGE_EXTENSIONS for f in filenames):
            found.append(Path(dirpath))
    return found


def folders_with_sheets(root: Path) -> list[Path]:
    """Return every folder under root (and root) that already has a contact sheet."""
    return [Path(d) for d, _dirs, files in os.walk(root) if any(f.lower() == SHEET_NAME for f in files)]
