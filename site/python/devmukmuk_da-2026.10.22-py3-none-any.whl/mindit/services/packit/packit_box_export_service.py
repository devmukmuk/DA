"""packit export services."""
# src/mindit/services/packit_export_service.py

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Any

from mindit import __version__
from mindit.models.packit_refs import BoxRef
from mindit.services.packit.packit_box_validator import validate_box_sheet


@dataclass(frozen=True)
class BoxValidationSummary:
    valid: bool
    warnings: list[str]
    errors: list[str]
    metadata_updates: dict[str, Any] | None
    room_folder_name: str
    sheet_title: str


@dataclass(frozen=True)
class BoxDetails:
    table_name: str | None
    headers: list[str]
    rows: list[dict[str, Any]]
    metadata: dict[str, Any]


@dataclass(frozen=True)
class BoxExportData:
    box_id: str
    box_name: str
    room_folder_name: str
    exported_by: str
    validation: BoxValidationSummary
    box_details: BoxDetails | None
    box_details_error: str | None = None


def build_box_export_data(
    service_sheets,
    settings,
    box_ref: BoxRef,
    write_metadata_updates: bool = False,
) -> BoxExportData:
    """
    Build validated export data for a single box.
    """
    room_folder_name = box_ref.room_ref.room_folder_name

    validation_result = validate_box_sheet(
        service_sheets=service_sheets,
        spreadsheet_id=box_ref.box_id,
        sheet_name=box_ref.box_name,
        room_folder_name=room_folder_name,
        settings=settings,
        write_updates=write_metadata_updates,
    )

    validation = BoxValidationSummary(
        valid=validation_result.valid,
        warnings=validation_result.warnings,
        errors=validation_result.errors,
        metadata_updates=validation_result.metadata_updates,
        room_folder_name=validation_result.room_folder_name,
        sheet_title=validation_result.sheet_title,
    )

    if validation_result.valid:
        box_details = BoxDetails(
            table_name=validation_result.table_name,
            headers=validation_result.headers,
            rows=validation_result.parsed_rows,
            metadata=(
                validation_result.metadata_expected
                if validation_result.metadata_expected
                else validation_result.metadata_original
            ),
        )
        return BoxExportData(
            box_id=box_ref.box_id,
            box_name=box_ref.box_name,
            room_folder_name=room_folder_name,
            exported_by=f"DA {__version__}",
            validation=validation,
            box_details=box_details,
        )

    return BoxExportData(
        box_id=box_ref.box_id,
        box_name=box_ref.box_name,
        room_folder_name=room_folder_name,
        exported_by=f"DA {__version__}",
        validation=validation,
        box_details=None,
        box_details_error="Validation failed",
    )


def write_box_export_json(
    service_sheets,
    settings,
    box_ref: BoxRef,
    output_dir: str,
    write_metadata_updates: bool = False,
) -> str:
    """
    Validate a box and write its export JSON file.

    Returns:
        Path to the written JSON file.
    """
    export_data = build_box_export_data(
        service_sheets=service_sheets,
        settings=settings,
        box_ref=box_ref,
        write_metadata_updates=write_metadata_updates,
    )

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    json_path = output_path / f"{box_ref.box_name}.json"
    json_path.write_text(
        json.dumps(asdict(export_data), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return str(json_path)
