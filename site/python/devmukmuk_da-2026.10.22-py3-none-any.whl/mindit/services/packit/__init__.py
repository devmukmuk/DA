"""PackIt services.

Description:
    High-level PackIt workflows built from smaller reusable service functions.

Design:
    This module should contain orchestration logic only. Each workflow should:
    - accept a shared PackItContext
    - call smaller resolver / validation / export / QR services
    - return structured data
    - avoid printing directly

Layering:
    1. Context layer
        - build_packit_context()
        - PackItContext

    2. Resolver layer
        - get_rooms()
        - get_room_by_name_or_abbr()
        - get_box_by_name()
        - get_box_parent_room()

    3. Primitive service layer
        - validate_box_sheet()
        - export_single_box_json()
        - parse_box_name()
        - get_box_qrcode_filename()
        - create_qrcode_for_box()
        - get_room_parent_name()

    4. Workflow layer
        - validate_box_workflow()
        - validate_room_workflow()
        - create_room_workflow()
        - add_boxes_workflow()
"""
