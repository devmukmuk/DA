"""PackIt box tree helpers."""
# src/mindit/services/packit_box_tree_helpers.py


from __future__ import annotations

from typing import Any

from mindit.models.packit_refs import BoxRef
from mindit.services.packit.packit_box_processing_service import process_box_ref_with_cache
from mindit.services.packit.packit_resolver_service import (
    get_box_parent_room_ref,
    parse_box_name,
)


def process_tree_box_item(
    ctx,
    item: dict[str, Any],
    write_metadata_updates: bool,
    regenerate_qrcodes: bool = False,
    qr_output_dir: str | None = None,
    resume: bool = False,
    skip_contents: bool = False,
    cache_dir: str = "output/cache/boxes",
) -> dict[str, Any]:
    """
    Process a single tree item representing a PackIt box sheet.

    Args:
        ctx: Shared PackIt context
        item: Raw Drive file dict for a Google Sheets box
        write_metadata_updates: Whether metadata corrections may be written
        regenerate_qrcodes: Whether to regenerate QR code output
        qr_output_dir: QR code output directory
        resume: Whether to reuse cached box results when possible
        skip_contents: Whether to skip detailed contents extraction
        cache_dir: Cache directory for per-box export data

    Returns:
        Dict suitable for merging into a tree node.
    """
    file_id = item["id"]
    file_name = item["name"]

    result: dict[str, Any] = {}

    try:
        room_ref = get_box_parent_room_ref(ctx, file_id)
        _, box_number = parse_box_name(file_name)

        box_ref = BoxRef(
            box_id=file_id,
            box_name=file_name,
            box_number=box_number,
            room_ref=room_ref,
        )

        result.update(
            process_box_ref_with_cache(
                service_drive=ctx.service_drive,
                service_sheets=ctx.service_sheets,
                settings=ctx.settings,
                box_ref=box_ref,
                write_metadata_updates=write_metadata_updates,
                resume=resume,
                skip_contents=skip_contents,
                cache_dir=cache_dir,
            )
        )



    except Exception as exc:  # pylint: disable=broad-except
        result["box_details_error"] = str(exc)

        if regenerate_qrcodes:
            result["qrcode"] = {
                "generated": False,
                "error": str(exc),
            }

    return result



def resolve_drive_folder_path(
    service_drive,
    root_folder_id: str,
    relative_path: str,
) -> str:
    """
    Resolve a slash-delimited relative folder path under a Drive root folder
    and return the final folder ID.
    """
    current_id = root_folder_id

    if not relative_path.strip():
        return current_id

    parts = [part.strip() for part in relative_path.split("/") if part.strip()]

    for part in parts:
        query = (
            f"'{current_id}' in parents and "
            f"name = '{part}' and "
            f"mimeType = 'application/vnd.google-apps.folder' and "
            f"trashed = false"
        )

        results = (
            service_drive.files()
            .list(
                q=query,
                spaces="drive",
                fields="files(id, name)",
                pageSize=10,
            )
            .execute()
        )

        files = results.get("files", [])
        if not files:
            raise ValueError(f"Folder not found in path: {part}")

        current_id = files[0]["id"]

    return current_id

