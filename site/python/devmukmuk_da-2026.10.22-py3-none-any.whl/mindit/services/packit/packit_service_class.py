"""PackIt service class."""
# src/mindit/services/packit_service.py

from __future__ import annotations

from pathlib import Path
from typing import Optional

from mindit.config.settings import load_settings
from mindit.providers.google_drive import GoogleDriveProvider
from mindit.providers.google.clients import get_drive_service, get_sheets_service
from mindit.services.packit.packit_tree_service import (
    format_tree_json,
    format_tree_txt,
)


class PackItService:
    """PackIt service layer."""

    def __init__(self, auth_type: str = "oauth") -> None:
        self.settings = load_settings()
        self.auth_type = auth_type

        self.service_drive = get_drive_service(auth_type=auth_type)
        self.service_sheets = get_sheets_service(auth_type=auth_type)

        self.drive_root_id = self.settings.providers.google_drive.root_folder_id
        self.rooms_root_path = self.settings.modules.packit.rooms_root
        
        self.provider = GoogleDriveProvider(
            service=self.service_drive,
            root_folder_id=self.drive_root_id,
        )
        
    def _get_rooms_root_path(self) -> str:
        return self.rooms_root_path or ""

    def list_rooms(self) -> list[str]:
        return [
            item.name
            for item in self.provider.list_items(self.rooms_root_path)
            if item.is_folder
        ]

    def list_rooms_with_counts(self) -> list[dict[str, object]]:
        return [
            {
                "name": item.name,
                "box_count": item.count,
            }
            for item in self.provider.list_items_with_counts(self.rooms_root_path)
            if item.is_folder
        ]

    def add_room(self, name: str) -> str:
        """
        Create a room folder and return its relative path.
        """
        room_path = f"{self.rooms_root_path}/{name}" if self.rooms_root_path else name
        created = self.provider.ensure_folder(room_path)
        return created.path


 
