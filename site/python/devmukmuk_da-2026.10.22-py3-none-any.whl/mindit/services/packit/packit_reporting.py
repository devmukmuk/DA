"""PackIt report generator."""
# src/mindit/modules/packit/report.py

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mindit.reporting.base import ReportGenerator


class PackItReportGenerator(ReportGenerator):
    """Generate PackIt-specific reports from exported tree data."""

    def load_data(self, data_path: Path) -> Any:
        """Load PackIt JSON export data."""
        with data_path.open("r", encoding="utf-8") as file:
            return json.load(file)

    def build_report(self, data: Any) -> dict[str, Any]:
        """Build a normalized PackIt report from exported tree data."""
        if not isinstance(data, list):
            raise TypeError("PackIt exported data must be a top-level list")

        packit_node = self._find_child_by_name(data, "packit")
        rooms_root = []

        if packit_node:
            packit_children = packit_node.get("children", [])
            rooms_node = self._find_child_by_name(packit_children, "rooms")
            if rooms_node:
                rooms_root = rooms_node.get("children", [])

        normalized_rooms = []
        total_boxes = 0

        for room in rooms_root:
            if room.get("type") != "folder":
                continue

            children = room.get("children", [])

            valid_boxes = []
            invalid_boxes = 0
            other_files = 0

            for child in children:
                if not isinstance(child, dict):
                    continue

                if self._is_r2_box(child):
                    valid_boxes.append(child)
                elif child.get("type") == "file":
                    if "validation" in child or "box_details_error" in child:
                        invalid_boxes += 1
                    else:
                        other_files += 1

            normalized_rooms.append({
                "name": room.get("name", "Unknown"),
                "box_count": len(valid_boxes),
                "invalid_box_count": invalid_boxes,
                "other_file_count": other_files,
                "boxes": valid_boxes,
            })

            total_boxes += len(valid_boxes)

        return {
            "module": "packit",
            "room_count": len(normalized_rooms),
            "box_count": total_boxes,
            "rooms": normalized_rooms,
        }

    def render_text(self, report: dict[str, Any]) -> str:
        """Render the PackIt report as plain text."""
        lines = [
            "PackIt Report",
            f"Rooms: {report['room_count']}",
            f"Boxes: {report['box_count']}",
            "",
        ]

        for room in report["rooms"]:
            lines.append(
                f"- {room['name']} "
                f"({room['box_count']} valid boxes, "
                f"{room['invalid_box_count']} invalid, "
                f"{room['other_file_count']} other files)"
            )

        return "\n".join(lines)

    @staticmethod
    def _find_child_by_name(nodes: list[dict[str, Any]], name: str) -> dict[str, Any] | None:
        """Find the first child node with the given name."""
        for node in nodes:
            if isinstance(node, dict) and node.get("name") == name:
                return node
        return None

    @staticmethod
    def _is_r2_box(node: dict[str, Any]) -> bool:
        """Return True if a node is a valid R2 PackIt box sheet."""
        if not isinstance(node, dict):
            return False

        if node.get("type") != "file":
            return False

        box_details = node.get("box_details")
        if not isinstance(box_details, dict):
            return False

        metadata = box_details.get("metadata")
        if not isinstance(metadata, dict):
            return False

        template = str(metadata.get("Template", "")).strip().upper()
        return template == "R2"
