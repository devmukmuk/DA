"""
DA - Box Validator Service
# src/mindit/services/box_validator.py

Description:
    Validates and normalizes PackIt box sheets using the configured
    template and metadata rules.

Responsibilities:
    - Detect the named Contents table from Google Sheets table metadata
    - Parse row data from that table
    - Parse the Metadata: section from worksheet cell values
    - Validate required metadata fields
    - Derive Room / Abbr / Tape from the parent folder name
    - Update Updated from config datetime format
    - Calculate Fragile from table rows
    - Calculate Heavy from metadata Weight against config threshold
    - Optionally write metadata corrections back to the sheet
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from mindit.config.settings import AppSettings


@dataclass
class ValidationResult:
    """
    Structured validation result for a single box sheet.
    """

    sheet_id: str
    sheet_name: str
    room_folder_name: str
    valid: bool = True
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    headers: list[str] = field(default_factory=list)
    parsed_rows: list[dict[str, Any]] = field(default_factory=list)
    metadata_original: dict[str, str] = field(default_factory=dict)
    metadata_expected: dict[str, str] = field(default_factory=dict)
    metadata_updates: dict[str, str] = field(default_factory=dict)
    table_name: str = "Contents"
    sheet_title: str = ""

    def add_warning(self, message: str) -> None:
        """
        Add a warning to the validation result.

        Args:
            message: Warning text.
        """
        self.warnings.append(message)

    def add_error(self, message: str) -> None:
        """
        Add an error and mark the result invalid.

        Args:
            message: Error text.
        """
        self.errors.append(message)
        self.valid = False


def get_first_sheet_info(service_sheets, spreadsheet_id: str) -> dict[str, Any]:
    """
    Return the first worksheet tab info, including table metadata.

    Args:
        service_sheets: Authenticated Google Sheets API service.
        spreadsheet_id: Spreadsheet ID.

    Returns:
        Dict containing first sheet title, sheet ID, and tables.
    """
    spreadsheet = service_sheets.spreadsheets().get(
        spreadsheetId=spreadsheet_id,
        fields="sheets(properties(sheetId,title),tables)",
    ).execute()

    first_sheet = spreadsheet["sheets"][0]
    properties = first_sheet["properties"]

    return {
        "sheet_id": properties["sheetId"],
        "title": properties["title"],
        "tables": first_sheet.get("tables", []),
    }


def get_sheet_values(
    service_sheets,
    spreadsheet_id: str,
    sheet_title: str,
) -> list[list[str]]:
    """
    Read all values from the given worksheet tab.

    Args:
        service_sheets: Authenticated Google Sheets API service.
        spreadsheet_id: Spreadsheet ID.
        sheet_title: Worksheet tab title.

    Returns:
        2D list of sheet cell values.
    """
    result = service_sheets.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id,
        range=sheet_title,
    ).execute()

    return result.get("values", [])


def find_named_table(
    tables: list[dict[str, Any]],
    table_name: str,
) -> dict[str, Any] | None:
    """
    Find a Google Sheets table by name.

    Args:
        tables: List of table metadata objects.
        table_name: Desired table name.

    Returns:
        Matching table dict, or None if not found.
    """
    for table in tables:
        if table.get("name") == table_name:
            return table
    return None


def extract_table_from_values(
    values: list[list[str]],
    table_range: dict[str, Any],
) -> dict[str, Any]:
    """
    Extract headers and row dicts from a table range.

    The Google Sheets table range uses zero-based, end-exclusive indexes.

    Args:
        values: Full worksheet cell values.
        table_range: Range object from Sheets table metadata.

    Returns:
        Dict with 'headers' and 'rows'.
    """
    start_row = table_range.get("startRowIndex", 0)
    end_row = table_range.get("endRowIndex", len(values))
    start_col = table_range.get("startColumnIndex", 0)
    end_col = table_range.get("endColumnIndex", 0)

    sliced_rows: list[list[str]] = []

    for row in values[start_row:end_row]:
        padded = row + [""] * max(0, end_col - len(row))
        sliced_rows.append(padded[start_col:end_col])

    if not sliced_rows:
        return {"headers": [], "rows": []}

    headers = [str(cell).strip() for cell in sliced_rows[0]]
    data_rows = sliced_rows[1:]

    parsed_rows: list[dict[str, Any]] = []

    for row in data_rows:
        if not any(str(cell).strip() for cell in row):
            continue

        record: dict[str, Any] = {}
        for index, header in enumerate(headers):
            if not header:
                continue
            value = row[index].strip() if index < len(row) and row[index] else ""
            record[header] = value

        if record:
            parsed_rows.append(record)

    return {
        "headers": headers,
        "rows": parsed_rows,
    }


def parse_metadata_section(
    values: list[list[str]],
    metadata_marker: str,
) -> dict[str, str] | None:
    """
    Parse metadata rows below the configured Metadata marker.

    Expected layout example:

        Metadata:
        Room      Dining
        Abbr      D
        Box#      10

    Args:
        values: Full worksheet cell values.
        metadata_marker: Marker row first-cell value, such as 'Metadata:'.

    Returns:
        Metadata dict, or None if marker is not found.
    """
    metadata_start = None

    for index, row in enumerate(values):
        if row and row[0].strip() == metadata_marker:
            metadata_start = index + 1
            break

    if metadata_start is None:
        return None

    metadata: dict[str, str] = {}

    for row in values[metadata_start:]:
        if not row or not any(str(cell).strip() for cell in row):
            continue

        key = row[0].strip() if len(row) > 0 else ""
        value_parts = [str(cell).strip() for cell in row[1:] if str(cell).strip()]
        value = " ".join(value_parts)

        if key:
            metadata[key] = value

    return metadata


def parse_room_folder_name(
    room_folder_name: str,
    delimiter: str,
    room_index: int,
    abbr_index: int,
    tape_index: int,
) -> dict[str, str]:
    """
    Parse the room folder naming convention into Room / Abbr / Tape.

    Example:
        GARAGE-G-BLUE

    Args:
        folder_name: Parent folder name.
        delimiter: Split delimiter, typically '-'.
        room_index: Index of room token.
        abbr_index: Index of abbreviation token.
        tape_index: Index of tape token.

    Returns:
        Dict containing Room, Abbr, Tape.

    Raises:
        ValueError: If the folder name cannot be parsed.
    """
    parts = [part.strip() for part in room_folder_name.split(delimiter)]

    max_needed_index = max(room_index, abbr_index, tape_index)
    if len(parts) <= max_needed_index:
        raise ValueError(
            f"Room folder name '{room_folder_name}' does not match expected format"
        )

    return {
        "Room": parts[room_index],
        "Abbr": parts[abbr_index],
        "Tape": parts[tape_index],
    }


def calculate_fragile(rows: list[dict[str, Any]]) -> str:
    """
    Calculate Fragile from table rows.

    Rule:
        True if any row's Fragile column is truthy.

    Truthy values accepted:
        true, yes, y, 1, fragile

    Args:
        rows: Parsed table rows.

    Returns:
        'True' or 'False'
    """
    truthy_values = {"true", "yes", "y", "1", "fragile", "X", "x"}

    for row in rows:
        fragile_value = str(row.get("Fragile", "")).strip().lower()
        if fragile_value in truthy_values:
            return "True"

    return "False"


def calculate_heavy_from_metadata(
    metadata: dict[str, str],
    heavy_threshold: float,
) -> str:
    """
    Calculate Heavy from metadata Weight.

    Rule:
        If Weight > heavy_threshold, Heavy is True.

    Args:
        metadata: Parsed metadata dictionary.
        heavy_threshold: Threshold from config.

    Returns:
        'True' or 'False'
    """
    raw_weight = str(metadata.get("Weight", "")).strip()
    if not raw_weight:
        return "False"

    cleaned = (
        raw_weight.replace(",", "")
        .replace("$", "")
        .replace("lbs", "")
        .replace("lb", "")
        .strip()
    )

    try:
        weight = float(cleaned)
    except ValueError:
        return "False"

    return "True" if weight > heavy_threshold else "False"


def build_updated_timestamp(updated_format: str) -> str:
    """
    Build Updated timestamp using the configured format.

    Args:
        updated_format: strftime format string.

    Returns:
        Formatted timestamp string.
    """
    return datetime.now().strftime(updated_format)


def validate_required_metadata(
    result: ValidationResult,
    metadata: dict[str, str],
    required_fields: list[str],
    expected_template: str,
) -> None:
    """
    Validate required metadata fields and template version.

    Missing required fields are warnings, not hard errors, because
    the validator may be able to normalize them automatically.

    Args:
        result: Validation result accumulator.
        metadata: Parsed metadata.
        required_fields: Required metadata field names.
        expected_template: Expected template version.
    """
    for field_name in required_fields:
        if field_name not in metadata:
            result.add_warning(f"Missing metadata field: {field_name}")

    actual_template = metadata.get("Template", "")
    if actual_template != expected_template:
        result.add_warning(
            f"Template mismatch: found '{actual_template}', expected '{expected_template}'"
        )

def parse_box_number_from_file_name(file_name: str) -> str:
    """
    Extract Box# from a file name like 'G-1'.

    Args:
        file_name: Spreadsheet file name.

    Returns:
        Box number as a string.

    Raises:
        ValueError: If the file name cannot be parsed.
    """
    parts = [part.strip() for part in file_name.split("-", maxsplit=1)]
    if len(parts) != 2 or not parts[1]:
        raise ValueError(f"File name '{file_name}' does not match expected ABBR-BOX# format")

    return parts[1]

def compute_expected_metadata(
    metadata: dict[str, str],
    room_folder_name: str,
    sheet_name: str,
    parsed_rows: list[dict[str, Any]],
    settings: AppSettings,
) -> dict[str, str]:
    """
    Compute normalized metadata values from config, folder name, and row data.

    Rules:
        - Room from parent folder split
        - Abbr from parent folder split
        - Tape from parent folder split
        - Template from config
        - Updated from config datetime format
        - Fragile from row Fragile values
        - Heavy from metadata Weight compared to config threshold

    Args:
        metadata: Existing metadata.
        room_folder_name: Room folder name such as GARAGE-G-BLUE.
        parsed_rows: Parsed table rows.
        settings: Application settings.

    Returns:
        Expected normalized metadata dictionary.
    """
    box_settings = settings.modules.packit.box

    folder_parts = parse_room_folder_name(
        room_folder_name=room_folder_name,
        delimiter=box_settings.parent_folder_delimiter,
        room_index=box_settings.parent_folder_room_index,
        abbr_index=box_settings.parent_folder_abbr_index,
        tape_index=box_settings.parent_folder_tape_index,
    )

    box_number = parse_box_number_from_file_name(sheet_name)

    expected = dict(metadata)
    expected["Room"] = folder_parts["Room"]
    expected["Abbr"] = folder_parts["Abbr"]
    expected["Box#"] = box_number
    expected["Tape"] = folder_parts["Tape"]
    expected["Template"] = box_settings.template_version
    expected["Updated"] = build_updated_timestamp(box_settings.updated_format)
    expected["Fragile"] = calculate_fragile(parsed_rows)
    expected["Heavy"] = calculate_heavy_from_metadata(
        metadata=metadata,
        heavy_threshold=box_settings.heavy_threshold,
    )

    return expected


def normalize_metadata_value(key: str, value: str) -> str:
    """
    Normalize metadata values for comparison.

    Args:
        key: Metadata key.
        value: Metadata value.

    Returns:
        Normalized string value.
    """
    normalized = str(value).strip()

    if key in {"Fragile", "Heavy"}:
        lowered = normalized.lower()
        if lowered in {"true", "yes", "y", "1", "x"}:
            return "True"
        if lowered in {"false", "no", "n", "0", ""}:
            return "False"

    return normalized


def diff_metadata(
    original: dict[str, str],
    expected: dict[str, str],
) -> dict[str, str]:
    """
    Return only changed metadata values.

    Args:
        original: Existing metadata.
        expected: Expected metadata.

    Returns:
        Dict containing only changed values.
    """
    updates: dict[str, str] = {}

    for key, expected_value in expected.items():
        current_value = original.get(key, "")

        normalized_current = normalize_metadata_value(key, current_value)
        normalized_expected = normalize_metadata_value(key, expected_value)

        if normalized_current != normalized_expected:
            updates[key] = expected_value

    return updates


def find_metadata_row_indexes(
    values: list[list[str]],
    metadata_marker: str,
) -> dict[str, int]:
    """
    Map metadata keys to worksheet row numbers.

    Returns 1-based row numbers for sheet write-back.

    Args:
        values: Full worksheet values.
        metadata_marker: Metadata marker string.

    Returns:
        Dict of metadata key -> row number.
    """
    metadata_start = None

    for index, row in enumerate(values):
        if row and row[0].strip() == metadata_marker:
            metadata_start = index + 1
            break

    if metadata_start is None:
        return {}

    row_map: dict[str, int] = {}

    for index in range(metadata_start, len(values)):
        row = values[index]
        if not row or not any(str(cell).strip() for cell in row):
            continue

        key = row[0].strip() if len(row) > 0 else ""
        if key:
            row_map[key] = index + 1

    return row_map


def update_metadata_cells(
    service_sheets,
    spreadsheet_id: str,
    sheet_title: str,
    values: list[list[str]],
    updates: dict[str, str],
    metadata_marker: str,
) -> None:
    """
    Write metadata updates back into column B for existing metadata rows.

    Args:
        service_sheets: Authenticated Google Sheets API service.
        spreadsheet_id: Spreadsheet ID.
        sheet_title: Worksheet tab title.
        values: Full worksheet values.
        updates: Metadata values to update.
        metadata_marker: Metadata marker string.
    """
    metadata_rows = find_metadata_row_indexes(values, metadata_marker)
    data = []

    for key, value in updates.items():
        row_number = metadata_rows.get(key)
        if not row_number:
            continue

        data.append(
            {
                "range": f"{sheet_title}!B{row_number}",
                "values": [[value]],
            }
        )

    if not data:
        return

    service_sheets.spreadsheets().values().batchUpdate(
        spreadsheetId=spreadsheet_id,
        body={
            "valueInputOption": "USER_ENTERED",
            "data": data,
        },
    ).execute()


def validate_box_sheet(
    service_sheets,
    spreadsheet_id: str,
    sheet_name: str,
    room_folder_name: str,
    settings: AppSettings,
    write_updates: bool = False,
) -> ValidationResult:
    """
    Validate and optionally normalize a single box sheet.

    Args:
        service_sheets: Authenticated Google Sheets API service.
        spreadsheet_id: Spreadsheet ID.
        sheet_name: File name, such as G-1.
        room_folder_name: Room folder name, such as GARAGE-G-BLUE.
        settings: Loaded application settings.
        write_updates: Whether to write normalized metadata back to the sheet.

    Returns:
        ValidationResult containing validation details and normalized metadata.
    """
    box_settings = settings.modules.packit.box

    result = ValidationResult(
        sheet_id=spreadsheet_id,
        sheet_name=sheet_name,
        room_folder_name=room_folder_name,
        table_name=box_settings.contents_table_name,
    )

    sheet_info = get_first_sheet_info(service_sheets, spreadsheet_id)
    sheet_title = sheet_info["title"]
    tables = sheet_info["tables"]
    result.sheet_title = sheet_title

    values = get_sheet_values(service_sheets, spreadsheet_id, sheet_title)

    contents_table = find_named_table(tables, box_settings.contents_table_name)
    if not contents_table:
        result.add_error(
            f"Missing table named '{box_settings.contents_table_name}'"
        )
        return result

    parsed_table = extract_table_from_values(values, contents_table["range"])
    headers = parsed_table["headers"]
    rows = parsed_table["rows"]

    result.headers = headers
    result.parsed_rows = rows

    if not headers:
        result.add_error("Contents table has no headers")

    metadata = parse_metadata_section(values, box_settings.metadata_marker)
    if metadata is None:
        result.add_error(
            f"Missing metadata section marker '{box_settings.metadata_marker}'"
        )
        return result

    result.metadata_original = metadata

    validate_required_metadata(
        result=result,
        metadata=metadata,
        required_fields=box_settings.required_metadata_fields,
        expected_template=box_settings.template_version,
    )

    try:
        expected_metadata = compute_expected_metadata(
            metadata=metadata,
            room_folder_name=room_folder_name,
            sheet_name=sheet_name,
            parsed_rows=rows,
            settings=settings,
        )
    except ValueError as exc:
        result.add_error(str(exc))
        return result

    result.metadata_expected = expected_metadata
    result.metadata_updates = diff_metadata(metadata, expected_metadata)

    if write_updates and result.metadata_updates:
        update_metadata_cells(
            service_sheets=service_sheets,
            spreadsheet_id=spreadsheet_id,
            sheet_title=sheet_title,
            values=values,
            updates=result.metadata_updates,
            metadata_marker=box_settings.metadata_marker,
        )

    return result
