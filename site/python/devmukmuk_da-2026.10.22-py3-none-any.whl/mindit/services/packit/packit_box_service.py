"""
PackIt box sheet services.

Description:
    Create, remove, and rename box spreadsheets stored directly inside
    a Google Drive room folder.
"""

from __future__ import annotations

from typing import Any

from rich import print  # pylint: disable=W0622

from mindit import __version__
from mindit.services.google.drive_service import get_room_parent_name
from mindit.services.qrcodes.qrcode_service import create_qrcode_for_box

SHEET_MIME = "application/vnd.google-apps.spreadsheet"


def parse_box_name(box_name: str) -> tuple[str, int | None]:
    """
    Parse a box name into room abbreviation and optional box number.
    """
    parts = [part.strip() for part in box_name.split("-") if part.strip()]

    room_abbr = parts[0] if parts else box_name.strip()
    box_number = None

    if len(parts) >= 2 and parts[-1].isdigit():
        box_number = int(parts[-1])

    return room_abbr, box_number


def copy_box_template_to_room(
    service_drive,
    template_id: str,
    room_folder_id: str,
    box_name: str,
) -> dict[str, str]:
    """
    Copy the configured box template spreadsheet into a room folder.
    """
    body = {
        "name": box_name,
        "parents": [room_folder_id],
    }

    copied_sheet = (
        service_drive.files()
        .copy(
            fileId=template_id,
            body=body,
            fields="id, name, mimeType, parents",
        )
        .execute()
    )

    print(f"Box sheet created: {copied_sheet['name']} ({copied_sheet['id']})")
    return copied_sheet


def rename_first_sheet_tab(
    service_sheets,
    spreadsheet_id: str,
    new_title: str,
) -> None:
    """
    Rename the first worksheet tab in a spreadsheet.
    """
    metadata = (
        service_sheets.spreadsheets()
        .get(spreadsheetId=spreadsheet_id)
        .execute()
    )

    sheets = metadata.get("sheets", [])
    if not sheets:
        return

    first_sheet_id = sheets[0]["properties"]["sheetId"]

    request_body = {
        "requests": [
            {
                "updateSheetProperties": {
                    "properties": {
                        "sheetId": first_sheet_id,
                        "title": new_title,
                    },
                    "fields": "title",
                }
            }
        ]
    }

    (
        service_sheets.spreadsheets()
        .batchUpdate(
            spreadsheetId=spreadsheet_id,
            body=request_body,
        )
        .execute()
    )


def update_box_metadata(
    service_sheets,
    sheet_id: str,
    sheet_filename: str,
    room_folder_name: str | None = None,
) -> None:
    """
    Update key metadata fields in a box spreadsheet.

    Box files are named like:
        LR-01

    Room folders are named like:
        LIVINGROOM-LR-YELLOW
    """
    updates: list[dict[str, Any]] = []

    room_abbr, box_number = parse_box_name(sheet_filename)

    room_name = ""
    tape = ""

    if room_folder_name:
        parts = [part.strip() for part in room_folder_name.split("-")]
        room_name = parts[0] if len(parts) > 0 else ""
        if len(parts) > 2:
            tape = parts[2]

    metadata_rows = [
        ["Room", room_name],
        ["Abbr", room_abbr],
        ["Box#", f"{box_number:02d}" if box_number is not None else ""],
        ["Tape", tape],
        ["Template", "R2"],
    ]

    result = (
        service_sheets.spreadsheets()
        .values()
        .get(
            spreadsheetId=sheet_id,
            range="A1:Z1000",
        )
        .execute()
    )

    rows = result.get("values", [])

    metadata_index = None
    for index, row in enumerate(rows):
        if row and str(row[0]).strip().lower().startswith("metadata"):
            metadata_index = index
            break

    start_row = metadata_index + 2 if metadata_index is not None else len(rows) + 1

    range_str = f"A{start_row}:B{start_row + len(metadata_rows) - 1}"
    updates.append(
        {
            "range": range_str,
            "values": metadata_rows,
        }
    )

    body = {
        "valueInputOption": "RAW",
        "data": updates,
    }

    (
        service_sheets.spreadsheets()
        .values()
        .batchUpdate(
            spreadsheetId=sheet_id,
            body=body,
        )
        .execute()
    )


def create_box_sheet(
    service_drive,
    service_sheets,
    template_id: str,
    room_folder_id: str,
    box_name: str,
    output_dir: str,
) -> str:
    """
    Create a new box spreadsheet directly under a room folder and generate its QR code.
    """
    room_abbr, box_number = parse_box_name(box_name)

    sheet = copy_box_template_to_room(
        service_drive=service_drive,
        template_id=template_id,
        room_folder_id=room_folder_id,
        box_name=box_name,
    )
    sheet_id = sheet["id"]

    try:
        rename_first_sheet_tab(
            service_sheets=service_sheets,
            spreadsheet_id=sheet_id,
            new_title=box_name,
        )
    except Exception as exc:  # pylint: disable=broad-except
        print(f"[WARN] Could not rename first worksheet tab: {exc}")

    try:
        room_meta = service_drive.files().get(
            fileId=room_folder_id,
            fields="name",
        ).execute()
        room_folder_name = room_meta["name"]

        update_box_metadata(
            service_sheets=service_sheets,
            sheet_id=sheet_id,
            sheet_filename=box_name,
            room_folder_name=room_folder_name,
        )
    except Exception as exc:  # pylint: disable=broad-except
        print(f"[WARN] Could not update metadata for new box sheet: {exc}")

    try:
        household_name, room_folder_name = get_room_parent_name(service_drive, sheet_id)

        qr_path = create_qrcode_for_box(
            sheet_id=sheet_id,
            room_abbr=room_abbr,
            room_folder_name=room_folder_name,
            household_name=household_name,
            output_dir=output_dir,
            box_number=box_number,
            version=__version__,
        )
        print(f"[INFO] QR code created: {qr_path}")
    except Exception as exc:  # pylint: disable=broad-except
        print(f"[WARN] Could not generate QR code for new box sheet: {exc}")

    return sheet_id


def delete_box_sheet(
    service_drive,
    sheet_id: str,
) -> None:
    """
    Delete a box spreadsheet from Google Drive.
    """
    service_drive.files().delete(fileId=sheet_id).execute()
    print(f"Box sheet deleted: {sheet_id}")


def rename_box_sheet(
    service_drive,
    service_sheets,
    sheet_id: str,
    new_name: str,
) -> None:
    """
    Rename a box spreadsheet and refresh its metadata.
    """
    service_drive.files().update(
        fileId=sheet_id,
        body={"name": new_name},
    ).execute()

    print(f"Box sheet renamed: {sheet_id} -> {new_name}")

    try:
        rename_first_sheet_tab(
            service_sheets=service_sheets,
            spreadsheet_id=sheet_id,
            new_title=new_name,
        )
    except Exception as exc:  # pylint: disable=broad-except
        print(f"[WARN] Could not rename first worksheet tab: {exc}")

    try:
        update_box_metadata(
            service_sheets=service_sheets,
            sheet_id=sheet_id,
            sheet_filename=new_name,
        )
    except Exception as exc:  # pylint: disable=broad-except
        print(f"[WARN] Could not refresh metadata after rename: {exc}")
