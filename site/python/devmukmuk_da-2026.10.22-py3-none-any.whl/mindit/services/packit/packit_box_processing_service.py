"""packit box processing service."""
# src/mindit/services/packit_processing_service.py

from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
from typing import Any

from mindit.models.packit_refs import BoxRef
from mindit.services.packit.packit_box_export_service import build_box_export_data


def process_box_ref_with_cache(
    service_drive,
    service_sheets,
    settings,
    box_ref: BoxRef,
    write_metadata_updates: bool,
    resume: bool,
    skip_contents: bool,
    cache_dir: str,
) -> dict[str, Any]:
    """
    Process one box with cache/resume support.
    """
    file_id = box_ref.box_id
    file_name = box_ref.box_name

    cache_path = Path(cache_dir)
    cache_path.mkdir(parents=True, exist_ok=True)

    box_cache_file = cache_path / f"{file_id}.json"

    meta = (
        service_drive.files()
        .get(
            fileId=file_id,
            fields="modifiedTime",
        )
        .execute()
    )
    modified_time = meta.get("modifiedTime")

    if resume and box_cache_file.exists():
        try:
            cached = json.loads(box_cache_file.read_text(encoding="utf-8"))
            cached_time = cached.get("_cache", {}).get("modifiedTime")
            if cached_time == modified_time:
                return cached
        except Exception:
            pass

    result: dict[str, Any] = {
        "id": file_id,
        "name": file_name,
        "parent_folder_name": box_ref.room_ref.room_folder_name,
    }

    if skip_contents:
        result["_cache"] = {"modifiedTime": modified_time}
        box_cache_file.write_text(
            json.dumps(result, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        return result

    try:
        export_data = build_box_export_data(
            service_sheets=service_sheets,
            settings=settings,
            box_ref=box_ref,
            write_metadata_updates=write_metadata_updates,
        )
        result.update(asdict(export_data))
    except Exception as exc:  # pylint: disable=broad-except
        result["box_details_error"] = str(exc)

    result["_cache"] = {"modifiedTime": modified_time}

    box_cache_file.write_text(
        json.dumps(result, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    return result
