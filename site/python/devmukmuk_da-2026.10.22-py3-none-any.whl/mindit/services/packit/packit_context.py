"""PackIt context and initialization helpers.

Description:
    Provides a shared context object used across PackIt services and workflows.
    This centralizes:
        - settings
        - Google API clients
        - resolved root folder IDs

Design:
    - Built once per CLI command
    - Passed into all services/workflows
    - Avoids repeated setup logic across modules
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mindit.config.settings import load_settings, AppSettings


from mindit.providers.google.clients import (
    get_drive_service,
    get_sheets_service,
)

from mindit.services.packit.packit_box_tree_helpers import resolve_drive_folder_path


@dataclass
class PackItContext:
    """Shared PackIt execution context."""

    settings: AppSettings

    # Google services
    service_drive: Any
    service_sheets: Any

    # Root identifiers
    drive_root_id: str
    rooms_root_path: str
    rooms_root_id: str


def build_packit_context(auth_type: str = "oauth") -> PackItContext:
    """
    Build a PackItContext.

    Args:
        auth_type: "oauth" or "service"

    Returns:
        Fully initialized PackItContext
    """
    settings = load_settings()

    # Initialize Google API clients
    service_drive = get_drive_service(auth_type=auth_type)
    service_sheets = get_sheets_service(auth_type=auth_type)

    # Root configuration
    drive_root_id = settings.providers.google_drive.root_folder_id
    rooms_root_path = settings.modules.packit.rooms_root

    # Resolve rooms root folder ID (path → actual Drive folder ID)
    rooms_root_id = resolve_drive_folder_path(
        service_drive=service_drive,
        root_folder_id=drive_root_id,
        relative_path=rooms_root_path,
    )

    return PackItContext(
        settings=settings,
        service_drive=service_drive,
        service_sheets=service_sheets,
        drive_root_id=drive_root_id,
        rooms_root_path=rooms_root_path,
        rooms_root_id=rooms_root_id,
    )
