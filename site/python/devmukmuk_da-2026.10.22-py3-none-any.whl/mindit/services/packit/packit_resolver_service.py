"""PackIt resolver services."""
# src/mindit/services/packit_resolver_service.py

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from mindit.models.packit_refs import HouseRef, RoomRef, BoxRef

if TYPE_CHECKING:
    from mindit.services.packit.packit_context import PackItContext


FOLDER_MIME_TYPE = "application/vnd.google-apps.folder"
SHEET_MIME_TYPE = "application/vnd.google-apps.spreadsheet"


def list_drive_children(
    ctx: PackItContext,
    parent_id: str,
) -> list[dict[str, Any]]:
    """
    List direct children of a Drive folder.
    """
    results = (
        ctx.service_drive.files()
        .list(
            q=f"'{parent_id}' in parents and trashed = false",
            spaces="drive",
            fields="files(id, name, mimeType, parents)",
            orderBy="name_natural",
            pageSize=1000,
        )
        .execute()
    )
    return results.get("files", [])


def split_room_folder_name(room_folder_name: str) -> tuple[str, str, str]:
    """
    Split canonical room folder name: ROOMNAME-ABBR-TAPE
    """
    parts = [part.strip() for part in room_folder_name.split("-")]

    room_name = parts[0] if len(parts) > 0 else room_folder_name.strip()
    room_abbr = parts[1] if len(parts) > 1 else ""
    room_tape = "-".join(parts[2:]) if len(parts) > 2 else ""

    return room_name, room_abbr, room_tape


def parse_box_name(box_name: str) -> tuple[str, int | None]:
    """
    Parse canonical box sheet name: ABBR-NN

    Examples:
        LR-01 -> ("LR", 1)
        D-12  -> ("D", 12)
        OFFICE -> ("OFFICE", None)
    """
    parts = [part.strip() for part in box_name.split("-", maxsplit=1)]

    room_abbr = parts[0] if parts else box_name.strip()
    box_number: int | None = None

    if len(parts) > 1:
        try:
            box_number = int(parts[1])
        except ValueError:
            box_number = None

    return room_abbr, box_number


def get_house_ref(ctx: PackItContext) -> HouseRef:
    """
    Resolve the top-level PackIt household/root reference.
    """
    meta = (
        ctx.service_drive.files()
        .get(
            fileId=ctx.drive_root_id,
            fields="id, name",
        )
        .execute()
    )

    return HouseRef(
        house_id=meta["id"],
        house_name=meta["name"],
    )


def get_room_refs(
    ctx: PackItContext,
    house_ref: HouseRef | None = None,
) -> list[RoomRef]:
    """
    Return all PackIt room refs under the household ref.
    """
    resolved_house_ref = house_ref or get_house_ref(ctx)
    children = list_drive_children(ctx, ctx.rooms_root_id)

    room_refs: list[RoomRef] = []

    for item in children:
        if item.get("mimeType") != FOLDER_MIME_TYPE:
            continue

        room_name, room_abbr, room_tape = split_room_folder_name(item["name"])

        room_refs.append(
            RoomRef(
                room_id=item["id"],
                room_folder_name=item["name"],
                room_name=room_name,
                room_abbr=room_abbr,
                room_tape=room_tape,
                house_ref=resolved_house_ref,
            )
        )

    return room_refs


def get_box_refs(
    ctx: PackItContext,
    room_ref: RoomRef,
) -> list[BoxRef]:
    """
    Return all box refs directly under a room folder.
    """
    children = list_drive_children(ctx, room_ref.room_id)

    box_refs: list[BoxRef] = []

    for item in children:
        if item.get("mimeType") != SHEET_MIME_TYPE:
            continue

        _, box_number = parse_box_name(item["name"])

        box_refs.append(
            BoxRef(
                box_id=item["id"],
                box_name=item["name"],
                box_number=box_number,
                room_ref=room_ref,
            )
        )

    return box_refs


def get_room_ref_by_name_or_abbr(
    ctx: PackItContext,
    room_name: str | None = None,
    room_abbr: str | None = None,
) -> RoomRef | None:
    """
    Find one room ref by room_name and/or room_abbr.

    Matching is case-insensitive.
    If both are provided, both must match.
    """
    if not room_name and not room_abbr:
        raise ValueError("Either room_name or room_abbr must be provided")

    normalized_room_name = room_name.strip().upper() if room_name else None
    normalized_room_abbr = room_abbr.strip().upper() if room_abbr else None

    matches: list[RoomRef] = []

    for room_ref in get_room_refs(ctx):
        room_name_matches = (
            normalized_room_name is None
            or room_ref.room_name.upper() == normalized_room_name
        )
        room_abbr_matches = (
            normalized_room_abbr is None
            or room_ref.room_abbr.upper() == normalized_room_abbr
        )

        if room_name_matches and room_abbr_matches:
            matches.append(room_ref)

    if not matches:
        return None

    if len(matches) > 1:
        match_names = ", ".join(match.room_folder_name for match in matches)
        raise ValueError(f"Multiple rooms matched: {match_names}")

    return matches[0]


def get_box_ref_by_name(
    ctx: PackItContext,
    box_name: str,
) -> BoxRef | None:
    """
    Find one box ref by sheet name across all rooms.

    Matching is case-insensitive.
    """
    normalized_box_name = box_name.strip().upper()
    matches: list[BoxRef] = []

    for room_ref in get_room_refs(ctx):
        for box_ref in get_box_refs(ctx, room_ref):
            if box_ref.box_name.strip().upper() == normalized_box_name:
                matches.append(box_ref)

    if not matches:
        return None

    if len(matches) > 1:
        match_names = ", ".join(
            f"{match.box_name} (room={match.room_ref.room_folder_name})"
            for match in matches
        )
        raise ValueError(f"Multiple boxes matched: {match_names}")

    return matches[0]


def get_box_parent_room_ref(
    ctx: PackItContext,
    box_id: str,
) -> RoomRef:
    """
    Resolve the parent room ref for a box by Drive file ID.
    """
    box_meta = (
        ctx.service_drive.files()
        .get(
            fileId=box_id,
            fields="id, name, parents",
        )
        .execute()
    )

    parent_ids = box_meta.get("parents", [])
    if not parent_ids:
        raise ValueError(f"Box has no parent folder: {box_meta.get('name', box_id)}")

    room_id = parent_ids[0]

    room_meta = (
        ctx.service_drive.files()
        .get(
            fileId=room_id,
            fields="id, name, mimeType",
        )
        .execute()
    )

    if room_meta.get("mimeType") != FOLDER_MIME_TYPE:
        raise ValueError(
            f"Box parent is not a folder: {room_meta.get('name', room_id)}"
        )

    house_ref = get_house_ref(ctx)
    room_name, room_abbr, room_tape = split_room_folder_name(room_meta["name"])

    return RoomRef(
        room_id=room_meta["id"],
        room_folder_name=room_meta["name"],
        room_name=room_name,
        room_abbr=room_abbr,
        room_tape=room_tape,
        house_ref=house_ref,
    )
