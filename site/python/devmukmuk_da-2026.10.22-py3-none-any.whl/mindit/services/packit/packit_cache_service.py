"""PackIt export cache helpers."""
# src/mindit/services/export_cache_service.py

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def ensure_cache_dir(cache_dir: str | Path) -> Path:
    """Ensure the cache directory exists and return it."""
    path = Path(cache_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_box_cache_path(cache_dir: str | Path, box_id: str) -> Path:
    """Return the cache file path for a box."""
    return ensure_cache_dir(cache_dir) / f"{box_id}.json"


def load_box_cache(cache_dir: str | Path, box_id: str) -> dict[str, Any] | None:
    """Load cached export JSON for a box if present."""
    path = get_box_cache_path(cache_dir, box_id)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def save_box_cache(
    cache_dir: str | Path,
    box_id: str,
    payload: dict[str, Any],
) -> Path:
    """Write cached export JSON for a box."""
    path = get_box_cache_path(cache_dir, box_id)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def is_box_cache_fresh(
    cached_payload: dict[str, Any] | None,
    modified_time: str | None,
) -> bool:
    """Return True when cache exists and matches Drive modifiedTime."""
    if not cached_payload or not modified_time:
        return False
    return cached_payload.get("_cache", {}).get("modifiedTime") == modified_time
