"""PackIt workflow services."""
# src/mindit/services/packit/packit_workflows.py

from __future__ import annotations

from pathlib import Path
from typing import Any
import time
from datetime import datetime
import json

from googleapiclient.errors import HttpError

from mindit.services.packit.packit_context import PackItContext
from mindit.services.packit.packit_box_service import (
    parse_box_name,
    create_box_sheet
)
from mindit.services.packit.packit_box_validator import validate_box_sheet
from mindit.services.qrcodes.qrcode_service import (
    create_qrcode_for_box,
    get_box_qrcode_filename,
)
from mindit.services.packit.packit_resolver_service import (
    get_box_ref_by_name,
    get_box_parent_room_ref,
    get_room_ref_by_name_or_abbr,
    get_room_refs,
    get_box_refs,
    get_house_ref
)
from mindit.services.packit.packit_room_service import create_room
from mindit.services.packit.packit_box_export_service import write_box_export_json
from collections import defaultdict

from mindit.models.packit_validation import ValidationIssue

def _get_metadata_value(metadata: dict[str, Any], *keys: str) -> Any:
    normalized = {
        str(key).strip().lower().replace(" ", "_"): value
        for key, value in metadata.items()
    }

    for key in keys:
        normalized_key = key.strip().lower().replace(" ", "_")
        if normalized_key in normalized:
            return normalized[normalized_key]

    return None

def _safe_float(value: Any) -> float:
    if value in (None, ""):
        return 0.0

    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _normalize_key(value: str) -> str:
    return (
        value.strip()
        .lower()
        .replace(" ", "_")
        .replace("#", "number")
        .replace(".", "")
        .replace(":", "")
    )


def _get_nested_value(data: dict[str, Any], *keys: str) -> Any:
    """
    Search a nested dict/list payload for the first matching key.
    This is intentionally flexible because PackIt export/metadata shape
    may evolve.
    """
    wanted = {_normalize_key(key) for key in keys}

    def walk(value: Any) -> Any:
        if isinstance(value, dict):
            for raw_key, raw_value in value.items():
                if _normalize_key(str(raw_key)) in wanted:
                    return raw_value

            for raw_value in value.values():
                found = walk(raw_value)
                if found is not None:
                    return found

        elif isinstance(value, list):
            for item in value:
                found = walk(item)
                if found is not None:
                    return found

        return None

    return walk(data)


def _validate_box_sheet_with_retry(
    *,
    service_sheets: Any,
    spreadsheet_id: str,
    sheet_name: str,
    room_folder_name: str,
    settings: Any,
    write_updates: bool = False,
    max_attempts: int = 6,
    base_sleep_seconds: float = 10.0,
) -> Any | None:
    for attempt in range(1, max_attempts + 1):
        try:
            return validate_box_sheet(
                service_sheets=service_sheets,
                spreadsheet_id=spreadsheet_id,
                sheet_name=sheet_name,
                room_folder_name=room_folder_name,
                settings=settings,
                write_updates=write_updates,
            )
        except HttpError as exc:
            status = getattr(exc.resp, "status", None)

            if status not in (429, 500, 502, 503, 504):
                raise

            sleep_seconds = base_sleep_seconds * attempt

            print(
                f"Google Sheets read failed for {sheet_name} "
                f"(HTTP {status}, attempt {attempt}/{max_attempts}). "
                f"Waiting {sleep_seconds:.1f}s..."
            )

            time.sleep(sleep_seconds)

    print(f"Skipping {sheet_name}: Google Sheets read failed after retries.")
    return None


def _read_box_export_payload(export_result: Any) -> dict[str, Any]:
    """
    Supports either:
      - write_box_export_json returning a Path/string path
      - write_box_export_json returning a dict payload
      - write_box_export_json returning {"path": "..."} style result
    """
    if isinstance(export_result, dict):
        for key in ("path", "output_path", "export_path", "file_path"):
            if key in export_result:
                return json.loads(
                    Path(export_result[key]).read_text(encoding="utf-8")
                )

        return export_result

    export_path = Path(export_result)
    return json.loads(export_path.read_text(encoding="utf-8"))

def export_house_totals_workflow(
    ctx: PackItContext,
    throttle_seconds: float = 8.0,
) -> dict[str, Any]:
    """
    Export total weight and dimensions for all rooms and boxes.

    Workflow:
        1. Resolve house + rooms
        2. Iterate all boxes
        3. Validate each box sheet
        4. Export/read box JSON payload
        5. Extract dimensions + weight
        6. Aggregate totals
        7. Write timestamped house totals JSON report
    """

    house_ref = get_house_ref(ctx)
    room_refs = get_room_refs(ctx, house_ref=house_ref)

    created_at = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")

    rooms: list[dict[str, Any]] = []

    total_boxes = 0
    total_weight_lbs = 0.0
    total_volume_cu_in = 0.0

    box_exports_read = 0
    box_exports_failed = 0

    for room_ref in room_refs:
        box_refs = get_box_refs(ctx, room_ref)

        room_boxes: list[dict[str, Any]] = []
        room_weight_lbs = 0.0
        room_volume_cu_in = 0.0

        for box_ref in box_refs:
            validation = _validate_box_sheet_with_retry(
                service_sheets=ctx.service_sheets,
                spreadsheet_id=box_ref.box_id,
                sheet_name=box_ref.box_name,
                room_folder_name=room_ref.room_folder_name,
                settings=ctx.settings,
                write_updates=False,
                base_sleep_seconds=throttle_seconds,
            )

            export_payload: dict[str, Any] = {}

            if validation.valid:
                try:
                    export_result = write_box_export_json(
                        service_sheets=ctx.service_sheets,
                        settings=ctx.settings,
                        box_ref=box_ref,
                        output_dir=ctx.settings.modules.packit.reports_root,
                    )
                    export_payload = _read_box_export_payload(export_result)
                    box_exports_read += 1
                except Exception:
                    box_exports_failed += 1
                    export_payload = {}

            length_in = _safe_float(
                _get_nested_value(
                    export_payload,
                    "length",
                    "length_in",
                    "box_length",
                    "box_length_in",
                    "length inches",
                    "length_in_inches",
                )
            )
            width_in = _safe_float(
                _get_nested_value(
                    export_payload,
                    "width",
                    "width_in",
                    "box_width",
                    "box_width_in",
                    "width inches",
                    "width_in_inches",
                )
            )
            height_in = _safe_float(
                _get_nested_value(
                    export_payload,
                    "height",
                    "height_in",
                    "box_height",
                    "box_height_in",
                    "height inches",
                    "height_in_inches",
                )
            )
            weight_lbs = _safe_float(
                _get_nested_value(
                    export_payload,
                    "weight",
                    "weight_lbs",
                    "box_weight",
                    "box_weight_lbs",
                    "weight lbs",
                    "weight_pounds",
                )
            )

            volume_cu_in = length_in * width_in * height_in
            volume_cu_ft = volume_cu_in / 1728 if volume_cu_in else 0.0

            room_weight_lbs += weight_lbs
            room_volume_cu_in += volume_cu_in

            room_boxes.append(
                {
                    "box_name": box_ref.box_name,
                    "box_number": box_ref.box_number,
                    "box_id": box_ref.box_id,
                    "is_valid": False,
                    "validation_issue_count": 0,
                    "read_failed": True,
                    "read_failed_reason": "google_sheets_rate_limit_or_transient_error",
                    "weight_lbs": 0.0,
                    "length_in": 0.0,
                    "width_in": 0.0,
                    "height_in": 0.0,
                    "volume_cu_in": 0.0,
                    "volume_cu_ft": 0.0,
                }
            )

            if throttle_seconds > 0:
                time.sleep(throttle_seconds)

        total_boxes += len(room_boxes)
        total_weight_lbs += room_weight_lbs
        total_volume_cu_in += room_volume_cu_in

        rooms.append(
            {
                "room_name": room_ref.room_name,
                "room_abbr": room_ref.room_abbr,
                "room_folder_name": room_ref.room_folder_name,
                "box_count": len(room_boxes),
                "total_weight_lbs": round(room_weight_lbs, 2),
                "total_volume_cu_in": round(room_volume_cu_in, 2),
                "total_volume_cu_ft": round(room_volume_cu_in / 1728, 2),
                "boxes": room_boxes,
            }
        )

    report = {
        "module": "packit",
        "report_type": "house_totals",
        "created_at": created_at,
        "house": {
            "house_name": house_ref.house_name,
            "house_id": house_ref.house_id,
        },
        "summary": {
            "total_rooms": len(room_refs),
            "total_boxes": total_boxes,
            "total_weight_lbs": round(total_weight_lbs, 2),
            "total_volume_cu_in": round(total_volume_cu_in, 2),
            "total_volume_cu_ft": round(total_volume_cu_in / 1728, 2),
            "box_exports_read": box_exports_read,
            "box_exports_failed": box_exports_failed,
        },
        "rooms": rooms,
    }

    output_dir = Path(ctx.settings.modules.packit.reports_root)
    output_dir.mkdir(parents=True, exist_ok=True)

    output_path = output_dir / f"packit-house-totals-{created_at}.json"
    output_path.write_text(
        json.dumps(report, indent=2, default=str),
        encoding="utf-8",
    )

    return {
        "report": report,
        "output_path": str(output_path),
    }

def validate_box_workflow(
    ctx: PackItContext,
    box_name: str,
    write_updates: bool = False,
) -> dict[str, Any]:
    """
    Validate a single box by name.

    Workflow:
        1. Resolve box by name
        2. Resolve room room
        3. Validate sheet contents / metadata
        4. Export validated box JSON
        5. Ensure QR code exists

    Returns:
        Structured result dictionary for CLI rendering.
    """

    # get box ref using the name
    # once you have a box ref, you
    # have access to everything else
    box_ref = get_box_ref_by_name(ctx, box_name)
    if not box_ref:
        raise ValueError(f"Box not found: {box_name}")
    
    # extract all of the attributes from box_ref
    box_id = box_ref.box_id
    box_number = box_ref.box_number
    room_ref = box_ref.room_ref
    room_folder_name = room_ref.room_folder_name
    room_abbr = room_ref.room_abbr
    house_ref = room_ref.house_ref
    household_name = house_ref.house_name

    #room_ref = get_box_parent_room_ref(ctx, box_ref.box_id)

    # TODO - refactor to pass only box_ref
    validation = validate_box_sheet(
        service_sheets=ctx.service_sheets,
        spreadsheet_id=box_id,
        sheet_name=box_name,
        room_folder_name=room_folder_name,
        settings=ctx.settings,
        write_updates=write_updates,
    )

    export_json = None
    if validation.valid:
        export_json = write_box_export_json(
            service_sheets=ctx.service_sheets,
            settings=ctx.settings,
            box_ref=box_ref,
            output_dir=ctx.settings.modules.packit.reports_root,
        )

    qr_filename = get_box_qrcode_filename(room_abbr, box_number)
    qr_path = Path(ctx.settings.modules.packit.qr_root) / qr_filename

    qr_created = False
    if not qr_path.exists():
        create_qrcode_for_box(
            sheet_id=box_id,
            room_abbr=room_abbr,
            room_folder_name=room_ref.room_folder_name,
            household_name=household_name,
            output_dir=ctx.settings.modules.packit.qr_root,
            box_number=box_number,
        )
        qr_created = True

    return {
        "box": box_ref,
        "room": room_ref,
        "validation": validation,
        "export_json": export_json,
        "qr_created": qr_created,
        "qr_path": str(qr_path),
    }


def validate_room_workflow(
    ctx: PackItContext,
    room_name: str | None = None,
    room_abbr: str | None = None,
    write_updates: bool = False,
) -> dict[str, Any]:
    """
    Validate all boxes in a room.

    Intended workflow:
        1. Resolve room by name and/or abbreviation
        2. List box sheets in the room
        3. Validate each box
        4. Optionally export valid boxes
        5. Optionally ensure QR codes exist
        6. Return per-box results plus summary
    """
    room_ref = get_room_ref_by_name_or_abbr(ctx, room_name=room_name, room_abbr=room_abbr)
    if not room_ref:
        raise ValueError("Room not found")

    boxes_ref = get_box_refs(ctx, room_ref)
    results: list[dict[str, Any]] = []

    for box in boxes_ref:
        result = validate_box_workflow(
            ctx=ctx,
            box_name=box.box_name,
            write_updates=write_updates,
        )
        results.append(result)
        time.sleep(2)

    valid_count = sum(1 for result in results if result["validation"].valid)
    invalid_count = len(results) - valid_count

    return {
        "room": room_ref,
        "boxes": boxes_ref,
        "results": results,
        "summary": {
            "total_boxes": len(results),
            "valid_boxes": valid_count,
            "invalid_boxes": invalid_count,
        },
    }




def validate_house_workflow(
    ctx: PackItContext,
    write_updates: bool = False,
) -> dict[str, Any]:
    """
    Validate the entire PackIt house.

    Workflow:
        1. Resolve house ref
        2. Resolve all room refs
        3. Detect duplicate room abbreviations / names
        4. Validate each room
        5. Aggregate room and box totals
    """
    house_ref = get_house_ref(ctx)
    room_refs = get_room_refs(ctx, house_ref=house_ref)

    issues: list[ValidationIssue] = []
    room_results: list[dict[str, Any]] = []

    rooms_by_abbr: dict[str, list[Any]] = defaultdict(list)
    rooms_by_name: dict[str, list[Any]] = defaultdict(list)

    for room_ref in room_refs:
        normalized_abbr = room_ref.room_abbr.strip().upper()
        normalized_name = room_ref.room_name.strip().upper()

        if normalized_abbr:
            rooms_by_abbr[normalized_abbr].append(room_ref)

        if normalized_name:
            rooms_by_name[normalized_name].append(room_ref)

        if not room_ref.room_abbr:
            issues.append(
                ValidationIssue(
                    code="ROOM_ABBR_MISSING",
                    message=f"Room has no abbreviation: {room_ref.room_folder_name}",
                    field_name="room_abbr",
                    actual=room_ref.room_folder_name,
                )
            )

        if not room_ref.room_tape:
            issues.append(
                ValidationIssue(
                    code="ROOM_TAPE_MISSING",
                    message=f"Room has no tape color: {room_ref.room_folder_name}",
                    field_name="room_tape",
                    actual=room_ref.room_folder_name,
                    severity="warning",
                )
            )

    for room_abbr, matches in rooms_by_abbr.items():
        if len(matches) > 1:
            issues.append(
                ValidationIssue(
                    code="DUPLICATE_ROOM_ABBR",
                    message=(
                        f"Duplicate room abbreviation '{room_abbr}' found in: "
                        + ", ".join(room.room_folder_name for room in matches)
                    ),
                    field_name="room_abbr",
                    expected="unique room abbreviation",
                    actual=[room.room_folder_name for room in matches],
                )
            )

    for room_name, matches in rooms_by_name.items():
        if len(matches) > 1:
            issues.append(
                ValidationIssue(
                    code="DUPLICATE_ROOM_NAME",
                    message=(
                        f"Duplicate room name '{room_name}' found in: "
                        + ", ".join(room.room_folder_name for room in matches)
                    ),
                    field_name="room_name",
                    expected="unique room name",
                    actual=[room.room_folder_name for room in matches],
                    severity="warning",
                )
            )

    total_boxes = 0
    valid_boxes = 0
    invalid_boxes = 0
    valid_rooms = 0
    invalid_rooms = 0

    for room_ref in room_refs:
        room_result = validate_room_workflow(
            ctx=ctx,
            room_name=room_ref.room_name,
            room_abbr=room_ref.room_abbr,
            write_updates=write_updates,
        )
        room_results.append(room_result)

        room_summary = room_result["summary"]
        total_boxes += room_summary["total_boxes"]
        valid_boxes += room_summary["valid_boxes"]
        invalid_boxes += room_summary["invalid_boxes"]

        if room_summary["invalid_boxes"] == 0:
            valid_rooms += 1
        else:
            invalid_rooms += 1

    is_valid = (invalid_rooms == 0) and not any(
        issue.severity == "error" for issue in issues
    )

    return {
        "house": house_ref,
        "rooms": room_refs,
        "room_results": room_results,
        "summary": {
            "total_rooms": len(room_refs),
            "valid_rooms": valid_rooms,
            "invalid_rooms": invalid_rooms,
            "total_boxes": total_boxes,
            "valid_boxes": valid_boxes,
            "invalid_boxes": invalid_boxes,
            "issues": issues,
            "is_valid": is_valid,
        },
    }

def create_room_workflow(
    ctx: PackItContext,
    room_name: str,
    room_abbr: str,
    tape_color: str,
) -> dict[str, Any]:
    """
    Create a room folder.

    Intended workflow:
        1. Build canonical room folder name
        2. Create room folder under rooms root
        3. Return created room information
    """
    created_room = create_room(
        service_drive=ctx.service_drive,
        rooms_root_id=ctx.rooms_root_id,
        room_name=room_name,
        room_abbr=room_abbr,
        tape_color=tape_color,
    )

    return {
        "created": created_room,
    }


def add_boxes_workflow(
    ctx: PackItContext,
    room_name: str | None = None,
    room_abbr: str | None = None,
    count: int = 1,
) -> dict[str, Any]:
    """
    Add one or more boxes to a room.

    Workflow:
        1. Resolve room
        2. Determine next available box numbers
        3. Create each box from template
        4. Initialize metadata / QR during creation
        5. Re-validate the room with write_updates=True
        6. Return created box results + validation summary
    """
    if count < 1:
        raise ValueError("count must be >= 1")

    room_ref = get_room_ref_by_name_or_abbr(
        ctx,
        room_name=room_name,
        room_abbr=room_abbr,
    )
    if not room_ref:
        raise ValueError("Room not found")

    existing_boxes = get_box_refs(ctx, room_ref)

    existing_numbers = [
        box.box_number
        for box in existing_boxes
        if box.box_number is not None
    ]
    start_number = max(existing_numbers, default=0) + 1

    template_id = ctx.settings.modules.packit.box.template_id
    qr_output_dir = ctx.settings.modules.packit.qr_root

    created_boxes: list[dict[str, Any]] = []

    for offset in range(count):
        box_number = start_number + offset
        box_name = f"{room_ref.room_abbr}-{box_number:02d}"

        sheet_id = create_box_sheet(
            service_drive=ctx.service_drive,
            service_sheets=ctx.service_sheets,
            template_id=template_id,
            room_folder_id=room_ref.room_id,
            box_name=box_name,
            output_dir=qr_output_dir,
        )

        created_boxes.append(
            {
                "sheet_id": sheet_id,
                "box_name": box_name,
                "box_number": box_number,
            }
        )

    validation_result = validate_room_workflow(
        ctx=ctx,
        room_name=room_ref.room_name,
        room_abbr=room_ref.room_abbr,
        write_updates=True,
    )

    return {
        "room": room_ref,
        "count_requested": count,
        "created_boxes": created_boxes,
        "validation": validation_result,
    }


def list_rooms_workflow(ctx: PackItContext) -> dict[str, Any]:
    """
    List all PackIt rooms.

    Returns:
        Structured room list suitable for CLI output.
    """
    house_ref = get_house_ref(ctx)
    rooms_ref = get_room_refs(ctx,house_ref)
    return {
        "house": house_ref,
        "rooms": rooms_ref,
        "count": len(rooms_ref),
    }
