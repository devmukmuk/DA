"""
PackIt Google Drive tree export services.

Description:
    Builds and formats a hierarchical representation of a Google Drive
    room structure, with optional box validation and QR regeneration.
"""

from __future__ import annotations

import json
from typing import Any

from mindit import __version__


FOLDER_MIME = "application/vnd.google-apps.folder"
SHEET_MIME = "application/vnd.google-apps.spreadsheet"


def parse_box_filename(file_name: str) -> tuple[str, int | None]:
    """
    Parse a box filename like:
    LR-01 → ("LR", 1)
    """

    parts = file_name.strip().split("-")

    room_abbr = parts[0].strip()
    box_number = None

    if len(parts) >= 2:
        try:
            box_number = int(parts[1])
        except ValueError:
            box_number = None

    return room_abbr, box_number




def list_files(service, parent_id: str) -> list[dict[str, Any]]:
    """
    List files and folders directly under a parent Google Drive folder.
    """
    results = []
    page_token = None

    while True:
        response = service.files().list(
            q=f"'{parent_id}' in parents and trashed=false",
            spaces="drive",
            fields="nextPageToken, files(id, name, mimeType)",
            pageToken=page_token,
        ).execute()

        results.extend(response.get("files", []))
        page_token = response.get("nextPageToken")

        if not page_token:
            break

    return results



def format_tree_txt(tree: list[dict[str, Any]], indent: int = 0) -> str:
    """
    Format the tree as readable plain text.
    """
    lines = []

    for node in tree:
        prefix = "📁" if node["type"] == "folder" else "📄"
        line = f"{'  ' * indent}{prefix} {node['name']} ({node['id']})"
        lines.append(line)

        if "validation" in node:
            validation = node["validation"]
            status = "VALID" if validation.get("valid") else "INVALID"
            lines.append(f"{'  ' * (indent + 1)}[Validation: {status}]")

            for warning in validation.get("warnings", []):
                lines.append(f"{'  ' * (indent + 2)}Warning: {warning}")

            for error in validation.get("errors", []):
                lines.append(f"{'  ' * (indent + 2)}Error: {error}")

        if "box_details" in node:
            lines.append(f"{'  ' * (indent + 1)}[Box Details Included]")

        if "box_details_error" in node:
            lines.append(
                f"{'  ' * (indent + 1)}[Box Details Error: {node['box_details_error']}]"
            )

        if node["type"] == "folder":
            lines.append(format_tree_txt(node.get("children", []), indent + 1))

    return "\n".join(part for part in lines if part)


def format_tree_json(tree: list[dict[str, Any]]) -> str:
    """
    Format the tree as JSON.
    """
    return json.dumps(tree, indent=2)
