"""PackIt room services.

Description:
    Small reusable services for PackIt room folder operations.
"""

from __future__ import annotations

from typing import Any


def build_room_folder_name(
    room_name: str,
    room_abbr: str,
    tape_color: str,
) -> str:
    """
    Build canonical PackIt room folder name.

    Example:
        DININGROOM, D, BLUE -> DININGROOM-D-BLUE
    """
    return f"{room_name.strip().upper()}-{room_abbr.strip().upper()}-{tape_color.strip().upper()}"


def create_room(
    service_drive: Any,
    rooms_root_id: str,
    room_name: str,
    room_abbr: str,
    tape_color: str,
) -> dict[str, Any]:
    """
    Create a room folder under the PackIt rooms root.

    Returns:
        Drive file resource for the created room folder.
    """
    folder_name = build_room_folder_name(
        room_name=room_name,
        room_abbr=room_abbr,
        tape_color=tape_color,
    )

    metadata = {
        "name": folder_name,
        "mimeType": "application/vnd.google-apps.folder",
        "parents": [rooms_root_id],
    }

    created = (
        service_drive.files()
        .create(
            body=metadata,
            fields="id, name, mimeType, parents",
        )
        .execute()
    )

    return created