# src/mindit/services/tagging/owners.py

"""Write camera owners into an archive's da-archive.yaml, so nobody has to edit it by hand.

The file is changed as text, not rewritten, so its notes (# lines) and layout stay as they were: a
camera's line in the `cameras:` section is replaced, or added, and the section is added at the end
when there isn't one. A copy of the old file is kept, and if the new one doesn't read back as the
same settings plus the new owners, the old one is put back.
"""

from __future__ import annotations

import json
import re
import shutil
from datetime import datetime
from pathlib import Path

import yaml

_SECTION = re.compile(r"^cameras:\s*(#.*)?$")
_TOP_LEVEL = re.compile(r"^[^\s#]")


def _line(camera: str, owner: str) -> str:
    return f"  {json.dumps(camera)}: {json.dumps(owner)}"


def _same_camera(line: str, camera: str) -> bool:
    """Return True when a cameras-section line is this camera's (quoted or not, any case)."""
    try:
        data = yaml.safe_load(line.strip())
    except yaml.YAMLError:
        return False
    return isinstance(data, dict) and any(str(k).strip().lower() == camera.strip().lower() for k in data)


def set_owners(archive_file: Path, owners: dict[str, str]) -> Path:
    """Set each camera's owner in archive_file; return the backup copy of the old file."""
    text = archive_file.read_text(encoding="utf-8")
    lines = text.splitlines()
    start = next((i for i, line in enumerate(lines) if _SECTION.match(line)), None)
    if start is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines += ["cameras:                      # who owned each camera, for owner: tags (da tag)"]
        start = len(lines) - 1
    end = next((i for i in range(start + 1, len(lines)) if _TOP_LEVEL.match(lines[i])), len(lines))
    while end > start + 1 and not lines[end - 1].strip():
        end -= 1                                        # keep the blank line before the next section

    for camera, owner in owners.items():
        at = next((i for i in range(start + 1, end) if _same_camera(lines[i], camera)), None)
        if at is not None:
            lines[at] = _line(camera, owner)
        else:
            lines.insert(end, _line(camera, owner))
            end += 1

    backup = archive_file.with_name(f"{archive_file.name}.bak-{datetime.now():%Y%m%d-%H%M%S}")
    shutil.copy2(archive_file, backup)
    archive_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    try:
        before = yaml.safe_load(text) or {}
        after = yaml.safe_load(archive_file.read_text(encoding="utf-8")) or {}
        expected = {**(before.get("cameras") or {}), **owners}
        ok = ({k: v for k, v in after.items() if k != "cameras"} == {k: v for k, v in before.items() if k != "cameras"}
              and all(after.get("cameras", {}).get(k) == v for k, v in owners.items())
              and len(after.get("cameras") or {}) <= len(expected))
    except yaml.YAMLError:
        ok = False
    if not ok:
        shutil.copy2(backup, archive_file)
        raise RuntimeError(f"Couldn't update {archive_file} safely; it's unchanged. Add the owners by hand.")
    return backup
