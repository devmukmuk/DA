"""Tags: camera details read from photos, automatic tags made from them, and your own tags."""
