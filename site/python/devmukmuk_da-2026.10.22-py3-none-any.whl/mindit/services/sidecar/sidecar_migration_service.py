# src/mindit/services/sidecar/sidecar_migration_service.py

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mindit.services.sidecar.sidecar_service import SidecarService


class SidecarMigrationService:
    """Normalize existing DA sidecar files."""

    def normalize_folder(
        self,
        folder: Path,
        recursive: bool = True,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        folder = folder.expanduser().resolve()

        if not folder.exists():
            raise FileNotFoundError(f"Folder not found: {folder}")

        pattern = "**/*.meta.json" if recursive else "*.meta.json"

        sidecars_found = 0
        normalized_count = 0
        skipped_count = 0
        error_count = 0
        actions: list[dict[str, Any]] = []

        for sidecar_path in sorted(folder.glob(pattern)):
            if not sidecar_path.is_file():
                continue

            sidecars_found += 1
            file_path = self.file_path_for_sidecar(sidecar_path)

            action: dict[str, Any] = {
                "sidecar_path": str(sidecar_path),
                "file_path": str(file_path),
                "dry_run": dry_run,
            }

            try:
                raw_payload = self._read_json(sidecar_path)
                normalized = SidecarService.normalize_data(file_path, raw_payload)

                changed = raw_payload != normalized

                action["changed"] = changed

                if changed:
                    normalized_count += 1

                    if not dry_run:
                        SidecarService.save(file_path, normalized)
                        action["status"] = "normalized"

                        SidecarService.append_history_event(
                            file_path=file_path,
                            event="sidecar_normalized",
                            module="sidecar",
                            details={
                                "sidecar_path": str(sidecar_path),
                            },
                        )

                    else:
                        action["status"] = "would_normalize"
                else:
                    skipped_count += 1
                    action["status"] = "skipped"

            except Exception as exc:  # pylint: disable=broad-except
                error_count += 1
                action["status"] = "error"
                action["error"] = str(exc)

            actions.append(action)

        return {
            "folder": str(folder),
            "recursive": recursive,
            "dry_run": dry_run,
            "sidecars_found": sidecars_found,
            "normalized": normalized_count,
            "skipped": skipped_count,
            "errors": error_count,
            "actions": actions,
        }

    @staticmethod
    def file_path_for_sidecar(sidecar_path: Path) -> Path:
        name = sidecar_path.name

        if not name.endswith(".meta.json"):
            raise ValueError(f"Not a DA sidecar path: {sidecar_path}")

        file_name = name.removesuffix(".meta.json")
        return sidecar_path.with_name(file_name)

    @staticmethod
    def _read_json(path: Path) -> dict[str, Any]:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {}

        if not isinstance(payload, dict):
            return {}

        return payload
