# src/mindit/services/sidecar/sidecar_schema.py

from __future__ import annotations

from copy import deepcopy
from typing import Any


SIDECAR_SCHEMA_NAME = "mindit.sidecar"
SIDECAR_SCHEMA_VERSION = 1


DEFAULT_SIDECAR: dict[str, Any] = {
    "schema": {
        "name": SIDECAR_SCHEMA_NAME,
        "version": SIDECAR_SCHEMA_VERSION,
    },
    "file": {
        "source_path": None,
        "current_path": None,
        "file_name": None,
        "extension": None,
        "size_bytes": None,
        "created_at": None,
        "modified_at": None,
        "sha256": None,
    },
    "classification": {
        "module": None,
        "media_type": None,
        "status": "active",
    },
    "photoit": {
        "captured_at": None,
        "original_file_name": None,
        "exif": {},
        "gps": {},
        "tags": [],
    },
    "scanit": {
        "document_date": None,
        "document_type": None,
        "ocr_status": None,
        "tags": [],
    },
    "validation": {
        "checked_at": None,
        "status": None,
        "problem_count": 0,
        "problems": [],
    },
    "quarantine": {
        "hash_status": "missing",
        "duplicate_status": "unknown",
        "duplicate_group_id": None,
        "duplicate_of": None,
        "duplicate_paths": [],
        "checked_at": None,
    },
    "history": [],
}


def default_sidecar() -> dict[str, Any]:
    return deepcopy(DEFAULT_SIDECAR)