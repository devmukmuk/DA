# src/mindit/services/sidecar/sidecar_service.py

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.sidecar.sidecar_schema import (
    SIDECAR_SCHEMA_NAME,
    SIDECAR_SCHEMA_VERSION,
    default_sidecar,
)
from mindit.utils.timestamps import safe_iso_timestamp


class SidecarService:
    @staticmethod
    def sidecar_path_for(file_path: Path) -> Path:
        return file_path.with_name(f"{file_path.name}.meta.json")

    @staticmethod
    def load(file_path: Path) -> dict[str, Any]:
        sidecar_path = SidecarService.sidecar_path_for(file_path)

        if not sidecar_path.exists():
            return default_sidecar()

        try:
            data = json.loads(sidecar_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            data = {}

        if not isinstance(data, dict):
            data = {}

        return SidecarService.normalize_data(file_path, data)

    @staticmethod
    def save(file_path: Path, data: dict[str, Any]) -> None:
        sidecar_path = SidecarService.sidecar_path_for(file_path)
        sidecar_path.parent.mkdir(parents=True, exist_ok=True)

        normalized = SidecarService.normalize_data(file_path, data)

        sidecar_path.write_text(
            json.dumps(normalized, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    @staticmethod
    def normalize_file(file_path: Path, module: str | None = None) -> dict[str, Any]:
        data = SidecarService.load(file_path)

        if module:
            data["classification"]["module"] = module

        if file_path.exists():
            stat = file_path.stat()
            data["file"]["current_path"] = str(file_path)
            data["file"]["file_name"] = file_path.name
            data["file"]["extension"] = file_path.suffix.lower()
            data["file"]["size_bytes"] = stat.st_size
            data["file"]["modified_at"] = safe_iso_timestamp(stat.st_mtime)

        SidecarService.save(file_path, data)
        return data

    @staticmethod
    def normalize_data(file_path: Path, existing: dict[str, Any]) -> dict[str, Any]:
        normalized = default_sidecar()
        SidecarService._deep_merge(normalized, existing)

        normalized["schema"]["name"] = SIDECAR_SCHEMA_NAME
        normalized["schema"]["version"] = SIDECAR_SCHEMA_VERSION

        # Preserve older top-level fields by mapping them into the standard shape.
        if existing.get("sha256") and not normalized["file"].get("sha256"):
            normalized["file"]["sha256"] = existing["sha256"]

        if existing.get("hash_sha256") and not normalized["file"].get("sha256"):
            normalized["file"]["sha256"] = existing["hash_sha256"]

        quarantine = existing.get("quarantine")
        if isinstance(quarantine, dict):
            if quarantine.get("hash_sha256") and not normalized["file"].get("sha256"):
                normalized["file"]["sha256"] = quarantine["hash_sha256"]

        if existing.get("current_path") and not normalized["file"].get("current_path"):
            normalized["file"]["current_path"] = existing["current_path"]

        if existing.get("source_path") and not normalized["file"].get("source_path"):
            normalized["file"]["source_path"] = existing["source_path"]

        if file_path.exists():
            stat = file_path.stat()
            normalized["file"]["current_path"] = str(file_path)
            normalized["file"]["file_name"] = file_path.name
            normalized["file"]["extension"] = file_path.suffix.lower()
            normalized["file"]["size_bytes"] = stat.st_size
            normalized["file"]["modified_at"] = safe_iso_timestamp(stat.st_mtime)
            
            
        # Preserve legacy PhotoIt fields by mapping them into the photoit block.
        if existing.get("captured_at") and not normalized["photoit"].get("captured_at"):
            normalized["photoit"]["captured_at"] = existing["captured_at"]

        if (
            existing.get("original_file_name")
            and not normalized["photoit"].get("original_file_name")
        ):
            normalized["photoit"]["original_file_name"] = existing["original_file_name"]

        if existing.get("tags") and not normalized["photoit"].get("tags"):
            normalized["photoit"]["tags"] = existing["tags"]

        if existing.get("gps") and not normalized["photoit"].get("gps"):
            normalized["photoit"]["gps"] = existing["gps"]

        if existing.get("dimensions") and not normalized["photoit"].get("dimensions"):
            normalized["photoit"]["dimensions"] = existing["dimensions"]

        if existing.get("mime_type") and not normalized["photoit"].get("mime_type"):
            normalized["photoit"]["mime_type"] = existing["mime_type"]

        # Preserve legacy ScanIt meta_ref fields by mapping them into scanit.
        meta_ref = existing.get("meta_ref")
        if isinstance(meta_ref, dict):
            if not normalized["scanit"].get("meta_ref"):
                normalized["scanit"]["meta_ref"] = meta_ref

            if meta_ref.get("scanned_at") and not normalized["scanit"].get("scanned_at"):
                normalized["scanit"]["scanned_at"] = meta_ref["scanned_at"]

            if (
                meta_ref.get("original_folder")
                and not normalized["scanit"].get("original_folder")
            ):
                normalized["scanit"]["original_folder"] = meta_ref["original_folder"]

            if (
                meta_ref.get("original_filename")
                and not normalized["scanit"].get("original_filename")
            ):
                normalized["scanit"]["original_filename"] = meta_ref["original_filename"]        

        return normalized

    @staticmethod
    def extract_sha256(data: dict[str, Any]) -> str | None:
        file_block = data.get("file", {})
        quarantine_block = data.get("quarantine", {})

        if isinstance(file_block, dict) and file_block.get("sha256"):
            return file_block["sha256"]

        if data.get("sha256"):
            return data["sha256"]

        if data.get("hash_sha256"):
            return data["hash_sha256"]

        if isinstance(quarantine_block, dict) and quarantine_block.get("hash_sha256"):
            return quarantine_block["hash_sha256"]

        return None
    
    @staticmethod
    def load_sidecar_path(sidecar_path: Path) -> dict[str, Any] | None:
        try:
            data = json.loads(sidecar_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None

        if not isinstance(data, dict):
            return None

        return data

    @staticmethod
    def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> None:
        for key, value in overlay.items():
            if (
                key in base
                and isinstance(base[key], dict)
                and isinstance(value, dict)
            ):
                SidecarService._deep_merge(base[key], value)
            else:
                base[key] = value


    @staticmethod
    def update_block(
        file_path: Path,
        block_name: str,
        block_data: dict[str, Any],
    ) -> dict[str, Any]:
        data = SidecarService.load(file_path)
        data[block_name] = block_data
        SidecarService.save(file_path, data)
        return data

    @staticmethod
    def get_block(
        file_path: Path,
        block_name: str,
    ) -> dict[str, Any]:
        data = SidecarService.load(file_path)
        value = data.get(block_name)

        if isinstance(value, dict):
            return value

        return {}
    
    @staticmethod
    def update_file_block(
        file_path: Path,
        file_data: dict[str, Any],
    ) -> dict[str, Any]:
        data = SidecarService.load(file_path)

        data["file"].update(file_data)

        SidecarService.save(file_path, data)
        return data

    @staticmethod
    def update_quarantine_block(
        file_path: Path,
        quarantine_data: dict[str, Any],
    ) -> dict[str, Any]:
        data = SidecarService.load(file_path)

        data["quarantine"].update(quarantine_data)

        SidecarService.save(file_path, data)
        return data

    @staticmethod
    def extract_hash_status(data: dict[str, Any]) -> str | None:
        quarantine = data.get("quarantine", {})

        if isinstance(quarantine, dict):
            value = quarantine.get("hash_status")
            if isinstance(value, str):
                return value

        return None

    @staticmethod
    def extract_duplicate_status(data: dict[str, Any]) -> str | None:
        quarantine = data.get("quarantine", {})

        if isinstance(quarantine, dict):
            value = quarantine.get("duplicate_status")
            if isinstance(value, str):
                return value

        return None

    @staticmethod
    def append_history_event(
        file_path: Path,
        event: str,
        module: str,
        details: dict[str, Any] | None = None,
        timestamp: str | None = None,
    ) -> dict[str, Any]:
        data = SidecarService.load(file_path)

        history = data.get("history")
        if not isinstance(history, list):
            history = []

        history.append(
            {
                "event": event,
                "module": module,
                "timestamp": timestamp
                or datetime.now().isoformat(timespec="seconds"),
                "details": details or {},
            }
        )

        data["history"] = history

        SidecarService.save(file_path, data)
        return data

    @staticmethod
    def get_history(file_path: Path) -> list[dict[str, Any]]:
        data = SidecarService.load(file_path)
        history = data.get("history")

        if not isinstance(history, list):
            return []

        return [item for item in history if isinstance(item, dict)]