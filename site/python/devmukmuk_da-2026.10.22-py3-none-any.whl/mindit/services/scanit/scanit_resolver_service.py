# src/mindit/services/scanit_resolver_service.py

from __future__ import annotations

import json
from pathlib import Path

from mindit.models.scanit_refs import MetaRef, ScannerRef


def _as_str(payload: dict, *keys: str) -> str:
    """Return the first matching value as a string."""
    for key in keys:
        value = payload.get(key)
        if value is not None:
            return str(value)
    return ""


def _as_int(payload: dict, *keys: str) -> int:
    """Return the first matching value as an int."""
    for key in keys:
        value = payload.get(key)
        if value is None or value == "":
            continue
        try:
            return int(value)
        except (TypeError, ValueError):
            try:
                return int(float(value))
            except (TypeError, ValueError):
                pass
    return 0


def _normalize_meta_payload(raw_payload: dict) -> dict:
    """
    Normalize common sidecar JSON shapes into one flat dictionary.
    """
    if not isinstance(raw_payload, dict):
        return {}

    for nested_key in ("meta_ref", "meta", "metadata", "document", "doc"):
        nested = raw_payload.get(nested_key)
        if isinstance(nested, dict):
            merged = dict(raw_payload)
            merged.update(nested)
            return merged

    return raw_payload


def _build_meta_ref(meta_path: Path, raw_payload: dict) -> MetaRef:
    """Build MetaRef from a possibly nested payload."""
    meta_payload = _normalize_meta_payload(raw_payload)

    return MetaRef(
        metadata_file=_as_str(meta_payload, "metadata_file") or str(meta_path.resolve()),
        file_extension=_as_str(meta_payload, "file_extension", "extension", "ext"),
        file_size=_as_int(meta_payload, "file_size", "size", "bytes"),
        created_at=_as_str(meta_payload, "created_at", "created", "created_on"),
        modified_at=_as_str(meta_payload, "modified_at", "modified", "updated_at"),
        scanned_at=_as_str(meta_payload, "scanned_at", "scan_date", "scanned_on"),
        original_folder=_as_str(meta_payload, "original_folder", "source_folder"),
        original_filename=_as_str(meta_payload, "original_filename", "source_filename"),
        current_folder=_as_str(meta_payload, "current_folder", "folder"),
        current_filename=_as_str(
            meta_payload,
            "current_filename",
            "filename",
            "file_name",
        ),
    )


def _try_load_meta_file(meta_path: Path) -> MetaRef | None:
    """Try to load one candidate metadata sidecar file."""
    if not meta_path.exists() or not meta_path.is_file():
        return None

    try:
        raw_payload = json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:
        return None

    if not isinstance(raw_payload, dict):
        return None

    return _build_meta_ref(meta_path, raw_payload)


def get_meta_ref(scanner_ref: ScannerRef) -> MetaRef | None:
    """
    Resolve the paired meta-json sidecar for a scanned document.
    """
    doc_path = Path(scanner_ref.doc_id)
    folder = doc_path.parent
    stem = doc_path.stem
    name = doc_path.name

    candidates = [
        doc_path.with_name(f"{name}.meta.json"),      # file.pdf.meta.json
        doc_path.with_suffix(".json"),                # file.json
        doc_path.with_name(f"{stem}.meta.json"),      # file.meta.json
        doc_path.with_name(f"{name}.json"),           # file.pdf.json
        doc_path.with_name(f"{stem}_metadata.json"),
        doc_path.with_name(f"{stem}-metadata.json"),
    ]

    for candidate in candidates:
        meta_ref = _try_load_meta_file(candidate)
        if meta_ref is not None:
            return meta_ref

    for candidate in sorted(folder.glob(f"{name}*.json")):
        meta_ref = _try_load_meta_file(candidate)
        if meta_ref is not None:
            return meta_ref

    return None

def load_sidecar_payload(scanner_ref: ScannerRef) -> dict | None:
    """Load the paired sidecar JSON payload for a scanned document."""
    doc_path = Path(scanner_ref.doc_id)
    folder = doc_path.parent
    stem = doc_path.stem
    name = doc_path.name

    candidates = [
        doc_path.with_name(f"{name}.meta.json"),
        doc_path.with_suffix(".json"),
        doc_path.with_name(f"{stem}.meta.json"),
        doc_path.with_name(f"{name}.json"),
        doc_path.with_name(f"{stem}_metadata.json"),
        doc_path.with_name(f"{stem}-metadata.json"),
    ]

    for candidate in candidates:
        if not candidate.exists() or not candidate.is_file():
            continue
        try:
            payload = json.loads(candidate.read_text(encoding="utf-8"))
        except Exception:
            continue
        if isinstance(payload, dict):
            return payload

    for candidate in sorted(folder.glob(f"{name}*.json")):
        if not candidate.exists() or not candidate.is_file():
            continue
        try:
            payload = json.loads(candidate.read_text(encoding="utf-8"))
        except Exception:
            continue
        if isinstance(payload, dict):
            return payload

    return None