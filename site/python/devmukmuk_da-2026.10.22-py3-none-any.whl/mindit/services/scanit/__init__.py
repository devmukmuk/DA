"""ScanIt services.

Description:
    High-level ScanIt workflows built from smaller reusable service functions.

Design:
    This module should contain orchestration logic only. Each workflow should:
    - accept a shared ScanItContext
    - call smaller resolver / validation / export / QR services
    - return structured data
    - avoid printing directly

Layering:
    1. Context layer
        - build_scanit_context()
        - ScanItContext

    2. Resolver layer
        - resolve_scan_metadata()
        - determine_scan_movements()    

    3. Primitive service layer
        - move_scan_file()
        - rename_scan_file()
        - extract_scan_metadata()
        - create_scan_qrcode()

    4. Workflow layer
        - scan_documents_workflow()
        - move_scans_workflow()
        - rename_scans_workflow()
        - create_scan_metadata_workflow()
        - quarantine_problematic_scans_workflow()
        - remove_empty_folders_workflow()
"""
