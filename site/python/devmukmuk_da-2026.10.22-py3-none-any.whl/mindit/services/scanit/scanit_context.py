"""ScanIt context and initialization helpers.

Description:
    Provides a shared context object used across ScanIt services and workflows.
    This centralizes:
        - settings

Design:
    - Built once per CLI command
    - Passed into all services/workflows    
    - Avoids repeated setup logic across modules
    
"""

from __future__ import annotations

from dataclasses import dataclass

from mindit.config.settings import load_settings, AppSettings



@dataclass
class ScanItContext:
    """Shared ScanIt execution context."""

    settings: AppSettings



def build_context() -> ScanItContext:
    """
    Build a ScanItContext.


    Returns:
        Fully initialized ScanItContext
    """
    settings = load_settings()


    return ScanItContext(
        settings=settings,

    )
