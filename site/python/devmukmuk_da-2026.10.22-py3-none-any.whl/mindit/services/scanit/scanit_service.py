"""Scanner service."""
# src/mindit/services/scanner_service.py

from __future__ import annotations

import hashlib
import json
import shutil
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from mindit.models.scanit_refs import MetaRef, ScannerRef
from mindit.models.scanit_validation import (
    ensure_folder_exists,
    get_default_metadata_path,
    is_allowed_document,
    normalize_extensions,
)
from mindit.utils.file_utils import (
    remove_empty_folders_workflow, 
)
from mindit.services.scanit.scanit_resolver_service import (
    get_meta_ref,
    load_sidecar_payload
)
from mindit.config.settings import load_settings
from mindit.services.sidecar import SidecarService
from mindit.utils.timestamps import UNREADABLE_FILE_TIME, safe_fromtimestamp, safe_iso_timestamp

# Adjust these imports to match your actual config module layout.
# These are written as a likely pattern based on the DA project structure.
settings = load_settings()


class ScannerServiceError(Exception):
    """Base scanner service error."""


class ScannerService:
    """Basic document scanning workflow service."""

    def get_doc_refs_from_folder(
        self,
        folder: str | Path,
        file_filter: list[str] | None = None,
    ) -> list[ScannerRef]:
        """
        Build document references from a folder.

        Args:
            folder: Folder to scan.
            file_filter: Optional list of allowed extensions.

        Returns:
            List of ScannerRef objects.
        """
        folder_path = Path(folder).expanduser().resolve()
        ensure_folder_exists(folder_path)

        normalized_filter = normalize_extensions(file_filter)

        refs: list[ScannerRef] = []

        for file_path in sorted(folder_path.rglob("*")):
            if not file_path.is_file():
                continue

            if not is_allowed_document(file_path, normalized_filter):
                continue

            scanner_ref = ScannerRef(
                doc_id=str(file_path.resolve()),
                doc_name=file_path.name,
                location_folder=str(file_path.parent.resolve()),
                hash="",
                meta_ref=None,
            )

            # load sidecar payload (for hash)
            sidecar_payload = load_sidecar_payload(scanner_ref)
            if sidecar_payload:
                sidecar_hash = SidecarService.extract_sha256(sidecar_payload)
                if sidecar_hash:
                    scanner_ref.hash = sidecar_hash
                else:
                    scanit = sidecar_payload.get("scanit", {})
                    if isinstance(scanit, dict):
                        scanner_ref.hash = str(scanit.get("hash", ""))

            # load meta_ref
            scanner_ref.meta_ref = get_meta_ref(scanner_ref)

            # 🔑 THIS WAS MISSING
            refs.append(scanner_ref)

        return refs

    @staticmethod
    def _get_scanit_block(payload: dict) -> dict:
        scanit = payload.get("scanit")
        if isinstance(scanit, dict):
            return scanit

        meta_ref = payload.get("meta_ref")
        if isinstance(meta_ref, dict):
            return meta_ref

        return payload

    def create_metadata(self, scanner_ref: ScannerRef, write: bool = True) -> MetaRef:
        """
        Create metadata for a document and optionally write sidecar JSON.

        Args:
            scanner_ref: Document reference.
            write: Whether to write sidecar metadata file.

        Returns:
            MetaRef
        """
        file_path = Path(scanner_ref.doc_id)
        stat = file_path.stat()

        metadata_file = get_default_metadata_path(file_path)
        existing_meta = self._read_existing_meta(file_path)

        original_folder = existing_meta.get("original_folder") or str(file_path.parent.resolve())
        original_filename = existing_meta.get("original_filename") or file_path.name

        meta_ref = MetaRef(
            metadata_file=str(metadata_file),
            file_extension=file_path.suffix.lower(),
            file_size=stat.st_size,
            created_at=self._safe_timestamp(stat.st_ctime),
            modified_at=self._safe_timestamp(stat.st_mtime),
            scanned_at=existing_meta.get(
                "scanned_at",
                datetime.now().isoformat(timespec="seconds"),
            ),
            original_folder=original_folder,
            original_filename=original_filename,
            current_folder=str(file_path.parent.resolve()),
            current_filename=file_path.name,
        )

        scanner_ref.meta_ref = meta_ref

        if write:
            self._write_metadata_file(scanner_ref)

        return meta_ref

    def create_hash(self, scanner_ref: ScannerRef, write: bool = True) -> ScannerRef:
        """
        Create SHA-256 hash for a document and optionally write metadata.
        """
        file_path = Path(scanner_ref.doc_id)
        if not file_path.exists():
            raise ScannerServiceError(f"File not found: {file_path}")

        scanner_ref.hash = self._sha256_for_file(file_path)

        if scanner_ref.meta_ref is None:
            self.create_metadata(scanner_ref, write=False)

        if write:
            self._write_metadata_file(scanner_ref)

        return scanner_ref

    def show_duplicates(
        self,
        folder: str | Path,
        output_file: str | Path = "output/scanit_duplicates.json",
        file_filter: list[str] | None = None,
    ) -> dict:
        """
        Scan a folder, hash files, and output duplicate groups as JSON.
        """
        refs = self.get_doc_refs_from_folder(folder=folder, file_filter=file_filter)

        by_hash: dict[str, list[ScannerRef]] = defaultdict(list)
        for ref in refs:
            self.create_metadata(ref, write=True)
            self.create_hash(ref, write=True)

            if ref.hash:
                by_hash[ref.hash].append(ref)

        duplicate_groups = []
        duplicate_file_count = 0

        for file_hash, group in sorted(
            by_hash.items(),
            key=lambda item: len(item[1]),
            reverse=True
            ):
            if len(group) < 2:
                continue

            duplicate_file_count += len(group)
            duplicate_groups.append(
                {
                    "hash": file_hash,
                    "count": len(group),
                    "documents": [ref.to_dict() for ref in group],
                }
            )

        report = {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "folder": str(Path(folder).expanduser().resolve()),
            "total_documents": len(refs),
            "duplicate_group_count": len(duplicate_groups),
            "duplicate_file_count": duplicate_file_count,
            "duplicate_groups": duplicate_groups,
        }

        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

        return report

    def rename_docs(
        self,
        source_folder: str | Path,
        destination_folder: str | Path,
        file_filter: list[str] | None = None,
    ) -> list[dict]:
        """
        Rename documents using modified_at:
            Document_YYYYMMDDTHHMMSS.ext

        Also renames/moves the sidecar JSON file.
        """
        refs = self.get_doc_refs_from_folder(folder=source_folder, file_filter=file_filter)
        destination_path = Path(destination_folder).expanduser().resolve()
        destination_path.mkdir(parents=True, exist_ok=True)

        results: list[dict] = []

        for ref in refs:
            self.create_metadata(ref, write=True)
            self.create_hash(ref, write=True)

            file_path = Path(ref.doc_id)
            old_meta_path = get_default_metadata_path(file_path)

            modified_dt = self._get_ref_modified_datetime(ref)
            new_name = self._build_document_filename(modified_dt, file_path.suffix.lower())

            new_doc_path = self._unique_path(destination_path / new_name)
            new_meta_path = get_default_metadata_path(new_doc_path)

            shutil.move(str(file_path), str(new_doc_path))

            if old_meta_path.exists():
                shutil.move(str(old_meta_path), str(new_meta_path))

            updated_ref = ScannerRef(
                doc_id=str(new_doc_path.resolve()),
                doc_name=new_doc_path.name,
                location_folder=str(new_doc_path.parent.resolve()),
                hash=ref.hash,
                meta_ref=None,
            )
            self.create_metadata(updated_ref, write=True)
            self.create_hash(updated_ref, write=True)

            results.append(
                {
                    "old_doc": str(file_path),
                    "new_doc": str(new_doc_path),
                    "old_meta": str(old_meta_path),
                    "new_meta": str(new_meta_path),
                }
            )

        return results

    def move_docs(
        self,
        source_folder: str | Path,
        destination_folder: str | Path,
        file_filter: list[str] | None = None,
    ) -> list[dict]:
        """
        Move documents into:
            <destination>/YYYY/YYYY-MM scans/Document_YYYYMMDDTHHMMSS.ext

        Also moves sidecar JSON files and updates metadata.
        """
        refs = self.get_doc_refs_from_folder(folder=source_folder, file_filter=file_filter)
        destination_root = Path(destination_folder).expanduser().resolve()
        destination_root.mkdir(parents=True, exist_ok=True)

        results: list[dict] = []

        for ref in refs:
            self.create_metadata(ref, write=True)
            self.create_hash(ref, write=True)

            file_path = Path(ref.doc_id)
            old_meta_path = get_default_metadata_path(file_path)

            modified_dt = self._get_ref_modified_datetime(ref)

            year_folder = modified_dt.strftime("%Y")
            month_folder = modified_dt.strftime("%Y-%m scans")

            target_folder = destination_root / year_folder / month_folder
            target_folder.mkdir(parents=True, exist_ok=True)

            new_name = self._build_document_filename(modified_dt, file_path.suffix.lower())
            new_doc_path = self._unique_path(target_folder / new_name)
            new_meta_path = get_default_metadata_path(new_doc_path)

            shutil.move(str(file_path), str(new_doc_path))

            if old_meta_path.exists():
                shutil.move(str(old_meta_path), str(new_meta_path))

            updated_ref = ScannerRef(
                doc_id=str(new_doc_path.resolve()),
                doc_name=new_doc_path.name,
                location_folder=str(new_doc_path.parent.resolve()),
                hash=ref.hash,
                meta_ref=None,
            )
            self.create_metadata(updated_ref, write=True)
            self.create_hash(updated_ref, write=True)

            results.append(
                {
                    "old_doc": str(file_path),
                    "new_doc": str(new_doc_path),
                    "old_meta": str(old_meta_path),
                    "new_meta": str(new_meta_path),
                }
            )

        return results

    def _build_document_filename(self, modified_dt: datetime, extension: str) -> str:
        """
        Build:
            Document_YYYYMMDDTHHMMSS.ext

        Uses config general.datetime_format when available, but normalizes it
        into a filename-safe compact form.
        """
        dt_text = self._format_datetime_for_filename(modified_dt)
        return f"Document_{dt_text}{extension}"

    def _format_datetime_for_filename(self, dt_value: datetime) -> str:
        """
        Preferred format:
            YYYYMMDDTHHMMSS

        If config general.datetime_format exists, use it first, then normalize.
        """
        format_string = self._get_datetime_format()

        try:
            raw_text = dt_value.strftime(format_string)
        except ValueError:
            raw_text = dt_value.strftime("%Y%m%dT%H%M%S")

        normalized = self._normalize_datetime_filename(raw_text)

        if not normalized:
            normalized = dt_value.strftime("%Y%m%dT%H%M%S")

        return normalized

    def _get_datetime_format(self) -> str:
        """
        Read general.datetime_format from config if available.

        Fallback:
            %Y%m%dT%H%M%S
        """
        default_format = "%Y%m%dT%H%M%S"

        try:
            scanner_settings = load_settings()
            ##print(f"date_format: {scanner_settings.general.datetime_format}")
            return scanner_settings.general.datetime_format or default_format
        except Exception:  # pragma: no cover
            return default_format

    @staticmethod
    def _normalize_datetime_filename(value: str) -> str:
        """
        Turn common datetime outputs into a compact filename-safe value.

        Examples:
            260326_142530 -> 260326T142530
            2026-03-26 14:25:30 -> 20260326T142530
            20260326T142530 -> 20260326T142530
        """
        cleaned = value.strip()

        cleaned = cleaned.replace(" ", "T")
        cleaned = cleaned.replace("_", "T")
        cleaned = cleaned.replace(":", "")
        cleaned = cleaned.replace("-", "")
        cleaned = cleaned.replace("/", "")

        # collapse repeated T if any
        while "TT" in cleaned:
            cleaned = cleaned.replace("TT", "T")

        return cleaned

    def _get_ref_modified_datetime(self, ref: ScannerRef) -> datetime:
        """
        Use meta_ref.modified_at when available; otherwise file stat mtime.
        """
        if ref.meta_ref is not None and ref.meta_ref.modified_at:
            try:
                return datetime.fromisoformat(ref.meta_ref.modified_at)
            except ValueError:
                pass

        file_path = Path(ref.doc_id)
        return safe_fromtimestamp(file_path.stat().st_mtime) or UNREADABLE_FILE_TIME

    @staticmethod
    def _safe_timestamp(timestamp_value: float) -> str:
        """Convert timestamp to ISO string."""
        return safe_iso_timestamp(timestamp_value) or ""

    @staticmethod
    def _sha256_for_file(file_path: Path, chunk_size: int = 1024 * 1024) -> str:
        """Create SHA-256 hash for a file."""
        digest = hashlib.sha256()
        with file_path.open("rb") as handle:
            while True:
                chunk = handle.read(chunk_size)
                if not chunk:
                    break
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _write_metadata_file(scanner_ref: ScannerRef) -> None:
        """Write standardized ScanIt sidecar metadata."""
        if scanner_ref.meta_ref is None:
            raise ScannerServiceError("Cannot write metadata file without meta_ref.")

        file_path = Path(scanner_ref.doc_id)

        scanit_block = {
            "doc_id": scanner_ref.doc_id,
            "doc_name": scanner_ref.doc_name,
            "location_folder": scanner_ref.location_folder,
            "hash": scanner_ref.hash,
            "meta_ref": scanner_ref.meta_ref.to_dict(),
            "scanned_at": scanner_ref.meta_ref.scanned_at,
            "original_folder": scanner_ref.meta_ref.original_folder,
            "original_filename": scanner_ref.meta_ref.original_filename,
            "current_folder": scanner_ref.meta_ref.current_folder,
            "current_filename": scanner_ref.meta_ref.current_filename,
            "document_type": None,
            "ocr_status": None,
            "tags": [],
        }

        data = SidecarService.load(file_path)

        data["file"].update(
            {
                "source_path": scanner_ref.meta_ref.original_folder,
                "current_path": scanner_ref.doc_id,
                "file_name": scanner_ref.doc_name,
                "extension": scanner_ref.meta_ref.file_extension,
                "size_bytes": scanner_ref.meta_ref.file_size,
                "created_at": scanner_ref.meta_ref.created_at,
                "modified_at": scanner_ref.meta_ref.modified_at,
                "sha256": scanner_ref.hash,
            }
        )

        data["classification"].update(
            {
                "module": "scanit",
                "media_type": "document",
                "status": "active",
            }
        )

        data["scanit"] = scanit_block

        SidecarService.save(file_path, data)

    @staticmethod
    def _read_existing_meta(file_path: Path) -> dict:
        """Read existing ScanIt metadata sidecar if present."""
        metadata_path = SidecarService.sidecar_path_for(file_path)

        if not metadata_path.exists():
            return {}

        try:
            raw_payload = json.loads(metadata_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            raw_payload = {}

        try:
            payload = SidecarService.load(file_path)
        except OSError:
            payload = {}

        raw_meta_ref = raw_payload.get("meta_ref", {})
        if not isinstance(raw_meta_ref, dict):
            raw_meta_ref = {}

        scanit = payload.get("scanit", {})
        if not isinstance(scanit, dict):
            scanit = {}

        scanit_meta_ref = scanit.get("meta_ref", {})
        if not isinstance(scanit_meta_ref, dict):
            scanit_meta_ref = {}

        return {
            "scanned_at": (
                scanit.get("scanned_at")
                or scanit_meta_ref.get("scanned_at")
                or raw_meta_ref.get("scanned_at")
            ),
            "original_folder": (
                scanit.get("original_folder")
                or scanit_meta_ref.get("original_folder")
                or raw_meta_ref.get("original_folder")
            ),
            "original_filename": (
                scanit.get("original_filename")
                or scanit_meta_ref.get("original_filename")
                or raw_meta_ref.get("original_filename")
            ),
        }

    @staticmethod
    def _unique_path(target_path: Path) -> Path:
        """
        Return a unique path if target already exists.
        """
        if not target_path.exists():
            return target_path

        stem = target_path.stem
        suffix = target_path.suffix
        parent = target_path.parent

        index = 2
        while True:
            candidate = parent / f"{stem}_{index}{suffix}"
            if not candidate.exists():
                return candidate
            index += 1

    def remove_empty_folders(
        self, 
        folder: str | Path,
        dry_run: bool = False,
    ) -> dict:
        """
        Remove empty folders within the specified folder.

        Returns a report of removed folders.
        """
        folder_path = Path(folder).expanduser().resolve()
        ensure_folder_exists(folder_path)

        removed_folders = remove_empty_folders_workflow(str(folder_path), dry_run=dry_run)

        report = {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "folder": str(folder_path),
            "removed_folder_count": len(removed_folders),
            "removed_folders": [str(path) for path in removed_folders],
        }

        return report

    def remove_duplicates(
        self,
        duplicate_report_file: str | Path,
        dry_run: bool = True,
        quarantine_folder: str | Path | None = None,
    ) -> dict:
        """
        Remove or quarantine duplicate files listed in a duplicate report.

        Rules:
        - keep the first document in each duplicate group
        - process only the remaining documents in the group
        - remove or quarantine both the document and its sidecar metadata
        """
        report_path = Path(duplicate_report_file).expanduser().resolve()
        if not report_path.exists():
            raise ScannerServiceError(f"Duplicate report file not found: {report_path}")

        try:
            report = json.loads(report_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ScannerServiceError(
                f"Invalid duplicate report JSON: {report_path}"
            ) from exc

        quarantine_path: Path | None = None
        if quarantine_folder:
            quarantine_path = Path(quarantine_folder).expanduser().resolve()
            if not dry_run:
                quarantine_path.mkdir(parents=True, exist_ok=True)

        actions: list[dict] = []
        removed_count = 0

        for group in report.get("duplicate_groups", []):
            documents = group.get("documents", [])
            if len(documents) < 2:
                continue

            keep_doc = documents[0]
            duplicate_docs = documents[1:]

            for duplicate in duplicate_docs:
                doc_path = Path(duplicate["doc_id"])
                meta_path = Path(
                    duplicate.get("meta_ref", {}).get(
                        "metadata_file",
                        f"{doc_path}.meta.json",
                    )
                )

                action = {
                    "hash": group.get("hash"),
                    "kept_doc": keep_doc.get("doc_id"),
                    "removed_doc": str(doc_path),
                    "removed_meta": str(meta_path),
                    "dry_run": dry_run,
                    "quarantine_folder": str(quarantine_path) if quarantine_path else None,
                }

                if not dry_run:
                    if quarantine_path is not None:
                        target_doc = self._unique_path(quarantine_path / doc_path.name)
                        shutil.move(str(doc_path), str(target_doc))

                        if meta_path.exists():
                            target_meta = self._unique_path(quarantine_path / meta_path.name)
                            shutil.move(str(meta_path), str(target_meta))

                        action["quarantined_doc"] = str(target_doc)
                        action["quarantined_meta"] = str(target_meta) if meta_path.exists() else None
                    else:
                        if doc_path.exists():
                            doc_path.unlink()

                        if meta_path.exists():
                            meta_path.unlink()

                    removed_count += 1

                actions.append(action)

        removal_report = {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "duplicate_report_file": str(report_path),
            "dry_run": dry_run,
            "quarantine_folder": str(quarantine_path) if quarantine_path else None,
            "groups_processed": len(report.get("duplicate_groups", [])),
            "duplicates_selected_for_removal": len(actions),
            "duplicates_removed": removed_count,
            "actions": actions,
        }

        output_path = report_path.with_name(f"{report_path.stem}_removal.json")
        output_path.write_text(json.dumps(removal_report, indent=2), encoding="utf-8")

        return removal_report
