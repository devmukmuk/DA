
"""ScanIt workflow services.

Description:
    High-level ScanIt workflows built from smaller reusable service functions.

Design:
    This module should contain orchestration logic only. Each workflow should:

Layering:
    1. Context layer

    2. Resolver layer

    3. Primitive service layer

    4. Workflow layer

"""

from __future__ import annotations

from pathlib import Path
from typing import Any
import time

from mindit.utils.file_utils import (
    remove_empty_folders_workflow,
)






