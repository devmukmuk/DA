# src/mindit/services/location/folders.py

"""Location folders: a month's photos grouped by place, e.g. organized\2019\2019-04 Easter at grandma's (springfield-il)."""

from __future__ import annotations

import os
import re
from pathlib import Path


def is_month_folder(folder: Path, month_folder: Path) -> bool:
    """Return True when folder is the month folder itself or a location folder of that month.

    A location folder sits in the same year folder and its name starts with the month: "2019-04 <title>"
    or "2019-04-20 <title>". "2019-04" is organized\2019\2019-04 (month_folder).
    """
    if os.path.normcase(os.path.abspath(folder.parent)) != os.path.normcase(os.path.abspath(month_folder.parent)):
        return False
    month, name = month_folder.name.lower(), folder.name.lower()
    return name == month or name.startswith(month + " ") or re.match(re.escape(month) + r"-\d\d( |$)", name) is not None
