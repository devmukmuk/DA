"""Google Drive service helpers and file operations."""
# src/mindit/services/drive_service.py

from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Any, Callable, Optional, TypeVar
import random
import time

from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload, MediaIoBaseUpload

from mindit.config.settings import load_settings
from mindit.providers.google.clients import get_drive_service

settings = load_settings()

FOLDER_MIME = "application/vnd.google-apps.folder"
SHEET_MIME = "application/vnd.google-apps.spreadsheet"

T = TypeVar("T")


def _is_retryable_google_error(exc: HttpError) -> bool:
    """Return True for retryable Google API quota/rate/server errors."""
    status = getattr(exc.resp, "status", None)

    if status in {429, 500, 502, 503, 504}:
        return True

    content = ""
    if hasattr(exc, "content") and exc.content:
        try:
            content = exc.content.decode("utf-8", errors="ignore").lower()
        except Exception:  # pylint: disable=broad-except
            content = str(exc).lower()

    retry_markers = (
        "ratelimitexceeded",
        "userratelimitexceeded",
        "quotaexceeded",
        "backenderror",
    )
    return any(marker in content for marker in retry_markers)


def execute_with_backoff(
    operation: Callable[[], T],
    max_retries: int = 6,
    base_delay: float = 1.0,
    max_delay: float = 60.0,
) -> T:
    """
    Execute a Google API operation with exponential backoff.

    Args:
        operation: Callable that executes a Google API request.
        max_retries: Maximum retry attempts.
        base_delay: Initial backoff delay in seconds.
        max_delay: Maximum delay in seconds.

    Returns:
        Result of the operation.

    Raises:
        HttpError: If retries are exhausted or error is not retryable.
    """
    attempt = 0

    while True:
        try:
            return operation()
        except HttpError as exc:
            if attempt >= max_retries or not _is_retryable_google_error(exc):
                raise

            delay = min(max_delay, base_delay * (2 ** attempt)) + random.uniform(0, 1)
            time.sleep(delay)
            attempt += 1


def get_google_drive_service(auth_type: str = "oauth") -> Any:
    """
    Return an authenticated Google Drive API service.

    Args:
        auth_type: Authentication mode to use.

    Returns:
        Dynamic Google Drive API service object.
    """
    return get_drive_service(auth_type=auth_type)


def copy_sheet_template_to_folder(
    title: str,
    folder_id: str,
    template_id: Optional[str] = None,
    auth_type: str = "oauth",
) -> str:
    """
    Copy a Google Sheets template into a target Drive folder.

    Args:
        title: Name of the new spreadsheet.
        folder_id: Drive folder where the copied sheet will be placed.
        template_id: Optional template override.
        auth_type: Authentication mode to use.

    Returns:
        New spreadsheet file ID.
    """
    template_id = template_id or settings.modules.packit.box.template_id
    service = get_google_drive_service(auth_type=auth_type)

    body = {
        "name": title,
        "parents": [folder_id],
    }

    new_file = execute_with_backoff(
        lambda: service.files().copy(  # pylint: disable=E1101
            fileId=template_id,
            body=body,
            fields="id",
        ).execute()
    )

    return new_file["id"]


def list_subfolders(
    parent_id: str,
    auth_type: str = "oauth",
) -> list[dict[str, str]]:
    """
    Return all non-trashed subfolders under a given parent folder.

    Args:
        parent_id: Google Drive folder ID to inspect.
        auth_type: Authentication mode to use.

    Returns:
        List of folder metadata dicts containing 'id' and 'name'.
    """
    service = get_google_drive_service(auth_type=auth_type)

    query = (
        f"'{parent_id}' in parents "
        f"and mimeType = '{FOLDER_MIME}' "
        "and trashed = false"
    )

    results = execute_with_backoff(
        lambda: service.files().list(  # pylint: disable=E1101
            q=query,
            fields="files(id, name)",
            pageSize=1000,
        ).execute()
    )

    return results.get("files", [])


def list_room_boxes(
    room_id: str,
    auth_type: str = "oauth",
) -> list[dict[str, Any]]:
    """
    Return all non-trashed spreadsheet files directly under a room folder.

    Args:
        room_id: Room folder Drive ID.
        auth_type: Authentication mode to use.

    Returns:
        List of spreadsheet metadata dicts.
    """
    service = get_google_drive_service(auth_type=auth_type)

    query = (
        f"'{room_id}' in parents "
        f"and mimeType = '{SHEET_MIME}' "
        "and trashed = false"
    )

    results = execute_with_backoff(
        lambda: service.files().list(  # pylint: disable=E1101
            q=query,
            fields="files(id, name, mimeType, modifiedTime, parents)",
            pageSize=1000,
            orderBy="name",
        ).execute()
    )

    return results.get("files", [])


def get_file_metadata(
    file_id: str,
    fields: str = "id, name, mimeType, modifiedTime, parents",
    auth_type: str = "oauth",
) -> dict[str, Any]:
    """
    Return selected metadata for a Drive file.

    Args:
        file_id: Drive file ID.
        fields: Fields string for Drive API.
        auth_type: Authentication mode to use.

    Returns:
        File metadata dictionary.
    """
    service = get_google_drive_service(auth_type=auth_type)

    return execute_with_backoff(
        lambda: service.files().get(  # pylint: disable=E1101
            fileId=file_id,
            fields=fields,
        ).execute()
    )


def move_file_to_folder(
    file_id: str,
    folder_id: str,
    auth_type: str = "oauth",
) -> dict[str, Any]:
    """
    Move an existing Drive file into a target folder.

    Args:
        file_id: Google Drive file ID to move.
        folder_id: Destination Google Drive folder ID.
        auth_type: Authentication mode to use.

    Returns:
        Updated file metadata.
    """
    service = get_google_drive_service(auth_type=auth_type)

    file_metadata = execute_with_backoff(
        lambda: service.files().get(  # pylint: disable=E1101
            fileId=file_id,
            fields="parents",
        ).execute()
    )

    previous_parents = ",".join(file_metadata.get("parents", []))

    return execute_with_backoff(
        lambda: service.files().update(  # pylint: disable=E1101
            fileId=file_id,
            addParents=folder_id,
            removeParents=previous_parents,
            fields="id, parents",
        ).execute()
    )


def upload_text_file(
    file_path: str | Path,
    parent_id: str,
    mime_type: str = "text/plain",
    auth_type: str = "oauth",
) -> str:
    """
    Upload a local text file to Google Drive.

    Args:
        file_path: Path to the local file.
        parent_id: Destination Google Drive folder ID.
        mime_type: MIME type for the upload.
        auth_type: Authentication mode to use.

    Returns:
        Uploaded Google Drive file ID.
    """
    service = get_google_drive_service(auth_type=auth_type)
    file_path = Path(file_path)

    file_metadata = {
        "name": file_path.name,
        "parents": [parent_id],
    }

    media = MediaFileUpload(str(file_path), mimetype=mime_type)

    uploaded_file = execute_with_backoff(
        lambda: service.files().create(  # pylint: disable=E1101
            body=file_metadata,
            media_body=media,
            fields="id",
        ).execute()
    )

    return uploaded_file["id"]


def upload_text_file_from_content(
    parent_id: str,
    filename: str,
    content: str,
    mime_type: str = "text/plain",
    auth_type: str = "oauth",
) -> str:
    """
    Upload a text file to Google Drive directly from a string.

    Args:
        parent_id: Destination Google Drive folder ID.
        filename: Name of the file to create in Drive.
        content: Text content to upload.
        mime_type: MIME type for the upload.
        auth_type: Authentication mode to use.

    Returns:
        Uploaded Google Drive file ID.
    """
    service = get_google_drive_service(auth_type=auth_type)

    file_metadata = {
        "name": filename,
        "parents": [parent_id],
    }

    media = MediaIoBaseUpload(
        BytesIO(content.encode("utf-8")),
        mimetype=mime_type,
        resumable=False,
    )

    uploaded_file = execute_with_backoff(
        lambda: service.files().create(  # pylint: disable=E1101
            body=file_metadata,
            media_body=media,
            fields="id",
        ).execute()
    )

    return uploaded_file["id"]


def create_folder(
    name: str,
    parent_id: str,
    auth_type: str = "oauth",
) -> dict[str, str]:
    """
    Create a new folder under a specified parent folder.

    Args:
        name: Name of the folder to create.
        parent_id: Parent Google Drive folder ID.
        auth_type: Authentication mode to use.

    Returns:
        Created folder metadata containing 'id' and 'name'.
    """
    service = get_google_drive_service(auth_type=auth_type)

    folder_metadata = {
        "name": name,
        "mimeType": FOLDER_MIME,
        "parents": [parent_id],
    }

    return execute_with_backoff(
        lambda: service.files().create(  # pylint: disable=E1101
            body=folder_metadata,
            fields="id, name",
        ).execute()
    )


def delete_folder(folder_id: str, auth_type: str = "oauth") -> None:
    """
    Delete a folder from Google Drive.

    Args:
        folder_id: Google Drive folder ID to delete.
        auth_type: Authentication mode to use.
    """
    service = get_google_drive_service(auth_type=auth_type)
    execute_with_backoff(
        lambda: service.files().delete(fileId=folder_id).execute()  # pylint: disable=E1101
    )


def get_room_parent_name(service_drive: Any, room_id: str) -> tuple[str, str]:
    """
    Return the household name and room name for a room folder.

    Args:
        service_drive: Authenticated Google Drive service.
        room_id: Google Drive folder ID for the room.

    Returns:
        Tuple of household name and room name.
    """
    room = execute_with_backoff(
        lambda: service_drive.files().get(
            fileId=room_id,
            fields="id, name, parents",
        ).execute()
    )

    room_name = room.get("name", "Unknown Room")
    parent_ids = room.get("parents", [])

    if not parent_ids:
        return "Unknown Household", room_name

    parent = execute_with_backoff(
        lambda: service_drive.files().get(
            fileId=parent_ids[0],
            fields="id, name",
        ).execute()
    )

    household_name = parent.get("name", "Unknown Household")
    return household_name, room_name


def rename_folder(
    folder_id: str,
    new_name: str,
    auth_type: str = "oauth",
) -> dict[str, str]:
    """
    Rename an existing Google Drive folder.

    Args:
        folder_id: Google Drive folder ID to rename.
        new_name: New folder name.
        auth_type: Authentication mode to use.

    Returns:
        Updated folder metadata containing 'id' and 'name'.
    """
    service = get_google_drive_service(auth_type=auth_type)

    return execute_with_backoff(
        lambda: service.files().update(  # pylint: disable=E1101
            fileId=folder_id,
            body={"name": new_name},
            fields="id, name",
        ).execute()
    )
