"""Google Sheets service helpers."""
# src/mindit/services/sheets_service.py

from __future__ import annotations

from typing import Any

from googleapiclient.discovery import build

from mindit.providers.google.auth_service import get_google_credentials
from mindit.services.google.drive_service import execute_with_backoff

DEFAULT_SCOPES = [
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/spreadsheets",
]


def get_sheets_service(auth_type: str = "oauth") -> Any:
    """
    Return an authenticated Google Sheets API service.

    Args:
        auth_type: Authentication mode to use.

    Returns:
        Dynamic Google Sheets API service object.
    """
    creds = get_google_credentials(auth_type=auth_type, scopes=DEFAULT_SCOPES)
    return build("sheets", "v4", credentials=creds)


def batch_get_sheet_ranges(
    spreadsheet_id: str,
    ranges: list[str],
    auth_type: str = "oauth",
    major_dimension: str = "ROWS",
    value_render_option: str = "FORMATTED_VALUE",
) -> dict[str, Any]:
    """
    Read multiple ranges from a spreadsheet in a single API call.

    Args:
        spreadsheet_id: Spreadsheet file ID.
        ranges: A1 notation ranges to fetch.
        auth_type: Authentication mode to use.
        major_dimension: ROWS or COLUMNS.
        value_render_option: Sheets render mode.

    Returns:
        Raw batchGet response.
    """
    service = get_sheets_service(auth_type=auth_type)

    return execute_with_backoff(
        lambda: service.spreadsheets().values().batchGet( # pylint: disable=E1101
            spreadsheetId=spreadsheet_id,
            ranges=ranges,
            majorDimension=major_dimension,
            valueRenderOption=value_render_option,
        ).execute()
    )


def get_sheet_ranges_as_dict(
    spreadsheet_id: str,
    ranges: list[str],
    auth_type: str = "oauth",
) -> dict[str, list[list[str]]]:
    """
    Return a dict mapping each requested range to its values.

    Args:
        spreadsheet_id: Spreadsheet file ID.
        ranges: A1 notation ranges to fetch.
        auth_type: Authentication mode to use.

    Returns:
        Dict keyed by range string with row/value lists.
    """
    response = batch_get_sheet_ranges(
        spreadsheet_id=spreadsheet_id,
        ranges=ranges,
        auth_type=auth_type,
    )

    result: dict[str, list[list[str]]] = {}
    for value_range in response.get("valueRanges", []):
        range_name = value_range.get("range", "")
        values = value_range.get("values", [])
        result[range_name] = values

    return result


def get_box_sheet_payload(
    spreadsheet_id: str,
    auth_type: str = "oauth",
) -> dict[str, Any]:
    """
    Read the minimal set of box data needed for export/validation.

    Adjust these ranges to match your actual box template.

    Args:
        spreadsheet_id: Spreadsheet file ID.
        auth_type: Authentication mode to use.

    Returns:
        Structured payload for export logic.
    """
    ranges = [
        "Box Details!A1:B12",
        "Contents!A1:Z200",
    ]

    data = get_sheet_ranges_as_dict(
        spreadsheet_id=spreadsheet_id,
        ranges=ranges,
        auth_type=auth_type,
    )

    return {
        "spreadsheet_id": spreadsheet_id,
        "details": data.get("Box Details!A1:B12", []),
        "contents": data.get("Contents!A1:Z200", []),
    }
