# src/mindit/commands/dbit_cli.py

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich import print_json

from rich.console import Console
from rich.table import Table

from mindit.config.settings import resolve_database_path
from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas
from mindit.services.dbit.archive_stats import archive_stats
from mindit.services.dbit.dbit_service import DbitService

app = typer.Typer(help="The DA database: index the archive, show what's where.")
console = Console()


def _default_db_path() -> Path:
    """Return the configured database path (<data_root>/.da/da.sqlite)."""
    return resolve_database_path()


@app.command("build")
def build_db(
    area: Optional[list[str]] = typer.Option(
        None, "--area", help="Only these areas: photos, documents, intake, holding (repeatable)."
    ),
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    """Index every file in the archive (from its sidecar) and drop rows for files that are gone."""
    areas = [a for a in default_areas() if not area or a.name in area]
    db = DbitService(db_path or _default_db_path())
    for a in areas:
        console.print(f"{a.name:10} {a.root}" + ("" if a.root.is_dir() else "  (not found, skipped)"))
    result = ArchiveIndexService(db).build(areas, progress=lambda msg: console.print(f"  {msg}"))

    table = Table(title=f"Indexed into {db.db_path}")
    for col in ("area", "files", "GB", "photo", "raw", "document", "other", "no sidecar", "no hash"):
        table.add_column(col, justify="left" if col == "area" else "right")
    for name, s in result.as_dict()["areas"].items():
        k = s["by_kind"]
        table.add_row(name, f"{s['files']:,}", f"{s['gb']:,}", *(f"{k.get(x, 0):,}" for x in ("photo", "raw", "document", "other")),
                      f"{s['no_sidecar']:,}", f"{s['no_hash']:,}")
    console.print(table)
    console.print(f"Removed {result.removed:,} rows for files no longer on disk. {result.seconds:.0f}s.")


@app.command("stats")
def stats_db(
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
    json_out: bool = typer.Option(False, "--json", help="Print JSON instead of tables."),
) -> None:
    """Show what's in the archive by area and year, and how far each intake folder is."""
    stats = archive_stats(DbitService(db_path or _default_db_path()))
    if json_out:
        print_json(data=stats)
        return

    if not stats["last_build"]:
        console.print("This archive isn't indexed yet. Run  da db build  (or choose 5 Refresh index in the menu).")
        return
    console.print(f"Last build: {stats['last_build']}")
    table = Table(title="By area")
    for col in ("area", "kind", "files", "GB", "no sidecar", "no hash"):
        table.add_column(col, justify="left" if col in ("area", "kind") else "right")
    for r in stats["by_area"]:
        table.add_row(r["area"], r["kind"], f"{r['files']:,}", f"{r['gb']:,}", f"{r['no_sidecar']:,}", f"{r['no_hash']:,}")
    console.print(table)

    table = Table(title="Intake folders (by content hash)")
    for col in ("folder", "files", "already in organized", "to check / file", "not hashed yet"):
        table.add_column(col, justify="left" if col == "folder" else "right")
    for name, f in stats["intake_folders"].items():
        table.add_row(name, f"{f['files']:,}", f"{f['already_in_organized']:,}", f"{f['to_check_or_file']:,}", f"{f['not_hashed']:,}")
    console.print(table)


@app.command("init")
def init_db(
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    service = DbitService(db_path or _default_db_path())
    service.initialize()
    print_json(data=service.inspect())


@app.command("inspect")
def inspect_db(
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    service = DbitService(db_path or _default_db_path())
    print_json(data=service.inspect())


@app.command("query")
def query_db(
    sql: str = typer.Argument(..., help="SELECT query to run."),
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    service = DbitService(db_path or _default_db_path())
    rows = service.query(sql)
    print_json(data={"rows": rows, "row_count": len(rows)})
