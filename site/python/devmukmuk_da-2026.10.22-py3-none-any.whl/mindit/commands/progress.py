from rich.console import Console

class ConsoleProgressReporter:
    def __init__(self, console: Console, update_every: int = 100) -> None:
        self.console = console
        self.update_every = update_every
        self.label = ""
        self.total: int | None = None
        self.current = 0

    def start(self, label: str, total: int | None = None) -> None:
        self.label = label
        self.total = total
        self.current = 0

        if total:
            self.console.print(f"{label}: 0/{total}")

    def advance(self, current_item: str | None = None, step: int = 1) -> None:
        self.current += step

        if self.current % self.update_every != 0:
            return

        if self.total:
            self.console.print(f"{self.label}: {self.current}/{self.total}")
        else:
            self.console.print(f"{self.label}: {self.current}")

    def finish(self) -> None:
        if self.total:
            self.console.print(f"{self.label}: {self.current}/{self.total} complete")
        else:
            self.console.print(f"{self.label}: {self.current} complete")