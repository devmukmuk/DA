from __future__ import annotations

from pathlib import Path

import typer
from rich import print_json

from mindit.services.sidecar import SidecarMigrationService

app = typer.Typer(help="Sidecar metadata utilities.")


@app.command("normalize")
def normalize_sidecars(
    folder: Path = typer.Argument(..., help="Folder containing sidecars to normalize."),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    service = SidecarMigrationService()
    result = service.normalize_folder(
        folder=folder,
        recursive=recursive,
        dry_run=dry_run,
    )
    print_json(data=result)
