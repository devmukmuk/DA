"""PackIt CLI commands."""
# src/mindit/modules/packit/cli.py

from __future__ import annotations

from typing import Optional

import typer
from rich import print  # pylint: disable=W0622

from mindit.providers.google.clients import (
    get_drive_service,
    get_sheets_service,
)
from mindit.reporting.engine import run_report
from mindit.services.packit.packit_box_service import (
    delete_box_sheet,
    rename_box_sheet,
)
from mindit.services.packit.packit_context import build_packit_context
from mindit.services.packit.packit_reporting import PackItReportGenerator
from mindit.services.packit.packit_service_class import PackItService
from mindit.services.packit.packit_workflows import (
    create_room_workflow,
    export_house_totals_workflow,
    list_rooms_workflow,
    validate_box_workflow,
    validate_room_workflow,
    validate_house_workflow,
    add_boxes_workflow
)
from mindit.services.packit.packit_box_export_service import build_box_export_data

app = typer.Typer(help="PackIt household packing and inventory tools.")

house_app = typer.Typer(help="PackIt house commands.")
room_app = typer.Typer(help="PackIt room commands.")
box_app = typer.Typer(help="PackIt box commands.")

app.add_typer(house_app, name="house")
app.add_typer(room_app, name="room")
app.add_typer(box_app, name="box")


# ---------------------------------------------------------------------
# house commands
# ---------------------------------------------------------------------
@house_app.command("report")
def house_report(
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Report all rooms in a house."""

    ctx = build_packit_context(auth_type=auth_type)
    result = list_rooms_workflow(ctx)
    print(result)

@house_app.command("validate")
def house_validate(
    write_updates: bool = typer.Option(
        False,
        "--write-updates/--no-write-updates",
        help="Write normalized metadata updates back to box sheets.",
    ),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Validate the entire PackIt house."""
    ctx = build_packit_context(auth_type=auth_type)
    result = validate_house_workflow(
        ctx=ctx,
        write_updates=write_updates,
    )
    print(result)


@house_app.command("house-totals")
def packit_house_totals(
    throttle_seconds: float = typer.Option(
        1.5,
        "--throttle-seconds",
        help="Seconds to wait between Google Sheets reads.",
    ),
):
    """Export house totals (weight + volume)."""
    ctx = build_packit_context()

    result = export_house_totals_workflow(
        ctx,
        throttle_seconds=throttle_seconds,
    )

    print("[green]House totals report created[/green]")
    print(result["output_path"])

# ---------------------------------------------------------------------
# room commands
# ---------------------------------------------------------------------
@room_app.command("list")
def room_list(
    with_counts: bool = typer.Option(
        False,
        "--with-counts",
        help="Include box counts per room.",
    ),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """List rooms."""
    if with_counts:
        service = PackItService(auth_type=auth_type)
        rooms = service.list_rooms_with_counts()
        print({"rooms": rooms})
        return

    ctx = build_packit_context(auth_type=auth_type)
    result = list_rooms_workflow(ctx)
    print(result)


@room_app.command("create")
def room_create(
    room_name: str = typer.Option(
        ...,
        "--room-name",
        help="Full room name, e.g. LIVINGROOM",
    ),
    room_abbr: str = typer.Option(
        ...,
        "--room-abbr",
        help="Room abbreviation, e.g. LR",
    ),
    tape_color: str = typer.Option(
        ...,
        "--tape-color",
        help="Tape color, e.g. YELLOW",
    ),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Create a room folder."""
    ctx = build_packit_context(auth_type=auth_type)
    result = create_room_workflow(
        ctx=ctx,
        room_name=room_name,
        room_abbr=room_abbr,
        tape_color=tape_color,
    )
    print(result)


@room_app.command("validate")
def room_validate(
    room_name: Optional[str] = typer.Option(
        None,
        "--room-name",
        help="Full room name, e.g. LIVINGROOM",
    ),
    room_abbr: Optional[str] = typer.Option(
        None,
        "--room-abbr",
        help="Room abbreviation, e.g. LR",
    ),
    write_updates: bool = typer.Option(
        False,
        "--write-updates/--no-write-updates",
        help="Write normalized metadata updates back to the box sheets.",
    ),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Validate all boxes in a room."""
    if not room_name and not room_abbr:
        raise typer.BadParameter("Provide --room-name and/or --room-abbr")

    ctx = build_packit_context(auth_type=auth_type)
    result = validate_room_workflow(
        ctx=ctx,
        room_name=room_name,
        room_abbr=room_abbr,
        write_updates=write_updates,
    )
    print(result)


@room_app.command("addbox")
def room_addbox(
    room_name: Optional[str] = typer.Option(
        None,
        "--room-name",
        help="Full room name, e.g. PANTRYKITCHEN",
    ),
    room_abbr: Optional[str] = typer.Option(
        None,
        "--room-abbr",
        help="Room abbreviation, e.g. P2",
    ),
    count: int = typer.Option(
        1,
        "--count",
        min=1,
        help="Number of new boxes to create.",
    ),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Add one or more new boxes to a room and validate the room."""
    if not room_name and not room_abbr:
        raise typer.BadParameter("Provide --room-name and/or --room-abbr")

    ctx = build_packit_context(auth_type=auth_type)
    result = add_boxes_workflow(
        ctx=ctx,
        room_name=room_name,
        room_abbr=room_abbr,
        count=count,
    )
    print(result)

# ---------------------------------------------------------------------
# box commands
# ---------------------------------------------------------------------
@box_app.command("validate")
def box_validate(
    box_name: str = typer.Argument(..., help="Box sheet name, e.g. LR-01"),
    write_updates: bool = typer.Option(
        False,
        "--write-updates/--no-write-updates",
        help="Write normalized metadata updates back to the sheet.",
    ),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Validate a single box by name."""
    ctx = build_packit_context(auth_type=auth_type)
    result = validate_box_workflow(
        ctx=ctx,
        box_name=box_name,
        write_updates=write_updates,
    )
    print(result)


@box_app.command("remove")
def box_remove(
    sheet_id: str = typer.Option(..., "--sheet-id", help="Spreadsheet file ID of the box"),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Remove a box sheet."""
    service_drive = get_drive_service(auth_type=auth_type)
    delete_box_sheet(
        service_drive=service_drive,
        sheet_id=sheet_id,
    )
    print({"deleted": sheet_id})


@box_app.command("rename")
def box_rename(
    sheet_id: str = typer.Option(..., "--sheet-id", help="Spreadsheet file ID of the box"),
    new_name: str = typer.Option(..., "--new-name", help="New name for the box sheet"),
    auth_type: str = typer.Option(
        "oauth",
        "--auth-type",
        help="Authentication type: oauth or service",
    ),
) -> None:
    """Rename a box sheet and refresh its metadata."""
    service_drive = get_drive_service(auth_type=auth_type)
    service_sheets = get_sheets_service(auth_type=auth_type)

    rename_box_sheet(
        service_drive=service_drive,
        service_sheets=service_sheets,
        sheet_id=sheet_id,
        new_name=new_name,
    )
    print({"renamed": sheet_id, "new_name": new_name})





# ---------------------------------------------------------------------
# reporting commands
# ---------------------------------------------------------------------
@app.command("report")
def report(data: str) -> None:
    """Generate a PackIt report from JSON data."""
    run_report(PackItReportGenerator(), data)
