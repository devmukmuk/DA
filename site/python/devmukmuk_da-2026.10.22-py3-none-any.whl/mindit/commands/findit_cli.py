#src/mindit/commands/findit_cli.py

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

import typer
from rich import print_json

from typing import Literal

from mindit.services.findit.findit_sqlite import find_sqlite_summary_workflow

from mindit.services.findit.findit_workflows import (
    find_tag_workflow,
    find_summary_workflow,
)


app = typer.Typer(help="Find files using metadata sidecars.")


@app.command("summary")
def find_summary(
    folder: Path = typer.Argument(
        ...,
        help="Folder to summarize.",
    ),
    recursive: bool = typer.Option(
        True,
        "--recursive/--no-recursive",
        help="Search folders recursively.",
    ),
    output_file: Path | None = typer.Option(
        None,
        "--output-file",
        help="Optional JSON file path for summary results.",
    ),
    write_output: bool = typer.Option(
        False,
        "--write-output",
        help="Write summary results to a dated JSON output file.",
    ),
    backend: Literal["sidecar", "sqlite"] = typer.Option(
        "sidecar",
        "--backend",
        help="Search backend to use.",
    ),
    db_path: Path | None = typer.Option(
        None,
        "--db-path",
        help="SQLite database path. Required when --backend sqlite.",
    ),
) -> None:
    
    if backend == "sqlite":
        if db_path is None:
            raise typer.BadParameter("--db-path is required when --backend sqlite")

        result = find_sqlite_summary_workflow(
            db_path=db_path,
            folder=folder,
        )
    else:
        result = find_summary_workflow(
            folder=folder,
            recursive=recursive,
        )

    written_output_file: Path | None = None

    if output_file is not None:
        written_output_file = output_file
        _write_json_output(written_output_file, result)

    elif write_output:
        written_output_file = _default_output_file(folder, command_name="summary")
        _write_json_output(written_output_file, result)

    if written_output_file is not None:
        result["output_file"] = str(written_output_file)

    print_json(data=result)

@app.command("tags")
def find_tags(
    folder: Path = typer.Argument(..., help="Folder to search."),
    recursive: bool = typer.Option(
        True,
        "--recursive/--no-recursive",
        help="Search folders recursively.",
    ),
    require_tag: list[str] | None = typer.Option(
        None,
        "--require-tag",
        "-r",
        help="Required tag. Can be used multiple times.",
    ),
    exclude_tag: list[str] | None = typer.Option(
        None,
        "--exclude-tag",
        "-x",
        help="Excluded tag. Can be used multiple times.",
    ),
    date_prefix: str | None = typer.Option(
        None,
        "--date-prefix",
        help='Match captured_at prefix, such as "2022", "2022-07", or "2022-07-10".',
    ),
    name_contains: str | None = typer.Option(
        None,
        "--name-contains",
        help="Case-insensitive filename substring filter.",
    ),
    require_gps: bool = typer.Option(
        False,
        "--require-gps",
        help="Only include files with GPS metadata.",
    ),
    module: str | None = typer.Option(
        None,
        "--module",
        help='Filter by metadata module, such as "photoit" or "scanit".',
    ),
    media_type: str | None = typer.Option(
        None,
        "--media-type",
        help='Filter by metadata media_type, such as "photo" or "document".',
    ),
    file_exists_only: bool = typer.Option(
        False,
        "--file-exists",
        help="Only include matches where the referenced file exists.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Print full match details to the terminal.",
    ),
    output_file: Path | None = typer.Option(
        None,
        "--output-file",
        help="Optional JSON file path for full results.",
    ),
    write_output: bool = typer.Option(
        False,
        "--write-output",
        help="Write full results to a dated JSON output file.",
    ),
    backend: Literal["sidecar", "sqlite"] = typer.Option(
        "sidecar",
        "--backend",
        help="Search backend to use.",
    ),
    db_path: Path | None = typer.Option(
        None,
        "--db-path",
        help="SQLite database path. Reserved for SQLite backend.",
    ),
) -> None:
    if backend == "sqlite":
        raise typer.BadParameter(
            "SQLite tag search is not implemented yet. Use --backend sidecar."
        )
    
    result = find_tag_workflow(
        folder=folder,
        recursive=recursive,
        require_tags=require_tag,
        exclude_tags=exclude_tag,
        date_prefix=date_prefix,
        name_contains=name_contains,
        require_gps=require_gps,
        module=module,
        media_type=media_type,
        file_exists_only=file_exists_only,
    )

    written_output_file: Path | None = None

    if output_file is not None:
        written_output_file = output_file
        _write_json_output(written_output_file, result)

    elif write_output:
        written_output_file = _default_output_file(folder, command_name="tags")
        _write_json_output(written_output_file, result)

    if verbose:
        terminal_result = dict(result)
    else:
        terminal_result = _summary_only(result)

    if written_output_file is not None:
        terminal_result["output_file"] = str(written_output_file)

    print_json(data=terminal_result)


def _summary_only(result: dict) -> dict:
    return {
        "folder": result["folder"],
        "recursive": result["recursive"],
        "sidecar_count": result["sidecar_count"],
        "metadata_read_count": result["metadata_read_count"],
        "metadata_error_count": result["metadata_error_count"],
        "require_tags": result["require_tags"],
        "exclude_tags": result["exclude_tags"],
        "date_prefix": result["date_prefix"],
        "name_contains": result["name_contains"],
        "require_gps": result["require_gps"],
        "module": result["module"],
        "media_type": result["media_type"],
        "file_exists_only": result["file_exists_only"],
        "match_count": result["match_count"],
    }


def _write_json_output(output_file: Path, result: dict) -> None:
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(
        json.dumps(result, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def _default_output_file(folder: Path, command_name: str = "tags") -> Path:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_folder_name = folder.name or "findit"
    return (
        Path("reports")
        / "findit"
        / f"findit-{command_name}-{safe_folder_name}-{timestamp}.json"
    )