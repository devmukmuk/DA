"""qrcode CLI commands."""
# src/mindit/modules/qrcode/cli.py

from __future__ import annotations

from pathlib import Path

import typer
from rich import print  # pylint: disable=W0622
import json

from mindit.services.qrcodes.qrcode_workflows import create_pdf_qrcodes_from_folder_workflow


app = typer.Typer(help="QR Code creatation tools.")


@app.callback()
def app_callback(ctx: typer.Context) -> None:
    """Get settings from parent context."""
    settings = ctx.obj  # Retrieved from main() callback
    # Now use settings in packit commands




@app.command("pdf-folder")
def create_pdf_folder_qrcodes(
    root_id: str = typer.Option(..., "--root-id"),
    output_dir: str = typer.Option("output/qrcodes/pdfs", "--output-dir"),
    recursive: bool = typer.Option(False, "--recursive"),
    overwrite: bool = typer.Option(False, "--overwrite"),
    preserve_tree: bool = typer.Option(False, "--preserve-tree"),
    limit: int | None = typer.Option(None, "--limit"),
) -> None:
    result = create_pdf_qrcodes_from_folder_workflow(
        root_id=root_id,
        output_dir=output_dir,
        recursive=recursive,
        overwrite=overwrite,
        preserve_tree=preserve_tree,
        limit=limit,
    )
    print(json.dumps(result, indent=2))
