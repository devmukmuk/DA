"""DA (Digital Archive) app cli command."""
# src/mindit/cli.py

from __future__ import annotations

import sys
from collections import defaultdict
from typing import Any, Callable
import typer
from rich.console import Console
console = Console()



from mindit.config.cli import app as config_app
from mindit.config.settings import (
    load_settings,
    get_archive_root,
    is_profile_chosen,
    get_config_root,
    get_config_path,
    get_data_root_path,
    resolve_config_relative_path,
    resolve_data_path,
    resolve_packit_output_path,
    resolve_packit_qr_path,
    resolve_packit_reports_path,
    resolve_packit_rooms_path,
    resolve_photoit_organized_path,
    resolve_photoit_output_path,
    resolve_photoit_quarantine_path,
    resolve_photoit_intake_path,
    resolve_scanit_organized_path,
    resolve_scanit_output_path,
    resolve_scanit_quarantine_path,
    resolve_scanit_intake_path,
)

from mindit.core.logging import (
    configure_logging,
    get_context_logger,
    log_command,
    log_command_start,
)
from mindit.utils.feedback import chime_start, chime_done
from mindit.core.feedback import cli_feedback

from mindit import __app_name__, __version__
from mindit.providers.cli import app as storage_app
from mindit.commands.validateit.cli import app as validateit_app
from mindit.commands.validateit.cli import validate_folder
from mindit.commands.dbit_cli import app as dbit_app
from mindit.commands.sidecar_cli import app as sidecar_cli_app
from mindit.commands.findit_cli import app as findit_cli_app
from mindit.commands.intake_cli import app as intake_app
from mindit.commands.location_cli import app as location_app
from mindit.commands.date_cli import app as date_app
from mindit.commands import workflow_cli





# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------

def _is_pathlike_key(key: str) -> bool:
    return key.endswith(("_root", "_dir", "_path", "_file")) or key in {
        "data_root",
        "intake",
        "documents",
        "photos",
        "metadata",
        "exports",
        "logs",
        "output",
        "camera_inbox",
        "archive_dir",
    }


def _flatten_dict(data: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    flat: dict[str, Any] = {}

    for key, value in data.items():
        full_key = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict):
            flat.update(_flatten_dict(value, full_key))
        else:
            flat[full_key] = value

    return flat


def _section_name(dot_key: str) -> str:
    parts = dot_key.split(".")

    if parts[0] == "paths":
        return "Paths"
    if parts[0] == "logs":
        return "Logs"
    if parts[0] == "providers":
        return f"Providers / {parts[1]}"
    if parts[0] == "modules":
        return parts[1].capitalize()

    return parts[0].capitalize()


def _field_name(dot_key: str) -> str:
    parts = dot_key.split(".")

    if parts[0] in {"paths", "logs"}:
        return ".".join(parts[1:])

    if parts[0] == "providers":
        return ".".join(parts[2:])

    if parts[0] == "modules":
        return ".".join(parts[2:])

    return ".".join(parts[1:])


_SPECIAL_RESOLVERS: dict[str, Callable[[Any], str]] = {
    # shared paths
    "paths.data_root": lambda settings: str(get_data_root_path(settings)),
    "paths.intake": lambda settings: str(resolve_data_path(settings.paths.intake, settings)),
    "paths.documents": lambda settings: str(resolve_data_path(settings.paths.documents, settings)),
    "paths.photos": lambda settings: str(resolve_data_path(settings.paths.photos, settings)),
    "paths.metadata": lambda settings: str(resolve_data_path(settings.paths.metadata, settings)),
    "paths.exports": lambda settings: str(resolve_data_path(settings.paths.exports, settings)),
    "paths.logs": lambda settings: str(resolve_data_path(settings.paths.logs, settings)),
    "paths.output": lambda settings: str(resolve_data_path(settings.paths.output, settings)),
    "paths.camera_inbox": lambda settings: str(resolve_data_path(settings.paths.camera_inbox, settings)),

    # logs
    "logs.root": lambda settings: str(resolve_data_path(settings.logs.root, settings)),
    "logs.archive_dir": lambda settings: str(resolve_data_path(settings.logs.archive_dir, settings)),

    # provider files
    "providers.google_drive.credentials_file": lambda settings: str(
        resolve_config_relative_path(settings.providers.google_drive.credentials_file)
    ),
    "providers.google_drive.service_account_file": lambda settings: str(
        resolve_config_relative_path(settings.providers.google_drive.service_account_file)
    ),
    "providers.google_drive.token_file": lambda settings: str(
        resolve_config_relative_path(settings.providers.google_drive.token_file)
    ),

    # packit
    "modules.packit.rooms_root": lambda settings: str(resolve_packit_rooms_path(settings)),
    "modules.packit.reports_root": lambda settings: str(resolve_packit_reports_path(settings)),
    "modules.packit.qr_root": lambda settings: str(resolve_packit_qr_path(settings)),
    "modules.packit.output_root": lambda settings: str(resolve_packit_output_path(settings)),

    # scanit
    "modules.scanit.intake_root": lambda settings: str(resolve_scanit_intake_path(settings)),
    "modules.scanit.organized_root": lambda settings: str(resolve_scanit_organized_path(settings)),
    "modules.scanit.quarantine_root": lambda settings: str(resolve_scanit_quarantine_path(settings)),
    "modules.scanit.output_root": lambda settings: str(resolve_scanit_output_path(settings)),

    # photoit
    "modules.photoit.intake_root": lambda settings: str(resolve_photoit_intake_path(settings)),
    "modules.photoit.organized_root": lambda settings: str(resolve_photoit_organized_path(settings)),
    "modules.photoit.quarantine_root": lambda settings: str(resolve_photoit_quarantine_path(settings)),
    "modules.photoit.output_root": lambda settings: str(resolve_photoit_output_path(settings)),
}


def _resolve_config_value(key: str, value: Any, settings: Any) -> str:
    if not isinstance(value, str):
        return str(value)

    special_resolver = _SPECIAL_RESOLVERS.get(key)
    if special_resolver is not None:
        return special_resolver(settings)

    # generic config-relative files
    if key.endswith("_file"):
        return str(resolve_config_relative_path(value))

    # generic data-relative paths
    if _is_pathlike_key(key.split(".")[-1]):
        return str(resolve_data_path(value, settings))

    return str(value)


app = typer.Typer(
    help="DA (Digital Archive): validate, de-duplicate and file photos and documents. "
         "Run `da` on its own for the menu.",
    no_args_is_help=False,
    pretty_exceptions_enable=False,
)

app.add_typer(config_app, name="config")
app.add_typer(storage_app, name="storage")
try:                                    # the household inventory needs Google's libraries (an extra)
    from mindit.commands.packit.cli import app as packit_app  # pylint: disable=wrong-import-position
    from mindit.commands.qrcode.cli import app as qrcode_app  # pylint: disable=wrong-import-position
except ImportError:
    packit_app = typer.Typer(help="Household inventory (needs Google's libraries: the 'google' extra).")
    qrcode_app = typer.Typer(help="QR labels for the household inventory (needs Google's libraries: the 'google' extra).")
app.add_typer(packit_app, name="packit")
app.add_typer(qrcode_app, name="qrcode")
app.add_typer(validateit_app, name="validateit")
app.add_typer(dbit_app, name="db")
app.add_typer(sidecar_cli_app, name="sidecar")
app.add_typer(findit_cli_app, name="findit")
app.add_typer(intake_app, name="intake")
app.add_typer(location_app, name="location")
app.add_typer(date_app, name="date")

# The archive's main job, so it is a top-level command too: `da validate <folder>`.
app.command("validate")(validate_folder)

# The whole workflow, for running it yourself on any archive.
app.command("setup")(workflow_cli.setup)
app.command("run")(workflow_cli.run)
app.command("status")(workflow_cli.status)
app.command("archives")(workflow_cli.archives)
app.command("guide")(workflow_cli.guide)
app.command("contact-sheets")(workflow_cli.contact_sheets)
app.command("pair-movies")(workflow_cli.pair_movies)
app.command("heic-to-jpg")(workflow_cli.heic_to_jpg)
app.command("tag")(workflow_cli.tag)
app.command("split")(workflow_cli.split)
app.command("report")(workflow_cli.report)
app.command("merge")(workflow_cli.merge)
app.command("install")(workflow_cli.install)
app.command("update")(workflow_cli.update)
app.command("check")(workflow_cli.check)
app.command("verify")(workflow_cli.verify)


@app.command("menu")
def menu() -> None:
    """The interactive menu (same as running `da` on its own)."""
    from mindit.commands.menu import run_menu  # pylint: disable=import-outside-toplevel

    run_menu()



# Commands that work on an archive's files; outside an archive they stop instead of using an old profile.
ARCHIVE_COMMANDS = {"run", "status", "validate", "validateit", "db", "intake", "findit", "sidecar", "pair-movies", "tag", "location", "split", "report", "merge", "date"}


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    config_dir: str | None = typer.Option(
        None,
        "--config-dir",
        help="Use an old-style profile config folder instead of an archive.",
    ),
    archive: str | None = typer.Option(
        None,
        "--archive",
        help="The archive folder (holding da-archive.yaml). Default: the current folder or one above it.",
    ),
) -> None:
    """
    Initialize DA before running any subcommand.

    Notes:
        - The actual config root bootstrap happens earlier in __main__.py.
        - This option exists here so it appears in CLI help output.
    """
    asking_for_help = any(arg in ("--help", "-h") for arg in sys.argv[1:])
    if (ctx.invoked_subcommand in ARCHIVE_COMMANDS and get_archive_root() is None
            and not is_profile_chosen() and not asking_for_help):
        console.print("[yellow]Not inside an archive.[/yellow] Run this inside an archive folder "
                      r"(cd D:\jane-archive-202x), add --archive <folder>,")
        console.print("double-click the archive's Open DA.cmd, or run `da` to pick one. "
                      "Archives on this PC: da archives")
        raise typer.Exit(1)

    settings = load_settings()
    # A relative log folder ("logs") belongs to the archive's data root, not wherever DA was started.
    configure_logging(settings.logs.model_copy(update={"root": str(resolve_data_path(settings.logs.root, settings))}))
    if not asking_for_help:
        root = get_archive_root()
        log_command_start(sys.argv[1:], str(root) if root else None)

    # store settings in context for subcommands to access without reloading
    ctx.obj = settings

    if ctx.invoked_subcommand is None:          # `da` on its own: the interactive menu
        from mindit.commands.menu import run_menu  # pylint: disable=import-outside-toplevel

        run_menu()

    # logger = get_context_logger(
    #     __name__,
    #     app="mindit",
    #     command="cli",
    #     profile=settings.profile,
    # )

    # logger.info(
    #     "CLI initialized",
    #     extra={
    #         "event": "mindit.cli.init",
    #         "status": "ok",
    #         "profile": settings.profile,
    #         "config_root": str(get_config_root()),
    #         "config_path": str(get_config_path()),
    #         "config_dir_option": config_dir,
    #         "invoked_subcommand": ctx.invoked_subcommand,
    #         "version": __version__,
    #     },
    # )


@app.command("version")
def version() -> None:
    """ Show the current DA version. """
    settings = load_settings()
    with cli_feedback(settings):
        print(f"{__app_name__} v{__version__}")



@app.command("about")
def about(
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="Show full flat path dump.",
    )
) -> None:
    """
    Show basic application information and resolved paths.
    """
    settings = load_settings()

    logger = get_context_logger(
        __name__,
        app="mindit",
        command="about",
        profile=settings.profile,
    )

    with log_command(logger, "mindit.about"):
        print(f"[bold]{__app_name__} v{__version__}[/bold]")
        print(f"config_root = {get_config_root()}")
        print(f"config      = {get_config_path()}")

        flat = _flatten_dict(settings.model_dump())

        if verbose:
            print("\n[bold]Raw Path-Like Config[/bold]")
            for key, value in flat.items():
                if _is_pathlike_key(key.split(".")[-1]):
                    print(f"{key:45} = {value}")

            print("\n[bold]Resolved Path-Like Config[/bold]")
            for key, value in flat.items():
                if _is_pathlike_key(key.split(".")[-1]):
                    resolved = _resolve_config_value(key, value, settings)
                    print(f"{key:45} = {resolved}")

            return

        grouped: dict[str, list[tuple[str, Any, str]]] = defaultdict(list)

        for key, value in flat.items():
            if not _is_pathlike_key(key.split(".")[-1]):
                continue

            section = _section_name(key)
            field = _field_name(key)
            resolved = _resolve_config_value(key, value, settings)
            grouped[section].append((field, value, resolved))

        for section, items in grouped.items():
            print(f"\n[bold]{section}[/bold]")
            for field, raw, resolved in sorted(items):
                print(f"{field:20} {str(raw):30} -> {resolved}")


def run() -> None:
    """
    Run the DA CLI with top-level error logging.
    """
    bootstrap_logger = get_context_logger(__name__, app="mindit", command="run")

    try:
        app()
    except Exception:  # pylint: disable=broad-except
        bootstrap_logger.exception(
            "Unhandled CLI error",
            extra={
                "event": "mindit.cli.crash",
                "status": "error",
            },
        )
        raise
