# src/mindit/commands/intake_cli.py

"""`da intake`: move intake through the database - status, hash, set copies aside, undo."""

from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from mindit.config.settings import resolve_database_path
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.dbit.intake_service import (
    PLAN_FIELDS,
    apply_set_aside,
    default_layout,
    folder_prefix,
    hash_candidates,
    intake_status,
    plan_set_aside,
    undo_set_aside,
    write_csv,
)

app = typer.Typer(help="Process intake through the database: status, hash, set copies aside, undo.")
console = Console()

FOLDER_HELP = "Intake subfolder, relative to intake (e.g. photos\\phone-2024) or absolute. Default: all of intake."


def _db(db_path: Optional[Path]) -> DbitService:
    return DbitService(db_path or resolve_database_path())


@app.command("status")
def status(
    depth: int = typer.Option(2, "--depth", help="How many folder levels below intake to group by."),
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    """Show each intake folder's progress: hashed, already in organized, copies within intake."""
    rows = intake_status(_db(db_path), default_layout(), depth)
    table = Table(title="Intake (from the last `da db build`, plus hashes and set-asides since)")
    cols = ("folder", "files", "GB", "photo", "raw", "doc", "video/other", "hashed", "in organized", "copies in intake")
    for col in cols:
        table.add_column(col, justify="left" if col == "folder" else "right")
    for r in rows:
        table.add_row(r["folder"], *(f"{r[k]:,}" for k in ("files", "gb", "photo", "raw", "document", "video_other",
                                                           "hashed", "in_organized", "copies_in_intake")))
    console.print(table)


@app.command("hash")
def hash_cmd(
    folder: Optional[str] = typer.Option(None, "--folder", help=FOLDER_HELP),
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    """Hash the intake files that could be copies (same size as an organized or another intake file)."""
    layout = default_layout()
    prefix = folder_prefix(layout, folder)
    console.print(f"Hashing possible copies under {prefix}")
    stats = hash_candidates(_db(db_path), prefix, progress=lambda m: console.print(f"  {m}"))
    console.print(
        f"Unhashed: {stats.get('unhashed', 0):,}; same size as another file: {stats.get('candidates', 0):,}; "
        f"unhashed organized files that could match: {stats.get('organized_unhashed', 0):,}; "
        f"hashed {stats.get('hashed', 0):,} ({stats.get('bytes', 0) / 1e9:,.1f} GB), "
        f"unreadable {stats.get('unreadable', 0):,} in {stats.get('seconds', 0)}s."
    )


@app.command("set-aside")
def set_aside(
    folder: Optional[str] = typer.Option(None, "--folder", help=FOLDER_HELP),
    apply: bool = typer.Option(False, "--apply", help="Move the files. Without it, only write the plan."),
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    """Set aside intake files already in organized, and extra copies within intake (one copy stays)."""
    layout = default_layout()
    db = _db(db_path)
    prefix = folder_prefix(layout, folder)
    plan = plan_set_aside(db, layout, prefix)
    run = layout.run_dir("set-aside")
    plan_csv = write_csv(run / "plan.csv", plan, PLAN_FIELDS)
    by_class = Counter(p["class"] for p in plan)
    gb = sum(int(p["size_bytes"]) for p in plan) / 1e9
    console.print(f"Plan: {len(plan):,} files ({gb:,.1f} GB) under {prefix}")
    console.print(f"  already in organized: {by_class['in_organized']:,}   extra copies within intake: {by_class['copy_in_intake']:,}")
    console.print(f"  -> {layout.holding_root}")
    console.print(f"  plan: {plan_csv}")
    if not apply:
        console.print("Nothing moved. Re-run with --apply to move them.")
        return
    stats = apply_set_aside(db, plan, run / "moved.csv")
    console.print(f"Moved {stats['moved']:,} files ({stats['bytes'] / 1e9:,.1f} GB). Log: {run / 'moved.csv'}")
    for k, n in sorted(stats.items()):
        if k.startswith("skipped"):
            console.print(f"  {k}: {n:,}")
    console.print(f"Undo: da intake undo \"{run / 'moved.csv'}\"")


@app.command("undo")
def undo(
    log: Path = typer.Argument(..., help="A moved.csv written by `da intake set-aside --apply`."),
    db_path: Optional[Path] = typer.Option(None, "--db-path", help="SQLite database path."),
) -> None:
    """Move everything a set-aside moved back where it came from."""
    stats = undo_set_aside(_db(db_path), log)
    console.print(f"Restored {stats['restored']:,} files; skipped {stats['skipped']:,}.")
