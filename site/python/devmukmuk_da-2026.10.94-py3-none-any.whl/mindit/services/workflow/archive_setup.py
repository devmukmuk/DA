# src/mindit/services/workflow/archive_setup.py

"""Create a Digital Archive in any folder: da-archive.yaml, the folder layout, and a DA.cmd launcher.

A folder that already has files in it (e.g. one you've been copying photos into) can be adopted: its
contents move into intake\\ so the workflow can process them.
"""

from __future__ import annotations

import csv
import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import yaml

from mindit.config.archive import is_archive, register_archive, this_computer
from mindit.config.settings import ARCHIVE_FILE, DEFAULT_INTAKE_FOLDERS

FOLDERS = ("intake", "photos/organized", "documents/organized", "output", "logs")
# Names that belong to an archive; anything else at the top of an adopted folder moves into intake\.
ARCHIVE_ENTRIES = {"intake", "photos", "documents", "output", "logs", "_duplicates-holding", ".da",
                   ARCHIVE_FILE.lower(), "da.cmd", "open da.cmd", "desktop.ini", "thumbs.db",
                   "$recycle.bin", "system volume information"}
# Not "DA.cmd": cmd looks in the current folder first, so `da` typed in the archive (or called by the
# launcher itself) would run the launcher again instead of DA.exe - an endless, silent loop.
LAUNCHER = "Open DA.cmd"
OLD_LAUNCHERS = ("DA.cmd",)
DEFAULT_EXE = r"C:\Scripts\DA\DA.exe"
_YEARS = re.compile(r"^(\d{4})\s*-\s*(\d{4})$")
_YEAR = re.compile(r"^(\d{4})$")
_DECADE = re.compile(r"^(\d{3})[xX]$")                     # 199x: the archives' own naming

ARCHIVE_TEMPLATE = """\
# DA archive: {title}
# This file makes this folder an archive. Double-click "Open DA.cmd" here, or run `da` from inside this folder.
# Paths are relative to this folder.

archive:
  name: {name}
  years: {years}            # capture years this archive takes, e.g. "1990-1999"; others stay in intake
  owner: null               # whose archive it is (shown by `da archives`); else the name before "-archive"
  home: {home}            # the one PC that changes this archive (da archives home); others only look

paths:
  photos: photos              # photos\\organized\\YYYY\\YYYY-MM
  documents: documents        # documents\\organized\\YYYY\\YYYY-MM
  intake: intake              # new files go in one of the intake folders below
  output: output              # reports and run records
  logs: logs

# The folders under intake\\ and what DA files from each. A .jpg/.png/.tif in a "document" folder is
# filed as a scanned document; PDFs and Office files are documents wherever they are.
intake:
  photos: photo
  docs: document
  scans: document

modules:
  photoit:
    organized_root: organized
    pattern: photo_{{date_taken:%Y%m%d_%H%M%S}}_{{hash:4}}
    edits:                    # a photographer's exports (Lightroom, Photoshop): filed beside the RAW they came from
      folder: ''              # '' beside it, or '{{Purpose}}' for a subfolder per purpose (Print, Social Media)
      name: '{{raw}}-{{purpose}}'  # or '{{raw}}-edit{{n}}' (numbered, largest first)
  scanit:
    organized_root: organized
    pattern: doc_{{date_taken:%y%m%d_%H%M%S}}_{{hash:4}}

contact_sheets:
  layout: 3x4                 # pictures per page, columns x rows: 3x4 (bigger) or 4x5 (more per page)

feedback:
  enabled: false
"""

LAUNCHER_TEMPLATE = """\
@echo off
rem Opens a DA console in this archive ({name}). Created by `da setup`.
cd /d "%~dp0"
title DA - {name}
echo Opening DA in {name} ...
set "DA_EXE="
rem DA run by Python (da.cmd) or the DA.exe, found on the PATH only ($PATH:), never the bare name "da"
rem (that would find a launcher in this folder again).
for /f "delims=" %%i in ('where $PATH:da.cmd 2^>nul') do if not defined DA_EXE set "DA_EXE=%%i"
for /f "delims=" %%i in ('where $PATH:DA.exe 2^>nul') do if not defined DA_EXE set "DA_EXE=%%i"
if not defined DA_EXE if exist "C:\\Scripts\\DA\\da.cmd" set "DA_EXE=C:\\Scripts\\DA\\da.cmd"
if not defined DA_EXE if exist "{exe}" set "DA_EXE={exe}"
if not defined DA_EXE (
  echo DA is not installed on this PC. See "Getting started" at https://da.gamenightbymike.com
  pause
  exit /b 1
)
call "%DA_EXE%" menu
echo.
echo   You're in {name}. Type  da  for the menu again, or a command:  da run, da status, da archives
echo.
cmd /k
"""


@dataclass
class TargetState:
    """What's in the folder `da setup` was pointed at."""

    root: Path
    kind: str                                   # "new", "archive" or "folder"
    items: list[Path] = field(default_factory=list)   # top-level entries that would move into intake\


@dataclass
class SetupResult:
    """What setup did."""

    root: Path
    archive_file: Path
    launcher: Path
    created_folders: list[Path]
    moved: list[tuple[Path, Path]]
    skipped: list[tuple[Path, str]]
    move_log: Path | None


def exe_path() -> Path | None:
    """Return the running DA exe, or None when running from source."""
    return Path(sys.executable).resolve() if getattr(sys, "frozen", False) else None


def inspect_target(root: Path) -> TargetState:
    """Say whether root is new, already an archive, or a folder with things in it to adopt."""
    root = Path(root).resolve()
    if is_archive(root):
        return TargetState(root, "archive")
    if not root.exists():
        return TargetState(root, "new")
    items = sorted(p for p in root.iterdir() if p.name.lower() not in ARCHIVE_ENTRIES)
    return TargetState(root, "folder" if items else "new", items)


def parse_years(years: str | None) -> str | None:
    """Return the years an archive takes as "YYYY-YYYY", from 1990-1999, a single year (1999) or a decade (199x)."""
    if not years:
        return None
    text = years.strip()
    if _YEAR.match(text):
        return f"{text}-{text}"
    decade = _DECADE.match(text)
    if decade:
        return f"{decade[1]}0-{decade[1]}9"
    m = _YEARS.match(text)
    if not m or int(m[1]) > int(m[2]):
        raise ValueError(f"years look like 1990-1999, 1999 (one year) or 199x (a decade), not {years!r}")
    return f"{m[1]}-{m[2]}"


def unsuitable(folder: Path) -> str | None:
    """Return why a folder can't be made an archive (a drive's top, Windows, Program Files, your user folder), or None."""
    import os  # pylint: disable=import-outside-toplevel

    root = Path(folder).resolve()
    if root.parent == root:
        return f"{root} is the top of a drive - make a folder for the archive there, e.g. {root / 'jane-archive-199x'}"
    home = Path.home().resolve()
    if root == home:
        return (f"{root} is your user folder - make a folder for the archive, e.g. "
                f"{root / 'Pictures' / 'jane-archive-199x'}")
    for name in ("SystemRoot", "ProgramFiles", "ProgramFiles(x86)", "ProgramData"):
        system = os.environ.get(name)
        if system and (root == Path(system).resolve() or Path(system).resolve() in root.parents):
            return f"{root} is part of Windows or its programs - pick a folder of your own"
    return None


def setup_archive(root: Path, name: str | None = None, years: str | None = None,
                  adopt: bool = True, exe: Path | None = None) -> SetupResult:
    """Make root an archive. An existing archive keeps its settings; a folder's contents move into intake\\.

    Re-running on an archive only adds what's missing (folders, launcher) and keeps da-archive.yaml.
    """
    state = inspect_target(root)
    root = state.root
    years = parse_years(years)
    created = []
    for rel in FOLDERS:
        folder = root / rel
        if not folder.exists():
            folder.mkdir(parents=True)
            created.append(folder)

    moved, skipped, log_path = [], [], None
    if state.kind == "folder" and adopt:
        moved, skipped, log_path = _adopt(root, state.items)

    archive_file = root / ARCHIVE_FILE
    if not archive_file.exists():
        archive_file.write_text(
            ARCHIVE_TEMPLATE.format(title=name or root.name, name=json.dumps(name or root.name),
                                    years=f'"{years}"' if years else "null", home=json.dumps(this_computer())),
            encoding="utf-8")
    elif years or name:
        _update_archive_file(archive_file, name, years)
    for folder in intake_folder_names(archive_file):   # after adopting, so an adopted "scans" isn't skipped
        path = root / "intake" / folder
        if not path.exists():
            path.mkdir(parents=True)
            created.append(path)

    launcher = write_launcher(root, name, exe)
    for old in OLD_LAUNCHERS:                    # an older setup's launcher (it looped; see LAUNCHER)
        old_path = root / old
        if old_path.exists() and "Created by `da setup`" in old_path.read_text(encoding="utf-8", errors="ignore"):
            old_path.unlink()
    register_archive(root)
    return SetupResult(root, archive_file, launcher, created, moved, skipped, log_path)


def write_launcher(root: Path, name: str | None = None, exe: Path | None = None) -> Path:
    """Write (or rewrite) an archive's Open DA.cmd; return it."""
    launcher = Path(root) / LAUNCHER
    launcher.write_text(LAUNCHER_TEMPLATE.format(name=name or Path(root).name, exe=exe or exe_path() or DEFAULT_EXE),
                        encoding="utf-8", newline="\r\n")
    return launcher


def refresh_launchers(archives: list[Path]) -> list[Path]:
    """Rewrite the Open DA.cmd that `da setup` made in each archive (a hand-made one is left alone)."""
    done = []
    for root in archives:
        launcher = Path(root) / LAUNCHER
        try:
            if not launcher.exists() or "Created by `da setup`" not in launcher.read_text(encoding="utf-8",
                                                                                          errors="ignore"):
                continue
            data = yaml.safe_load((Path(root) / ARCHIVE_FILE).read_text(encoding="utf-8")) or {}
            name = str((data.get("archive") or {}).get("name") or "") or None
            done.append(write_launcher(root, name))
        except (OSError, yaml.YAMLError):
            continue
    return done


def intake_folder_names(archive_file: Path) -> list[str]:
    """Return the intake folders an archive file lists, or the defaults when it lists none."""
    try:
        data = yaml.safe_load(archive_file.read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        data = {}
    folders = data.get("intake") if isinstance(data, dict) else None
    return list(folders) if isinstance(folders, dict) and folders else list(DEFAULT_INTAKE_FOLDERS)


def _adopt(root: Path, items: list[Path]) -> tuple[list[tuple[Path, Path]], list[tuple[Path, str]], Path]:
    """Move each top-level item into intake\\ (same drive: a rename), logging every move."""
    intake = root / "intake"
    run_dir = root / "output" / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-setup"
    run_dir.mkdir(parents=True, exist_ok=True)
    log_path = run_dir / "moved.csv"
    moved, skipped = [], []
    with log_path.open("w", newline="", encoding="utf-8") as f:
        log = csv.writer(f)
        log.writerow(["result", "source", "destination", "note"])
        for item in items:
            dest = intake / item.name
            if dest.exists():
                skipped.append((item, "already in intake"))
                log.writerow(["skipped", item, dest, "already in intake"])
                continue
            try:
                os.rename(item, dest)
            except OSError as exc:
                skipped.append((item, str(exc)))
                log.writerow(["skipped", item, dest, str(exc)])
                continue
            moved.append((item, dest))
            log.writerow(["moved", item, dest, ""])
    return moved, skipped, log_path


def undo_adopt(log_path: Path) -> int:
    """Move what an adoption moved into intake\\ back to the top of the archive folder."""
    back = 0
    with Path(log_path).open(encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            src, dst = Path(row["source"]), Path(row["destination"])
            if row["result"] == "moved" and dst.exists() and not src.exists():
                os.rename(dst, src)
                back += 1
    return back


def _update_archive_file(path: Path, name: str | None, years: str | None) -> None:
    text = path.read_text(encoding="utf-8")
    if name:
        text = re.sub(r"(?m)^(\s*name:\s*).*$", lambda m: m[1] + json.dumps(name), text, count=1)
    if years:
        text = re.sub(r"(?m)^(\s*years:\s*)\S+", lambda m: m[1] + f'"{years}"', text, count=1)
    path.write_text(text, encoding="utf-8")
