# src/mindit/services/livephoto/content_id.py

"""Apple's content identifier: the id an iPhone writes into both halves of a Live Photo.

The still (HEIC/JPG) keeps it in Apple's EXIF maker note (tag 0x0011, a UUID); the video keeps the same
UUID in its QuickTime metadata (`video_info` reads that one as `content_id`). Backup apps rename the two
halves, and a second export of the same camera roll names them differently again, but this id stays.
"""

from __future__ import annotations

import re
import struct
from pathlib import Path

_MAKER_NOTE = b"Apple iOS\x00"
_EXIF = b"Exif\x00\x00"
_CONTENT_ID_TAG = 0x0011
_ASCII = 2
_HEAD_BYTES = 512 * 1024            # an iPhone's EXIF sits near the start; read no more than this first
_UUID = re.compile(r"^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$")


def parse_maker_note(note: bytes) -> str | None:
    """Return the content identifier in an Apple maker note (offsets count from the note's start), or None."""
    if not note.startswith(_MAKER_NOTE) or len(note) < 16:
        return None
    order = {b"MM": ">", b"II": "<"}.get(note[12:14])
    if order is None:
        return None
    count = struct.unpack(order + "H", note[14:16])[0]
    for i in range(min(count, 256)):
        entry = note[16 + 12 * i:28 + 12 * i]
        if len(entry) < 12:
            return None
        tag, kind, size, value = struct.unpack(order + "HHI4s", entry)
        if tag != _CONTENT_ID_TAG or kind != _ASCII:
            continue
        raw = value[:size] if size <= 4 else note[struct.unpack(order + "I", value)[0]:][:size]
        text = raw.rstrip(b"\x00").decode("ascii", "ignore")
        return text.upper() if _UUID.match(text) else None
    return None


def still_content_id(path: Path) -> str | None:
    """Return the Live Photo content identifier of a still photo, or None (not an iPhone Live Photo, unreadable)."""
    try:
        with open(path, "rb") as handle:
            head = handle.read(_HEAD_BYTES)
    except OSError:
        return None
    at = head.find(_MAKER_NOTE)
    if at >= 0:
        found = parse_maker_note(head[at:])
        if found:
            return found
    if at < 0 and _EXIF in head:
        return None                         # its EXIF was right there, with no Apple note: not a Live Photo
    return _content_id_by_pillow(path)


def _content_id_by_pillow(path: Path) -> str | None:
    """Return the content identifier through Pillow's EXIF reader (the maker note lies past the first bytes)."""
    from PIL import Image  # pylint: disable=import-outside-toplevel
    from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

    register_heif_opener()
    try:
        with Image.open(path) as image:
            note = image.getexif().get_ifd(0x8769).get(0x927C)
    except Exception:  # pylint: disable=broad-except
        return None
    return parse_maker_note(note) if isinstance(note, bytes) else None
