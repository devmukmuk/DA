# src/mindit/services/dbit/apple_edits.py

"""Apple's edit recipes: .aae and <id>-adjustment.plist files that iPhone backups leave beside photos.

Photos (or Google Photos on an iPhone) keeps an edit as a small property list of adjustments - crop, filter,
light - for re-applying to the original inside that app. It is not a picture: DA would leave it in intake
forever. Where the edit mattered, the backup also exported the finished picture (<id>-photo-full.jpg), which
DA files like any photo.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mindit.services.dbit.dbit_service import DbitService

EXTENSIONS = (".aae", ".plist")
MAX_SIZE = 1 << 20                          # a few KB of settings, never a picture
_MARKER = b"<key>adjustmentData</key>"      # what makes a property list an edit recipe


def is_apple_adjustment(path: Path) -> bool:
    """Return True for a .aae / .plist file that really is an edit recipe (checked by its content, not just its name)."""
    path = Path(path)
    if path.suffix.lower() not in EXTENSIONS:
        return False
    try:
        if path.stat().st_size > MAX_SIZE:
            return False
        with path.open("rb") as f:
            head = f.read(MAX_SIZE)
    except OSError:
        return False
    return head.lstrip().startswith(b"<?xml") and _MARKER in head


def plan_apple_adjustments(db: DbitService, layout: Any, prefix: str) -> list[dict[str, Any]]:
    """Plan moving the edit recipes under prefix into holding (class apple_adjustment, nothing kept to check)."""
    db.initialize(log=False)
    with db.connect() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT path, size_bytes, sha256 FROM files WHERE area = 'intake' AND lower(extension) IN ('.aae', '.plist') "
            "ORDER BY path")]
    plan = []
    for r in rows:
        src = Path(r["path"])
        if not r["path"].startswith(prefix) or not is_apple_adjustment(src):
            continue
        plan.append({
            "class": "apple_adjustment", "source": r["path"],
            "destination": str(layout.holding_root / src.relative_to(layout.data_root)),
            "size_bytes": r["size_bytes"], "sha256": r["sha256"] or "", "kept": "",
            "source_mtime": src.stat().st_mtime, "note": "an Apple Photos edit recipe (.aae / adjustment plist), not a photo",
        })
    return plan
