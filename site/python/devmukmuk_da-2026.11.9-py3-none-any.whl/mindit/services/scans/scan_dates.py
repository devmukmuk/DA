﻿# src/mindit/services/scans/scan_dates.py

"""Whether a picture is a scan, and the dates DA can be sure of for one.

A scan (a picture in an intake folder of kind `scanphoto`, or from a scanner in cameras.json) never takes its own date
as its taken date: that's when it was scanned. Its date comes from a date set by hand, a date typed into it before, its
name, or the folders it came in from (`folder_date`: from-W-1998 \\ 06-15 Party -> 1998-06-15); a date on or after the
year it was scanned is the scanning date and is skipped. It files with a month at least; a year alone leaves it for
review.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path, PurePath, PureWindowsPath
from typing import Any

SCAN_BLOCK = "scan"
# Folder levels that name the scanning, not the photos: "2023-04-22scanned date", "Box 3", "check dates".
_SCANNING_WORDS = ("scan", "box", "check", "need", "backup", "copies")
_YEAR_MONTH = re.compile(r"(?<!\d)(?P<y>19\d{2}|20\d{2})[-_. ](?P<m>0[1-9]|1[0-2])(?![\d])")
_MONTH_DAY_FIRST = re.compile(r"^\s*(?P<m>0?[1-9]|1[0-2])[-_.](?P<d>0?[1-9]|[12]\d|3[01])(?![\d])")
_MONTH_FIRST = re.compile(r"^\s*(?P<m>0[1-9]|1[0-2])(?=\s|$|[-_ ][A-Za-z])")
_DRIVE_LABEL = re.compile(r"^[A-Za-z]-")               # import's from-<drive>-<folder>: from-W-1998
# A name a scanning app (or a phone) gave it: the date in it is when it was scanned. Document_20210305_0010.jpg
_SCAN_APP_NAME = re.compile(r"^(?:document|doc|scan(?:ned)?|img|image|pxl)[ _-]?(?:19|20)\d{6}"
                            r"|[ _-](?:19|20)\d{6}[ _-]\d{3,4}$", re.IGNORECASE)        # ..._20210303_0009
# A home scanner's own date before this is a date someone typed in, not when it was scanned.
_FIRST_SCANNING_YEAR = 1995


@dataclass(frozen=True)
class Found:
    """A date and how much of it is known: 'day', 'month' or 'year'."""

    value: datetime
    precision: str
    where: str                                          # the name or folder it came from


def load(path: Path) -> dict[str, Any]:
    """Return a file's sidecar, or {} (no sidecar, or one DA can't read)."""
    side = Path(f"{path}.meta.json")
    try:
        return json.loads(side.read_text(encoding="utf-8")) if side.exists() else {}
    except (OSError, ValueError):
        return {}


def _intake_kind(path: Path, data: dict[str, Any]) -> str | None:
    """Return the kind of the intake folder the file is in, or came in through (sidecar origin)."""
    try:
        from mindit.config.settings import get_intake_folders, load_settings  # pylint: disable=import-outside-toplevel

        folders = get_intake_folders()
        named = load_settings().intake
    except Exception:  # pylint: disable=broad-except
        return None
    resolved = Path(path).resolve()
    for folder, kind in folders.items():
        if resolved.is_relative_to(folder):
            return kind
    origin = data.get("origin") if isinstance(data.get("origin"), dict) else {}
    return named.get(str(origin.get("intake") or "")) if origin.get("intake") else None


def _exif_camera(path: Path) -> dict[str, Any] | None:
    """Return make and model from the picture's EXIF (the sidecar has no camera block yet), or None."""
    try:
        from PIL import Image  # pylint: disable=import-outside-toplevel

        with Image.open(path) as img:
            exif = img.getexif()
    except Exception:  # pylint: disable=broad-except
        return None
    make, model = exif.get(271), exif.get(272)
    return {"make": str(make).strip("\x00 ") if make else None,
            "model": str(model).strip("\x00 ") if model else None} if (make or model) else None


def camera_of(path: Path, data: dict[str, Any]) -> dict[str, Any] | None:
    """Return the camera block (the sidecar's, else make/model read from the picture)."""
    info = data.get("camera") if isinstance(data.get("camera"), dict) else None
    if info is not None:
        return info
    from mindit.services.validateit.validateit_file_types import PHOTO_EXTENSIONS  # pylint: disable=import-outside-toplevel

    return _exif_camera(path) if Path(path).suffix.lower() in PHOTO_EXTENSIONS else None


def why_a_scan(path: Path, data: dict[str, Any] | None = None) -> str | None:
    """Return why the picture is a scan ('intake folder', 'scanner Gcmc RODFS70'), or None when it isn't one."""
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    data = load(path) if data is None else data
    info = camera_of(path, data)
    listed = cams.current()
    if info and listed.rule(info) == "scanned":
        return f"scanner {cams.name_of(info)}"
    if info and cams.name_of(info) and listed.kind(info) in ("camera", "phone"):
        return None                                     # a camera's own photo keeps its date, wherever it is
    block = data.get(SCAN_BLOCK)
    if isinstance(block, dict):
        return str(block.get("why") or "scan")
    if _intake_kind(path, data) == "scanphoto":
        return "intake folder"
    return None


def scan_block(path: Path, data: dict[str, Any]) -> dict[str, Any] | None:
    """Return the `scan` block for a new sidecar ({why, scanner, scanned_at}), or None for a picture that isn't a scan."""
    why = why_a_scan(path, data)
    if why is None:
        return None
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    info = camera_of(path, data) or {}
    return {"why": why, "scanner": cams.name_of(info), "scanned_at": scanned_at(path, data)}


def _exif_dates(path: Path) -> tuple[datetime | None, datetime | None]:
    """Return EXIF (date taken, date saved): DateTimeOriginal and DateTime, either None when missing or unset."""
    try:
        from PIL import Image  # pylint: disable=import-outside-toplevel

        with Image.open(path) as img:
            exif = img.getexif()
            taken = exif.get_ifd(0x8769).get(36867) if exif else None
            saved = exif.get(306) if exif else None
    except Exception:  # pylint: disable=broad-except
        return None, None

    def when(raw: Any) -> datetime | None:
        try:
            value = datetime.strptime(str(raw).strip("\x00 ")[:19], "%Y:%m:%d %H:%M:%S")
        except (TypeError, ValueError):
            return None
        return None if value.year <= 1970 or value > datetime.now() else value

    return when(taken), when(saved)


def taken_set_by_hand(path: Path, data: dict[str, Any]) -> datetime | None:
    """Return a scan's date taken when a person set it - from before the scanner was used (its cameras.json years,
    else before home scanners) - else None. A later date is when it was scanned, even if it was edited since."""
    if not Path(path).exists():
        return None
    taken, saved = _exif_dates(Path(path))
    if taken is None:
        return None
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    row = cams.current().of(camera_of(path, data))
    years = cams.parse_years(row.get("years")) if row and row.get("type") == "scanner" and row.get("years") else None
    if years:
        return taken if taken.year < years[0] else None
    if saved is not None and (saved - taken).days < 2:
        return None                                     # saved when taken: the scanner's own clock
    return taken if taken.year < _FIRST_SCANNING_YEAR else None


def scanned_at(path: Path, data: dict[str, Any]) -> str | None:
    """Return when it was scanned (its saved date, else its own date unless a person set that), as ISO text, or None."""
    block = data.get(SCAN_BLOCK) if isinstance(data.get(SCAN_BLOCK), dict) else {}
    if block.get("scanned_at"):
        return str(block["scanned_at"])
    if not Path(path).exists():
        return None
    taken, saved = _exif_dates(Path(path))
    value = saved or (None if taken_set_by_hand(path, data) else taken)
    return value.isoformat(timespec="seconds") if value else None


# --------------------------------------------------------------------------- dates in names and folders

def _parts(text: str) -> list[str]:
    pure: PurePath = PureWindowsPath(text) if ("\\" in text or ":" in text) else PurePath(text)
    return list(pure.parts)


def came_through(path: Path, data: dict[str, Any]) -> list[str]:
    """Return the folders under intake\\<kind> it came in through, top first (import labels like from-W-1998 kept)."""
    file_block = data.get("file") if isinstance(data.get("file"), dict) else {}
    for candidate in (str(file_block.get("source_path") or ""), str(path)):
        parts = _parts(candidate) if candidate else []
        lower = [p.lower() for p in parts]
        if "intake" in lower:
            i = lower.index("intake")
            return parts[i + 2:-1]
    origin = data.get("origin") if isinstance(data.get("origin"), dict) else {}
    return [str(f) for f in origin.get("folders") or []]


def _scanning(level: str, extra: tuple[str, ...]) -> bool:
    lowered = level.lower()
    return any(word in lowered for word in (*_SCANNING_WORDS, *extra))


def _plain(level: str) -> str:
    """Return a folder level without an import label's from-<drive>- (from-W-1998 -> 1998)."""
    if level.lower().startswith("from-"):
        rest = level[5:]
        return "" if "archive" in rest.lower() else _DRIVE_LABEL.sub("", rest)
    return level


def date_in(text: str, now: datetime) -> Found | None:
    """Return the fullest date in a name or folder name: a day, a month, or a year."""
    from mindit.services.validateit import capture_date as cd  # pylint: disable=import-outside-toplevel

    value, _has_time = cd._filename_full_date(text, now)  # pylint: disable=protected-access
    if value is not None:
        return Found(value, "day", text)
    month = cd._filename_month(text, now)  # pylint: disable=protected-access
    if month is None:
        m = _YEAR_MONTH.search(text)
        month = (int(m["y"]), int(m["m"])) if m and 1900 <= int(m["y"]) <= now.year else None
    if month is not None:
        return Found(datetime(month[0], month[1], 1), "month", text)
    year = cd._filename_year(text, now)  # pylint: disable=protected-access
    return Found(datetime(year, 1, 1), "year", text) if year else None


def folder_date(levels: list[str], now: datetime | None = None, extra_skip: tuple[str, ...] = ()) -> Found | None:
    """Return the date the folders give, top to bottom: a later level's date wins; 'MM-DD ...' adds to a year above."""
    now = now or datetime.now()
    found: Found | None = None
    for raw in levels:
        level = _plain(raw)
        if not level.strip() or _scanning(level, extra_skip):
            continue
        here = date_in(level, now)
        if here is not None:
            if found is None or here.precision != "year" or found.value.year != here.value.year:
                found = Found(here.value, here.precision, raw)
            elif found.precision == "year":
                found = Found(found.value, "year", raw)     # the same year, named by a closer folder
            continue
        if found is not None and found.precision == "year":
            m = _MONTH_DAY_FIRST.match(level)
            try:
                if m:
                    found = Found(datetime(found.value.year, int(m["m"]), int(m["d"])), "day", raw)
                elif _MONTH_FIRST.match(level):
                    found = Found(datetime(found.value.year, int(_MONTH_FIRST.match(level)["m"]), 1), "month", raw)
            except ValueError:
                pass
    return found


def scan_date(path: Path, data: dict[str, Any], now: datetime | None = None,
              extra_skip: tuple[str, ...] = ()) -> Found | None:
    """Return a scan's date from its name, else its folders (a date from the year it was scanned on is skipped)."""
    now = now or datetime.now()
    scanned = scanned_at(path, data)
    years = [int(scanned[:4])] if scanned and scanned[:4].isdigit() else []
    try:
        years.append(datetime.fromtimestamp(Path(path).stat().st_mtime).year)   # the print is older than its file
    except (OSError, ValueError, OverflowError):
        pass
    ceiling = min(years) if years else None

    def usable(found: Found | None) -> Found | None:
        return found if found is not None and (ceiling is None or found.value.year < ceiling) else None

    def named_by_a_person(stem: str) -> Found | None:
        return None if _SCAN_APP_NAME.match(stem) else usable(date_in(stem, now))

    origin = data.get("origin") if isinstance(data.get("origin"), dict) else {}
    named = named_by_a_person(Path(path).stem) or named_by_a_person(Path(str(origin.get("file_name") or "")).stem)
    if named is not None and named.precision != "year":
        return named
    folders = usable(folder_date(came_through(path, data), now, extra_skip))
    if folders is not None and (named is None or folders.precision != "year"):
        return folders
    return named or folders


def skip_words() -> tuple[str, ...]:
    """Return da-archive.yaml's origin: skip: names, as extra words that mark a scanning folder."""
    try:
        from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

        return tuple(s.strip("*?").lower() for s in load_settings().origin.skip or [] if s.strip("*?"))
    except Exception:  # pylint: disable=broad-except
        return ()
