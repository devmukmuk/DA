# src/mindit/services/validateit/capture_date.py

"""Resolve a file's capture date and how much to trust it."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import StrEnum
from pathlib import Path

from mindit.services.photoit.photoit_workflows import _read_exif_capture_datetime
from mindit.services.validateit.document_dates import DOCUMENT_DATE_EXTENSIONS, read_document_date
from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS
from mindit.utils.timestamps import UNREADABLE_FILE_TIME, safe_fromtimestamp


class CaptureDateSource(StrEnum):
    USER = "user"                      # set by hand (da date set / shift): wins over everything
    TEMPLATE = "template"              # printed on a document a template read (da run --template)
    FILENAME = "filename"
    EXIF = "exif"
    DOCUMENT = "document"              # the creation date stored inside a PDF / Office file
    VIDEO = "video"                    # when a video was recorded, from the video file itself
    FILENAME_MONTH = "filename_month"
    FILENAME_YEAR = "filename_year"
    MODIFIED_TIME = "modified_time"
    # A scanned print (docs/da-docs/SCANS-DESIGN.md): its own date is when it was scanned, never used.
    SCAN_NAME = "scan_name"            # a day or a month in a scan's name
    FOLDER = "folder"                  # a day or a month from the folders a scan came in from
    SCAN_YEAR = "scan_year"            # only a year (name, folders, or set by hand): it waits for a month
    SCANNED = "scanned"                # nothing but the day it was scanned


# Only these sources are trusted enough to rename or move a file automatically.
CERTAIN_SOURCES = {CaptureDateSource.USER, CaptureDateSource.TEMPLATE, CaptureDateSource.FILENAME, CaptureDateSource.EXIF, CaptureDateSource.DOCUMENT,
                   CaptureDateSource.VIDEO, CaptureDateSource.SCAN_NAME, CaptureDateSource.FOLDER}


@dataclass(frozen=True, slots=True)
class CaptureDate:
    value: datetime
    source: CaptureDateSource

    @property
    def certain(self) -> bool:
        return self.source in CERTAIN_SOURCES


# 2021_01_14, 2021-01-14, 20210114, optionally followed by a time: 20210201_094024.
_FULL_DATE = re.compile(
    r"(?<!\d)(?P<y>19\d{2}|20\d{2})[-_.]?(?P<m>0[1-9]|1[0-2])[-_.]?(?P<d>0[1-9]|[12]\d|3[01])"
    r"(?:[ _T-]?(?P<H>[01]\d|2[0-3])[-_.:]?(?P<M>[0-5]\d)[-_.:]?(?P<S>[0-5]\d))?(?!\d)"
)

# yymmdd_hhmmss, as in ScanIt's own doc_210203_140935_d7e9.pdf names. The time is required so
# arbitrary six-digit numbers aren't read as dates.
_SHORT_DATE_TIME = re.compile(
    r"(?<!\d)(?P<y>\d{2})(?P<m>0[1-9]|1[0-2])(?P<d>0[1-9]|[12]\d|3[01])"
    r"_(?P<H>[01]\d|2[0-3])(?P<M>[0-5]\d)(?P<S>[0-5]\d)(?!\d)"
)

# US-style month-day-year: 04-27-2010, 4.27.2010 (a date, no time).
_US_DATE = re.compile(
    r"(?<!\d)(?P<m>0?[1-9]|1[0-2])[-_.](?P<d>0?[1-9]|[12]\d|3[01])[-_.](?P<y>19\d{2}|20\d{2})(?!\d)"
)

# US-style with a two-digit year and dashes: 01-11-09, 2-9-09 (a letter's or journal's name).
_US_SHORT_DATE = re.compile(
    r"(?<![\d-])(?P<m>0?[1-9]|1[0-2])-(?P<d>0?[1-9]|[12]\d|3[01])-(?P<y>\d{2})(?![\d-])"
)

_MONTH_NAME = (r"(?P<mon>jan(?:uary)?|feb(?:ruary|urary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?"
               r"|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)")

# A month name, a day and a year: January 4th 2009, FEBURARY 13th 2009, Jan 5 through the 10th 2009.
_MONTH_DAY_YEAR = re.compile(
    r"(?<![A-Za-z])" + _MONTH_NAME + r"\.?[ _-]+(?P<d>0?[1-9]|[12]\d|3[01])(?:st|nd|rd|th)?(?![\d])"
    r"[^\d]{0,25}?(?:\d{1,2}(?:st|nd|rd|th)[^\d]{0,5}?)?[ ,_-]*(?P<y>19\d{2}|20\d{2})(?!\d)",
    re.IGNORECASE,
)

# A month name and a year: April-2010, Apr 2010, "Resume, April 2010".
_MONTH_YEAR = re.compile(
    r"(?<![A-Za-z])(?P<mon>jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?"
    r"|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)(?![A-Za-z])[-_ .,]*"
    r"(?P<y>19\d{2}|20\d{2})(?!\d)",
    re.IGNORECASE,
)
_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

# Default dates cameras write when their clock was never set. Treated as no EXIF date at all.
_UNSET_CAMERA_CLOCKS = {datetime(1970, 1, 1), datetime(1980, 1, 1)}

_BARE_YEAR = re.compile(r"(?<!\d)(?P<y>19\d{2}|20\d{2})(?!\d)")

# A camera's own name starts with a frame counter (IMG_1900.CR2, DSC_2014.NEF), not a year.
_CAMERA_COUNTER = re.compile(
    r"^(?:IMG_E?|_MG_|MVI_|DSC_?|_DSC|DSCN|DSCF|SAM_|DCP_?|PICT|CIMG|IMAG|HPIM|GOPR|DJI_|SDC|KIF_|CRW_)(?=\d{4}(?!\d))",
    re.IGNORECASE,
)
# A prefix the photographer set on the camera (Canon's "8W9A1900"): four letters/digits, at least one a digit,
# then the 4-digit frame number.
_CUSTOM_COUNTER = re.compile(r"^(?=[A-Z_]{0,3}\d)[A-Z0-9_]{4}(?=\d{4}(?!\d))")

# A backup app's asset id (11ee30fb1950a6c3-photo.JPG) or a UUID's tail: 12+ hex characters with both a digit and a
# letter a-f. Its digits are not a date ("1950", "19971124"), so the name readers below never look inside one.
_HEX_ID = re.compile(r"(?<![0-9A-Za-z])(?=[0-9A-Fa-f]*[A-Fa-f])(?=[0-9A-Fa-f]*\d)[0-9A-Fa-f]{12,}(?![0-9A-Za-z])")


def _without_ids(stem: str) -> str:
    """Return the name with each hex asset id blanked out (same length, so positions in the name still line up)."""
    return _HEX_ID.sub(lambda m: "_" * len(m.group()), stem)


def resolve_capture_date(path: Path, now: datetime | None = None) -> CaptureDate:
    """Return the best capture date for path, with the source it came from.

    Order: a date set by hand (`da date`), then a full date in the file name, then EXIF, then a bare year in the file name, then
    the file's modified time. A name with a date but no time (2022-05-11_EASTOW_1711.jpg)
    gives way to EXIF from that same day, which has the time too. A bare year that
    disagrees with EXIF wins over EXIF, because that is usually an old photo scanned or
    edited years later.
    """
    now = now or datetime.now()
    stem = path.stem

    # A date set by hand (`da date`) is kept in the sidecar and wins over everything.
    from mindit.services.dates.user_dates import read_user_date  # pylint: disable=import-outside-toplevel

    by_hand = read_user_date(path)
    is_document = path.suffix.lower() in DOCUMENT_DATE_EXTENSIONS
    is_video = path.suffix.lower() in VIDEO_EXTENSIONS
    scan = None if is_document or is_video else _scan(path)
    if by_hand is not None:
        precision = _precision(path, scan)
        if precision == "decade" or (scan is not None and precision == "year"):
            return CaptureDate(by_hand, CaptureDateSource.SCAN_YEAR)    # a decade never files; a scan needs a month
        return CaptureDate(by_hand, CaptureDateSource.USER)

    # A document a template read (`da run --template`): the date printed on it (a bill's date).
    from mindit.services.templates.template import read_template_date  # pylint: disable=import-outside-toplevel

    printed = read_template_date(path)
    if printed is not None:
        return CaptureDate(printed, CaptureDateSource.TEMPLATE)

    if scan is not None:                        # a scanned print: its own date is when it was scanned
        return _scan_capture(path, scan[0], now)

    # The date inside the file: EXIF for photos, the stored creation date for PDF / Office files.
    inside_source = (CaptureDateSource.DOCUMENT if is_document else
                     CaptureDateSource.VIDEO if is_video else CaptureDateSource.EXIF)

    filename_date, has_time = _filename_full_date(stem, now)
    exif_date = None
    if filename_date is not None and not has_time:
        exif_date = _inside_date(path, now, is_document)
        if exif_date is not None and exif_date.date() == filename_date.date():
            return CaptureDate(exif_date, inside_source)
    if filename_date is not None:
        return CaptureDate(filename_date, CaptureDateSource.FILENAME)

    exif_date = exif_date or _inside_date(path, now, is_document)
    if exif_date is not None and inside_source == CaptureDateSource.EXIF:
        exif_date = _camera_rule(path, exif_date)       # cameras.json: a clock that was off, or not to be trusted

    month = _filename_month(stem, now)
    if month is not None:
        # "Resume April-2010": the date inside wins when it's from that month, else only the month is known.
        if exif_date is not None and (exif_date.year, exif_date.month) == month:
            return CaptureDate(exif_date, inside_source)
        return CaptureDate(datetime(month[0], month[1], 1), CaptureDateSource.FILENAME_MONTH)

    year = _filename_year(stem, now)

    if exif_date is not None and (year is None or year == exif_date.year):
        return CaptureDate(exif_date, inside_source)

    if year is not None:
        return CaptureDate(datetime(year, 1, 1), CaptureDateSource.FILENAME_YEAR)

    modified = safe_fromtimestamp(path.stat().st_mtime)
    return CaptureDate(modified or UNREADABLE_FILE_TIME, CaptureDateSource.MODIFIED_TIME)


def _precision(path: Path, scan: tuple[dict, str] | None) -> str | None:
    """Return how precise the date set by hand is (year, decade, ...), from the sidecar already read when there is one."""
    from mindit.services.scans.scan_dates import load  # pylint: disable=import-outside-toplevel

    data = scan[0] if scan is not None else load(path)
    user = data.get("user") if isinstance(data.get("user"), dict) else {}
    return user.get("date_precision")


def _scan(path: Path) -> tuple[dict, str] | None:
    """Return (sidecar, why) when the picture is a scanned print, else None."""
    from mindit.services.scans.scan_dates import load, why_a_scan  # pylint: disable=import-outside-toplevel

    data = load(path)
    why = why_a_scan(path, data)
    return (data, why) if why else None


def _scan_capture(path: Path, data: dict, now: datetime) -> CaptureDate:
    """Return a scan's date: a day or a month from its name or folders; a year waits; else the day it was scanned."""
    from mindit.services.scans.scan_dates import scan_date, scanned_at, skip_words, taken_set_by_hand  # pylint: disable=import-outside-toplevel

    typed = taken_set_by_hand(path, data)               # a date someone typed into the scan (Windows, Picasa)
    if typed is not None and _plausible(typed, now):
        return CaptureDate(typed, CaptureDateSource.EXIF)
    found = scan_date(path, data, now, skip_words())
    if found is not None and found.precision != "year":
        named = found.where in (path.stem, Path(str((data.get("origin") or {}).get("file_name") or "")).stem)
        return CaptureDate(found.value, CaptureDateSource.SCAN_NAME if named else CaptureDateSource.FOLDER)
    if found is not None:
        return CaptureDate(found.value, CaptureDateSource.SCAN_YEAR)
    scanned = scanned_at(path, data)
    try:
        value = datetime.fromisoformat(scanned) if scanned else None
    except ValueError:
        value = None
    if value is None:
        value = safe_fromtimestamp(path.stat().st_mtime) or UNREADABLE_FILE_TIME
    return CaptureDate(value, CaptureDateSource.SCANNED)


def _camera_rule(path: Path, value: datetime) -> datetime | None:
    """Return the EXIF date as the camera's cameras.json rule reads it: as is, shifted, or None (not to be trusted)."""
    from mindit.services.scans import cameras as cams  # pylint: disable=import-outside-toplevel

    listed = cams.current()
    if not listed.rows:
        return value
    from mindit.services.scans.scan_dates import camera_of, load  # pylint: disable=import-outside-toplevel

    rule = listed.rule(camera_of(path, load(path)))
    if rule == "none":
        return None
    if rule.startswith("shift "):
        from mindit.services.dates.user_dates import parse_shift  # pylint: disable=import-outside-toplevel

        return parse_shift(rule[6:]).apply(value)
    return value


def describe(capture: CaptureDate) -> str:
    """Return a short human description of an uncertain capture date."""
    if capture.source == CaptureDateSource.SCAN_YEAR:
        return f"only a year or a decade ({capture.value.year}) is known, so it waits for a month"
    if capture.source == CaptureDateSource.SCANNED:
        return f"a scanned print with no date of its own (scanned {capture.value:%Y-%m-%d})"
    if capture.source == CaptureDateSource.FILENAME_YEAR:
        return f"only a year ({capture.value.year}) is known, from the file name"
    if capture.source == CaptureDateSource.FILENAME_MONTH:
        return f"only a month ({capture.value:%B %Y}) is known, from the file name"
    if capture.source == CaptureDateSource.MODIFIED_TIME and capture.value == UNREADABLE_FILE_TIME:
        return "no date in the file or its name, and its modified time can't be read"
    if capture.source == CaptureDateSource.MODIFIED_TIME:
        return (
            f"no date in the file or its name; modified time "
            f"{capture.value:%Y-%m-%d %H:%M} is probably when it was copied"
        )
    return f"{capture.value:%Y-%m-%d %H:%M:%S} from {capture.source}"


def _filename_full_date(stem: str, now: datetime) -> tuple[datetime | None, bool]:
    """Return the first plausible date in the name and whether it included a time."""
    stem = _without_ids(stem)
    for pattern, short_year in ((_FULL_DATE, False), (_SHORT_DATE_TIME, True), (_US_DATE, False),
                                (_MONTH_DAY_YEAR, False), (_US_SHORT_DATE, True)):
        for match in pattern.finditer(stem):
            parts = match.groupdict()
            year = int(parts["y"])
            if short_year:
                year += 2000 if 2000 + year <= now.year else 1900
            month = _MONTHS[parts["mon"].lower()[:3]] if parts.get("mon") else int(parts["m"])

            try:
                value = datetime(
                    year,
                    month,
                    int(parts["d"]),
                    int(parts.get("H") or 0),
                    int(parts.get("M") or 0),
                    int(parts.get("S") or 0),
                )
            except ValueError:
                continue

            if _plausible(value, now):
                return value, parts.get("H") is not None
    return None, False


def name_and_exif_taken(path: Path, now: datetime | None = None) -> tuple[datetime, datetime] | None:
    """Return (date+time in the name, EXIF date taken) when both exist and disagree, else None.

    Only a name with a full date and time counts (a DA photo_YYYYMMDD_HHMMSS_ name), and
    only EXIF's date-taken fields, not "last saved", which changes on every edit.
    """
    now = now or datetime.now()
    named, has_time = _filename_full_date(path.stem, now)
    if named is None or not has_time:
        return None
    raw = _read_exif_capture_datetime(path, include_last_saved=False)
    if not raw:
        return None
    try:
        taken = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if not _plausible(taken, now) or taken == named:
        return None
    return named, taken


_DATE_HHMM = re.compile(r"(?<!\d)(?P<y>19\d{2}|20\d{2})(?P<m>0[1-9]|1[0-2])(?P<d>0[1-9]|[12]\d|3[01])"
                        r"[-_ ](?P<H>[01]\d|2[0-3])(?P<M>[0-5]\d)(?!\d)")


def _name_date_hhmm(stem: str, now: datetime) -> datetime | None:
    """Return the date and hour-minute in a phone video's name (VID 00000-20091016-2017), or None."""
    m = _DATE_HHMM.search(_without_ids(stem))
    if not m:
        return None
    try:
        value = datetime(*(int(m[k]) for k in ("y", "m", "d", "H", "M")))
    except ValueError:
        return None
    return value if _plausible(value, now) else None


def _filename_year(stem: str, now: datetime) -> int | None:
    stem = _without_ids(stem)
    counter = _CAMERA_COUNTER.match(stem) or _CUSTOM_COUNTER.match(stem)
    for match in _BARE_YEAR.finditer(stem):
        if counter and match.start() == counter.end():
            continue                     # IMG_1900: the camera's frame number
        year = int(match["y"])
        if 1900 <= year <= now.year:
            return year
    return None


def _filename_month(stem: str, now: datetime) -> tuple[int, int] | None:
    """Return (year, month) for a month name and year in the name ("April-2010"), or None."""
    for match in _MONTH_YEAR.finditer(_without_ids(stem)):
        year, month = int(match["y"]), _MONTHS[match["mon"].lower()[:3]]
        if 1900 <= year <= now.year:
            return year, month
    return None


def _inside_date(path: Path, now: datetime, is_document: bool) -> datetime | None:
    """The date stored inside the file: a document's creation date, a video's recording date, else EXIF."""
    if path.suffix.lower() in VIDEO_EXTENSIONS:
        from mindit.services.video.video_info import read_video_info, recorded_at, utc_only  # pylint: disable=import-outside-toplevel

        info = read_video_info(path)
        value = recorded_at(info, now)
        named = _name_date_hhmm(path.stem, now)
        # A UTC header time was turned into local time with THIS PC's time zone; a phone's name
        # (VID 00000-20091016-2017) has the local time where it was recorded. Same day or so: the name wins.
        if value is not None and named is not None and utc_only(info) and abs(value - named) < timedelta(hours=26):
            return named.replace(second=value.second)
        return value
    if not is_document:
        return _exif_date(path, now)
    value = read_document_date(path)
    if value is None or value in _UNSET_CAMERA_CLOCKS:
        return None
    return value if _plausible(value, now) else None


def _exif_date(path: Path, now: datetime) -> datetime | None:
    raw = _read_exif_capture_datetime(path)
    if not raw:
        return None

    try:
        value = datetime.fromisoformat(raw)
    except ValueError:
        return None

    if value in _UNSET_CAMERA_CLOCKS:
        return None                      # a camera whose clock was never set, not a real date
    return value if _plausible(value, now) else None


def _plausible(value: datetime, now: datetime) -> bool:
    return datetime(1900, 1, 1) <= value <= now
