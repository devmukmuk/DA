# src/mindit/services/workflow/run_workflow.py

"""`da run`: the whole intake workflow for one folder, step by step, with a record of every step."""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit import __version__
from mindit.core.progress import NullProgressReporter, ProgressReporter
from mindit.services.contactsheet.contact_sheet import refresh_sheets
from mindit.services.dbit.archive_index_service import Area, ArchiveIndexService, default_areas
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.dbit.intake_service import (
    PLAN_FIELDS,
    Layout,
    apply_set_aside,
    folder_prefix,
    hash_candidates,
    plan_set_aside,
    write_csv,
)
from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider
from mindit.services.validateit.scanit_repair_provider import ScanItRepairProvider
from mindit.services.validateit.validateit_file_types import MediaClassifier, MediaKind
from mindit.services.validateit.validateit_models import RepairActionType, ValidationMode
from mindit.services.validateit.validateit_reports import write_validation_report
from mindit.services.validateit.validateit_repair_providers import RepairProviderRegistry
from mindit.services.validateit.video_repair_provider import VideoRepairProvider
from mindit.services.validateit.validateit_service import ValidateItService
from mindit.services.workflow.checks import check_plan, check_report, load_report, verify_report

Say = Callable[[str], None]
Ask = Callable[[str], bool]


@dataclass
class RunRecord:
    """Everything one `da run` did, saved as summary.json in its run folder."""

    folder: str
    run_dir: str
    started_at: str
    steps: dict[str, Any] = field(default_factory=dict)
    stopped_at_step: str | None = None
    finished_at: str | None = None

    def save(self) -> Path:
        path = Path(self.run_dir) / "summary.json"
        path.write_text(json.dumps(self.__dict__, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        if self.finished_at:                          # once, at the end (save() also runs after each step)
            from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

            filed = ((self.steps.get("6_file") or {}).get("verify") or {}).get("moved", 0)
            log_event("run", f"run of {self.folder}: "
                      + (f"stopped at {self.stopped_at_step}" if self.stopped_at_step else f"filed {filed}")
                      + f" (summary: {path})", path=str(path))
        return path


def free_intake_name(intake: Path, name: str) -> Path:
    """Return intake\\name, or intake\\name-2, -3 ... when that's taken."""
    dest, n = intake / name, 1
    while dest.exists():
        n += 1
        dest = intake / f"{name}-{n}"
    return dest


def copy_into_intake(source: Path, dest: Path) -> int:
    """Copy a folder from outside the archive into intake (sidecars left behind; DA makes fresh ones)."""
    shutil.copytree(source, dest, copy_function=shutil.copy2, ignore=shutil.ignore_patterns("*.meta.json"))
    return sum(1 for _, _, files in os.walk(dest) for _f in files)


def filed_folders(state) -> set[Path]:
    """Return the folders a repair moved or renamed files into (each gets a contact sheet)."""
    kinds = {RepairActionType.MOVE_FILE, RepairActionType.RENAME_FILE, RepairActionType.MOVE_RAW_COMPANION}
    return {Path(a.target_path).parent for a in state.repair_actions
            if a.executed and a.target_path and a.action_type in kinds}


def left_folders(state, layout: Layout) -> set[Path]:
    """Return the folders outside intake that a repair moved files out of (filed files given a new folder)."""
    kinds = {RepairActionType.MOVE_FILE, RepairActionType.MOVE_RAW_COMPANION}
    intake = Path(layout.intake_root).resolve()
    return {Path(a.source_path).parent for a in state.repair_actions
            if a.executed and a.source_path and a.action_type in kinds
            and not Path(a.source_path).resolve().is_relative_to(intake)}


def _validator(kind: str | None) -> ValidateItService:
    return ValidateItService(
        repair_provider_registry=RepairProviderRegistry(providers=[PhotoItRepairProvider(), ScanItRepairProvider(),
                                                                    VideoRepairProvider()]),
        # No kind: an image is what its intake folder says (intake\scans: document), else a photo.
        media_classifier=MediaClassifier(force_kind=MediaKind(kind) if kind else None, default_kind=MediaKind.PHOTO),
    )


def run_workflow(
    folder: Path,
    db: DbitService,
    layout: Layout,
    areas: list[Area] | None = None,
    kind: str | None = None,
    say: Say = print,
    ask: Ask = lambda question: True,
    progress: ProgressReporter | None = None,
    after: Callable[[list[Path]], dict[str, Any]] | None = None,
    templates: list[Any] | None = None,
    reader: Any | None = None,
    skip: list[str] | None = None,
    date: str | None = None,
) -> RunRecord:
    """Index, hash, set duplicates aside, preview, check, file, verify, refresh - asking before each change.

    `ask` is called before anything moves; returning False stops the run there (nothing after it happens).
    With `templates` only the documents one of them matches are filed (by the date, name and folder it read);
    `reader` (Windows' OCR) lets them read scans too. `skip` leaves out steps 3 (duplicates) and 7 (refresh).
    `date` (1987-03) is set by hand on every photo here with no sure date, before the preview.
    """
    folder = Path(folder).resolve()
    progress = progress or NullProgressReporter()
    areas = areas if areas is not None else default_areas()
    run_dir = layout.run_dir("run")
    record = RunRecord(folder=str(folder), run_dir=str(run_dir), started_at=_now())
    index = ArchiveIndexService(db)
    prefix = folder_prefix(layout, str(folder))
    skip = set(skip or [])

    def step(name: str, data: dict[str, Any]) -> None:
        record.steps[name] = data
        record.save()

    # 1. Index: what the archive and this folder hold right now.
    say("1/12 Indexing the archive (organized + intake) ...")
    built = index.build(areas, progress=lambda m: say(f"    {m}"))
    step("1_index", built.as_dict())

    # 2. Hash every file here that could be a copy (same size as something else).
    say("2/12 Hashing files that could be copies ...")
    hashed = hash_candidates(db, prefix, progress=lambda m: say(f"    {m}"))
    step("2_hash", hashed)

    if "duplicates" in skip:
        say("3/12 Duplicates: skipped (left out in the pre-run setup)")
        step("3_set_aside_plan", {"skipped": True})
    else:
        # 3a. Set aside a Mac's hidden "._" files (AppleDouble metadata): no picture, so never filed (they'd stay as
        # "without a date"), and often identical to each other (they'd look like duplicates).
        from mindit.services.dbit.mac_files import plan_mac_metadata  # pylint: disable=import-outside-toplevel

        mac = plan_mac_metadata(db, layout, prefix)
        if mac:
            mac_log = run_dir / "mac-metadata-moved.csv"
            write_csv(run_dir / "mac-metadata-plan.csv", mac, PLAN_FIELDS)
            say(f"3/12 {len(mac):,} of a Mac's hidden \"._\" files (its own metadata, not photos), e.g. {Path(mac[0]['source']).name}")
            if ask(f"Move them to {layout.holding_root}?"):
                moved = apply_set_aside(db, mac, mac_log)
                step("3_mac_metadata", {"log": str(mac_log), **dict(moved)})
                say(f"    Moved {moved['moved']:,}. Undo: da intake undo \"{mac_log}\"")

        # 3a. Set aside Apple's edit recipes (.aae, <id>-adjustment.plist): settings for the Photos app, not pictures.
        from mindit.services.dbit.apple_edits import plan_apple_adjustments  # pylint: disable=import-outside-toplevel

        edits = plan_apple_adjustments(db, layout, prefix)
        if edits:
            edits_log = run_dir / "apple-edits-moved.csv"
            write_csv(run_dir / "apple-edits-plan.csv", edits, PLAN_FIELDS)
            say(f"3/12 {len(edits):,} Apple Photos edit recipes (.aae / adjustment .plist, not photos), "
                f"e.g. {Path(edits[0]['source']).name}")
            if ask(f"Move them to {layout.holding_root}?"):
                moved = apply_set_aside(db, edits, edits_log)
                step("3_apple_edits", {"log": str(edits_log), **dict(moved)})
                say(f"    Moved {moved['moved']:,}. Undo: da intake undo \"{edits_log}\"")

        # 3. Set aside exact copies (already in organized, or extra copies in intake).
        say("3/12 Finding exact duplicates ...")
        plan = plan_set_aside(db, layout, prefix)
        plan_csv = write_csv(run_dir / "set-aside-plan.csv", plan, PLAN_FIELDS)
        checked = check_plan(plan_csv) if plan else {"rows": 0, "ok": True}
        step("3_set_aside_plan", {"plan": str(plan_csv), **checked})
        if plan:
            gb = sum(int(p["size_bytes"]) for p in plan) / 1e9
            say(f"    {len(plan):,} duplicates ({gb:,.1f} GB): {checked['by_class']}. "
                f"Sample check: {checked['identical']}/{checked['sampled']} identical, kept copies missing: {checked['kept_missing']}.")
            if not checked["ok"]:
                say("    The sample check failed - stopping before anything moves. See the plan CSV.")
                if checked["kept_missing"]:
                    say(f"    {checked['kept_missing']:,} of the copies to keep aren't there (e.g. "
                        f"{checked['kept_missing_example']}). The index lists files that are gone - often an archive "
                        "moved or copied by hand; `da db build` (or menu 5 Refresh index) drops them.")
                return _stop(record, "3_set_aside_plan")
            if not ask(f"Move {len(plan):,} duplicates to {layout.holding_root}?"):
                return _stop(record, "3_set_aside")
            moved = apply_set_aside(db, plan, run_dir / "set-aside-moved.csv")
            step("3_set_aside", {"log": str(run_dir / "set-aside-moved.csv"), **dict(moved)})
            say(f"    Moved {moved['moved']:,}. Undo: da intake undo \"{run_dir / 'set-aside-moved.csv'}\"")
            not_moved = {k: v for k, v in moved.items() if k == "failed" or k.startswith("skipped")}
            if not_moved:
                say(f"    Not moved (they stay in intake; see set-aside-moved.csv): "
                    + ", ".join(f"{v:,} {k}" for k, v in not_moved.items()))
        else:
            say("    No duplicates.")

        # 3b. Set aside resized copies (the same picture, smaller: the largest stays) and re-saved copies (the same
        # pixels, other bytes: the dated one stays).
        from mindit.services.similar.resized import give_details, plan_copies  # pylint: disable=import-outside-toplevel

        say("    Looking for resized and re-saved copies (the same picture, not the same file) ...")
        resized = plan_copies(db, layout, prefix, progress=lambda m: say(f"    {m}"))
        if resized:
            resized_csv = write_csv(run_dir / "resized-plan.csv", resized, PLAN_FIELDS + ["pixels", "kept_pixels", "bits"])
            checked = check_plan(resized_csv)
            step("3_resized_plan", {"plan": str(resized_csv), **checked})
            kinds = _copy_kinds(resized)
            say(f"    {kinds} (e.g. {resized[0]['pixels']} of a {resized[0]['kept_pixels']} picture). "
                f"Sample check: {checked['identical']}/{checked['sampled']} the same picture, kept missing: {checked['kept_missing']}.")
            if not checked["ok"]:
                say("    The sample check failed - leaving those copies where they are. See resized-plan.csv.")
            elif ask(f"Move {kinds} to {layout.holding_root} (the largest, or the dated one, of each stays)?"):
                give_details(resized)
                moved = apply_set_aside(db, resized, run_dir / "resized-moved.csv")
                step("3_resized", {"log": str(run_dir / "resized-moved.csv"), **dict(moved)})
                say(f"    Moved {moved['moved']:,}. Undo: da intake undo \"{run_dir / 'resized-moved.csv'}\"")
        else:
            say("    No resized or re-saved copies.")

    # 3c. A photographer's edits (Lightroom/Photoshop exports) here: link each to its RAW and its sister exports.
    # Their sidecars move with them when they're filed.
    from mindit.services.similar import edits as photo_edits  # pylint: disable=import-outside-toplevel

    found = photo_edits.find_edits(db, prefix)
    if found:
        photo_edits.write_report(found, run_dir / "edits.csv")
        paired = sum(1 for e in found if e["raw"])
        linked = photo_edits.write_blocks(found)
        step("3_edits", {"edits": len(found), "paired_with_raw": paired, "sidecars": linked})
        say(f"    {len(found):,} edits (exports from a photo editor): {paired:,} paired with their RAW, all kept.")

    # 3d. Document templates (--template): read each document; only the ones a template matches are filed.
    only = None
    if templates:
        only = _read_templates(folder, templates, reader, run_dir, step, say)
        if not only:
            say("    No document matched, so nothing is filed.")
            return _after(_finish(record, index, areas, say, skip), after, [])

    # 4. Preview: plan every rename/move without moving anything.
    say("4/12 Preview: planning names and folders (nothing moves) ...")
    validator = _validator(kind)
    if date:
        given = date_undated(folder, date)
        step("3e_date", {"date": date, "set": len(given)})
        say(f"    The date {date} set on {len(given):,} photos with no sure date.")
    reviewed = [] if templates else _file_reviewed(layout, run_dir, kind, step, say, ask, progress)
    preview = validator.validate_folder(folder, mode=ValidationMode.PREVIEW, progress=progress, only=only)
    preview_path = write_validation_report(preview, run_dir)
    report = check_report(load_report(preview_path))
    step("4_preview", {"report": str(preview_path), **report})

    # 5. Check the plan and ask.
    renamed = f", {report['renames']:,} filed already to rename where they are" if report["renames"] else ""
    say(f"5/12 Plan: {report['moves']:,} files to file{renamed}, {report['raw_companions']:,} raw files and Live Photo "
        f"videos with them, {report['uncertain_dates']:,} without a date (they stay"
        + (", or wait in review to be dated" if _review_on() else "") + f"), years {report['years']}.")
    for warning in report["warnings"]:
        say(f"    ! {warning}")
    if report["moves"] + report["renames"] == 0:
        say("    Nothing to file.")
        return _after(_finish(record, index, areas, say, skip), after, reviewed)
    if not ask(f"File {report['moves']:,} files into organized"
               + (f" and rename {report['renames']:,}?" if report["renames"] else "?")):
        return _stop(record, "5_check")

    # 6. File (repair) and verify.
    say("6/12 Filing ...")
    repaired = validator.apply_repairs(preview, progress=progress)          # the preview's plan, not a second check
    repair_path = write_validation_report(repaired, run_dir)
    say("    Checking every filed file (place, size, date; a sample re-hashed) ...")
    verified = verify_report(load_report(repair_path), progress=lambda m: say(f"    {m}"))
    say(f"    Filed {verified.get('moved', 0):,}; unchanged {verified.get('size_ok', 0) + verified.get('hash_ok', 0):,} "
        f"({verified.get('hash_ok', 0):,} re-hashed); problems: {len(verified['problems'])}"
        + ("" if verified["ok"] else "  <-- see summary.json"))
    say(f"    (Every hash: da verify \"{repair_path}\" --full)")
    sheets = refresh_sheets(_not_review(filed_folders(repaired)), create=True, version=__version__)
    if sheets.made or sheets.failed:
        say(f"    Contact sheets: {len(sheets.made):,} made or updated"
            + (f", {len(sheets.failed)} failed (see summary.json)" if sheets.failed else ""))
    left = left_folders(repaired, layout) - filed_folders(repaired)
    if left:                                    # filed files moved on (a template's folder): their old folders' sheets
        from mindit.services.naming.rename import tidy_folders  # pylint: disable=import-outside-toplevel

        tidy_folders(set(), left, [folder])
    step("6_file", {"report": str(repair_path), "verify": verified, "contact_sheets": sheets.as_dict()})

    return _after(_finish(record, index, areas, say, skip), after, sorted(set(filed_folders(repaired)) | set(reviewed)))


def date_undated(folder: Path, text: str) -> list[Path]:
    """Set a date by hand (da run --date) on each photo under folder with no sure date; return them.

    A photo with no sidecar yet gets its full one first (hash, camera details), as the preview would make it.
    """
    from mindit.services.dates.user_dates import parse_when, set_dates  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.capture_date import resolve_capture_date  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.quarantine_hash_service import compute_sha256, record_file_hash  # pylint: disable=import-outside-toplevel

    when, precision = parse_when(text)
    provider = PhotoItRepairProvider()
    undated: list[Path] = []
    for path in files_under([folder], photos_only=True):
        if not Path(f"{path}.meta.json").exists():
            sha256 = compute_sha256(path)
            provider.create_or_refresh_sidecar(path, sha256=sha256)
            record_file_hash(path, sha256)
        if not resolve_capture_date(path).certain:
            undated.append(path)
    if undated:
        set_dates(undated, when, precision, text)
    return undated


def _not_review(folders: set[Path]) -> set[Path]:
    """Return the folders outside the review folder (photos only wait there: no contact sheets)."""
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.scans.review import review_root  # pylint: disable=import-outside-toplevel

    root = review_root(resolve_photoit_organized_path())
    return folders if root is None else {f for f in folders if not Path(f).resolve().is_relative_to(root.resolve())}


def _review_on() -> bool:
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.scans.review import review_root  # pylint: disable=import-outside-toplevel

    return review_root(resolve_photoit_organized_path()) is not None


def _file_reviewed(layout: Layout, run_dir: Path, kind: str | None, step: Callable[[str, dict[str, Any]], None],
                   say: Say, ask: Ask, progress: ProgressReporter) -> list[Path]:
    """File the photos in the review folder that have a date now (set by hand since); return the folders filled."""
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.scans.review import dated, review_root  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel

    root = review_root(resolve_photoit_organized_path())
    if root is None or not root.is_dir():
        return []
    ready = [p for p in files_under([root], photos_only=True) if dated(p)]
    if not ready:
        return []
    say(f"    Review: {len(ready):,} photos dated since they went to review; filing them too.")
    validator = _validator(kind)
    preview = validator.validate_folder(root, mode=ValidationMode.PREVIEW, progress=progress, only=set(ready))
    report = check_report(load_report(write_validation_report(preview, run_dir)))
    if report["moves"] + report["renames"] == 0 or not ask(f"File {report['moves']:,} dated photos from review?"):
        return []
    repaired = validator.apply_repairs(preview, progress=progress)
    repair_path = write_validation_report(repaired, run_dir)
    verified = verify_report(load_report(repair_path), progress=lambda m: say(f"    {m}"))
    say(f"    Filed {verified.get('moved', 0):,} from review; problems: {len(verified['problems'])}")
    folders = filed_folders(repaired)
    refresh_sheets(folders, create=True, version=__version__)
    from mindit.services.naming.rename import tidy_folders  # pylint: disable=import-outside-toplevel

    tidy_folders(set(), left_folders(repaired, layout) - folders, [root])
    step("4_review", {"report": str(repair_path), "verify": verified})
    return sorted(folders)


def _read_templates(folder: Path, templates: list[Any], reader: Any | None, run_dir: Path,
                    step: Callable[[str, dict[str, Any]], None], say: Say) -> set[Path]:
    """Read the folder's documents with the templates; return the ones they matched (their readings in the sidecars)."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.templates.reading import read_folder, write_results  # pylint: disable=import-outside-toplevel

    names = ", ".join(t.name for t in templates)
    say(f"    Reading documents with the {names} template{'s' if len(templates) > 1 else ''} ...")
    found = read_folder(folder, templates, reader=reader)
    csv_path = write_results(found.results, run_dir / "templates.csv")
    for result in found.matched:
        r = result.reading
        say(f"    {result.path.name}: {r.template.name} - " + ", ".join(f"{k} {_shown(v)}" for k, v in r.fields.items()))
    failures = [result.failure(names) for result in found.failed]
    for line in failures[:30]:
        say(f"    ! {line}")
    if len(failures) > 30:
        say(f"    ! ... and {len(failures) - 30:,} more (see {csv_path.name})")
    say(f"    {len(found.matched):,} of {len(found.results):,} documents matched; the others stay where they are"
        + (f" ({found.other:,} other files left alone)" if found.other else "") + f". List: {csv_path}")
    step("3_templates", {"templates": [t.name for t in templates], "read": len(found.results),
                         "matched": [{"file": str(r.path), "template": r.reading.template.name,
                                      "fields": r.reading.fields} for r in found.matched],
                         "failed": failures, "other_files": found.other, "list": str(csv_path)})
    log_event("template", f"read {len(found.results)} documents with {names}: {len(found.matched)} matched",
              path=str(csv_path), read=len(found.results), matched=len(found.matched), failed=len(failures))
    return {r.path for r in found.matched}


def _shown(value: Any) -> str:
    if isinstance(value, dict) and "from" in value:
        return f"{value['from']} to {value['to']}"
    return str(value)


def _after(record: RunRecord, after: Callable[[list[Path]], dict[str, Any]] | None, folders: list[Path]) -> RunRecord:
    """Do the steps after filing (8-11) the caller chose, on the folders just filed."""
    if after is not None:
        record.steps["8_after_filing"] = after(folders)
        record.save()
    return record


def _copy_kinds(plan: list[dict[str, Any]]) -> str:
    resized = sum(1 for p in plan if p["class"] == "resized_copy")
    resaved = len(plan) - resized
    return " and ".join(t for t in ((f"{resized:,} resized copies" if resized else ""),
                                    (f"{resaved:,} re-saved copies" if resaved else "")) if t)


def _finish(record: RunRecord, index: ArchiveIndexService, areas: list[Area], say: Say, skip: set[str]) -> RunRecord:
    if "refresh" in skip:
        say("7/12 Refresh index: skipped (left out in the pre-run setup)")
        record.steps["7_refresh"] = {"skipped": True}
    else:
        say("7/12 Refreshing the index ...")
        record.steps["7_refresh"] = index.build(areas).as_dict()
    record.finished_at = _now()
    path = record.save()
    say(f"Done. Run record: {path}")
    return record


def _stop(record: RunRecord, at: str) -> RunRecord:
    record.stopped_at_step = at
    record.finished_at = _now()
    record.save()
    return record


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")
