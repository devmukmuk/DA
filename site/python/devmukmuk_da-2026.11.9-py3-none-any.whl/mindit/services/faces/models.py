"""The two face models (OpenCV model zoo, Apache 2.0), downloaded once into %LOCALAPPDATA%\\DA\\models and checked.

YuNet finds faces (a box and 5 points); SFace turns a face into 128 numbers. Design: docs/da-docs/FACES-DESIGN.md.
"""

from __future__ import annotations

import hashlib
import http.client
import os
import shutil
import subprocess
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

ZOO = "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/"
MIRROR = "https://github.com/devmukmuk/DA/releases/download/face-models/"   # the same files, for networks blocking the zoo


@dataclass(frozen=True)
class Model:
    """One model file: where it comes from and its SHA-256 (fixed, so a changed file is never used)."""

    name: str
    url: str
    sha256: str
    size: int

    @property
    def mirror(self) -> str:
        """Return DA's own copy (a release of the public DA repo; tools/release/public_release.py keeps it)."""
        return MIRROR + self.name


DETECTOR = Model("face_detection_yunet_2023mar.onnx", ZOO + "face_detection_yunet/face_detection_yunet_2023mar.onnx",
                 "8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4", 232_589)
RECOGNIZER = Model("face_recognition_sface_2021dec.onnx", ZOO + "face_recognition_sface/face_recognition_sface_2021dec.onnx",
                   "0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79", 38_696_353)


class ModelError(RuntimeError):
    """A model couldn't be downloaded or didn't match its fixed SHA-256."""


def models_dir() -> Path:
    """Return where the models are kept: DA_FACE_MODELS, else %LOCALAPPDATA%\\DA\\models."""
    if os.environ.get("DA_FACE_MODELS"):
        return Path(os.environ["DA_FACE_MODELS"])
    return Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "DA" / "models"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _user_agent() -> str:
    from mindit import __version__  # pylint: disable=import-outside-toplevel

    return f"DA/{__version__}"


def _with_python(url: str, part: Path, proxies: dict[str, str] | None = None) -> None:
    """Download with Python (through the proxy Windows or HTTPS_PROXY names, or with `proxies={}`, none)."""
    request = urllib.request.Request(url, headers={"User-Agent": _user_agent()})
    opened = (urllib.request.build_opener(urllib.request.ProxyHandler(proxies)).open if proxies is not None
              else urllib.request.urlopen)
    with opened(request, timeout=120) as answer, part.open("wb") as out:  # noqa: S310 (fixed URL)
        for chunk in iter(lambda: answer.read(1 << 20), b""):
            out.write(chunk)


def _curl() -> str | None:
    """Return Windows' own curl.exe (Windows 10 1803 and later), which uses Windows' secure connections."""
    found = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "curl.exe"
    return str(found) if found.exists() else shutil.which("curl.exe")


def _with_curl(url: str, part: Path) -> None:
    """Download with curl.exe."""
    curl = _curl()
    if not curl:
        raise OSError("no curl.exe")
    done = subprocess.run([curl, "-sS", "-f", "-L", "--retry", "2", "-A", _user_agent(), "-o", str(part), url],
                          capture_output=True, text=True, timeout=1200, check=False,
                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if done.returncode:
        raise OSError((done.stderr or f"curl exit {done.returncode}").strip())


def web_filter(host: str, timeout: float = 5.0) -> str | None:
    """Return the site a network web filter sends `host` to (it answers plain HTTP on the secure port), else None."""
    import socket  # pylint: disable=import-outside-toplevel

    try:
        with socket.create_connection((host, 443), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall(f"GET / HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n".encode("ascii"))
            reply = s.recv(2048).decode("latin-1")
    except (OSError, UnicodeError):
        return None
    if not reply.startswith("HTTP/"):
        return None                                          # a real secure server: nothing in between
    for line in reply.split("\r\n")[1:]:
        if line.lower().startswith("location:"):
            return urllib.parse.urlsplit(line.split(":", 1)[1].strip()).hostname or "unknown"
    return "unknown"


def _routes() -> list[tuple[str, Callable[[str, Path], None]]]:
    """Return the ways to try a download, in order: Python, Python without the proxy (if one is set), curl.exe."""
    routes: list[tuple[str, Callable[[str, Path], None]]] = [("Python", _with_python)]
    if urllib.request.getproxies():
        routes.append(("without the proxy", lambda url, part: _with_python(url, part, proxies={})))
    routes.append(("curl.exe", _with_curl))
    return routes


def model_path(model: Model, say: Callable[[str], None] | None = None) -> Path:
    """Return the model file, downloading it the first time (and checking its SHA-256 every time it's fetched)."""
    folder = models_dir()
    path = folder / model.name
    if path.exists() and path.stat().st_size == model.size:
        return path
    folder.mkdir(parents=True, exist_ok=True)
    if say:
        say(f"Downloading {model.name} ({model.size / 1e6:,.1f} MB, once) from the OpenCV model zoo ...")
    part = path.with_name(path.name + ".part")
    errors: list[str] = []
    for url in (model.url, model.mirror):
        where = urllib.parse.urlsplit(url).hostname
        for how, fetch in _routes():
            try:
                fetch(url, part)
            except (OSError, http.client.HTTPException, subprocess.SubprocessError) as exc:  # HTTPException: broke off
                part.unlink(missing_ok=True)
                errors.append(f"{where}, {how}: {exc}")
                continue
            if _sha256(part) == model.sha256:
                os.replace(part, path)
                return path
            part.unlink(missing_ok=True)
            errors.append(f"{where}: didn't match its fingerprint - not used")
            break                                                   # the same file again by another route: no
    host = urllib.parse.urlsplit(model.url).hostname or ""
    blocker = web_filter(host)
    why = (f"A web filter on this network ({blocker}) blocks {host}: allow that site in the router's or internet "
           "provider's safe-browsing settings, or" if blocker else
           "Something between this PC and GitHub - a proxy, or antivirus checking web traffic - may be in the way. Or")
    raise ModelError(f"Couldn't download {model.name} ({'; '.join(errors)}). {why} download it in a web browser "
                     f"from {model.mirror} (or {model.url}) and save it as {path}, then run this again.")
