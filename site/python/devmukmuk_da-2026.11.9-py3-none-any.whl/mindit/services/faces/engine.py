"""Find the faces in a photo and describe each (YuNet + SFace through OpenCV), on the photo turned upright."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

READ_SIZE = 1280                    # photos are read at most this big (faces down to ~20 px still found)
MIN_SCORE = 0.7                     # YuNet's own confidence


class EngineError(RuntimeError):
    """OpenCV or the models couldn't be loaded (not installed, or blocked by Windows)."""


@dataclass
class Found:
    """One face found: its box and 5 points (fractions of the upright photo), the detector's score, its 128 numbers."""

    box: tuple[float, float, float, float]
    points: list[float]
    score: float
    vector: Any                      # numpy float32[128], length 1


def read_upright(path: Path) -> Any | None:
    """Return the photo as an OpenCV (BGR) array, upright, at most READ_SIZE, or None when it can't be read."""
    import numpy as np  # pylint: disable=import-outside-toplevel
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    _read_heic()
    try:
        with Image.open(path) as img:
            if img.format == "JPEG":
                img.draft("RGB", (READ_SIZE, READ_SIZE))
            img = ImageOps.exif_transpose(img).convert("RGB")
            img.thumbnail((READ_SIZE, READ_SIZE))
            return np.ascontiguousarray(np.asarray(img)[:, :, ::-1])
    except Exception:  # pylint: disable=broad-except
        return None


def _read_heic() -> None:
    """Let Pillow open HEIC/HEIF photos (an iPhone's) when pillow-heif is installed."""
    try:
        from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

        register_heif_opener()
    except ImportError:
        pass


def _load(cv2: Any, path: Path, from_buffer: Callable[[Any], Any], from_path: Callable[[str], Any]) -> Any:
    """Load a model from its bytes (OpenCV can't open a path with letters like é or 名 on Windows), else by path."""
    import numpy as np  # pylint: disable=import-outside-toplevel

    try:
        return from_buffer(np.fromfile(path, dtype=np.uint8))
    except (TypeError, AttributeError, cv2.error):
        return from_path(str(path))         # an OpenCV without the buffer overloads


class FaceEngine:
    """YuNet + SFace, loaded once."""

    def __init__(self, say: Callable[[str], None] | None = None):
        from mindit.services.faces.models import DETECTOR, RECOGNIZER, ModelError, model_path  # pylint: disable=import-outside-toplevel

        try:
            import cv2  # pylint: disable=import-outside-toplevel
        except ImportError as exc:
            raise EngineError("Face finding needs OpenCV, which isn't installed here (pip install "
                              "opencv-python-headless) - or Windows blocked it (Smart App Control), or the Microsoft "
                              f"Visual C++ Redistributable it needs is missing ({exc}).") from exc
        import numpy as np  # pylint: disable=import-outside-toplevel

        none = np.array([], dtype=np.uint8)
        try:
            self.detector = _load(
                cv2, model_path(DETECTOR, say),
                lambda b: cv2.FaceDetectorYN.create("onnx", b, none, (320, 320), MIN_SCORE, 0.3, 5000),
                lambda p: cv2.FaceDetectorYN.create(p, "", (320, 320), MIN_SCORE, 0.3, 5000))
            self.recognizer = _load(cv2, model_path(RECOGNIZER, say),
                                    lambda b: cv2.FaceRecognizerSF.create("onnx", b, none),
                                    lambda p: cv2.FaceRecognizerSF.create(p, ""))
        except ModelError as exc:
            raise EngineError(str(exc)) from exc
        except Exception as exc:  # pylint: disable=broad-except
            raise EngineError(f"OpenCV couldn't load the face models: {exc}") from exc

    def faces(self, image: Any) -> list[Found]:
        """Return the faces in an upright BGR image."""
        import numpy as np  # pylint: disable=import-outside-toplevel

        h, w = image.shape[:2]
        self.detector.setInputSize((w, h))
        _ok, rows = self.detector.detect(image)
        out = []
        for row in rows if rows is not None else []:
            x, y, bw, bh = (float(v) for v in row[:4])
            vector = self.recognizer.feature(self.recognizer.alignCrop(image, row)).flatten().astype(np.float32)
            norm = float(np.linalg.norm(vector)) or 1.0
            box = (max(0.0, x / w), max(0.0, y / h), min(1.0, (x + bw) / w), min(1.0, (y + bh) / h))
            points = [round(float(v) / (w if i % 2 == 0 else h), 4) for i, v in enumerate(row[4:14])]
            out.append(Found(tuple(round(v, 4) for v in box), points, round(float(row[14]), 3), vector / norm))
        return out
