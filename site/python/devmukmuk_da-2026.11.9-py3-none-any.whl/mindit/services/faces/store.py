"""The faces found, kept in the archive's index: their boxes, numbers, names and how each name was given.

A face's numbers (biometric) are kept here only - never in sidecars, shares or logs. `forget()` deletes them.
Status of a face's name: picasa (Picasa named it), confirmed (you), suggested (DA's guess, with how sure), or none.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

SCHEMA = """
CREATE TABLE IF NOT EXISTS faces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sha256 TEXT NOT NULL,
    n INTEGER NOT NULL,
    box TEXT NOT NULL,
    points TEXT,
    score REAL,
    vector BLOB,
    name TEXT,
    status TEXT,
    similarity REAL,
    rejected TEXT,
    group_id INTEGER,
    made_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_faces_sha ON faces(sha256);
CREATE INDEX IF NOT EXISTS idx_faces_name ON faces(name);
CREATE TABLE IF NOT EXISTS face_scans (sha256 TEXT PRIMARY KEY, faces INTEGER, made_at TEXT);
"""
NAMED = ("picasa", "confirmed")
UNREADABLE = "unreadable 2"                  # face_scans.made_at of a photo that couldn't be read (2: HEIC read too)             # names that count: examples of a person, and person: tags


def connect(db_path: Path) -> sqlite3.Connection:
    """Open the index with the faces tables there."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def scanned(conn: sqlite3.Connection) -> set[str]:
    """Return the photos (by SHA-256) already looked at (unreadable before HEIC was read: tried again)."""
    return {r[0] for r in conn.execute("SELECT sha256 FROM face_scans WHERE made_at IS NOT NULL")}


def add(conn: sqlite3.Connection, sha256: str, found: Iterable[Any]) -> int:
    """Keep the faces found in one photo (and that it was looked at); return how many."""
    now = datetime.now().isoformat(timespec="seconds")
    rows = [(sha256, i, json.dumps(f.box), json.dumps(f.points), f.score, f.vector.tobytes(), now)
            for i, f in enumerate(found)]
    conn.executemany("INSERT INTO faces (sha256, n, box, points, score, vector, made_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                     rows)
    conn.execute("INSERT OR REPLACE INTO face_scans VALUES (?, ?, ?)", (sha256, len(rows), now))
    return len(rows)


def vector_of(row: sqlite3.Row) -> Any:
    """Return a face row's 128 numbers as a numpy array."""
    import numpy as np  # pylint: disable=import-outside-toplevel

    return np.frombuffer(row["vector"], dtype=np.float32)


def rejected_names(row: sqlite3.Row) -> list[str]:
    """Return the names you said this face isn't."""
    try:
        return json.loads(row["rejected"] or "[]")
    except ValueError:
        return []


def forget(conn: sqlite3.Connection, person: str | None = None) -> int:
    """Delete face data: everything, or one person's faces; return how many faces."""
    if person:
        n = conn.execute("DELETE FROM faces WHERE name = ? COLLATE NOCASE", (person,)).rowcount
    else:
        n = conn.execute("DELETE FROM faces").rowcount
        conn.execute("DELETE FROM face_scans")
    return n
