# src/mindit/services/workflow/run_workflow.py

"""`da run`: the whole intake workflow for one folder, step by step, with a record of every step."""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit import __version__
from mindit.core.progress import NullProgressReporter, ProgressReporter
from mindit.services.contactsheet.contact_sheet import refresh_sheets
from mindit.services.dbit.archive_index_service import Area, ArchiveIndexService, default_areas
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.dbit.intake_service import (
    PLAN_FIELDS,
    Layout,
    apply_set_aside,
    folder_prefix,
    hash_candidates,
    plan_set_aside,
    write_csv,
)
from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider
from mindit.services.validateit.scanit_repair_provider import ScanItRepairProvider
from mindit.services.validateit.validateit_file_types import MediaClassifier, MediaKind
from mindit.services.validateit.validateit_models import RepairActionType, ValidationMode
from mindit.services.validateit.validateit_reports import write_validation_report
from mindit.services.validateit.validateit_repair_providers import RepairProviderRegistry
from mindit.services.validateit.video_repair_provider import VideoRepairProvider
from mindit.services.validateit.validateit_service import ValidateItService
from mindit.services.workflow.checks import check_plan, check_report, load_report, verify_report

Say = Callable[[str], None]
Ask = Callable[[str], bool]


@dataclass
class RunRecord:
    """Everything one `da run` did, saved as summary.json in its run folder."""

    folder: str
    run_dir: str
    started_at: str
    steps: dict[str, Any] = field(default_factory=dict)
    stopped_at_step: str | None = None
    finished_at: str | None = None

    def save(self) -> Path:
        path = Path(self.run_dir) / "summary.json"
        path.write_text(json.dumps(self.__dict__, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        if self.finished_at:                          # once, at the end (save() also runs after each step)
            from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

            filed = ((self.steps.get("6_file") or {}).get("verify") or {}).get("moved", 0)
            log_event("run", f"run of {self.folder}: "
                      + (f"stopped at {self.stopped_at_step}" if self.stopped_at_step else f"filed {filed}")
                      + f" (summary: {path})", path=str(path))
        return path


def free_intake_name(intake: Path, name: str) -> Path:
    """Return intake\\name, or intake\\name-2, -3 ... when that's taken."""
    dest, n = intake / name, 1
    while dest.exists():
        n += 1
        dest = intake / f"{name}-{n}"
    return dest


def copy_into_intake(source: Path, dest: Path) -> int:
    """Copy a folder from outside the archive into intake (sidecars left behind; DA makes fresh ones)."""
    shutil.copytree(source, dest, copy_function=shutil.copy2, ignore=shutil.ignore_patterns("*.meta.json"))
    return sum(1 for _, _, files in os.walk(dest) for _f in files)


def filed_folders(state) -> set[Path]:
    """Return the folders a repair moved or renamed files into (each gets a contact sheet)."""
    kinds = {RepairActionType.MOVE_FILE, RepairActionType.RENAME_FILE, RepairActionType.MOVE_RAW_COMPANION}
    return {Path(a.target_path).parent for a in state.repair_actions
            if a.executed and a.target_path and a.action_type in kinds}


def _validator(kind: str | None) -> ValidateItService:
    return ValidateItService(
        repair_provider_registry=RepairProviderRegistry(providers=[PhotoItRepairProvider(), ScanItRepairProvider(),
                                                                    VideoRepairProvider()]),
        # No kind: an image is what its intake folder says (intake\scans: document), else a photo.
        media_classifier=MediaClassifier(force_kind=MediaKind(kind) if kind else None, default_kind=MediaKind.PHOTO),
    )


def run_workflow(
    folder: Path,
    db: DbitService,
    layout: Layout,
    areas: list[Area] | None = None,
    kind: str | None = None,
    say: Say = print,
    ask: Ask = lambda question: True,
    progress: ProgressReporter | None = None,
    after: Callable[[list[Path]], dict[str, Any]] | None = None,
) -> RunRecord:
    """Index, hash, set duplicates aside, preview, check, file, verify, refresh - asking before each change.

    `ask` is called before anything moves; returning False stops the run there (nothing after it happens).
    """
    folder = Path(folder).resolve()
    progress = progress or NullProgressReporter()
    areas = areas if areas is not None else default_areas()
    run_dir = layout.run_dir("run")
    record = RunRecord(folder=str(folder), run_dir=str(run_dir), started_at=_now())
    index = ArchiveIndexService(db)
    prefix = folder_prefix(layout, str(folder))

    def step(name: str, data: dict[str, Any]) -> None:
        record.steps[name] = data
        record.save()

    # 1. Index: what the archive and this folder hold right now.
    say("1/11 Indexing the archive (organized + intake) ...")
    built = index.build(areas, progress=lambda m: say(f"    {m}"))
    step("1_index", built.as_dict())

    # 2. Hash every file here that could be a copy (same size as something else).
    say("2/11 Hashing files that could be copies ...")
    hashed = hash_candidates(db, prefix, progress=lambda m: say(f"    {m}"))
    step("2_hash", hashed)

    # 3. Set aside exact copies (already in organized, or extra copies in intake).
    say("3/11 Finding exact duplicates ...")
    plan = plan_set_aside(db, layout, prefix)
    plan_csv = write_csv(run_dir / "set-aside-plan.csv", plan, PLAN_FIELDS)
    checked = check_plan(plan_csv) if plan else {"rows": 0, "ok": True}
    step("3_set_aside_plan", {"plan": str(plan_csv), **checked})
    if plan:
        gb = sum(int(p["size_bytes"]) for p in plan) / 1e9
        say(f"    {len(plan):,} duplicates ({gb:,.1f} GB): {checked['by_class']}. "
            f"Sample check: {checked['identical']}/{checked['sampled']} identical, kept copies missing: {checked['kept_missing']}.")
        if not checked["ok"]:
            say("    The sample check failed - stopping before anything moves. See the plan CSV.")
            return _stop(record, "3_set_aside_plan")
        if not ask(f"Move {len(plan):,} duplicates to {layout.holding_root}?"):
            return _stop(record, "3_set_aside")
        moved = apply_set_aside(db, plan, run_dir / "set-aside-moved.csv")
        step("3_set_aside", {"log": str(run_dir / "set-aside-moved.csv"), **dict(moved)})
        say(f"    Moved {moved['moved']:,}. Undo: da intake undo \"{run_dir / 'set-aside-moved.csv'}\"")
        not_moved = {k: v for k, v in moved.items() if k == "failed" or k.startswith("skipped")}
        if not_moved:
            say(f"    Not moved (they stay in intake; see set-aside-moved.csv): "
                + ", ".join(f"{v:,} {k}" for k, v in not_moved.items()))
    else:
        say("    No duplicates.")

    # 3b. Set aside resized copies (the same picture, smaller: the largest stays) and re-saved copies (the same
    # pixels, other bytes: the dated one stays).
    from mindit.services.similar.resized import give_details, plan_copies  # pylint: disable=import-outside-toplevel

    say("    Looking for resized and re-saved copies (the same picture, not the same file) ...")
    resized = plan_copies(db, layout, prefix, progress=lambda m: say(f"    {m}"))
    if resized:
        resized_csv = write_csv(run_dir / "resized-plan.csv", resized, PLAN_FIELDS + ["pixels", "kept_pixels", "bits"])
        checked = check_plan(resized_csv)
        step("3_resized_plan", {"plan": str(resized_csv), **checked})
        kinds = _copy_kinds(resized)
        say(f"    {kinds} (e.g. {resized[0]['pixels']} of a {resized[0]['kept_pixels']} picture). "
            f"Sample check: {checked['identical']}/{checked['sampled']} the same picture, kept missing: {checked['kept_missing']}.")
        if not checked["ok"]:
            say("    The sample check failed - leaving those copies where they are. See resized-plan.csv.")
        elif ask(f"Move {kinds} to {layout.holding_root} (the largest, or the dated one, of each stays)?"):
            give_details(resized)
            moved = apply_set_aside(db, resized, run_dir / "resized-moved.csv")
            step("3_resized", {"log": str(run_dir / "resized-moved.csv"), **dict(moved)})
            say(f"    Moved {moved['moved']:,}. Undo: da intake undo \"{run_dir / 'resized-moved.csv'}\"")
    else:
        say("    No resized or re-saved copies.")

    # 4. Preview: plan every rename/move without moving anything.
    say("4/11 Preview: planning names and folders (nothing moves) ...")
    validator = _validator(kind)
    preview = validator.validate_folder(folder, mode=ValidationMode.PREVIEW, progress=progress)
    preview_path = write_validation_report(preview, run_dir)
    report = check_report(load_report(preview_path))
    step("4_preview", {"report": str(preview_path), **report})

    # 5. Check the plan and ask.
    say(f"5/11 Plan: {report['moves']:,} files to file, {report['raw_companions']:,} raw files and Live Photo videos with them, "
        f"{report['uncertain_dates']:,} without a date (they stay), years {report['years']}.")
    for warning in report["warnings"]:
        say(f"    ! {warning}")
    if report["moves"] == 0:
        say("    Nothing to file.")
        return _after(_finish(record, index, areas, say), after, [])
    if not ask(f"File {report['moves']:,} files into organized?"):
        return _stop(record, "5_check")

    # 6. File (repair) and verify.
    say("6/11 Filing ...")
    repaired = validator.apply_repairs(preview, progress=progress)          # the preview's plan, not a second check
    repair_path = write_validation_report(repaired, run_dir)
    say("    Checking every filed file (place, size, date; a sample re-hashed) ...")
    verified = verify_report(load_report(repair_path), progress=lambda m: say(f"    {m}"))
    say(f"    Filed {verified.get('moved', 0):,}; unchanged {verified.get('size_ok', 0) + verified.get('hash_ok', 0):,} "
        f"({verified.get('hash_ok', 0):,} re-hashed); problems: {len(verified['problems'])}"
        + ("" if verified["ok"] else "  <-- see summary.json"))
    say(f"    (Every hash: da verify \"{repair_path}\" --full)")
    sheets = refresh_sheets(filed_folders(repaired), create=True, version=__version__)
    if sheets.made or sheets.failed:
        say(f"    Contact sheets: {len(sheets.made):,} made or updated"
            + (f", {len(sheets.failed)} failed (see summary.json)" if sheets.failed else ""))
    step("6_file", {"report": str(repair_path), "verify": verified, "contact_sheets": sheets.as_dict()})

    return _after(_finish(record, index, areas, say), after, filed_folders(repaired))


def _after(record: RunRecord, after: Callable[[list[Path]], dict[str, Any]] | None, folders: list[Path]) -> RunRecord:
    """Do the steps after filing (8-11) the caller chose, on the folders just filed."""
    if after is not None:
        record.steps["8_after_filing"] = after(folders)
        record.save()
    return record


def _copy_kinds(plan: list[dict[str, Any]]) -> str:
    resized = sum(1 for p in plan if p["class"] == "resized_copy")
    resaved = len(plan) - resized
    return " and ".join(t for t in ((f"{resized:,} resized copies" if resized else ""),
                                    (f"{resaved:,} re-saved copies" if resaved else "")) if t)


def _finish(record: RunRecord, index: ArchiveIndexService, areas: list[Area], say: Say) -> RunRecord:
    say("7/11 Refreshing the index ...")
    rebuilt = index.build(areas)
    record.steps["7_refresh"] = rebuilt.as_dict()
    record.finished_at = _now()
    path = record.save()
    say(f"Done. Run record: {path}")
    return record


def _stop(record: RunRecord, at: str) -> RunRecord:
    record.stopped_at_step = at
    record.finished_at = _now()
    record.save()
    return record


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")
