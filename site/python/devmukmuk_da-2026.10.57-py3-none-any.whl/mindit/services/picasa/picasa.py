"""Bring in what Picasa knew about each photo (faces and who they are, captions, stars, albums) from its Picasa.ini files.

Picasa kept a `Picasa.ini` (or `.picasa.ini`) in every folder it looked at: a section per file with `faces=`
(a box and a contact id per face), `caption=`, `star=yes`, `albums=` and `rotate=`, plus `[Contacts2]`
(contact id = name;email;) and `[.album:<id>]` (name=). DA writes it into each photo's sidecar `picasa` block,
with `person:` / `album:` / `picasa:starred` automatic tags, then keeps the ini itself in `picasa\\<its folder>`.
"""

from __future__ import annotations

import csv
import os
import re
import shutil
import sqlite3
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

PICASA_BLOCK = "picasa"
INI_NAMES = {"picasa.ini", ".picasa.ini"}
UNNAMED = "ffffffffffffffff"
PLAN_FIELDS = ["ini", "entry", "result", "photo", "faces", "people", "caption", "starred", "albums", "note"]
_RECT = re.compile(r"rect64\(([0-9a-fA-F]{1,16})\)")
_ROTATE = re.compile(r"rotate\((\d)\)")


# --------------------------------------------------------------------------- reading an ini

@dataclass
class PicasaIni:
    """One Picasa.ini: its folder's name, its people and albums, and a section per file."""

    path: Path
    folder: dict[str, str] = field(default_factory=dict)
    contacts: dict[str, str] = field(default_factory=dict)
    albums: dict[str, str] = field(default_factory=dict)
    files: dict[str, dict[str, str]] = field(default_factory=dict)


def _text(path: Path) -> str:
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def read_ini(path: Path) -> PicasaIni:
    """Read a Picasa.ini (by hand: names repeat and values hold '=' and ';', which configparser dislikes)."""
    ini, section, values = PicasaIni(path=Path(path)), None, None
    for line in _text(Path(path)).splitlines():
        line = line.strip()
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1]
            if section.lower() == "picasa":
                values = ini.folder
            elif section.lower() in ("contacts", "contacts2"):
                values = ini.contacts
            elif section.lower().startswith(".album:"):
                values = ini.albums.setdefault(section[7:], {})          # type: ignore[assignment]
            else:
                values = ini.files.setdefault(section, {})
            continue
        if values is None or "=" not in line:
            continue
        key, _, value = line.partition("=")
        values[key.strip()] = value.strip()
    ini.contacts = {k: v.split(";")[0].strip() for k, v in ini.contacts.items() if v.split(";")[0].strip()}
    ini.albums = {k: v.get("name", "") for k, v in ini.albums.items() if isinstance(v, dict)}   # type: ignore[union-attr]
    return ini


def box(rect: str) -> list[float]:
    """Return a Picasa rect64 as [left, top, right, bottom], each a fraction of the photo's width or height."""
    value = rect.zfill(16)
    return [round(int(value[i:i + 4], 16) / 65535, 4) for i in range(0, 16, 4)]


def details(entry: dict[str, str], contacts: dict[str, str], albums: dict[str, str]) -> dict[str, Any]:
    """Return the sidecar `picasa` block for one ini section (names only - Picasa's emails stay out)."""
    faces = []
    for part in (entry.get("faces") or "").split(";"):
        rect, _, contact = part.partition(",")
        m = _RECT.search(rect)
        if m:
            name = contacts.get(contact.strip().lower()) if contact.strip().lower() != UNNAMED else None
            faces.append({"box": box(m.group(1)), "name": name})
    block: dict[str, Any] = {"faces": faces}
    if entry.get("caption"):
        block["caption"] = entry["caption"]
    if entry.get("star", "").lower() == "yes":
        block["starred"] = True
    names = [albums.get(a.strip(), "") for a in (entry.get("albums") or "").split(",") if a.strip()]
    if any(names):
        block["albums"] = [n for n in names if n]
    m = _ROTATE.search(entry.get("rotate") or "")
    if m and m.group(1) != "0":
        block["rotate"] = int(m.group(1)) * 90                         # clockwise, as Picasa showed it
    return block


def picasa_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the automatic tags a sidecar's `picasa` block gives (`da tag` keeps them)."""
    from mindit.services.tagging.tags import slug  # pylint: disable=import-outside-toplevel

    block = sidecar.get(PICASA_BLOCK)
    if not isinstance(block, dict):
        return []
    tags = [f"person:{slug(f['name'])}" for f in block.get("faces") or [] if f.get("name")]
    tags += [f"album:{slug(a)}" for a in block.get("albums") or []]
    if block.get("starred"):
        tags.append("picasa:starred")
    return list(dict.fromkeys(t for t in tags if not t.endswith(":")))


# --------------------------------------------------------------------------- finding the photos

def ini_files(folders: list[Path]) -> list[Path]:
    """Return every Picasa.ini under the folders."""
    found = []
    for folder in folders:
        for dirpath, _dirs, files in os.walk(folder):
            found += [Path(dirpath, f) for f in files if f.lower() in INI_NAMES]
    return sorted(found)


def original_folder(ini: Path, intake_root: Path, picasa_root: Path) -> Path:
    """Return the folder the ini's photos were in: its own, or (once kept in picasa\\) the intake folder it came from."""
    try:
        return intake_root / ini.parent.relative_to(picasa_root)
    except ValueError:
        return ini.parent


class Locator:
    """Find where a photo Picasa knew under its old name is now, from DA's history and index."""

    def __init__(self, db_path: Path, data_root: Path):
        self.conn = sqlite3.connect(db_path)
        self.holding = str(data_root / "_duplicates-holding").lower()
        self.indexed = self.conn.execute("SELECT 1 FROM sqlite_master WHERE name = 'files'").fetchone() is not None

    def close(self) -> None:
        """Close the index."""
        self.conn.close()

    def find(self, original: Path) -> tuple[Path | None, str]:
        """Return (where the photo is now, how it was found), or (None, why not)."""
        from mindit.services.history.events import follow  # pylint: disable=import-outside-toplevel

        if original.is_file():
            return original, "where Picasa saw it"
        now = Path(follow(self.conn, str(original)))
        if now != original and now.is_file():
            if str(now).lower().startswith(self.holding):              # set aside as a copy: the one kept
                kept = self._kept_copy(now)
                return (kept, "the copy kept (it was a duplicate)") if kept else (None, "only its held copy is left")
            return now, "followed through DA's moves"
        if self.indexed:
            rows = self.conn.execute("SELECT path FROM files WHERE source_path = ? COLLATE NOCASE", (str(original),)).fetchall()
            rows = [Path(r[0]) for r in rows if Path(r[0]).is_file()]
            if len(rows) == 1:
                return rows[0], "by where it came from"
        return None, "not found (deleted, or moved outside DA)"

    def _kept_copy(self, held: Path) -> Path | None:
        from mindit.services.workflow.checks import sha256_file  # pylint: disable=import-outside-toplevel

        if not self.indexed:
            return None
        sha = sha256_file(held)
        for (path,) in self.conn.execute("SELECT path FROM files WHERE sha256 = ? AND area IN ('photos', 'intake') "
                                         "ORDER BY area = 'intake'", (sha,)):
            if Path(path).is_file():
                return Path(path)
        return None


# --------------------------------------------------------------------------- the plan and applying it

@dataclass
class PicasaPlan:
    """What each Picasa.ini gives, and which photos it goes to."""

    inis: list[Path] = field(default_factory=list)
    rows: list[dict[str, Any]] = field(default_factory=list)

    def counts(self) -> Counter:
        """Return how many entries matched, faces, named faces, people, captions, stars."""
        c: Counter = Counter()
        people: set[str] = set()
        for r in self.rows:
            c[r["result"]] += 1
            if r["result"] == "matched":
                block = r["block"]
                c["faces"] += len(block["faces"])
                c["named faces"] += sum(1 for f in block["faces"] if f["name"])
                people |= {f["name"] for f in block["faces"] if f["name"]}
                c["captions"] += 1 if block.get("caption") else 0
                c["starred"] += 1 if block.get("starred") else 0
        c["people"] = len(people)
        return c


def plan(inis: list[Path], intake_root: Path, picasa_root: Path, locator: Locator,
         progress: Callable[[str], None] | None = None) -> PicasaPlan:
    """Read each ini and find the photo for each of its entries (nothing is written)."""
    result = PicasaPlan(inis=inis)
    read = [read_ini(p) for p in inis]
    everyone: dict[str, str] = {}
    for ini in read:                                    # a face can be named in another folder's ini
        everyone.update({k.lower(): v for k, v in ini.contacts.items()})
    for i, ini in enumerate(read, 1):
        folder = original_folder(ini.path, intake_root, picasa_root)
        for name, entry in ini.files.items():
            block = details(entry, everyone, ini.albums)
            useful = block["faces"] or len(block) > 1
            photo, how = locator.find(folder / name) if useful else (None, "nothing to bring in")
            result.rows.append({"ini": ini.path, "entry": name, "photo": photo, "block": block,
                                "result": "matched" if photo else "nothing to bring in" if not useful else "not found",
                                "note": how, "folder_name": ini.folder.get("name", "")})
        if progress and i % 10 == 0:
            progress(f"read {i:,} of {len(read):,} Picasa.ini files")
    return result


def write_plan(p: PicasaPlan, path: Path) -> Path:
    """Write the plan as a CSV, one row per ini entry."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=PLAN_FIELDS)
        w.writeheader()
        for r in p.rows:
            b = r["block"]
            w.writerow({"ini": str(r["ini"]), "entry": r["entry"], "result": r["result"], "photo": str(r["photo"] or ""),
                        "faces": len(b["faces"]), "people": "; ".join(f["name"] for f in b["faces"] if f["name"]),
                        "caption": b.get("caption", ""), "starred": "yes" if b.get("starred") else "",
                        "albums": "; ".join(b.get("albums") or []), "note": r["note"]})
    return path


def apply(p: PicasaPlan, intake_root: Path, picasa_root: Path, log_path: Path) -> tuple[Counter, dict[str, str]]:
    """Write each matched photo's `picasa` block and tags, then keep each ini in picasa\\ (logged, so undo moves it back)."""
    import json  # pylint: disable=import-outside-toplevel

    from mindit.services.dbit.intake_service import LOG_FIELDS  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import AUTO_BLOCK, all_tags  # pylint: disable=import-outside-toplevel

    stats: Counter = Counter()
    changed: dict[str, str] = {}
    now = datetime.now().isoformat(timespec="seconds")
    for r in p.rows:
        if r["result"] != "matched":
            continue
        photo = Path(r["photo"])
        data = SidecarService.load(photo)
        data[PICASA_BLOCK] = {**r["block"], "from": str(r["ini"].name), "folder": r["folder_name"] or
                              original_folder(r["ini"], intake_root, picasa_root).name, "entry": r["entry"],
                              "imported_at": now}
        auto = data.get(AUTO_BLOCK) if isinstance(data.get(AUTO_BLOCK), dict) else {}
        old = [t for t in auto.get("tags") or [] if t.partition(":")[0] not in ("person", "album")
               and t != "picasa:starred"]
        auto["tags"] = old + [t for t in picasa_tags(data) if t not in old]
        data[AUTO_BLOCK] = auto
        SidecarService.save(photo, data)
        changed[str(photo)] = json.dumps(all_tags(data))
        stats["photos"] += 1
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", newline="", encoding="utf-8") as f:
        log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        log.writeheader()
        for ini in p.inis:
            target = picasa_root / original_folder(ini, intake_root, picasa_root).relative_to(intake_root) / ini.name \
                if _inside(ini, intake_root) else None
            row = {k: "" for k in LOG_FIELDS} | {"class": "picasa_ini", "source": str(ini)}
            if target is None:
                row["result"], row["note"] = "skipped", "already kept, or not in intake"
                stats["inis kept already"] += 1
            elif target.exists():
                row["result"], row["destination"], row["note"] = "skipped", str(target), "one is already there"
                stats["inis skipped"] += 1
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.move(str(ini), str(target))
                row["result"], row["destination"] = "moved", str(target)
                stats["inis moved"] += 1
            log.writerow(row)
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("picasa", f"Picasa details on {stats['photos']} photos; {stats['inis moved']} Picasa.ini kept in "
              f"{picasa_root}", path=str(log_path), counts=dict(stats))
    return stats, changed


def _inside(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False
