# src/mindit/__main__.py

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Any, Callable

from mindit import __app_name__
from mindit.config.archive import register_archive, resolve_archive
from mindit.config.bootstrap import get_env_config_dir, read_bootstrap_config_dir, resolve_user_config_dir
from mindit.config.settings import load_settings, set_archive_root, set_config_root, set_profile_chosen
from mindit.commands import cli
from mindit.core.feedback import ended, started, take_flag
from mindit.core.logging import log_command_end


def _extract_arg(argv: list[str], name: str) -> str | None:
    for index, arg in enumerate(argv):
        if arg == name and index + 1 < len(argv):
            return argv[index + 1]

        if arg.startswith(f"{name}="):
            return arg.split("=", 1)[1]

    return None


def _hoist_arg(argv: list[str], name: str) -> list[str]:
    """Move `name value` (or name=value) to the front, so it works after the command too."""
    for index, arg in enumerate(argv):
        if arg == name and index + 1 < len(argv):
            return [arg, argv[index + 1], *argv[:index], *argv[index + 2:]]
        if arg.startswith(f"{name}="):
            return [arg, *argv[:index], *argv[index + 1:]]
    return argv


# Options naming another archive (`da split --to ...`, `da merge --from ...`): never the one to work in.
OTHER_ARCHIVE_OPTIONS = {"--to", "--from"}


def _existing_paths(argv: list[str]) -> list[Path]:
    """Return the arguments that name an existing file or folder (what a command works on)."""
    if argv and argv[0] in ("archives", "import", "backup"):
        return []                                   # da archives delete <folder>, da import <drive>: what it works on, not in
    paths = []
    skip = False
    for arg in argv:
        if skip:
            skip = False
            continue
        if arg in OTHER_ARCHIVE_OPTIONS:
            skip = True
            continue
        if arg.startswith("-"):
            continue
        try:
            if Path(arg).exists():
                paths.append(Path(arg))
        except (OSError, ValueError):
            continue
    return paths


def _allow_big_pictures() -> None:
    """Let Pillow open very large scans and panoramas (its 89-megapixel guard is for pictures from the web)."""
    try:
        from PIL import Image  # pylint: disable=import-outside-toplevel

        Image.MAX_IMAGE_PIXELS = 1_000_000_000
    except ImportError:
        pass


def _use_windows_certificates() -> None:
    """Check websites' certificates the way Windows does, which fetches a root it doesn't have yet.

    Python on its own trusts only the roots already in Windows' store, so a PC that never needed a newer root
    (Let's Encrypt's Root YR, 2026) failed every place lookup with CERTIFICATE_VERIFY_FAILED.
    """
    try:
        import truststore  # pylint: disable=import-outside-toplevel

        truststore.inject_into_ssl()
    except Exception:                                # pylint: disable=broad-except  # Python's own check still works
        pass


def _own_copy_for_children() -> None:
    """DA.exe: make every DA it starts unpack its own copy (the background dashboard, `da archives --open`, the updater).

    Without this a child DA.exe inherits PyInstaller's settings, reuses this one's temporary folder, and loses its
    files when this one ends and deletes it ("Could not find a suitable TLS CA certificate bundle ... cacert.pem").
    """
    if getattr(sys, "frozen", False):
        os.environ["PYINSTALLER_RESET_ENVIRONMENT"] = "1"


def _note_details(root: Path | None) -> None:
    """Have a hidden DA bring this archive's line in archives.json up to date when its index changed."""
    if root is None:
        return
    try:
        from mindit.services.workflow.archive_details import refresh_later  # pylint: disable=import-outside-toplevel

        refresh_later(root)
    except Exception:                                # pylint: disable=broad-except  # never fail a command for it
        pass


def _command(argv: list[str]) -> str | None:
    """Return the command named in argv (None: `da` on its own, the menu)."""
    skip = False
    for arg in argv:
        if skip:
            skip = False
        elif arg in ("--archive", "--config-dir"):
            skip = True
        elif not arg.startswith("-"):
            return arg
    return None


def _chime(play: Callable[[Any], None]) -> None:
    """Play a start/end chime with the archive's settings; never fail a command for it."""
    try:
        play(load_settings())
    except Exception:                                # pylint: disable=broad-except  # e.g. a broken da-archive.yaml
        try:
            play(None)
        except Exception:                            # pylint: disable=broad-except
            pass


def main() -> None:
    _own_copy_for_children()
    _allow_big_pictures()
    _use_windows_certificates()
    argv = _hoist_arg(sys.argv[1:], "--archive")   # da validate S:\more-fotos --archive D:\jane-archive-198x
    argv, feedback = take_flag(argv)                # da run --no-feedback, da db build --feedback
    cli_config_dir = _extract_arg(argv, "--config-dir")
    resolved_config_dir = resolve_user_config_dir(cli_config_dir=cli_config_dir)
    set_config_root(resolved_config_dir)

    # An archive (a folder with da-archive.yaml) wins over profiles: --archive (before or after the
    # command), else the archive a folder named on the command line is in, else the current folder's
    # (or one above it), else the exe's own folder. An explicit --config-dir keeps the old way.
    root = None
    if not cli_config_dir:
        exe_dir = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else None
        root = set_archive_root(resolve_archive(_extract_arg(argv, "--archive"), Path(os.getcwd()), exe_dir,
                                                targets=_existing_paths(argv)))
        if root is not None:
            # Opening an archive (e.g. its Open DA.cmd on a new PC) makes it one of this PC's archives.
            try:
                register_archive(root)
            except OSError:
                pass
    set_profile_chosen(bool(cli_config_dir or get_env_config_dir() or read_bootstrap_config_dir()))

    command = _command(argv)
    began = time.monotonic()
    _chime(lambda settings: started(feedback, settings))
    try:
        cli.app(args=argv, prog_name=__app_name__)
    except SystemExit as done:                       # Typer always ends with one
        _note_details(root)
        log_command_end(done.code if isinstance(done.code, int) else (0 if done.code is None else 1))
        _chime(lambda settings: ended(feedback, settings, command, time.monotonic() - began))
        raise
    except BaseException as error:                   # pylint: disable=broad-except
        log_command_end(1, error)
        _chime(lambda settings: ended(feedback, settings, command, time.monotonic() - began))
        raise
    log_command_end(0)
    _chime(lambda settings: ended(feedback, settings, command, time.monotonic() - began))


if __name__ == "__main__":
    main()
