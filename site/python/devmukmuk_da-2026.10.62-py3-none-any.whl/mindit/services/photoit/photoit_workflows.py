# src/mindit/services/photoit/photoit_workflows.py

"""PhotoIt workflow services.
# src/mindit/services/photo_workflows.py

Description:
    High-level PhotoIt workflows built from smaller reusable services.

Design:
    This module should contain orchestration logic only. Each workflow should:
    - accept primitive inputs or a shared PhotoIt context
    - call smaller resolver / metadata / duplicate / file services
    - return structured data
    - avoid printing directly

Initial workflow coverage:
    - scan folders
    - detect duplicates
    - quarantine duplicates
    - rename photos
    - move photos
    - create paired metadata .json files
    - run a full end-to-end processing workflow
"""

from __future__ import annotations


from datetime import datetime
import hashlib
import json
import re
import mimetypes
from pathlib import Path
import shutil
from typing import Any

from dataclasses import dataclass

from PIL import Image, ExifTags
#from rich.tree import node

from mindit.services.naming.tokens import CODE_TOKENS, sidecar_tokens, token_value
from mindit.services.sidecar.sidecar_service import SidecarService
from mindit.utils.file_utils import (
    remove_empty_folders_workflow,
)
from mindit.utils.feedback import chime_start, chime_done
from mindit.models.photoit_refs import PhotoFileRef, PhotoRootRef

from mindit.services.photoit.photoit_tag_service import (
    _normalize_tags,
    _merge_tags,
)

from mindit.services.validateit.validateit_file_types import (
    PHOTO_EXTENSIONS,
    PAIRED_MOTION_EXTENSIONS,
)
from mindit.utils.timestamps import UNREADABLE_FILE_TIME, safe_fromtimestamp


NORMALIZED_PHOTO_STEM_PATTERN = re.compile(
    r"^\d{8}_\d{6}_.+",
    re.IGNORECASE,
)

DOUBLE_TIMESTAMP_STEM_PATTERN = re.compile(
    r"^(\d{8}_\d{6})_(\d{8}_\d{6})_(.+)$",
    re.IGNORECASE,
)

TOKEN_PATTERN = re.compile(r"\{([^{}]+)\}")


@dataclass(frozen=True)
class RenameFormatOptions:
    pattern: str = "{date_taken:%Y%m%d_%H%M%S}_{hash:8}"
    lowercase: bool = True
    replace_spaces_with: str = "_"
    sanitize: bool = True
    preserve_extension: bool = True
    rename_sidecar: bool = True
    update_sidecar_contents: bool = True
    skip_if_name_matches: bool = True
    collision_suffix_style: str = "counter"  # counter | hash
    missing_sidecar_action: str = "warn" # options: "ignore" | "warn" | "regenerate"
    separator: str = "_"

try:
    from pillow_heif import register_heif_opener

    register_heif_opener()
    HEIC_SUPPORT_ENABLED = True
except ImportError:
    HEIC_SUPPORT_ENABLED = False

# =============================================================================
# low-level helper functions
# =============================================================================
def _normalize_suffix(path: Path) -> str:
    """Return normalized lowercase file extension."""
    return path.suffix.lower().strip()

def _cleanup_rendered_name(value: str, separator: str = "_") -> str:
    """
    Collapse repeated separators and trim them from both ends.
    """
    value = value.strip()

    if not value:
        return ""

    if separator:
        escaped = re.escape(separator)
        value = re.sub(rf"{escaped}+", separator, value)
        value = re.sub(rf"^{escaped}+|{escaped}+$", "", value)

    return value.strip("._ -")


def _is_photo_file(path: Path) -> bool:
    """Return True when the path looks like a supported photo file."""
    return path.is_file() and _normalize_suffix(path) in PHOTO_EXTENSIONS


def _build_file_id(path: Path) -> str:
    """
    Build a stable-ish file identifier for local filesystem workflows.

    For local files we use the absolute path string as the file_id.
    """
    return str(path.resolve())


def _safe_rel_path(path: Path, root: Path) -> str:
    """Return a relative path string when possible, else just the filename."""
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return path.name


def _read_exif_capture_datetime(path: Path, include_last_saved: bool = True) -> str | None:
    """
    Return EXIF capture datetime in ISO-like string form if available.

    Tries DateTimeOriginal, then DateTimeDigitized (both in the Exif sub-IFD, where cameras
    write them), then the top-level DateTime, which is often when the file was last edited
    (skipped when include_last_saved is False).
    """
    from mindit.services.validateit.raw_files import open_picture  # pylint: disable=import-outside-toplevel

    try:
        with open_picture(path) as image:                 # a CR3 too (its EXIF is in Canon's own records)
            exif = image.getexif()
            if not exif:
                return None

            exif_ifd = exif.get_ifd(ExifTags.IFD.Exif)
            candidates = (
                exif_ifd.get(ExifTags.Base.DateTimeOriginal),
                exif_ifd.get(ExifTags.Base.DateTimeDigitized),
                exif.get(ExifTags.Base.DateTimeOriginal),
                exif.get(ExifTags.Base.DateTime) if include_last_saved else None,
            )
    except Exception:  # pylint: disable=broad-except
        return None

    for raw_value in candidates:
        if not raw_value:
            continue
        # Typical EXIF format: 2024:03:01 18:22:15 (some cameras pad with NULs or spaces)
        text = str(raw_value).strip().strip("\x00").strip()
        try:
            return datetime.strptime(text[:19], "%Y:%m:%d %H:%M:%S").isoformat()
        except ValueError:
            continue
    return None


def _read_image_dimensions(path: Path) -> tuple[int | None, int | None]:
    """Return image width and height when readable."""
    try:
        with Image.open(path) as image:
            width, height = image.size
            return int(width), int(height)
    except Exception:  # pylint: disable=broad-except
        return None, None


def _get_capture_datetime(path: Path) -> datetime:
    """
    Return the best available capture datetime.

    Preference:
        1. EXIF DateTimeOriginal / DateTime
        2. file modified time
    """
    exif_value = _read_exif_capture_datetime(path)
    if exif_value:
        try:
            return datetime.fromisoformat(exif_value)
        except ValueError:
            pass

    return safe_fromtimestamp(path.stat().st_mtime) or UNREADABLE_FILE_TIME


def _compute_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    """Compute SHA-256 for a file."""
    hasher = hashlib.sha256()

    with path.open("rb") as file_handle:
        while True:
            chunk = file_handle.read(chunk_size)
            if not chunk:
                break
            hasher.update(chunk)

    return hasher.hexdigest()


def _build_photo_ref(path: Path, root: Path) -> PhotoFileRef:
    """Build a PhotoFileRef from a filesystem path."""
    stat = path.stat()
    root_ref = PhotoRootRef(root_path=str(root.resolve()))

    return PhotoFileRef(
        file_id=_build_file_id(path),
        file_name=path.name,
        file_ext=_normalize_suffix(path),
        abs_path=str(path.resolve()),
        rel_path=_safe_rel_path(path, root),
        folder_path=str(path.resolve().parent),
        size_bytes=int(stat.st_size),
        modified_ts=float(stat.st_mtime),
        created_ts=float(stat.st_ctime) if hasattr(stat, "st_ctime") else None,
        root_ref=root_ref,
    )


def _default_metadata_path(photo_path: Path) -> Path:
    """Return the sidecar metadata JSON path for a photo file."""
    return Path(f"{photo_path}.meta.json")


def _build_target_filename(
    source_path: Path,
    capture_dt: datetime,
    existing_names: set[str] | None = None,
    rename_options: RenameFormatOptions | None = None,
    existing_metadata: dict[str, Any] | None = None,
    sha256: str | None = None,
) -> str:
    """
    Build a collision-safe target filename.

    Phase 1:
        - supports configurable rename pattern
        - preserves current extension
        - supports tokens:
            {date_taken:%...}
            {orig_stem}
            {orig_folder}
            {hash}
            {hash:8}

    Default behavior remains similar to current rename behavior.
    """
    options = rename_options or RenameFormatOptions()
    ext = _normalize_suffix(source_path)

    resolved_hash = sha256 or _compute_sha256(source_path)

    rename_context = _build_rename_context(
        source_path=source_path,
        capture_dt=capture_dt,
        sha256=resolved_hash,
        existing_metadata=existing_metadata,
    )

    rendered = _render_rename_pattern(options.pattern, rename_context)

    if options.lowercase:
        rendered = rendered.lower()

        # Restore directional GPS tokens (n/s/e/w → N/S/E/W when followed by number)
        rendered = re.sub(
            r"([nsew])(?=\d)",
            lambda m: m.group(1).upper(),
            rendered,
        )

    if options.sanitize:
        rendered = _sanitize_filename_text(
            rendered,
            replace_spaces_with=options.replace_spaces_with,
        )
    rendered = _cleanup_rendered_name(
        rendered,
        separator=options.replace_spaces_with or "_",
    )

    if not rendered:
        rendered = "photo"

    extension = ext if options.preserve_extension else ""
    base_candidate = f"{rendered}{extension}"

    if existing_names is None:
        return base_candidate

    if base_candidate == source_path.name:
        return base_candidate

    return _resolve_filename_collision(
        base_name=rendered,
        extension=extension,
        existing_names=existing_names,
        source_name=source_path.name,
        context=rename_context,
        style=options.collision_suffix_style,
    )

def _build_target_folder(dest_root: Path, capture_dt: datetime) -> Path:
    """Return destination folder path using YYYY/YYYY-MM layout."""
    return dest_root / capture_dt.strftime("%Y") / capture_dt.strftime("%Y-%m")


def _load_metadata_json(metadata_path: Path) -> dict[str, Any] | None:
    """Load sidecar metadata JSON if present."""
    if not metadata_path.exists():
        return None

    try:
        return json.loads(metadata_path.read_text(encoding="utf-8"))
    except Exception:  # pylint: disable=broad-except
        return None


def _write_metadata_json(metadata_path: Path, payload: dict[str, Any]) -> str:
    """Write standardized PhotoIt sidecar metadata."""

    photo_path = Path(str(metadata_path).removesuffix(".meta.json"))

    existing_photoit = SidecarService.get_block(photo_path, "photoit")

    photoit_block = {
        **existing_photoit,
        "captured_at": (
            payload.get("captured_at")
            or existing_photoit.get("captured_at")
        ),
        "original_file_name": payload.get("original_file_name"),
        "exif": (
            payload.get("exif", {})
            or existing_photoit.get("exif", {})
        ),
        "gps": (
            payload.get("gps", {})
            or existing_photoit.get("gps", {})
        ),
        "tags": (
            payload.get("tags")
            or existing_photoit.get("tags", [])
        ),
                "dimensions": payload.get("dimensions", {}),
        "mime_type": payload.get("mime_type"),
        "paired_motion_file": payload.get("paired_motion_file"),
        "converted_jpeg": payload.get("converted_jpeg"),
    }

    data = SidecarService.load(photo_path)

    data["file"].update(
        {
            "source_path": payload.get("source_path"),
            "current_path": payload.get("current_path"),
            "file_name": payload.get("file_name"),
            "extension": payload.get("extension"),
            "size_bytes": payload.get("size_bytes"),
            "created_at": payload.get("created_at"),
            "modified_at": payload.get("modified_at"),
            "sha256": payload.get("sha256"),
        }
    )

    data["classification"].update(
        {
            "module": "photoit",
            "media_type": "photo",
            "status": "active",
        }
    )

    data["photoit"] = photoit_block

    SidecarService.save(photo_path, data)

    return str(metadata_path)


def _build_metadata_payload(
    source_path: Path,
    current_path: Path,
    sha256: str | None = None,
    duplicate_status: str = "original",
    duplicate_of: str | None = None,
    paired_motion_path: Path | None = None,
    converted_jpeg_path: Path | None = None,
    original_file_name: str | None = None,
    original_source_path: str | None = None,
    tags: list[str] | None = None,
) -> dict[str, Any]:
    """
    Build metadata payload for a photo sidecar JSON.

    Important:
        - original_file_name should remain stable across rename/move operations
        - source_path should preserve the first known/original source path
    """
    stat = current_path.stat()
    capture_dt = _get_capture_datetime(current_path)
    width, height = _read_image_dimensions(current_path)
    mime_type, _ = mimetypes.guess_type(str(current_path))
    gps = _read_exif_gps(current_path)

    normalized_tags = [str(tag).strip() for tag in (tags or []) if str(tag).strip()]

    return {
        "source_path": original_source_path or str(source_path.resolve()),
        "current_path": str(current_path.resolve()),
        "file_name": current_path.name,
        "original_file_name": original_file_name or source_path.name,
        "extension": _normalize_suffix(current_path),
        "size_bytes": int(stat.st_size),
        "sha256": sha256,
        "created_at": _iso_or_none(safe_fromtimestamp(stat.st_ctime)) if hasattr(stat, "st_ctime") else None,
        "modified_at": _iso_or_none(safe_fromtimestamp(stat.st_mtime)),
        "captured_at": capture_dt.isoformat(),
        "dimensions": {
            "width": width,
            "height": height,
        },
        "mime_type": mime_type,
        "duplicate_status": duplicate_status,
        "duplicate_of": duplicate_of,
        "paired_motion_file": (
            str(paired_motion_path.resolve()) if paired_motion_path else None
        ),
        "converted_jpeg": (
            str(converted_jpeg_path.resolve()) if converted_jpeg_path else None
        ),
        "tags": normalized_tags,
        "gps": {
            "latitude": gps.get("latitude"),
            "longitude": gps.get("longitude"),
        },
        "imported_by": "DA",
        "module": "photoit",
    }

def _is_already_normalized_photo_name(file_name: str) -> bool:
    """
    Return True when the filename stem already starts with the standard
    YYYYMMDD_HHMMSS_ prefix.
    """
    stem = Path(file_name).stem
    return bool(NORMALIZED_PHOTO_STEM_PATTERN.match(stem))


def _get_original_file_name(
    source_path: Path,
    existing_metadata: dict[str, Any] | None = None,
) -> str:
    """
    Return the preserved original filename when available.
    """
    if existing_metadata:
        photoit = existing_metadata.get("photoit") if isinstance(existing_metadata.get("photoit"), dict) else {}
        # The photoit block (sidecar schema 2), else the old top-level field (schema 1).
        original_name = photoit.get("original_file_name") or existing_metadata.get("original_file_name")
        if original_name:
            return str(original_name)

    return source_path.name

def _strip_existing_timestamp_prefix(stem: str) -> str:
    """
    Remove one leading YYYYMMDD_HHMMSS_ prefix from a stem if present.
    """
    return re.sub(r"^\d{8}_\d{6}_", "", stem)

def _collapse_double_timestamp_prefix(stem: str) -> str:
    """
    Collapse:
        YYYYMMDD_HHMMSS_YYYYMMDD_HHMMSS_rest
    into:
        YYYYMMDD_HHMMSS_rest
    """
    match = DOUBLE_TIMESTAMP_STEM_PATTERN.match(stem)
    if not match:
        return stem

    first_ts, _second_ts, rest = match.groups()
    return f"{first_ts}_{rest}"

def _collapse_duplicate_extension_in_stem(stem: str, ext: str) -> str:
    """
    Collapse bad stems like:
        photo.heic   when ext == ".heic"
        photo.jpg    when ext == ".jpg"

    This repairs filenames such as:
        something.heic.heic
        something.jpg.jpg

    Works on the stem only.
    """
    ext_no_dot = ext.lstrip(".").lower()
    suffix = f".{ext_no_dot}"

    if stem.lower().endswith(suffix):
        return stem[: -len(suffix)]

    return stem

def _get_original_source_path(
    source_path: Path,
    existing_metadata: dict[str, Any] | None = None,
) -> str:
    """
    Return the preserved original source path when available.
    """
    if existing_metadata:
        file_block = existing_metadata.get("file") if isinstance(existing_metadata.get("file"), dict) else {}
        # The old top-level field first (schema 1 kept the first path there), else the file block.
        original_source_path = existing_metadata.get("source_path") or file_block.get("source_path")
        if original_source_path:
            return str(original_source_path)

    return str(source_path.resolve())

def _find_paired_motion_file(photo_path: Path) -> Path | None:
    """
    Try to find a paired motion file for a HEIC image.

    Current heuristic:
        - same folder
        - same file stem
        - extension .mov or .mp4

    Examples:
        IMG_1234.HEIC -> IMG_1234.MOV
        IMG_1234.heic -> IMG_1234.mov
    """
    if _normalize_suffix(photo_path) not in {".heic", ".heif"}:
        return None

    for ext in PAIRED_MOTION_EXTENSIONS:
        candidate = photo_path.with_suffix(ext)
        if candidate.exists() and candidate.is_file():
            return candidate

        candidate_upper = photo_path.with_suffix(ext.upper())
        if candidate_upper.exists() and candidate_upper.is_file():
            return candidate_upper

    return None

def _build_converted_jpeg_path(photo_path: Path) -> Path:
    """Return the sibling JPEG path for a converted HEIC file."""
    return photo_path.with_suffix(".jpg")




def _convert_heic_to_jpeg(
    photo_path: Path,
    jpeg_path: Path | None = None,
    quality: int = 95,
) -> Path | None:
    """
    Convert a HEIC/HEIF image to JPEG while preserving metadata when possible.

    Preserves:
        - EXIF (including GPS if present in EXIF)
        - ICC profile
        - XMP, when available through Pillow image.info

    Returns:
        Path to created JPEG, or None if conversion is not available.
    """
    if _normalize_suffix(photo_path) not in {".heic", ".heif"}:
        return None

    if not HEIC_SUPPORT_ENABLED:
        return None

    target_path = jpeg_path or _build_converted_jpeg_path(photo_path)

    try:
        with Image.open(photo_path) as image:
            # Pull metadata before conversion
            exif_bytes = image.info.get("exif")
            icc_profile = image.info.get("icc_profile")
            xmp_data = image.info.get("xmp")

            rgb_image = image.convert("RGB")
            target_path.parent.mkdir(parents=True, exist_ok=True)

            save_kwargs: dict[str, Any] = {
                "format": "JPEG",
                "quality": quality,
            }

            if exif_bytes:
                save_kwargs["exif"] = exif_bytes

            if icc_profile:
                save_kwargs["icc_profile"] = icc_profile

            # Pillow may support XMP on save depending on version/format support.
            if xmp_data:
                save_kwargs["xmp"] = xmp_data

            rgb_image.save(target_path, **save_kwargs)

        return target_path
    except Exception:  # pylint: disable=broad-except
        return None
    

def _build_rename_context(
    source_path: Path,
    capture_dt: datetime,
    sha256: str,
    existing_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Build supported rename tokens.
    """
    metadata = existing_metadata or {}
    photoit_metadata = _get_photoit_metadata_block(metadata)

    original_file_name = _get_original_file_name(
        source_path=source_path,
        existing_metadata=existing_metadata,
    )
    original_source_path = _get_original_source_path(
        source_path=source_path,
        existing_metadata=existing_metadata,
    )

    original_path = Path(original_source_path)

    # {tag}/{tags}: your own tags (`da tag <files> beach`, the "user" block) first, then any an older
    # version kept in "photoit". Automatic tags (maker:, camera:, ...) never go into names.
    user_block = metadata.get("user") if isinstance(metadata.get("user"), dict) else {}
    tags_list = []
    for raw_tags in (user_block.get("tags", []), photoit_metadata.get("tags", [])):
        if isinstance(raw_tags, str):
            raw_tags = raw_tags.split(",")
        for item in raw_tags if isinstance(raw_tags, list) else []:
            if str(item).strip() and str(item).strip() not in tags_list:
                tags_list.append(str(item).strip())

    gps = (
        photoit_metadata.get("gps")
        if isinstance(photoit_metadata.get("gps"), dict)
        else {}
    )

    gps_lat = gps.get("latitude") if gps else None
    gps_lon = gps.get("longitude") if gps else None

    if gps_lat is None or gps_lon is None:
        exif_gps = _read_exif_gps(source_path)
        gps_lat = exif_gps.get("latitude") if gps_lat is None else gps_lat
        gps_lon = exif_gps.get("longitude") if gps_lon is None else gps_lon

    gps_lat_dir = _format_gps_directional(gps_lat, lat=True)
    gps_lon_dir = _format_gps_directional(gps_lon, lat=False)
    gps_compact = f"{gps_lat_dir}{gps_lon_dir}" if gps_lat_dir and gps_lon_dir else ""

    resolved_folder = (
        original_path.parent.name
        if original_path.parent and original_path.parent.name
        else source_path.parent.name
    )

    tags_joined = "_".join(tags_list)
    first_tag = tags_list[0] if tags_list else ""

    return {
        **sidecar_tokens(source_path, metadata, capture_dt),     # camera, owner, place, title...: the older tokens win
        "date_taken": capture_dt,
        "year": capture_dt.strftime("%Y"),
        "month": capture_dt.strftime("%m"),
        "day": capture_dt.strftime("%d"),
        "orig_name": original_file_name,
        "orig_stem": Path(original_file_name).stem,
        "orig_ext": source_path.suffix.lower().lstrip("."),
        "orig_folder": resolved_folder,
        "folder": resolved_folder,
        "hash": sha256,
        "tag": first_tag,
        "tags": tags_joined,
        "gps_lat": gps_lat,
        "gps_lon": gps_lon,
        "gps_lat_dir": gps_lat_dir,
        "gps_lon_dir": gps_lon_dir,
        "gps_compact": gps_compact,
    }

def _stringify_rename_value(value: Any) -> str:
    if value is None:
        return ""

    if isinstance(value, list):
        return "_".join(str(item) for item in value if str(item).strip())

    return str(value)


def _render_rename_pattern(
    pattern: str,
    context: dict[str, Any],
) -> str:
    """
    Render a rename pattern using supported tokens.
    """
    def replace(match: re.Match[str]) -> str:
        token = match.group(1).strip()

        if token in CODE_TOKENS:                                  # {state:2}, {country:2}: the codes
            return _stringify_rename_value(token_value(token, context))

        if ":" in token:
            field_name, modifier = token.split(":", 1)
            field_name = field_name.strip()
            modifier = modifier.strip()

            value = context.get(field_name)

            if isinstance(value, datetime) and modifier.startswith("%"):
                return value.strftime(modifier)

            if field_name == "gps_lat_dir" and modifier.isdigit():
                return _format_gps_directional(
                    context.get("gps_lat"),
                    lat=True,
                    precision=int(modifier),
                )

            if field_name == "gps_lon_dir" and modifier.isdigit():
                return _format_gps_directional(
                    context.get("gps_lon"),
                    lat=False,
                    precision=int(modifier),
                )

            if value is None:
                return ""

            if isinstance(value, (int, float)):
                if modifier.isdigit():
                    return f"{float(value):.{int(modifier)}f}"
                return str(value)

            text = str(value)

            if modifier.isdigit():
                return text[: int(modifier)]

            return text

        value = context.get(token)
        return _stringify_rename_value(value)

    return TOKEN_PATTERN.sub(replace, pattern)


def _sanitize_filename_text(
    value: str,
    replace_spaces_with: str = "_",
) -> str:
    """
    Sanitize generated filename text for Windows-safe file names.
    """
    value = value.strip()

    if replace_spaces_with:
        value = re.sub(r"\s+", replace_spaces_with, value)

    value = re.sub(r'[<>:"/\\|?*]+', "_", value)
    value = re.sub(r"_+", "_", value)
    value = re.sub(r"\.+", ".", value)

    return value.strip("._ ")


def _resolve_filename_collision(
    *,
    base_name: str,
    extension: str,
    existing_names: set[str],
    source_name: str,
    context: dict[str, Any],
    style: str = "counter",
) -> str:
    """
    Resolve collisions for a generated filename.
    """
    comparison_names = set(existing_names)
    comparison_names.discard(source_name)

    candidate = f"{base_name}{extension}"
    if candidate not in comparison_names:
        return candidate

    if style == "hash":
        short_hash = str(context.get("hash", ""))[:8]
        candidate = f"{base_name}_{short_hash}{extension}"
        if candidate not in comparison_names:
            return candidate

    counter = 2
    while True:
        candidate = f"{base_name}_{counter:03d}{extension}"
        if candidate not in comparison_names:
            return candidate
        counter += 1

# =============================================================================
# scan workflow
# =============================================================================
def scan_photos_workflow(
    folder: str,
    recursive: bool = True,
) -> dict[str, Any]:
    """
    Scan a folder and return discovered PhotoFileRef objects.
    """
    root = Path(folder).expanduser().resolve()

    if not root.exists():
        raise FileNotFoundError(f"Folder not found: {root}")

    walker = root.rglob("*") if recursive else root.glob("*")
    photos = [_build_photo_ref(path, root) for path in walker if _is_photo_file(path)]

    return {
        "root": str(root),
        "recursive": recursive,
        "count": len(photos),
        "photos": photos,
    }



# =============================================================================
# tag workflows
# =============================================================================
def _get_photoit_metadata_block(
    metadata: dict[str, Any] | None,
) -> dict[str, Any]:
    if not isinstance(metadata, dict):
        return {}

    photoit = metadata.get("photoit")

    if isinstance(photoit, dict):
        return photoit

    return metadata


def tag_photos_workflow(
    folder: str,
    recursive: bool = True,
    add_tags: list[str] | None = None,
    remove_tags: list[str] | None = None,
    replace_tags: list[str] | None = None,
    dry_run: bool = True,
    refresh_missing_metadata: bool = True,
) -> dict[str, Any]:
    """
    Add, remove, or replace tags in photo sidecar metadata files.

    Behavior:
        - scans photos under folder
        - loads existing sidecar metadata when present
        - optionally creates missing metadata sidecars first
        - updates the PhotoIt tags field only
        - preserves all other metadata fields
    """
    scan_result = scan_photos_workflow(folder=folder, recursive=recursive)
    photos: list[PhotoFileRef] = scan_result["photos"]

    normalized_add = _normalize_tags(add_tags)
    normalized_remove = _normalize_tags(remove_tags)
    normalized_replace = (
        _normalize_tags(replace_tags) if replace_tags is not None else None
    )

    actions: list[dict[str, Any]] = []

    for photo in photos:
        photo_path = Path(photo.abs_path)
        metadata_path = _default_metadata_path(photo_path)
        sidecar_exists = metadata_path.exists()

        existing_metadata = _load_metadata_json(metadata_path)
        if existing_metadata is None:
            existing_metadata = {}

        photoit_metadata = _get_photoit_metadata_block(existing_metadata)

        action: dict[str, Any] = {
            "photo_path": str(photo_path),
            "metadata_path": str(metadata_path),
            "sidecar_exists": sidecar_exists,
            "dry_run": dry_run,
        }

        if not sidecar_exists and refresh_missing_metadata:
            sha256 = _compute_sha256(photo_path)

            original_file_name = _get_original_file_name(
                source_path=photo_path,
                existing_metadata=existing_metadata,
            )
            original_source_path = _get_original_source_path(
                source_path=photo_path,
                existing_metadata=existing_metadata,
            )

            regenerated_payload = _build_metadata_payload(
                source_path=photo_path,
                current_path=photo_path,
                sha256=sha256,
                original_file_name=original_file_name,
                original_source_path=original_source_path,
                tags=[],
            )

            if not dry_run:
                _write_metadata_json(metadata_path, regenerated_payload)

            existing_metadata = regenerated_payload
            photoit_metadata = _get_photoit_metadata_block(existing_metadata)
            sidecar_exists = True
            action["sidecar_created"] = True
            action["sidecar_exists"] = True

        elif not sidecar_exists:
            action["warning"] = "missing_sidecar"

        existing_tags = photoit_metadata.get("tags", [])
        if not isinstance(existing_tags, list):
            if isinstance(existing_tags, str):
                existing_tags = [
                    item.strip() for item in existing_tags.split(",") if item.strip()
                ]
            else:
                existing_tags = []

        tags_before = _normalize_tags(existing_tags)
        tags_after = _merge_tags(
            existing_tags=tags_before,
            add_tags=normalized_add,
            remove_tags=normalized_remove,
            replace_tags=normalized_replace,
        )

        action["tags_before"] = tags_before
        action["tags_after"] = tags_after
        action["updated"] = tags_before != tags_after

        if action["updated"] and sidecar_exists and not dry_run:
            photoit_payload = dict(photoit_metadata)
            photoit_payload["tags"] = tags_after

            SidecarService.update_block(
                photo_path,
                "photoit",
                photoit_payload,
            )

        actions.append(action)

    updated_count = sum(1 for action in actions if action.get("updated") is True)
    missing_sidecar_count = sum(
        1 for action in actions if action.get("warning") == "missing_sidecar"
    )
    created_sidecar_count = sum(
        1 for action in actions if action.get("sidecar_created") is True
    )

    return {
        "folder": folder,
        "recursive": recursive,
        "dry_run": dry_run,
        "add_tags": normalized_add,
        "remove_tags": normalized_remove,
        "replace_tags": normalized_replace,
        "photo_count": len(photos),
        "updated_count": updated_count,
        "missing_sidecar_count": missing_sidecar_count,
        "created_sidecar_count": created_sidecar_count,
        "actions": actions,
    }


def find_photos_workflow(
    folder: str,
    recursive: bool = True,
    require_tags: list[str] | None = None,
    exclude_tags: list[str] | None = None,
    require_gps: bool = False,
    date_prefix: str | None = None,
    file_name_contains: str | None = None,
) -> dict[str, Any]:
    """
    Find photos by metadata/tag/GPS/file-name filters.

    Filters:
        - require_tags: photo must contain all of these tags
        - exclude_tags: photo must contain none of these tags
        - require_gps: photo must have latitude and/or longitude
        - date_prefix: matches captured_at prefix, e.g. "2022-07" or "2022-07-10"
        - file_name_contains: case-insensitive substring match on file name

    Notes:
        - if metadata sidecar is missing, the photo is skipped from metadata-based
          matching but still included in scan counts
        - tags are normalized before comparison
    """
    scan_result = scan_photos_workflow(folder=folder, recursive=recursive)
    photos: list[PhotoFileRef] = scan_result["photos"]

    normalized_require = _normalize_tags(require_tags)
    normalized_exclude = _normalize_tags(exclude_tags)
    normalized_name_contains = (
        file_name_contains.strip().lower() if file_name_contains else None
    )
    normalized_date_prefix = date_prefix.strip() if date_prefix else None

    matches: list[dict[str, Any]] = []
    missing_sidecar_count = 0
    metadata_read_count = 0

    for photo in photos:
        photo_path = Path(photo.abs_path)
        metadata_path = _default_metadata_path(photo_path)
        sidecar_exists = metadata_path.exists()

        if not sidecar_exists:
            missing_sidecar_count += 1

        existing_metadata = _load_metadata_json(metadata_path)
        if existing_metadata is None:
            existing_metadata = {}

        if sidecar_exists:
            metadata_read_count += 1

        file_name = photo.file_name
        if normalized_name_contains and normalized_name_contains not in file_name.lower():
            continue

        existing_tags = existing_metadata.get("tags", [])
        if not isinstance(existing_tags, list):
            if isinstance(existing_tags, str):
                existing_tags = [
                    item.strip() for item in existing_tags.split(",") if item.strip()
                ]
            else:
                existing_tags = []

        normalized_tags = _normalize_tags(existing_tags)
        tag_set = set(normalized_tags)

        if normalized_require and not all(tag in tag_set for tag in normalized_require):
            continue

        if normalized_exclude and any(tag in tag_set for tag in normalized_exclude):
            continue

        gps = existing_metadata.get("gps", {})
        if not isinstance(gps, dict):
            gps = {}

        gps_present = (
            gps.get("latitude") is not None or gps.get("longitude") is not None
        )

        if require_gps and not gps_present:
            continue

        captured_at = str(existing_metadata.get("captured_at", "")).strip()
        if normalized_date_prefix and not captured_at.startswith(normalized_date_prefix):
            continue

        matches.append(
            {
                "photo_path": str(photo_path),
                "metadata_path": str(metadata_path),
                "sidecar_exists": sidecar_exists,
                "file_name": file_name,
                "tags": normalized_tags,
                "tag_count": len(normalized_tags),
                "gps_present": gps_present,
                "gps": {
                    "latitude": gps.get("latitude"),
                    "longitude": gps.get("longitude"),
                },
                "captured_at": captured_at or None,
            }
        )

    return {
        "folder": folder,
        "recursive": recursive,
        "photo_count": len(photos),
        "metadata_read_count": metadata_read_count,
        "missing_sidecar_count": missing_sidecar_count,
        "require_tags": normalized_require,
        "exclude_tags": normalized_exclude,
        "require_gps": require_gps,
        "date_prefix": normalized_date_prefix,
        "file_name_contains": normalized_name_contains,
        "match_count": len(matches),
        "matches": matches,
    }



# =============================================================================
# duplicate detection workflow
# =============================================================================
def detect_duplicates_workflow(
    folder: str,
    recursive: bool = True,
) -> dict[str, Any]:
    """
    Detect duplicates in a folder.

    Duplicate groups:
        - exact_hash_duplicates
        - probable_duplicates
        - name_duplicates
    """
    scan_result = scan_photos_workflow(folder=folder, recursive=recursive)
    root = Path(scan_result["root"])
    photos: list[PhotoFileRef] = scan_result["photos"]

    hash_groups: dict[str, list[PhotoFileRef]] = {}
    probable_groups: dict[str, list[PhotoFileRef]] = {}
    name_groups: dict[str, list[PhotoFileRef]] = {}

    for photo in photos:
        photo_path = Path(photo.abs_path)
        sha256 = _compute_sha256(photo_path)
        hash_groups.setdefault(sha256, []).append(photo)

        capture_dt = _get_capture_datetime(photo_path)
        width, height = _read_image_dimensions(photo_path)

        probable_key = "|".join(
            [
                str(photo.size_bytes),
                capture_dt.isoformat(),
                str(width),
                str(height),
            ]
        )
        probable_groups.setdefault(probable_key, []).append(photo)

        normalized_name = photo.file_name.strip().lower()
        name_groups.setdefault(normalized_name, []).append(photo)

    exact_duplicates = {
        file_hash: refs
        for file_hash, refs in hash_groups.items()
        if len(refs) > 1
    }

    probable_duplicates = {
        key: refs
        for key, refs in probable_groups.items()
        if len(refs) > 1
    }

    name_duplicates = {
        key: refs
        for key, refs in name_groups.items()
        if len(refs) > 1
    }

    return {
        "root": str(root),
        "total_photos": len(photos),
        "exact_hash_duplicate_groups": exact_duplicates,
        "probable_duplicate_groups": probable_duplicates,
        "name_duplicate_groups": name_duplicates,
        "exact_hash_duplicate_count": sum(len(group) for group in exact_duplicates.values()),
        "probable_duplicate_count": sum(len(group) for group in probable_duplicates.values()),
        "name_duplicate_count": sum(len(group) for group in name_duplicates.values()),
    }
    
# =============================================================================
# EXIF GPS helpers
# =============================================================================  
def _extract_exif_tag_map(path: Path) -> dict[str, Any]:
    """
    Return EXIF tag map with human-readable tag names when possible.
    """
    try:
        with Image.open(path) as image:
            exif = image.getexif()
            if not exif:
                return {}

            tag_map: dict[str, Any] = {}

            for tag_id, value in exif.items():
                tag_name = ExifTags.TAGS.get(tag_id, f"Tag_{tag_id}")
                tag_map[str(tag_name)] = value

            return tag_map

    except Exception:  # pylint: disable=broad-except
        return {}


def _rational_to_float(value: Any) -> float | None:
    """
    Convert EXIF rational-ish values to float.
    """
    try:
        # Already numeric
        if isinstance(value, (int, float)):
            return float(value)

        # EXIF rational object (PIL style)
        if hasattr(value, "numerator") and hasattr(value, "denominator"):
            denominator = float(value.denominator)
            if denominator == 0:
                return None
            return float(value.numerator) / denominator

        # Tuple (num, denom)
        if isinstance(value, tuple):
            if len(value) != 2:
                return None

            numerator, denominator = value

            if not isinstance(numerator, (int, float)) or not isinstance(denominator, (int, float)):
                return None

            if denominator == 0:
                return None

            return float(numerator) / float(denominator)

        # String or other convertible types
        if isinstance(value, str):
            return float(value)

        # Final fallback — only if explicitly safe
        return float(value) if hasattr(value, "__float__") else None

    except Exception:  # pylint: disable=broad-except
        return None


def _dms_to_decimal(
    dms: Any,
    ref: str | None,
) -> float | None:
    """
    Convert EXIF GPS degrees/minutes/seconds to signed decimal degrees.
    """
    try:
        if not dms or len(dms) < 3:
            return None

        degrees = _rational_to_float(dms[0])
        minutes = _rational_to_float(dms[1])
        seconds = _rational_to_float(dms[2])

        if degrees is None or minutes is None or seconds is None:
            return None

        decimal = degrees + (minutes / 60.0) + (seconds / 3600.0)

        if ref and str(ref).upper() in {"S", "W"}:
            decimal *= -1.0

        return round(decimal, 6)
    except Exception:  # pylint: disable=broad-except
        return None


def _read_exif_gps(path: Path) -> dict[str, float | None]:
    """
    Extract GPS latitude/longitude from EXIF when available.

    Returns:
        {"latitude": float | None, "longitude": float | None}
    """
    try:
        with Image.open(path) as image:
            exif = image.getexif()
            if not exif:
                return {"latitude": None, "longitude": None}

            gps_ifd = exif.get_ifd(ExifTags.Base.GPSInfo)
            if not gps_ifd:
                return {"latitude": None, "longitude": None}

            gps_map = {
                ExifTags.GPSTAGS.get(tag_id, tag_id): value
                for tag_id, value in gps_ifd.items()
            }

            latitude = _dms_to_decimal(
                gps_map.get("GPSLatitude"),
                gps_map.get("GPSLatitudeRef"),
            )
            longitude = _dms_to_decimal(
                gps_map.get("GPSLongitude"),
                gps_map.get("GPSLongitudeRef"),
            )

            return {
                "latitude": latitude,
                "longitude": longitude,
            }
    except Exception:  # pylint: disable=broad-except
        return {"latitude": None, "longitude": None}


def _format_gps_directional(
    value: float | None,
    *,
    lat: bool,
    precision: int = 0,
) -> str:
    """
    Format GPS coordinate as directional text.

    Examples:
        latitude  41.954181 -> N41
        longitude -87.593269 -> W87

        with precision=2:
            41.954181 -> N41.95
            -87.593269 -> W87.59
    """
    if value is None:
        return ""

    direction = ""
    if lat:
        direction = "N" if value >= 0 else "S"
    else:
        direction = "E" if value >= 0 else "W"

    abs_value = abs(value)

    if precision > 0:
        formatted = f"{abs_value:.{precision}f}"
    else:
        formatted = str(int(abs_value))

    return f"{direction}{formatted}"

# =============================================================================
# repair jpeg from heic workflow
# =============================================================================
def repair_jpeg_from_heic_workflow(
    folder: str,
    recursive: bool = True,
    dry_run: bool = True,
) -> dict[str, Any]:
    """
    Recreate JPEG files from HEIC sources to restore metadata (EXIF, GPS, etc).

    Behavior:
        - finds .HEIC/.HEIF files
        - finds corresponding .JPG
        - overwrites JPG with a fresh conversion (preserving metadata)
        - does NOT delete anything
    """
    scan_result = scan_photos_workflow(folder=folder, recursive=recursive)
    photos: list[PhotoFileRef] = scan_result["photos"]

    actions: list[dict[str, Any]] = []

    for photo in photos:
        heic_path = Path(photo.abs_path)

        if _normalize_suffix(heic_path) not in {".heic", ".heif"}:
            continue

        jpeg_path = _build_converted_jpeg_path(heic_path)

        # only repair if jpg already exists
        if not jpeg_path.exists():
            continue

        action: dict[str, Any] = {
            "heic": str(heic_path),
            "jpeg": str(jpeg_path),
            "dry_run": dry_run,
        }

        if not dry_run:
            new_jpeg = _convert_heic_to_jpeg(
                photo_path=heic_path,
                jpeg_path=jpeg_path,
            )

            if new_jpeg:
                action["status"] = "repaired"
            else:
                action["status"] = "failed"

        actions.append(action)

    return {
        "folder": folder,
        "recursive": recursive,
        "dry_run": dry_run,
        "repair_count": len(actions),
        "actions": actions,
    }

# =============================================================================
# VERBOSE ON|OFF workflow
# =============================================================================
def render_workflow_result(result, *, verbose: bool) -> None:
    print(result.summary_text)

    if verbose:
        print(result.details_text)


def write_workflow_log(result, log_dir: Path, workflow_name: str) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"photoit_{workflow_name}_{timestamp}.log"

    log_path.write_text(
        result.full_text,
        encoding="utf-8",
    )

    return log_path


# =============================================================================
# quarantine duplicates workflow
# =============================================================================
def quarantine_duplicates_workflow(
    folder: str,
    quarantine_dir: str = "output/photoit/quarantine",
    recursive: bool = True,
    dry_run: bool = True,
) -> dict[str, Any]:
    """
    Quarantine exact hash duplicates.

    Policy:
        - keep the oldest path in each exact-hash group
        - quarantine the rest
        - update/create metadata JSON for quarantined files
    """
    duplicate_result = detect_duplicates_workflow(folder=folder, recursive=recursive)
    quarantine_root = Path(quarantine_dir).expanduser().resolve()

    actions: list[dict[str, Any]] = []
    kept: list[str] = []
    quarantined: list[str] = []

    for group in duplicate_result["exact_hash_duplicate_groups"].values():
        sorted_group = sorted(group, key=lambda item: (item.modified_ts, item.abs_path))
        keeper = sorted_group[0]
        kept.append(keeper.abs_path)

        for duplicate in sorted_group[1:]:
            source_path = Path(duplicate.abs_path)
            target_dir = quarantine_root / datetime.now().strftime("%Y-%m-%d")
            target_dir.mkdir(parents=True, exist_ok=True)
            target_path = target_dir / source_path.name

            if target_path.exists():
                counter = 1
                while True:
                    candidate = target_dir / f"{source_path.stem}_{counter:03d}{source_path.suffix.lower()}"
                    if not candidate.exists():
                        target_path = candidate
                        break
                    counter += 1

            action = {
                "source": str(source_path),
                "target": str(target_path),
                "kept_original": keeper.abs_path,
                "dry_run": dry_run,
            }

            if not dry_run:
                shutil.move(str(source_path), str(target_path))
                sha256 = _compute_sha256(target_path)
                metadata_payload = _build_metadata_payload(
                    source_path=source_path,
                    current_path=target_path,
                    sha256=sha256,
                    duplicate_status="quarantined",
                    duplicate_of=keeper.abs_path,
                )
                metadata_path = _default_metadata_path(target_path)
                action["metadata_path"] = _write_metadata_json(metadata_path, metadata_payload)

            actions.append(action)
            quarantined.append(str(target_path) if not dry_run else str(source_path))

    return {
        "folder": folder,
        "quarantine_dir": str(quarantine_root),
        "dry_run": dry_run,
        "kept_count": len(kept),
        "quarantined_count": len(actions),
        "kept": kept,
        "actions": actions,
    }


# ---------------------------------------------------------------------------
# rename_photos_workflow()
# ---------------------------------------------------------------------------
def rename_photos_workflow(
    folder: str,
    recursive: bool = True,
    dry_run: bool = False,
    rename_options: RenameFormatOptions | None = None,
) -> dict[str, Any]:
    """
    Rename photos in place using a configurable pattern.

    Supported tokens:
        {date_taken:%Y}
        {date_taken:%Y%m%d_%H%M%S}
        {orig_stem}
        {orig_folder}
        {folder}
        {orig_ext}
        {hash}
        {hash:8}
        {tag}
        {tags}
        {gps_lat}
        {gps_lon}
        {year}
        {month}
        {day}

    Rules:
        - preserve original_file_name in metadata across future operations
        - move/refresh sidecar JSON alongside renamed photo
        - surface missing sidecar warnings even when no rename is needed
    """
    options = rename_options or RenameFormatOptions()

    scan_result = scan_photos_workflow(folder=folder, recursive=recursive)
    photos: list[PhotoFileRef] = scan_result["photos"]

    actions: list[dict[str, Any]] = []
    names_by_dir: dict[str, set[str]] = {}

    for photo in photos:
        source_path = Path(photo.abs_path)
        parent_key = str(source_path.parent.resolve())
        names_by_dir.setdefault(parent_key, set())

    for photo in photos:
        source_path = Path(photo.abs_path)
        parent_dir = source_path.parent.resolve()
        parent_key = str(parent_dir)

        if not names_by_dir[parent_key]:
            names_by_dir[parent_key].update(item.name for item in parent_dir.iterdir())

        existing_names = names_by_dir[parent_key]
        source_meta = _default_metadata_path(source_path)
        sidecar_exists = source_meta.exists()
        existing_metadata = _load_metadata_json(source_meta)

        capture_dt = _get_capture_datetime(source_path)
        sha256 = _compute_sha256(source_path)

        photoit_metadata = _get_photoit_metadata_block(existing_metadata)

        gps = photoit_metadata.get("gps", {})
        tags = photoit_metadata.get("tags", [])

        gps_present = isinstance(gps, dict) and (
            gps.get("latitude") is not None or gps.get("longitude") is not None
        )

        if isinstance(tags, str):
            tag_count = len([item.strip() for item in tags.split(",") if item.strip()])
        elif isinstance(tags, list):
            tag_count = len(tags)
        else:
            tag_count = 0

        new_name = _build_target_filename(
            source_path=source_path,
            capture_dt=capture_dt,
            existing_names=existing_names,
            rename_options=options,
            existing_metadata=existing_metadata,
            sha256=sha256,
        )
        target_path = parent_dir / new_name

        action: dict[str, Any] = {
            "source": str(source_path),
            "target": str(target_path),
            "source_metadata": str(source_meta),
            "target_metadata": str(_default_metadata_path(target_path)),
            "dry_run": dry_run,
            "pattern": options.pattern,
            "sidecar_exists": sidecar_exists,
            "gps_present": gps_present,
            "tag_count": tag_count,
        }

        if not sidecar_exists:
            if options.missing_sidecar_action == "warn":
                action["warning"] = "missing_sidecar"

            elif options.missing_sidecar_action == "regenerate":
                action["warning"] = "missing_sidecar"

                if not dry_run:
                    original_file_name = source_path.name
                    original_source_path = str(source_path.resolve())

                    payload = _build_metadata_payload(
                        source_path=source_path,
                        current_path=source_path,
                        sha256=sha256,
                        original_file_name=original_file_name,
                        original_source_path=original_source_path,
                    )

                    _write_metadata_json(source_meta, payload)
                    sidecar_exists = True
                    existing_metadata = payload
                    action["sidecar_regenerated"] = True
                    action["sidecar_exists"] = True

                    regenerated_photoit = _get_photoit_metadata_block(payload)
                    regenerated_gps = regenerated_photoit.get("gps", {})
                    regenerated_tags = regenerated_photoit.get("tags", [])

                    action["gps_present"] = isinstance(regenerated_gps, dict) and (
                        regenerated_gps.get("latitude") is not None
                        or regenerated_gps.get("longitude") is not None
                    )
                    action["tag_count"] = (
                        len(regenerated_tags) if isinstance(regenerated_tags, list) else 0
                    )

        if options.skip_if_name_matches and source_path.name == new_name:
            action["skipped_reason"] = "name_matches"
            actions.append(action)
            continue

        if not dry_run:
            action["metadata_path"] = _apply_photo_and_sidecar_rename(
                source_path=source_path,
                target_path=target_path,
                existing_metadata=existing_metadata,
                rename_options=options,
                sha256=sha256,
            )

        existing_names.discard(source_path.name)
        existing_names.add(new_name)
        actions.append(action)

    missing_sidecar_count = sum(
        1 for action in actions if action.get("warning") == "missing_sidecar"
    )
    skipped_count = sum(
        1 for action in actions if action.get("skipped_reason") == "name_matches"
    )
    renamed_count = sum(
        1 for action in actions if action.get("skipped_reason") != "name_matches"
    )
    gps_present_count = sum(
        1 for action in actions if action.get("gps_present") is True
    )
    tagged_count = sum(
        1 for action in actions if action.get("tag_count", 0) > 0
    )

    return {
        "folder": folder,
        "dry_run": dry_run,
        "pattern": options.pattern,
        "rename_count": renamed_count,
        "missing_sidecar_count": missing_sidecar_count,
        "skipped_count": skipped_count,
        "gps_present_count": gps_present_count,
        "tagged_count": tagged_count,
        "actions": actions,
    }


def _apply_photo_and_sidecar_rename(
    source_path: Path,
    target_path: Path,
    existing_metadata: dict[str, Any] | None = None,
    rename_options: RenameFormatOptions | None = None,
    sha256: str | None = None,
) -> str | None:
    options = rename_options or RenameFormatOptions()

    source_meta = _default_metadata_path(source_path)
    target_meta = _default_metadata_path(target_path)

    original_file_name = _get_original_file_name(
        source_path=source_path,
        existing_metadata=existing_metadata,
    )
    original_source_path = _get_original_source_path(
        source_path=source_path,
        existing_metadata=existing_metadata,
    )

    shutil.move(str(source_path), str(target_path))

    if options.rename_sidecar and source_meta.exists():
        shutil.move(str(source_meta), str(target_meta))
    elif source_meta.exists():
        target_meta = source_meta

    if not options.update_sidecar_contents:
        return str(target_meta) if target_meta.exists() else None

    resolved_sha256 = sha256 or _compute_sha256(target_path)

    metadata_payload = _build_metadata_payload(
        source_path=source_path,
        current_path=target_path,
        sha256=sha256,
        original_file_name=original_file_name,
        original_source_path=original_source_path,
    )

    return _write_metadata_json(target_meta, metadata_payload)

# ---------------------------------------------------------------------------
# move_photos_workflow()
# ---------------------------------------------------------------------------
def move_photos_workflow(
    source_folder: str,
    dest_root: str,
    recursive: bool = True,
    dry_run: bool = True,
    convert_heic: bool = True,
) -> dict[str, Any]:
    """
    Move photos into YYYY/YYYY-MM folders under dest_root.

    For HEIC files, keep related assets together:
        - original HEIC
        - paired motion file
        - converted JPEG
        - metadata JSON

    Also preserves original_file_name and original source path in metadata.
    """
    scan_result = scan_photos_workflow(folder=source_folder, recursive=recursive)
    photos: list[PhotoFileRef] = scan_result["photos"]
    destination_root = Path(dest_root).expanduser().resolve()

    actions: list[dict[str, Any]] = []

    for photo in photos:
        source_path = Path(photo.abs_path)
        capture_dt = _get_capture_datetime(source_path)
        target_dir = _build_target_folder(destination_root, capture_dt)

        existing_names = {item.name for item in target_dir.iterdir()} if target_dir.exists() else set()

        target_name = _build_target_filename(
            source_path=source_path,
            capture_dt=capture_dt,
            existing_names=existing_names,
        )
        target_path = target_dir / target_name

        source_meta = _default_metadata_path(source_path)
        existing_metadata = _load_metadata_json(source_meta)
        paired_motion = _find_paired_motion_file(source_path)

        converted_jpeg_source: Path | None = None
        if convert_heic and _normalize_suffix(source_path) in {".heic", ".heif"}:
            converted_jpeg_source = _build_converted_jpeg_path(source_path)
            if not converted_jpeg_source.exists():
                converted_jpeg_source = _convert_heic_to_jpeg(source_path)

        converted_jpeg_target: Path | None = None
        paired_motion_target: Path | None = None

        if paired_motion:
            paired_motion_target = target_dir / paired_motion.name

        if converted_jpeg_source and converted_jpeg_source.exists():
            converted_jpeg_target = target_dir / converted_jpeg_source.name

        action: dict[str, Any] = {
            "source": str(source_path),
            "target": str(target_path),
            "paired_motion_source": str(paired_motion) if paired_motion else None,
            "paired_motion_target": str(paired_motion_target) if paired_motion_target else None,
            "converted_jpeg_source": (
                str(converted_jpeg_source) if converted_jpeg_source else None
            ),
            "converted_jpeg_target": (
                str(converted_jpeg_target) if converted_jpeg_target else None
            ),
            "dry_run": dry_run,
        }

        if not dry_run:
            target_dir.mkdir(parents=True, exist_ok=True)

            shutil.move(str(source_path), str(target_path))

            if paired_motion and paired_motion.exists() and paired_motion_target:
                shutil.move(str(paired_motion), str(paired_motion_target))

            if (
                converted_jpeg_source
                and converted_jpeg_source.exists()
                and converted_jpeg_target
            ):
                shutil.move(str(converted_jpeg_source), str(converted_jpeg_target))

            target_meta = _default_metadata_path(target_path)
            sha256 = _compute_sha256(target_path)

            original_file_name = _get_original_file_name(
                source_path=source_path,
                existing_metadata=existing_metadata,
            )
            original_source_path = _get_original_source_path(
                source_path=source_path,
                existing_metadata=existing_metadata,
            )

            payload = _build_metadata_payload(
                source_path=source_path,
                current_path=target_path,
                sha256=sha256,
                paired_motion_path=paired_motion_target,
                converted_jpeg_path=converted_jpeg_target,
                original_file_name=original_file_name,
                original_source_path=original_source_path,
            )

            _write_metadata_json(target_meta, payload)

            if source_meta.exists() and source_meta != target_meta:
                try:
                    source_meta.unlink()
                except OSError:
                    pass

            action["metadata_path"] = str(target_meta)

        actions.append(action)

    return {
        "source_folder": source_folder,
        "dest_root": str(destination_root),
        "dry_run": dry_run,
        "convert_heic": convert_heic,
        "move_count": len(actions),
        "actions": actions,
    }


# =============================================================================
# metadata workflow
# =============================================================================
# ---------------------------------------------------------------------------
# replace create_metadata_workflow()
# ---------------------------------------------------------------------------
def create_metadata_workflow(
    folder: str,
    recursive: bool = True,
    refresh_existing: bool = True,
    convert_heic: bool = True,
) -> dict[str, Any]:
    """
    Create or refresh paired metadata JSON files for all photos.

    For HEIC files:
        - detect paired motion file
        - optionally create sibling JPEG conversion
        - store both in metadata
    """
    scan_result = scan_photos_workflow(folder=folder, recursive=recursive)
    photos: list[PhotoFileRef] = scan_result["photos"]

    written: list[dict[str, Any]] = []

    for photo in photos:
        photo_path = Path(photo.abs_path)
        metadata_path = _default_metadata_path(photo_path)
        existing_metadata = _load_metadata_json(metadata_path)

        if metadata_path.exists() and not refresh_existing:
            continue

        paired_motion = _find_paired_motion_file(photo_path)
        converted_jpeg: Path | None = None

        if convert_heic and _normalize_suffix(photo_path) in {".heic", ".heif"}:
            converted_jpeg = _convert_heic_to_jpeg(photo_path)

        sha256 = _compute_sha256(photo_path)

        original_file_name = _get_original_file_name(
            source_path=photo_path,
            existing_metadata=existing_metadata,
        )
        original_source_path = _get_original_source_path(
            source_path=photo_path,
            existing_metadata=existing_metadata,
        )

        payload = _build_metadata_payload(
            source_path=photo_path,
            current_path=photo_path,
            sha256=sha256,
            paired_motion_path=paired_motion,
            converted_jpeg_path=converted_jpeg,
            original_file_name=original_file_name,
            original_source_path=original_source_path,
        )

        written.append(
            {
                "photo_path": str(photo_path),
                "paired_motion_file": str(paired_motion) if paired_motion else None,
                "converted_jpeg": str(converted_jpeg) if converted_jpeg else None,
                "metadata_path": _write_metadata_json(metadata_path, payload),
            }
        )

    return {
        "folder": folder,
        "recursive": recursive,
        "refresh_existing": refresh_existing,
        "convert_heic": convert_heic,
        "metadata_written_count": len(written),
        "written": written,
    }


# =============================================================================
# full process workflow
# =============================================================================
def process_photos_workflow(
    source_folder: str,
    dest_root: str,
    quarantine_dir: str = "output/photoit/quarantine",
    recursive: bool = True,
    dry_run: bool = True,
    convert_heic: bool = True,
    feedback: bool =  True,
) -> dict[str, Any]:
    """
    Run the end-to-end PhotoIt workflow.
    """
    if feedback:
        print("Starting full photo processing workflow...")
        print(f"Source folder: {source_folder}")
        chime_start()
    
    try:
        
        initial_scan = scan_photos_workflow(folder=source_folder, recursive=recursive)
        duplicates = detect_duplicates_workflow(folder=source_folder, recursive=recursive)

        quarantine = quarantine_duplicates_workflow(
            folder=source_folder,
            quarantine_dir=quarantine_dir,
            recursive=recursive,
            dry_run=dry_run,
        )

        rename = rename_photos_workflow(
            folder=source_folder,
            recursive=recursive,
            dry_run=dry_run,
        )

        move = move_photos_workflow(
            source_folder=source_folder,
            dest_root=dest_root,
            recursive=recursive,
            dry_run=dry_run,
        )

        # move_photos_workflow already writes metadata for each moved photo.
        # Do not run create_metadata_workflow(dest_root), because that scans and
        # rewrites metadata for the entire organized folder.
        # Update metadata block to safely handle missing "actions":
        if dry_run:
            metadata_result = {
                "folder": dest_root,
                "metadata_written_count": 0,
                "written": [],
                "skipped_reason": "dry_run",
            }
        else:
            move_actions = move.get("actions")

            if move_actions:
                moved_metadata = [
                    {
                        "photo_path": action["target"],
                        "metadata_path": action["metadata_path"],
                    }
                    for action in move_actions
                    if action.get("metadata_path")
                ]

                metadata_result = {
                    "folder": dest_root,
                    "metadata_written_count": len(moved_metadata),
                    "written": moved_metadata,
                    "source": "move_photos_workflow",
                }
            else:
                # fallback for tests / mocked workflows
                metadata_result = {
                "folder": dest_root,
                "metadata_written_count": move.get("move_count", 0),
                "written": [],
                "source": "move_photos_workflow_fallback",
            }

        empty_folder_cleanup = remove_empty_folders_workflow(
            folder=source_folder,
            dry_run=dry_run,
        )

        return {
            "source_folder": source_folder,
            "dest_root": dest_root,
            "quarantine_dir": quarantine_dir,
            "dry_run": dry_run,
            "convert_heic": convert_heic,
            "summary": {
                "initial_photo_count": initial_scan["count"],
                "exact_hash_duplicate_groups": len(duplicates["exact_hash_duplicate_groups"]),
                "probable_duplicate_groups": len(duplicates["probable_duplicate_groups"]),
                "name_duplicate_groups": len(duplicates["name_duplicate_groups"]),
                "quarantined_count": quarantine["quarantined_count"],
                "rename_count": rename["rename_count"],
                "move_count": move["move_count"],
                "metadata_written_count": metadata_result["metadata_written_count"],
                "empty_folders_removed": empty_folder_cleanup["removed_count"],
            },
            "scan": initial_scan,
            "duplicates": duplicates,
            "quarantine": quarantine,
            "rename": rename,
            "move": move,
            "metadata": metadata_result,
            "empty_folder_cleanup": empty_folder_cleanup,
        }
        
    finally:
        if feedback:
            chime_done()
    


def _iso_or_none(value: datetime | None) -> str | None:
    """Return value.isoformat(), or None for a timestamp that couldn't be read."""
    return value.isoformat() if value else None
