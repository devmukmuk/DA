"""Picture fingerprints, and the resized copies and versions they find (design: docs/da-docs/SIMILAR-DESIGN.md).

A fingerprint is a 256-bit difference hash of the photo turned upright, made grey and shrunk to 17x16: is each pixel
brighter than the one to its right. Resizing and re-saving barely change it (an original and its 800x600 export:
0-1 bits); a different picture changes about half. It is kept in the index's `pictures` table by SHA-256, so a
rename or move doesn't redo it, with the camera, its time and the software that last saved it (from EXIF).
"""

from __future__ import annotations

import sqlite3
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

RESIZED_BITS = 6                  # two fingerprints this close are the same picture
TIMED_BITS = 16                   # ... or this close when the camera and its time (to the second) agree too
EDITED_BITS = 20                  # an edit (brightness, colour) of the same picture from the same camera moment
SHAPE_TOLERANCE = 0.02            # width/height within 2%: the same shape
SMALLER = 0.9                     # a resized copy has under 90% of the original's pixels
FLAT = 24                         # a fingerprint with fewer than 24 bits set (or unset) is a plain picture: no match
BANDS = 8                         # 8 x 32 bits: two fingerprints within 6 bits share at least one band exactly
CROWDED = 8                       # more photos than this at one camera second: a camera that stamps a fixed date
PICTURE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".heic", ".heif", ".tif", ".tiff", ".bmp", ".webp"}
EDITORS = ("picasa", "elements", "photoshop", "gimp", "lightroom", "paint", "photos", "iphoto", "acdsee",
           "irfanview", "snapseed", "faststone", "windows live", "photo gallery", "aperture", "capture one")

SCHEMA = """
CREATE TABLE IF NOT EXISTS pictures (
    sha256 TEXT PRIMARY KEY,
    fingerprint TEXT,
    width INTEGER,
    height INTEGER,
    made_at TEXT
);
"""
EXTRA_COLUMNS = {"camera": "TEXT", "taken": "TEXT", "software": "TEXT", "meta": "INTEGER DEFAULT 0", "sharpness": "REAL"}


@dataclass(frozen=True)
class Print:
    """One picture's fingerprint, its full size upright, and its camera, camera time and editing software."""

    fingerprint: int
    width: int
    height: int
    camera: str = ""
    taken: str = ""
    software: str = ""

    @property
    def pixels(self) -> int:
        """Return width x height."""
        return self.width * self.height

    @property
    def edited(self) -> bool:
        """Return whether a photo editor saved it last (Picasa, Photoshop Elements ...)."""
        return any(e in self.software.lower() for e in EDITORS)


def _meta(img: Any) -> tuple[str, str, str]:
    exif = img.getexif()
    camera = " ".join(str(exif.get(t) or "").strip() for t in (0x010F, 0x0110)).strip()
    taken = str(exif.get_ifd(0x8769).get(0x9003) or "").strip()            # DateTimeOriginal (an edit keeps it)
    return camera, taken, str(exif.get(0x0131) or "").strip()


def picture_print(path: Path) -> Print | None:
    """Return a photo's fingerprint, upright size and EXIF camera details, or None when it can't be read."""
    import numpy as np  # pylint: disable=import-outside-toplevel
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    try:
        from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

        register_heif_opener()
    except ImportError:
        pass
    try:
        with Image.open(path) as img:
            width, height = img.size
            orientation = img.getexif().get(0x0112, 1)
            if orientation in (5, 6, 7, 8):
                width, height = height, width
            camera, taken, software = _meta(img)
            if img.format == "JPEG":
                img.draft("L", (256, 256))                      # decode at reduced size: much faster
            small = ImageOps.exif_transpose(img).convert("L").resize((17, 16), Image.LANCZOS)
        a = np.asarray(small, dtype=np.int16)
        bits = (a[:, 1:] > a[:, :-1]).flatten()
        value = 0
        for bit in bits:
            value = (value << 1) | int(bit)
        return Print(value, width, height, camera, taken, software)
    except Exception:  # pylint: disable=broad-except
        return None


def picture_meta(path: Path) -> tuple[str, str, str] | None:
    """Return (camera, camera time, software) from a photo's EXIF without decoding it, or None."""
    from PIL import Image  # pylint: disable=import-outside-toplevel

    try:
        with Image.open(path) as img:
            return _meta(img)
    except Exception:  # pylint: disable=broad-except
        return None


def distance(a: int, b: int) -> int:
    """Return how many bits two fingerprints differ in."""
    return (a ^ b).bit_count()


def connect(db_path: Path) -> sqlite3.Connection:
    """Open the index with the pictures table there (and its newer columns)."""
    conn = sqlite3.connect(db_path)
    conn.executescript(SCHEMA)
    have = {r[1] for r in conn.execute("PRAGMA table_info(pictures)")}
    for name, kind in EXTRA_COLUMNS.items():
        if name not in have:
            conn.execute(f"ALTER TABLE pictures ADD COLUMN {name} {kind}")
    return conn


def ensure(db_path: Path, files: Iterable[tuple[str, str]], progress: Callable[[int, int], None] | None = None,
           workers: int = 6) -> dict[str, Print]:
    """Return the fingerprint of each (path, sha256), working out (in threads) and keeping the ones not known yet."""
    files = [(p, s) for p, s in files if s and Path(p).suffix.lower() in PICTURE_EXTENSIONS]
    with connect(db_path) as conn:
        known, no_meta = {}, set()
        for s, f, w, h, cam, taken, soft, meta in conn.execute(
                "SELECT sha256, fingerprint, width, height, camera, taken, software, meta FROM pictures"):
            if f:
                known[s] = Print(int(f, 16), w or 0, h or 0, cam or "", taken or "", soft or "")
                if not meta:
                    no_meta.add(s)
    paths = {s: p for p, s in files}
    todo = [(s, p) for s, p in paths.items() if s not in known]
    later = [(s, p) for s, p in paths.items() if s in no_meta]          # fingerprinted before camera details were kept
    now = datetime.now().isoformat(timespec="seconds")
    with ThreadPoolExecutor(max_workers=workers) as pool, connect(db_path) as conn:
        done = 0
        for (sha, _path), made in zip(todo, pool.map(lambda item: picture_print(Path(item[1])), todo)):
            done += 1
            if made is not None:
                known[sha] = made
                conn.execute("INSERT OR REPLACE INTO pictures (sha256, fingerprint, width, height, made_at, camera, "
                             "taken, software, meta) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)",
                             (sha, f"{made.fingerprint:064x}", made.width, made.height, now, made.camera, made.taken,
                              made.software))
            if progress and (done % 200 == 0 or done == len(todo)):
                progress(done, len(todo))
        for (sha, _path), meta in zip(later, pool.map(lambda item: picture_meta(Path(item[1])), later)):
            camera, taken, software = meta or ("", "", "")
            old = known[sha]
            known[sha] = Print(old.fingerprint, old.width, old.height, camera, taken, software)
            conn.execute("UPDATE pictures SET camera = ?, taken = ?, software = ?, meta = 1 WHERE sha256 = ?",
                         (camera, taken, software, sha))
    return {s: known[s] for _p, s in files if s in known}


def _bands(value: int) -> list[tuple[int, int]]:
    return [(i, (value >> (32 * i)) & 0xFFFFFFFF) for i in range(BANDS)]


def same_shape(a: Print, b: Print) -> bool:
    """Return whether two pictures have the same shape (width/height within 2%)."""
    if not (a.width and a.height and b.width and b.height):
        return False
    return abs(a.width / a.height - b.width / b.height) <= SHAPE_TOLERANCE * (b.width / b.height)


def same_moment(a: Print, b: Print) -> bool:
    """Return whether two pictures come from the same camera at the same second."""
    return bool(a.camera and a.taken) and (a.camera, a.taken) == (b.camera, b.taken)


def _usable(rows: list[dict[str, Any]], prints: dict[str, Print]) -> dict[str, list[dict[str, Any]]]:
    by_sha: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in rows:
        if r["sha256"] in prints and FLAT <= prints[r["sha256"]].fingerprint.bit_count() <= 256 - FLAT:
            by_sha[r["sha256"]].append(r)
    return by_sha


def _moments(shas: Iterable[str], prints: dict[str, Print]) -> list[list[str]]:
    """Return the groups of pictures from one camera at one second (not a crowd: that's a camera's fixed date)."""
    at: dict[tuple[str, str], list[str]] = defaultdict(list)
    for sha in shas:
        p = prints[sha]
        if p.camera and p.taken:
            at[(p.camera, p.taken)].append(sha)
    return [members for members in at.values() if 2 <= len(members) <= CROWDED]


class _Groups:
    def __init__(self, items: Iterable[str]):
        self.parent = {s: s for s in items}

    def root(self, s: str) -> str:
        while self.parent[s] != s:
            self.parent[s] = self.parent[self.parent[s]]
            s = self.parent[s]
        return s

    def join(self, a: str, b: str) -> None:
        self.parent[self.root(a)] = self.root(b)

    def groups(self) -> list[list[str]]:
        out: dict[str, list[str]] = defaultdict(list)
        for s in self.parent:
            out[self.root(s)].append(s)
        return [g for g in out.values() if len(g) > 1]


RESAVED_PIXELS = 3.0              # mean difference (0-255) at 64x48: below this, the same pixels (a re-saved copy)
RESIZED_PIXELS = 8.0              # ... a resized copy (JPEG and scaling add a little)
EDITED_PIXELS = 25.0              # ... an edit saved by a photo editor (brightness, colour)


def pixel_difference(a: Path, b: Path) -> float | None:
    """Return the mean difference (0-255) of two pictures shrunk to 64x48, upright, or None when one can't be read."""
    import numpy as np  # pylint: disable=import-outside-toplevel
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    def small(path: Path) -> Any:
        with Image.open(path) as img:
            if img.format == "JPEG":
                img.draft("RGB", (256, 256))
            return np.asarray(ImageOps.exif_transpose(img).convert("RGB").resize((64, 48), Image.LANCZOS),
                              dtype=np.float32)

    try:
        return float(np.abs(small(Path(a)) - small(Path(b))).mean())
    except Exception:  # pylint: disable=broad-except
        return None


CROP_PIXELS = 14.0                # a crop's best place in the original differs by less than this (0-255, grey)


def crop_found(small: Path, big: Path) -> bool:
    """Return whether one picture is a part of another: tried at many sizes and places on tiny grey copies."""
    import numpy as np  # pylint: disable=import-outside-toplevel
    from numpy.lib.stride_tricks import sliding_window_view  # pylint: disable=import-outside-toplevel
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    def grey(path: Path, width: int) -> Any:
        with Image.open(path) as img:
            if img.format == "JPEG":
                img.draft("L", (256, 256))
            img = ImageOps.exif_transpose(img).convert("L")
            return np.asarray(img.resize((width, max(1, round(width * img.height / img.width))), Image.LANCZOS),
                              dtype=np.float32)

    try:
        whole = grey(big, 80)
        with Image.open(small) as img:
            ratio = img.height / img.width if img.getexif().get(0x0112, 1) not in (5, 6, 7, 8) else img.width / img.height
    except Exception:  # pylint: disable=broad-except
        return False
    best = 255.0
    for w in range(24, 77, 3):                                   # the crop as 30% to 95% of the original's width
        h = round(w * ratio)
        if h < 12 or h > whole.shape[0]:
            continue
        part = grey(small, w)[:h, :w]
        if part.shape != (h, w) or part.std() < 8:
            continue
        windows = sliding_window_view(whole, (h, w))[::2, ::2]
        best = min(best, float(np.abs(windows - part).mean(axis=(2, 3)).min()))
    return best <= CROP_PIXELS


class Pairs:
    """What each close pair of pictures is: a resized copy, a re-saved copy, an edited or a cropped version.

    Candidates come from fingerprint bands (within 6 bits share a band) and camera moments (the same camera at the
    same second, not a crowd); each candidate is classed by shape, size, fingerprint and - to rule out burst frames,
    whose fingerprints can be as close - the pictures' pixels.
    """

    def __init__(self, rows: list[dict[str, Any]], prints: dict[str, Print]):
        self.by_sha = _usable(rows, prints)
        self.prints = prints
        self._pixels: dict[tuple[str, str], float | None] = {}
        self.kinds: dict[tuple[str, str], str] = {}
        shas = list(self.by_sha)
        buckets: dict[tuple[int, int], list[str]] = defaultdict(list)
        for sha in shas:
            for band in _bands(prints[sha].fingerprint):
                buckets[band].append(sha)
        seen: set[tuple[str, str]] = set()
        for members in [m for m in buckets.values() if 2 <= len(m) <= 500] + _moments(shas, prints):
            for i, a in enumerate(members):
                for b in members[i + 1:]:
                    pair = (a, b) if a < b else (b, a)
                    if pair in seen:
                        continue
                    seen.add(pair)
                    kind = self._kind(*pair)
                    if kind:
                        self.kinds[pair] = kind

    def path(self, sha: str) -> Path:
        """Return a file with this content."""
        return Path(self.by_sha[sha][0]["path"])

    def pixels(self, a: str, b: str) -> float | None:
        """Return (once) how different two pictures' pixels are."""
        key = (a, b) if a < b else (b, a)
        if key not in self._pixels:
            self._pixels[key] = pixel_difference(self.path(a), self.path(b))
        return self._pixels[key]

    def _kind(self, a: str, b: str) -> str | None:
        pa, pb = self.prints[a], self.prints[b]
        bits = distance(pa.fingerprint, pb.fingerprint)
        moment = same_moment(pa, pb)
        if pa.taken and pb.taken and pa.taken != pb.taken:
            return None                                                    # the camera says: two different moments
        if same_shape(pa, pb):
            small, big = (pa, pb) if pa.pixels <= pb.pixels else (pb, pa)
            if small.pixels < SMALLER * big.pixels:                       # one is smaller
                if bits <= (TIMED_BITS if moment else RESIZED_BITS):
                    diff = self.pixels(a, b)
                    if diff is not None and diff <= RESIZED_PIXELS:
                        return "resized"
                if moment and small.edited:                                # a crop that kept the shape
                    return "cropped" if self._crop(a, b) else None
                return None
            if bits > (EDITED_BITS if moment else RESIZED_BITS):
                return None
            diff = self.pixels(a, b)
            if diff is None:
                return None
            if diff <= RESAVED_PIXELS:
                return "resaved"
            if (pa.edited or pb.edited) and diff <= EDITED_PIXELS:
                return "edited"
            return None                                                    # burst frames: phase 3
        if moment and (pa.edited or pb.edited):
            return "cropped" if self._crop(a, b) else None
        return None

    def _crop(self, a: str, b: str) -> bool:
        small, big = (a, b) if self.prints[a].pixels <= self.prints[b].pixels else (b, a)
        return crop_found(self.path(small), self.path(big))

    def groups(self, *kinds: str) -> list[list[str]]:
        """Return the groups joined by pairs of these kinds."""
        joined = _Groups(self.by_sha)
        for (a, b), kind in self.kinds.items():
            if kind in kinds:
                joined.join(a, b)
        return joined.groups()

    def kind(self, a: str, b: str) -> str | None:
        """Return the kind of one pair, or None."""
        return self.kinds.get((a, b) if a < b else (b, a))


def _row(by_sha: dict[str, list[dict[str, Any]]], sha: str) -> dict[str, Any]:
    return sorted(by_sha[sha], key=lambda r: (r["area"] == "intake", r["path"]))[0]


def resized_copies(rows: list[dict[str, Any]], prints: dict[str, Print],
                   pairs: Pairs | None = None) -> list[dict[str, Any]]:
    """Return each resized copy among rows (path, sha256, area) with the largest picture it's a copy of.

    Same picture (fingerprints within 6 bits, or 16 when the camera and its time to the second agree, and the pixels
    alike), the same shape, under 90% of the pixels. The kept one is the biggest; when two are as big, one not saved by
    an editor, then a filed one before one in intake. Exact copies (same SHA-256) aren't this step's.
    """
    pairs = pairs or Pairs(rows, prints)
    out = []
    for members in pairs.groups("resized"):
        rank = lambda s: (prints[s].pixels, not prints[s].edited,                      # noqa: E731
                          any(r["area"] != "intake" for r in pairs.by_sha[s]))
        best = max(members, key=rank)
        kept = _row(pairs.by_sha, best)
        for sha in members:
            p = prints[sha]
            if sha == best or pairs.kind(sha, best) != "resized":
                continue                                       # joined only through another copy: left for next time
            for r in pairs.by_sha[sha]:
                out.append({**r, "kept": kept["path"], "kept_sha256": best, "size": f"{p.width} x {p.height}",
                            "kept_size": f"{prints[best].width} x {prints[best].height}",
                            "bits": distance(p.fingerprint, prints[best].fingerprint)})
    return sorted(out, key=lambda r: r["path"])


def _dated(p: Print, row: dict[str, Any]) -> tuple:
    """Rank a re-saved copy: the camera's date known, a name with a time (not _000000_), not an editor's save."""
    name = Path(row["path"]).name
    return (bool(p.taken), "_000000_" not in name, not p.edited, bool(p.camera), row["area"] != "intake")


def resaved_copies(rows: list[dict[str, Any]], prints: dict[str, Print],
                   pairs: Pairs | None = None) -> list[dict[str, Any]]:
    """Return each re-saved copy (the same pixels, the same size, other bytes) with the one kept: the dated one."""
    pairs = pairs or Pairs(rows, prints)
    out = []
    for members in pairs.groups("resaved"):
        best = max(members, key=lambda s: _dated(prints[s], _row(pairs.by_sha, s)))
        kept = _row(pairs.by_sha, best)
        for sha in members:
            if sha == best or pairs.kind(sha, best) != "resaved":
                continue
            p = prints[sha]
            for r in pairs.by_sha[sha]:
                out.append({**r, "kept": kept["path"], "kept_sha256": best, "size": f"{p.width} x {p.height}",
                            "kept_size": f"{prints[best].width} x {prints[best].height}",
                            "bits": distance(p.fingerprint, prints[best].fingerprint)})
    return sorted(out, key=lambda r: r["path"])


def versions(rows: list[dict[str, Any]], prints: dict[str, Print],
             pairs: Pairs | None = None) -> list[list[dict[str, Any]]]:
    """Return groups of versions of one picture that all stay filed: the original first, then edited / cropped ones.

    Edited: the same shape, about as big, a photo editor saved one of them, and the pixels close but not the same.
    Cropped: the same camera moment, a different shape, an editor saved one. Resized and re-saved copies go aside.
    """
    pairs = pairs or Pairs(rows, prints)
    going = {r["sha256"] for r in resized_copies(rows, prints, pairs) + resaved_copies(rows, prints, pairs)}
    joined = _Groups(s for s in pairs.by_sha if s not in going)
    for (a, b), kind in pairs.kinds.items():
        if kind in ("edited", "cropped") and a not in going and b not in going:
            joined.join(a, b)
    out = []
    for members in joined.groups():
        original = max(members, key=lambda s: (not prints[s].edited, prints[s].pixels, bool(prints[s].taken)))
        group = []
        for sha in [original] + sorted(s for s in members if s != original):
            p = prints[sha]
            kind = pairs.kind(sha, original)
            role = "original" if sha == original else (kind or ("edited" if same_shape(p, prints[original]) else "cropped"))
            group.append({**_row(pairs.by_sha, sha), "role": role, "software": p.software,
                          "size": f"{p.width} x {p.height}"})
        out.append(group)
    return out
