# src/mindit/services/tagging/tags.py

"""Tags: automatic ones from what a photo says about itself, and your own.

A sidecar keeps them apart, so making the automatic tags again never touches yours:
    "auto_tags": {"tags": ["maker:apple", "camera:apple-iphone-12-pro", "owner:jane", "year:2021", "gps"]}
    "user":      {"tags": ["beach", "grandma"]}

Automatic tags are labelled (maker:, camera:, owner:, year:), plus "gps" for a photo with a position.
The owner comes from the archive's `cameras:` list in da-archive.yaml (a camera, or one camera body
by its serial number, to a person), else from the owner/artist the camera recorded.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

from mindit.services.tagging.camera_info import (
    CAMERA_BLOCK,
    apply_camera_info,
    camera_name,
    maker_name,
    read_camera_info,
)
from mindit.services.validateit.validateit_file_types import PHOTO_EXTENSIONS

AUTO_BLOCK = "auto_tags"
USER_BLOCK = "user"
SIDECAR_SUFFIX = ".meta.json"
SKIP_NAMES = {"_contact-sheet.pdf", "desktop.ini", "thumbs.db"}
# Automatic tags `da location lookup` adds; remaking the camera tags keeps them.
PLACE_TAG_LABELS = ("place", "state", "country")


def slug(text: str) -> str:
    """Return a tag-friendly form: lower case, words joined by '-'."""
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def clean_tag(tag: str) -> str:
    """Return a tag as stored: lower case, spaces as '-', a 'label:value' kept as one tag."""
    label, sep, value = tag.strip().partition(":")
    return f"{slug(label)}:{slug(value)}" if sep and value.strip() else slug(tag)


def _key(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def owner_for(info: dict[str, Any], cameras: dict[str, str]) -> str | None:
    """Return who owned the camera: the cameras list (by body serial, then model), else EXIF owner/artist."""
    table = {_key(k): v for k, v in (cameras or {}).items() if v}
    name = camera_name(info)
    if name:
        if info.get("body_serial") and _key(f"{name} #{info['body_serial']}") in table:
            return table[_key(f"{name} #{info['body_serial']}")]
        if _key(name) in table:
            return table[_key(name)]
    return info.get("owner") or info.get("artist")


def auto_tags(info: dict[str, Any] | None, captured_at: str | None, cameras: dict[str, str]) -> list[str]:
    """Return the automatic tags for a photo from its camera details and capture date."""
    tags: list[str] = []
    info = info or {}
    maker, name = maker_name(info.get("make")), camera_name(info)
    if maker:
        tags.append(f"maker:{slug(maker)}")
    if name:
        tags.append(f"camera:{slug(name)}")
    owner = owner_for(info, cameras)
    if owner:
        tags.append(f"owner:{slug(owner)}")
    year = _year(info.get("date_taken")) or _year(captured_at)
    if year:
        tags.append(f"year:{year}")
    if (info.get("gps") or {}).get("latitude") is not None:
        tags.append("gps")
    return tags


def _year(value: str | None) -> str | None:
    m = re.match(r"(\d{4})[:-]", value or "")
    return m.group(1) if m and 1826 <= int(m.group(1)) <= 2100 else None


def all_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return every tag a sidecar holds: automatic, yours, and any written by older versions."""
    found: list[str] = []
    for block in (AUTO_BLOCK, USER_BLOCK, "photoit", "scanit"):
        value = sidecar.get(block)
        for tag in (value.get("tags") if isinstance(value, dict) else None) or []:
            if isinstance(tag, str) and tag.strip() and tag.strip() not in found:
                found.append(tag.strip())
    return found


# --------------------------------------------------------------------------- files

def is_photo(path: Path) -> bool:
    """Return True for a photo DA can read camera details from."""
    return path.suffix.lower() in PHOTO_EXTENSIONS and path.name.lower() not in SKIP_NAMES


def files_under(targets: Iterable[Path], *, photos_only: bool) -> list[Path]:
    """Return the files named, and every file in the folders named (sidecars and DA's own files left out)."""
    found: list[Path] = []
    for target in (Path(t).resolve() for t in targets):     # the index keeps full paths
        candidates: list[Path] = [target] if target.is_file() else []
        if target.is_dir():
            for dirpath, dirnames, filenames in os.walk(target):
                dirnames[:] = [d for d in dirnames if not d.startswith(".")]   # DA's own .da folder
                candidates.extend(Path(dirpath, f) for f in filenames)
        for path in candidates:
            name = path.name.lower()
            if name.endswith(SIDECAR_SUFFIX) or name in SKIP_NAMES:
                continue
            if photos_only and not is_photo(path):
                continue
            found.append(path)
    return sorted(set(found))


@dataclass
class TagResult:
    """What a tagging run did."""

    files: int = 0
    read: int = 0                    # camera details read from the photo (missing before, or --refresh)
    unreadable: list[Path] = field(default_factory=list)
    changed: dict[str, str] = field(default_factory=dict)    # path -> its tags as JSON, for the index


def ocr_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the tags `da tag ocr` gives a sidecar (from its `ocr` block)."""
    from mindit.services.ocr.ocr_tags import ocr_tags as tags_from_ocr  # pylint: disable=import-outside-toplevel

    return tags_from_ocr(sidecar)


def picasa_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the tags `da picasa` gives a sidecar (from its `picasa` block)."""
    from mindit.services.picasa.picasa import picasa_tags as tags_from_picasa  # pylint: disable=import-outside-toplevel

    return tags_from_picasa(sidecar)


def series_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the tags `da similar` gives a sidecar (burst, burst:best, blurry)."""
    from mindit.services.similar.series import series_tags as tags_from_series  # pylint: disable=import-outside-toplevel

    return tags_from_series(sidecar)


def tag_photos(photos: list[Path], cameras: dict[str, str], *, refresh: bool = False,
               progress: Callable[[int, int], None] | None = None) -> TagResult:
    """Fill in missing camera details and make each photo's automatic tags."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    result = TagResult(files=len(photos))
    for i, photo in enumerate(photos, 1):
        data = SidecarService.load(photo)               # one read and at most one write per photo
        dirty = False
        info = data.get(CAMERA_BLOCK) if isinstance(data.get(CAMERA_BLOCK), dict) else None
        if info is None or refresh:
            info = read_camera_info(photo)
            if info is None:
                result.unreadable.append(photo)
            else:
                result.read += 1
                apply_camera_info(data, info)
                dirty = True
        captured = (data.get("photoit") or {}).get("captured_at") if isinstance(data.get("photoit"), dict) else None
        old = (data.get(AUTO_BLOCK) or {}).get("tags") or []
        tags = auto_tags(info, captured, cameras)
        tags += [t for t in old if t.partition(":")[0] in PLACE_TAG_LABELS and t not in tags]
        tags += [t for t in ocr_tags(data) if t not in tags]            # `da tag ocr`'s text / document
        tags += [t for t in picasa_tags(data) if t not in tags]         # `da picasa`'s people, albums, stars
        tags += [t for t in series_tags(data) if t not in tags]         # `da similar`'s burst / blurry marks
        if old != tags:
            data[AUTO_BLOCK] = {"tags": tags, "made_at": datetime.now().isoformat(timespec="seconds")}
            dirty = True
        if dirty:
            SidecarService.save(photo, data)
        result.changed[str(photo)] = json.dumps(all_tags(data))
        if progress:
            progress(i, len(photos))
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("tag", f"automatic tags on {result.files} photos; camera details read from {result.read}"
              + (f"; {len(result.unreadable)} unreadable" if result.unreadable else ""))
    return result


def change_user_tags(files: list[Path], add: list[str], remove: list[str]) -> TagResult:
    """Add and remove your own tags on each file."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    add, remove = [clean_tag(t) for t in add if clean_tag(t)], {clean_tag(t) for t in remove}
    result = TagResult(files=len(files))
    for path in files:
        data = SidecarService.load(path)
        block = data.get(USER_BLOCK) if isinstance(data.get(USER_BLOCK), dict) else {}
        tags = [t for t in block.get("tags") or [] if t not in remove]
        tags += [t for t in add if t not in tags]
        if tags != (block.get("tags") or []):
            block["tags"] = tags
            data[USER_BLOCK] = block
            SidecarService.save(path, data)
        result.changed[str(path)] = json.dumps(all_tags(data))
    return result


def update_index(db_path: Path, changed: dict[str, str]) -> int:
    """Write the new tags into the index rows of those files; return how many rows matched."""
    if not changed or not db_path.exists():
        return 0
    with sqlite3.connect(db_path) as conn:
        before = conn.total_changes
        conn.executemany("UPDATE files SET tags = ? WHERE path = ?",
                         [(tags if tags != "[]" else None, path) for path, tags in changed.items()])
        return conn.total_changes - before


# --------------------------------------------------------------------------- the cameras list

@dataclass
class CameraSeen:
    """One camera (or one camera body, by serial number) and the photos it took."""

    name: str
    serial: str | None
    photos: int = 0
    years: set[str] = field(default_factory=set)
    owner: str | None = None

    @property
    def key(self) -> str:
        """Return the name to use in da-archive.yaml's cameras list."""
        return f"{self.name} #{self.serial}" if self.serial else self.name


def cameras_seen(photos: list[Path], cameras: dict[str, str]) -> list[CameraSeen]:
    """Return each camera found in the photos' sidecars, most photos first (no photo is opened)."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    seen: dict[tuple[str, str | None], CameraSeen] = {}
    for photo in photos:
        if not SidecarService.sidecar_path_for(photo).exists():
            continue
        info = SidecarService.get_block(photo, CAMERA_BLOCK)
        name = camera_name(info) if info else None
        if not name:
            continue
        serial = info.get("body_serial")
        cam = seen.setdefault((name, serial), CameraSeen(name, serial, owner=owner_for(info, cameras)))
        cam.photos += 1
        year = _year(info.get("date_taken"))
        if year:
            cam.years.add(year)
    return sorted(seen.values(), key=lambda c: (-c.photos, c.name))


def camera_years(cam: CameraSeen) -> str:
    """Return '2019-2023' (or one year, or '')."""
    return f"{min(cam.years)}-{max(cam.years)}" if len(cam.years) > 1 else "".join(cam.years)


def group_by_folder(paths: Iterable[Path]) -> dict[Path, list[Path]]:
    """Return the paths grouped by folder."""
    groups: dict[Path, list[Path]] = defaultdict(list)
    for path in paths:
        groups[path.parent].append(path)
    return groups
