"""The faces known in a photo (today from Picasa) and drawing them: a yellow box on each face, the name above it.

A box is [left, top, right, bottom] as fractions of the photo as stored. Picasa measured them before the photo
was turned upright, so `upright()` turns each box the way EXIF orientation turns the picture.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

FACE_YELLOW = (1.0, 0.85, 0.0)


@dataclass(frozen=True)
class Face:
    """One face: where it is in the upright photo (fractions, top-left origin) and who it is, if known."""

    box: tuple[float, float, float, float]
    name: str | None


def _turn(x: float, y: float, orientation: int) -> tuple[float, float]:
    return {2: (1 - x, y), 3: (1 - x, 1 - y), 4: (x, 1 - y), 5: (y, x), 6: (1 - y, x), 7: (1 - y, 1 - x),
            8: (y, 1 - x)}.get(orientation, (x, y))


def upright(box: list[float] | tuple[float, ...], orientation: int | None) -> tuple[float, float, float, float]:
    """Return a stored-photo box as it lies once the photo is turned upright (EXIF orientation 1-8)."""
    (x1, y1), (x2, y2) = _turn(box[0], box[1], orientation or 1), _turn(box[2], box[3], orientation or 1)
    return min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)


def faces_of(sidecar: dict[str, Any]) -> tuple[Face, ...]:
    """Return the faces a sidecar knows (its `picasa` block), placed on the upright photo."""
    block = sidecar.get("picasa") if isinstance(sidecar.get("picasa"), dict) else {}
    camera = sidecar.get("camera") if isinstance(sidecar.get("camera"), dict) else {}
    try:
        orientation = int(camera.get("orientation") or 1)
    except (TypeError, ValueError):
        orientation = 1
    out = []
    for face in block.get("faces") or []:
        box = face.get("box") if isinstance(face, dict) else None
        if isinstance(box, list) and len(box) == 4 and all(isinstance(v, (int, float)) for v in box):
            out.append(Face(upright(box, orientation), face.get("name") or None))
    return tuple(out)


def people(faces: tuple[Face, ...] | list[Face]) -> list[str]:
    """Return the names of the faces, each once, in order."""
    return list(dict.fromkeys(f.name for f in faces if f.name))


def draw_faces(pdf: Any, faces: tuple[Face, ...] | list[Face], x: float, y: float, w: float, h: float,
               *, size: float = 7.0, names: bool = True) -> None:
    """Draw each face's yellow box on a picture drawn at (x, y, w, h) (PDF points, bottom-left), its name above it."""
    if not faces:
        return
    pdf.saveState()
    pdf.setStrokeColorRGB(*FACE_YELLOW)
    pdf.setLineWidth(1.4 if size >= 7 else 0.9)
    for face in faces:
        left, top, right, bottom = face.box
        bx, by = x + left * w, y + (1 - bottom) * h
        bw, bh = max((right - left) * w, 2), max((bottom - top) * h, 2)
        pdf.rect(bx, by, bw, bh, stroke=1, fill=0)
        if not (names and face.name):
            continue
        pdf.setFont("Helvetica-Bold", size)
        text_w = pdf.stringWidth(face.name, "Helvetica-Bold", size) + 4
        lx = min(max(bx + bw / 2 - text_w / 2, x), x + w - text_w)       # kept on the picture
        ly = by + bh + 1 if by + bh + size + 3 <= y + h else by + bh - size - 3   # above the box, or just inside
        pdf.setFillColorRGB(*FACE_YELLOW)
        pdf.rect(lx, ly, text_w, size + 2, stroke=0, fill=1)
        pdf.setFillColorRGB(0, 0, 0)
        pdf.drawString(lx + 2, ly + 2, face.name)
    pdf.restoreState()
