# src/mindit/commands/facial_cli.py

"""`da facial`: find the faces in photos, learn people from Picasa's names, suggest names for the rest."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

import typer
from rich.console import Console
from rich.prompt import Confirm
from rich.table import Table

from mindit.config.settings import resolve_database_path

console = Console()
facial_app = typer.Typer(help="Find the faces in photos, learn people from Picasa's names, and suggest names.",
                         no_args_is_help=True)


def _engine():
    from mindit.services.faces.engine import EngineError, FaceEngine  # pylint: disable=import-outside-toplevel

    try:
        return FaceEngine(say=console.print)
    except EngineError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from None


@facial_app.command("scan")
def scan(
    folders: list[Path] = typer.Argument(None, help="Only photos under these folders (default: all filed photos)."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before a long scan."),
) -> None:
    """Find and describe the faces in photos not looked at yet; faces Picasa named become examples of those people."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import scan as sc  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import store  # pylint: disable=import-outside-toplevel

    missing = [f for f in folders or [] if not f.exists()]
    if missing:
        raise typer.BadParameter(f"No such folder: {missing[0]}")
    db_path = resolve_database_path()
    console.print("Indexing the archive ...")
    ArchiveIndexService(DbitService(db_path)).build(default_areas())
    rows = sc.photos(db_path, [str(f.resolve()) for f in folders or []])
    with store.connect(db_path) as conn:
        done = store.scanned(conn)
    todo = len({r["sha256"] for r in rows} - done)
    console.print(f"{len(rows):,} photos; {todo:,} not looked at yet (about {todo * 0.25 / 60:,.0f} min).")
    if todo > 500 and not yes and not Confirm.ask("Look at them now?", default=True):
        raise typer.Exit(0)
    engine = _engine() if todo else None
    from mindit.commands.progress import ConsoleProgressReporter  # pylint: disable=import-outside-toplevel

    progress = ConsoleProgressReporter(console=console, update_every=25)
    progress.start(label="Photos", total=todo)
    try:
        result = sc.scan(db_path, rows, engine, progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    console.print(f"Looked at {result.photos:,} photos: {result.faces:,} faces"
                  + (f", {result.unreadable:,} couldn't be read" if result.unreadable else "")
                  + f". Faces with Picasa's names: {result.picasa_names:,}.")
    console.print("Next: da facial suggest (names for the others), da facial people (who's there).")
    log_event("facial_scan", f"face scan: {result.photos} photos, {result.faces} faces, {result.picasa_names} Picasa names",
              photos=result.photos, faces=result.faces, picasa=result.picasa_names)


@facial_app.command("people")
def people_list() -> None:
    """List everyone with a face: their photos, and the faces suggested for them waiting for you."""
    from mindit.services.faces.suggest import people  # pylint: disable=import-outside-toplevel

    found = people(resolve_database_path())
    if not found:
        console.print("Nobody yet. Run da facial scan first (it learns the people Picasa named).")
        return
    from mindit.services.faces.suggest import looks_like_an_id  # pylint: disable=import-outside-toplevel

    table = Table("Person", "Photos", "Named by Picasa", "Confirmed", "Suggested: probably", "maybe")
    ids = []
    for p in found:
        name = p.name
        if looks_like_an_id(p.name):
            ids.append(p.name)
            name = f"{p.name} [yellow](a Picasa contact with no name)[/yellow]"
        table.add_row(name, f"{len(p.photos):,}", f"{p.picasa:,}", f"{p.confirmed:,}", f"{p.probably:,}", f"{p.maybe:,}")
    console.print(table)
    for name in ids:
        console.print(f"Give {name!r} a name: da facial rename \"{name}\" \"<their name>\"")


@facial_app.command("suggest")
def suggest_names(
    pdf: bool = typer.Option(True, "--pdf/--no-pdf", help="Make a PDF of the suggestions and unknown faces."),
) -> None:
    """Suggest names for the faces nobody named (you confirm them later), and group the faces DA can't name."""
    import csv  # pylint: disable=import-outside-toplevel

    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import store  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import suggest as sg  # pylint: disable=import-outside-toplevel

    db_path = resolve_database_path()
    counts = sg.suggest(db_path)
    console.print(f"Suggested: {counts['probably']:,} faces probably someone known, {counts['maybe']:,} maybe; "
                  f"{counts['unknown']:,} not like anyone known ({counts['groups']:,} groups of alike faces).")
    run_dir = default_layout().run_dir("facial")
    with store.connect(db_path) as conn, (run_dir / "suggestions.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(["face", "photo sha256", "name", "status", "similarity", "group"])
        for r in conn.execute("SELECT id, sha256, name, status, similarity, group_id FROM faces "
                              "WHERE status = 'suggested' OR group_id IS NOT NULL ORDER BY name, group_id"):
            writer.writerow([r["id"], r["sha256"], r["name"] or "", r["status"] or "unknown", r["similarity"] or "",
                             r["group_id"] or ""])
    console.print(f"List: {run_dir / 'suggestions.csv'}")
    if pdf:
        console.print("Making the PDF (each face cut from its photo) ...")
        target = sg.report(db_path, run_dir / f"faces-{datetime.now():%Y-%m-%d}.pdf")
        console.print(f"PDF: {target}")
    console.print("Nothing is named until you confirm it (the dashboard's People page, coming next).")
    log_event("facial_suggest", "face suggestions made", **counts)


@facial_app.command("rename")
def rename(
    old: str = typer.Argument(..., help="The name to replace, e.g. \"Sam Smyth\"."),
    new: str = typer.Argument(..., help="The name to use instead, e.g. \"Sam Smith\"."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Make one person of two names (faces, Picasa's names in sidecars, person: tags)."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import suggest as sg  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import update_index  # pylint: disable=import-outside-toplevel

    if not yes and not Confirm.ask(f"Rename everyone called {old!r} to {new!r}?", default=False):
        raise typer.Exit(0)
    db_path = resolve_database_path()
    faces, shas = sg.rename(db_path, old, new)
    changed = sg.rename_in_sidecars(db_path, old, new, shas)
    update_index(db_path, changed)
    console.print(f"Renamed {faces:,} faces; {len(changed):,} sidecars changed.")
    log_event("facial_rename", f"renamed {old} to {new}: {faces} faces, {len(changed)} sidecars", faces=faces)


@facial_app.command("forget")
def forget(
    person: str = typer.Option(None, "--person", help="Only this person's faces."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Delete face data from the index (the faces found and their numbers). Picasa's names in sidecars stay."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.faces import store  # pylint: disable=import-outside-toplevel

    what = f"{person}'s faces" if person else "all face data"
    if not yes and not Confirm.ask(f"Delete {what} from the index?", default=False):
        raise typer.Exit(0)
    with store.connect(resolve_database_path()) as conn:
        n = store.forget(conn, person)
    console.print(f"Deleted {n:,} faces.")
    log_event("facial_forget", f"deleted {what}: {n} faces", faces=n)
