# src/mindit/services/workflow/importer.py

"""`da import <source>...`: copy into this archive's intake what no archive has yet, sorted into docs, photos or scans.

A file is skipped when the same content (SHA-256) is in any connected archive, or came earlier in the same import
(sizes first: only a file whose size matches something is hashed). The rest is sorted: a camera's picture, a
video or a RAW goes to photos; a PDF with text, an Office file, or a picture Windows' OCR reads as a document
goes to docs; any other picture (a scanner's, or one with no camera) goes to scans. A document whose name has
no date gets the first date on its page 1 as a user date. Copies go to intake\\<folder>\\from-<source>\\<path
under the source>, so the family's own folder names stay as the files' origin. The sources are never changed;
every copy is logged, and `da intake undo <log>` removes them. Design: docs/da-docs/IMPORT-DESIGN.md.
"""

from __future__ import annotations

import csv
import logging
import os
import re
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Protocol

from mindit.services.dbit.intake_service import LOG_FIELDS
from mindit.services.validateit.validateit_file_types import (DOCUMENT_ONLY_EXTENSIONS, PHOTO_EXTENSIONS,
                                                              RAW_EXTENSIONS, VIDEO_EXTENSIONS, companions)

SIDECAR_SUFFIX = ".meta.json"
LOG_CLASS = "import"
KINDS = ("docs", "photos", "scans")
PLAN_FIELDS = ["source", "size_bytes", "sha256", "action", "kind", "why", "date", "date_source", "destination",
               "archived_copy"]
SKIP_DIRS = {"$recycle.bin", "system volume information", ".sync-trash", "_duplicates-holding", "_secure-holding"}
JUNK = {"thumbs.db", "desktop.ini", ".ds_store", "_contact-sheet.pdf"}
PICASA = {"picasa.ini", ".picasa.ini"}
PDF_WORDS = 20                                     # a PDF with this many words on its first 2 pages has text
_SCANNER = re.compile(r"scan|epson|canoscan|scanjet|scansnap|fujitsu|brother|neat|visioneer|plustek|xerox", re.I)
_PHOTOS_ALONE = RAW_EXTENSIONS | VIDEO_EXTENSIONS | {".heic", ".heif", ".webp"}

log = logging.getLogger(__name__)


class Reader(Protocol):
    """Reads the text in a picture (WindowsOcr, or a fake in tests): {words, coverage, text} or {error}."""

    def read(self, path: Path) -> dict[str, Any]: ...


class ImportProblem(RuntimeError):
    """The archive can't take an import as it's set up (and what to change)."""


# --------------------------------------------------------------------------- what an import holds

@dataclass
class Item:
    """One file met in a source, and what the import does with it."""

    source: Path
    root: Path                                     # the source folder it was found under
    size: int
    action: str = ""                               # copy, archived, duplicate, junk, other, conflict, too long
    kind: str = ""                                 # docs, photos or scans
    why: str = ""
    sha256: str = ""
    date: str = ""
    date_source: str = ""
    destination: Path | None = None
    archived_copy: str = ""
    text: str = field(default="", repr=False)      # page 1's text, for the date (never written down)

    def row(self) -> dict[str, str]:
        """Return the plan CSV row."""
        return {"source": str(self.source), "size_bytes": str(self.size), "sha256": self.sha256,
                "action": self.action, "kind": self.kind, "why": self.why, "date": self.date,
                "date_source": self.date_source, "destination": str(self.destination or ""),
                "archived_copy": self.archived_copy}


@dataclass
class ImportPlan:
    """What an import will copy, and what it leaves."""

    here: Path
    sources: list[Path]
    items: list[Item] = field(default_factory=list)
    others: Counter = field(default_factory=Counter)       # files DA doesn't file, by extension
    unreadable: list[Path] = field(default_factory=list)

    @property
    def copies(self) -> list[Item]:
        """Return the files to copy."""
        return [i for i in self.items if i.action == "copy"]

    @property
    def bytes(self) -> int:
        """Return how much the copies take."""
        return sum(i.size for i in self.copies)

    def actions(self) -> Counter:
        """Return how many files each action has."""
        return Counter(i.action for i in self.items)

    def kinds(self) -> Counter:
        """Return how many copies go to each intake folder."""
        return Counter(i.kind for i in self.copies)


# --------------------------------------------------------------------------- the archive's intake folders

def intake_folders(intake_root: Path, intake: dict[str, str]) -> dict[str, Path]:
    """Return the intake folders docs, photos and scans go to, or say what to change in da-archive.yaml."""
    wanted = {"docs": "document", "photos": "photo", "scans": "photo"}
    wrong = [f"{name}: {kind}" for name, kind in wanted.items() if intake.get(name) != kind]
    if wrong:
        raise ImportProblem("da import sorts into intake\\docs (document), intake\\photos (photo) and intake\\scans "
                            "(photo: scanned pictures and old camera photos). In da-archive.yaml, under intake:, set "
                            + ", ".join(wrong) + ".")
    return {name: intake_root / name for name in wanted}


def source_label(source: Path) -> str:
    """Return the name of a source's folder in intake: the drive and the folder (W:\\Pictures -> 'W-Pictures', E:\\ -> 'E')."""
    source = Path(source)
    drive = source.drive.strip(":\\/")
    name = source.name if source.name else ""
    text = "-".join(p for p in (drive, name) if p)
    return re.sub(r"[^\w.'&-]+", "-", text).strip("-.") or "source"


# --------------------------------------------------------------------------- walking a source

def _inside(path: Path, roots: Iterable[Path]) -> bool:
    here = os.path.normcase(os.path.abspath(path))
    for root in roots:
        top = os.path.normcase(os.path.abspath(root))
        if here == top or here.startswith(top.rstrip("\\/") + os.sep):
            return True
    return False


def walk(source: Path, leave_out: list[Path]) -> Iterable[Path]:
    """Yield every file under source, leaving out the folders that aren't the family's (archives, bins, dot folders)."""
    for dirpath, dirnames, filenames in os.walk(source):
        dirnames[:] = sorted(d for d in dirnames if d.lower() not in SKIP_DIRS and not d.startswith(".")
                             and not _inside(Path(dirpath, d), leave_out))
        for name in sorted(filenames):
            yield Path(dirpath, name)


def _wanted(path: Path) -> str:
    """Return 'file' for a file DA files, 'picasa', 'sidecar', 'junk' or 'other'."""
    from mindit.services.dbit.mac_files import is_apple_double  # pylint: disable=import-outside-toplevel

    name, suffix = path.name.lower(), path.suffix.lower()
    if name.endswith(SIDECAR_SUFFIX):
        return "sidecar"
    if name in PICASA:
        return "picasa"
    if name in JUNK or (name.startswith("._") and is_apple_double(path)):
        return "junk"
    if suffix in PHOTO_EXTENSIONS | _PHOTOS_ALONE | DOCUMENT_ONLY_EXTENSIONS:
        return "file"
    return "other"


# --------------------------------------------------------------------------- docs, photos or scans

def camera_of(path: Path) -> tuple[str, bool]:
    """Return the camera a picture's EXIF names ('Apple iPhone 8'; 'a camera' for a capture date alone) and
    whether a scanner made it."""
    from PIL import ExifTags, Image  # pylint: disable=import-outside-toplevel

    try:
        with Image.open(path) as img:
            exif = img.getexif()
            taken = exif.get_ifd(ExifTags.IFD.Exif).get(ExifTags.Base.DateTimeOriginal) if exif else None
    except Exception:  # pylint: disable=broad-except
        return "", False
    make, model, software = (str(exif.get(tag) or "").strip("\x00 ") for tag in (271, 272, 305))
    name = model if make and model.lower().startswith(make.split()[0].lower()) else f"{make} {model}".strip()
    scanner = bool(_SCANNER.search(f"{make} {model} {software}"))
    return name or ("a camera" if taken and not scanner else ""), scanner


def _read(path: Path, reader: Reader | None, cache: Any) -> dict[str, Any]:
    if reader is None:
        return {}
    found = cache.get(path) if cache is not None else None
    if found is None:
        found = reader.read(path)
        if cache is not None:
            cache.put(path, found)
    return found or {}


def pdf_text(path: Path) -> tuple[str, str]:
    """Return the text of a PDF's first page, and of its first two pages."""
    from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

    logging.getLogger("pypdf").setLevel(logging.ERROR)
    try:
        pages = list(PdfReader(path, strict=False).pages[:2])
        texts = [page.extract_text() or "" for page in pages]
    except Exception:  # pylint: disable=broad-except
        return "", ""
    return (texts[0] if texts else ""), " ".join(texts)


def _pdf_ocr(path: Path, reader: Reader | None, cache: Any) -> dict[str, Any]:
    """Return what OCR reads in the first picture on a PDF's first page."""
    from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

    from mindit.services.secure.passwords import decoder_messages  # pylint: disable=import-outside-toplevel

    if reader is None:
        return {}
    found = cache.get(path) if cache is not None else None
    if found is not None:
        return found
    damaged: list[str] = []
    try:
        with decoder_messages(damaged):
            images = list(PdfReader(path, strict=False).pages[0].images)[:1]
    except Exception:  # pylint: disable=broad-except
        return {}
    if not images:
        return {}
    with tempfile.TemporaryDirectory(prefix="da-import-") as tmp:
        picture = Path(tmp, "page1" + (Path(images[0].name).suffix or ".png"))
        picture.write_bytes(images[0].data)
        found = reader.read(picture)
    if cache is not None:
        cache.put(path, found)
    return found or {}


def sort_file(path: Path, reader: Reader | None, cache: Any = None) -> tuple[str, str, str]:
    """Return where a file goes (docs, photos, scans), why, and its page 1 text (for a date)."""
    from mindit.services.ocr.ocr_tags import DOCUMENT_TAG, level  # pylint: disable=import-outside-toplevel

    suffix = path.suffix.lower()
    if suffix in VIDEO_EXTENSIONS:
        return "photos", "video", ""
    if suffix in RAW_EXTENSIONS:
        return "photos", "raw", ""
    if suffix in {".heic", ".heif"}:
        return "photos", "heic", ""
    if suffix == ".pdf":
        first, both = pdf_text(path)
        words = len(both.split())
        if words >= PDF_WORDS:
            return "docs", f"pdf text: {words} words", first
        found = _pdf_ocr(path, reader, cache)
        if not found:
            return ("docs", "pdf, nothing read", first) if words else ("scans", "pdf pictures (not read)", "")
        if level(int(found.get("words") or 0), float(found.get("coverage") or 0)) == DOCUMENT_TAG:
            return "docs", "pdf ocr: document", str(found.get("text") or "")
        return "scans", "pdf pictures, no text", ""
    if suffix in DOCUMENT_ONLY_EXTENSIONS:
        return "docs", "office" if suffix in {".doc", ".docx", ".xls", ".xlsx"} else "text", ""
    camera, scanner = camera_of(path)
    if camera and not scanner:
        return "photos", f"camera: {camera}", ""
    found = _read(path, reader, cache)
    if found and level(int(found.get("words") or 0), float(found.get("coverage") or 0)) == DOCUMENT_TAG:
        return "docs", "ocr: document", str(found.get("text") or "")
    made = "scanner" if scanner else "no camera"
    return "scans", f"{made}, no text" if found else f"{made} (not read)", ""


# --------------------------------------------------------------------------- dating documents

def name_has_date(path: Path, now: datetime | None = None) -> bool:
    """Return whether a file's name holds a date DA files by (a full date, a month, or a year)."""
    from mindit.services.validateit import capture_date as cd  # pylint: disable=import-outside-toplevel

    now = now or datetime.now()
    stem = path.stem
    return (cd._filename_full_date(stem, now)[0] is not None or cd._filename_month(stem, now) is not None  # pylint: disable=protected-access
            or cd._filename_year(stem, now) is not None)  # pylint: disable=protected-access


def date_document(item: Item, today: date | None = None) -> None:
    """Set a document's date: the first one on page 1 when its name has none; else say what DA will use."""
    from mindit.services.ocr.text_facts import first_date  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.document_dates import read_document_date  # pylint: disable=import-outside-toplevel

    if name_has_date(item.source):
        item.date_source = "name"
        return
    day = first_date(item.text, today)
    if day is not None:
        item.date, item.date_source = day.isoformat(), "page 1 text"
        return
    created = read_document_date(item.source) if item.source.suffix.lower() == ".pdf" else None
    if created is not None:
        item.date, item.date_source = created.date().isoformat(), "pdf created"     # DA reads this itself


# --------------------------------------------------------------------------- planning

def _archive_files(archives: list[Path], say: Callable[[str], None]) -> dict[int, list[tuple[Path, str | None, Path]]]:
    """Return every file in the archives by size: (path, sha256 or None, its index)."""
    from mindit.services.workflow.archive_delete import _rows, index_archive  # pylint: disable=import-outside-toplevel

    by_size: dict[int, list[tuple[Path, str | None, Path]]] = defaultdict(list)
    for archive in archives:
        say(f"Indexing {archive.name} (to know what it has) ...")
        db_path = index_archive(archive)
        for p, size, sha in _rows(db_path):
            if not p.endswith(SIDECAR_SUFFIX):
                by_size[size].append((Path(p), sha, db_path))
    return by_size


def plan_import(here: Path, sources: list[Path], intake: dict[str, Path], archives: list[Path], *,
                reader: Reader | None = None, cache: Any = None, exclude: list[Path] | None = None,
                say: Callable[[str], None] | None = None) -> ImportPlan:
    """Work out, file by file, what an import copies where (nothing is copied here)."""
    from mindit.services.workflow.archive_delete import _copy_with, _sha256  # pylint: disable=import-outside-toplevel

    say = say or (lambda _m: None)
    plan = ImportPlan(here, [Path(s) for s in sources])
    leave_out = [*archives, here, *(exclude or [])]
    picasa: list[Item] = []
    for source in plan.sources:
        say(f"Looking through {source} ...")
        for path in walk(source, leave_out):
            what = _wanted(path)
            if what == "sidecar":
                continue
            try:
                size = path.stat().st_size
            except OSError:
                plan.unreadable.append(path)
                continue
            item = Item(path, source, size)
            if what == "picasa":
                picasa.append(item)
                continue
            if what == "junk" or (what == "file" and size == 0):
                item.action = "junk"
            elif what == "other":
                item.action = "other"
                plan.others[path.suffix.lower() or "(none)"] += 1
            plan.items.append(item)
            if len(plan.items) % 20000 == 0:
                say(f"  {len(plan.items):,} files found ...")

    files = [i for i in plan.items if not i.action]
    elsewhere = _archive_files(archives, say)
    sizes = Counter(i.size for i in files)
    seen: dict[str, Item] = {}
    pending: dict[int, list] = {}
    say(f"Comparing {len(files):,} files with the archives ...")
    for n, item in enumerate(files, 1):
        if n % 5000 == 0:
            say(f"  {n:,} / {len(files):,} compared ...")
        candidates = elsewhere.get(item.size, [])
        if not candidates and sizes[item.size] == 1:
            item.action = "copy"                       # no other file has this size: it can't be a copy
            continue
        sha = _sha256(item.source)
        if sha is None:
            plan.unreadable.append(item.source)
            item.action = "unreadable"
            continue
        item.sha256 = sha
        if sha in seen:
            item.action, item.archived_copy = "duplicate", str(seen[sha].source)
            continue
        copy = _copy_with(sha, item.size, candidates, pending) if candidates else None
        if copy is not None:
            item.action, item.archived_copy = "archived", str(copy)
            seen[sha] = item
            continue
        item.action = "copy"
        seen[sha] = item

    _sort(plan, reader, cache, say)
    _place(plan, intake, picasa)
    return plan


def _sort(plan: ImportPlan, reader: Reader | None, cache: Any, say: Callable[[str], None]) -> None:
    """Sort the copies into docs, photos and scans; companions go with their photo; documents get their date."""
    copies = {os.path.normcase(str(i.source)): i for i in plan.copies}
    say(f"Sorting {len(copies):,} files into docs, photos and scans ...")
    order = sorted(plan.copies, key=lambda i: (i.source.suffix.lower() not in PHOTO_EXTENSIONS, str(i.source)))
    for n, item in enumerate(order, 1):
        if n % 2000 == 0:
            say(f"  {n:,} / {len(order):,} sorted ...")
        if item.kind:
            continue                                   # already placed as another photo's companion
        item.kind, item.why, item.text = sort_file(item.source, reader, cache)
        if item.kind == "docs":
            date_document(item)
        if item.source.suffix.lower() in PHOTO_EXTENSIONS:
            for other in companions(item.source):
                partner = copies.get(os.path.normcase(str(other)))
                if partner is not None and not partner.kind:
                    partner.kind, partner.why = item.kind, f"goes with {item.source.name}"


def _place(plan: ImportPlan, intake: dict[str, Path], picasa: list[Item]) -> None:
    """Give each copy its place in intake; a Picasa.ini goes wherever pictures from its folder went."""
    from mindit.core.long_paths import too_long  # pylint: disable=import-outside-toplevel

    went: dict[str, set[str]] = defaultdict(set)
    for item in plan.copies:
        relative = item.source.relative_to(item.root)
        destination = intake[item.kind] / f"from-{source_label(item.root)}" / relative
        item.destination = destination
        if destination.exists() or Path(f"{destination}{SIDECAR_SUFFIX}").exists():
            item.action = "conflict"
        elif too_long(destination):
            item.action = "too long"
        else:
            went[os.path.normcase(str(item.source.parent))].add(item.kind)
    for ini in picasa:
        for kind in sorted(went.get(os.path.normcase(str(ini.source.parent)), ())):
            copy = Item(ini.source, ini.root, ini.size, "copy", kind, "picasa.ini of these pictures")
            copy.destination = intake[kind] / f"from-{source_label(ini.root)}" / ini.source.relative_to(ini.root)
            if copy.destination.exists():
                copy.action = "conflict"
            plan.items.append(copy)


def write_plan(plan: ImportPlan, path: Path) -> Path:
    """Write the plan (every file met but junk) as a CSV."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        out = csv.DictWriter(f, fieldnames=PLAN_FIELDS)
        out.writeheader()
        for item in plan.items:
            if item.action != "junk":
                out.writerow(item.row())
    return path


# --------------------------------------------------------------------------- copying

def apply_import(plan: ImportPlan, log_path: Path, *, cache: Any = None,
                 progress: Callable[[int, int], None] | None = None) -> Counter:
    """Copy each file (with any sidecar beside it), date documents, and log every copy for `da intake undo`."""
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel
    from mindit.services.dates.user_dates import _save  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.merge import _copy  # pylint: disable=import-outside-toplevel

    stats: Counter = Counter()
    copies = plan.copies
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", newline="", encoding="utf-8") as f:
        out = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        out.writeheader()
        for n, item in enumerate(copies, 1):
            if progress:
                progress(n, len(copies))
            assert item.destination is not None
            entry = {"class": LOG_CLASS, "source": str(item.source), "destination": str(item.destination),
                     "size_bytes": str(item.size), "sha256": item.sha256, "kept": "", "sidecar_source": "",
                     "sidecar_destination": "", "note": f"{item.kind}: {item.why}"}
            if item.destination.exists() or not item.source.exists():
                entry["result"] = "skipped"
                stats["skipped"] += 1
                out.writerow(entry)
                continue
            try:
                _copy(item.source, item.destination)
                side_src, side_dst = Path(f"{item.source}{SIDECAR_SUFFIX}"), Path(f"{item.destination}{SIDECAR_SUFFIX}")
                if side_src.exists():
                    _copy(side_src, side_dst)
                    entry["sidecar_source"] = str(side_src)
                if item.date_source in ("page 1 text",):
                    _save(item.destination, datetime.fromisoformat(item.date), "day", f"da import: {item.date_source}")
                    stats["dated"] += 1
                if side_dst.exists():
                    entry["sidecar_destination"] = str(side_dst)
                if cache is not None and item.kind != "photos":
                    found = cache.get(item.source)                 # da tag ocr won't read the copy again
                    if found is not None:
                        cache.put(item.destination, found)
            except OSError as error:
                entry["result"], entry["note"] = "skipped", str(error)
                stats["failed"] += 1
                out.writerow(entry)
                continue
            entry["result"] = "copied"
            stats["copied"] += 1
            stats[item.kind] += 1
            out.writerow(entry)
    log_event("import", f"copied {stats['copied']} files from {', '.join(map(str, plan.sources))} "
              f"({stats['docs']} docs, {stats['photos']} photos, {stats['scans']} scans; undo: {log_path})",
              path=str(log_path), counts={k: v for k, v in stats.items()})
    return stats
