# src/mindit/services/ocr/text_facts.py

"""`da ocr`: read each document once and keep two facts in its sidecar - the dates in it, and whether it holds a secret.

    "dates":   {"found": ["2009-01-04", "2009-02-10"], "checked_at": "...", "file": {"size": .., "modified": ..}}
    "secrets": {"found": true, "level": "strong", "checked_at": "...", "file": {...}}

Text comes from `da find --passwords`' reader (a PDF's own text, Office files, text files, Windows' OCR for scans). A
date is a real calendar day written out in the text (2009-01-04, 1/4/2009, January 4, 2009, 4 Jan 2009 ...), from 1900
to next year. A secret is what `da find --passwords` calls one (strong: a label with a value; weak: the word); the
secret itself, and the text, are never written down. A document read before, and not changed since, is skipped.
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any, Callable, Iterable

DATES_BLOCK = "dates"
SECRETS_BLOCK = "secrets"
MAX_DATES = 100
FIELDS = ["path", "dates", "first_dates", "secrets"]

_MONTH = (r"(?P<mon>jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|"
          r"sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)")
_DAY = r"(?P<d>0?[1-9]|[12]\d|3[01])(?:st|nd|rd|th)?"
_PATTERNS = [
    re.compile(r"(?<![\d/.-])(?P<y>1[89]\d\d|20\d\d)[-/.](?P<m>0?[1-9]|1[0-2])[-/.](?P<d>0?[1-9]|[12]\d|3[01])(?![\d/-]|\.\d)"),
    re.compile(r"(?<![\d/.-])(?P<m>0?[1-9]|1[0-2])[-/.](?P<d>0?[1-9]|[12]\d|3[01])[-/.](?P<y>1[89]\d\d|20\d\d)(?![\d/-]|\.\d)"),
    re.compile(r"(?<![\d/.-])(?P<m>0?[1-9]|1[0-2])/(?P<d>0?[1-9]|[12]\d|3[01])/(?P<yy>\d\d)(?![\d/-]|\.\d)"),
    re.compile(r"(?<![A-Za-z])" + _MONTH + r"\.?\s+" + _DAY + r",?\s+(?P<y>1[89]\d\d|20\d\d)(?!\d)", re.I),
    re.compile(r"(?<![\d])" + _DAY + r"\s+(?:of\s+)?" + _MONTH + r"\.?,?\s+(?P<y>1[89]\d\d|20\d\d)(?!\d)", re.I),
]
_MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                        "dec"], 1)}


def _days(text: str, today: date) -> Iterable[tuple[int, date]]:
    """Yield each real calendar day written in text (1900 to next year) with where it starts."""
    for pattern in _PATTERNS:
        for m in pattern.finditer(text or ""):
            parts = m.groupdict()
            if parts.get("yy"):
                year = 2000 + int(parts["yy"])
                if year > today.year:
                    year -= 100
            else:
                year = int(parts["y"])
            month = _MONTHS[parts["mon"].lower()[:3]] if parts.get("mon") else int(parts["m"])
            try:
                day = date(year, month, int(parts["d"]))
            except ValueError:                                       # 2009-02-30 isn't a day
                continue
            if 1900 <= day.year <= today.year + 1:
                yield m.start(), day


def find_dates(text: str, today: date | None = None) -> list[str]:
    """Return every real calendar day written in text, as YYYY-MM-DD, oldest first (at most MAX_DATES)."""
    found = {day.isoformat() for _at, day in _days(text, today or date.today())}
    return sorted(found)[:MAX_DATES]


def first_date(text: str, today: date | None = None) -> date | None:
    """Return the first day written in text, in reading order, not after today (a letter's or a bill's date)."""
    today = today or date.today()
    days = [(at, day) for at, day in _days(text, today) if day <= today]
    return min(days)[1] if days else None


def secrets_in(text: str) -> dict[str, Any]:
    """Return whether text holds a secret, and how sure (strong / weak) - never the secret itself."""
    from mindit.services.secure.passwords import classify  # pylint: disable=import-outside-toplevel

    hit = classify(text or "")
    return {"found": bool(hit), "level": hit[0] if hit else None}


def _stamp(path: Path) -> dict[str, Any]:
    stat = path.stat()
    return {"size": stat.st_size, "modified": round(stat.st_mtime, 3)}


def is_current(sidecar: dict[str, Any], path: Path, blocks: Iterable[str]) -> bool:
    """Return whether these blocks were recorded for the file as it is now (same size and time)."""
    try:
        now = _stamp(path)
    except OSError:
        return False
    for name in blocks:
        block = sidecar.get(name)
        if not isinstance(block, dict) or block.get("file") != now:
            return False
    return True


@dataclass
class Result:
    """What reading a set of documents found."""

    read: int = 0
    skipped: int = 0                          # read before and not changed since
    no_text: int = 0                          # nothing to read (or OCR not available)
    with_dates: int = 0
    with_secrets: int = 0
    rows: list[dict[str, str]] = field(default_factory=list)


def read_documents(paths: list[Path], reader: Any, *, dates: bool = True, secrets: bool = True, again: bool = False,
                   progress: Callable[[int, int], None] | None = None) -> Result:
    """Read each document's text once and record its dates and/or secrets in its sidecar."""
    from mindit.services.secure.passwords import text_of  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    wanted = [b for b, on in ((DATES_BLOCK, dates), (SECRETS_BLOCK, secrets)) if on]
    result = Result()
    now = datetime.now().isoformat(timespec="seconds")
    for i, path in enumerate(paths, 1):
        if progress:
            progress(i, len(paths))
        data = SidecarService.load(path)
        if not again and is_current(data, path, wanted):
            result.skipped += 1
            found_dates = (data.get(DATES_BLOCK) or {}).get("found") or []
            has_secret = (data.get(SECRETS_BLOCK) or {}).get("found")
        else:
            text = text_of(path, reader, data)                       # used here only: never written down
            result.read += 1
            if not text.strip():
                result.no_text += 1
            stamp = _stamp(path)
            found_dates = find_dates(text) if dates else (data.get(DATES_BLOCK) or {}).get("found") or []
            has_secret = secrets_in(text)["found"] if secrets else (data.get(SECRETS_BLOCK) or {}).get("found")
            if dates:
                data[DATES_BLOCK] = {"found": found_dates, "checked_at": now, "file": stamp}
            if secrets:
                data[SECRETS_BLOCK] = {**secrets_in(text), "checked_at": now, "file": stamp}
            SidecarService.save(path, data)
        result.with_dates += bool(found_dates)
        result.with_secrets += bool(has_secret)
        result.rows.append({"path": str(path), "dates": str(len(found_dates)),
                            "first_dates": ", ".join(found_dates[:5]),
                            "secrets": "" if has_secret is None else ("yes" if has_secret else "no")})
    return result


def write_results(result: Result, path: Path) -> Path:
    """Write ocr-facts.csv: each document, how many dates (the first few), and Secrets yes/no (never the secret)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(result.rows)
    return path
