from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from datetime import datetime

from mindit.services.photoit.photoit_workflows import (
    _build_target_filename,
    _build_metadata_payload,
    _compute_sha256,
    _load_metadata_json,
    _default_metadata_path,
    _write_metadata_json,
    RenameFormatOptions,
)

from mindit.services.validateit.quarantine_hash_service import stored_or_computed_sha256
from mindit.services.validateit.capture_date import CaptureDate, resolve_capture_date
from mindit.config.settings import (
    load_settings,
    resolve_photoit_organized_path,
    get_rename_pattern,
)


from mindit.services.validateit.validateit_file_types import PHOTO_EXTENSIONS, RAW_EXTENSIONS, MediaKind
from mindit.services.tagging.camera_info import record_camera_info


class PhotoItRepairProvider:
    name = "photoit"
    media_kind = MediaKind.PHOTO
    rename_module = "photoit"           # whose pattern names the file (da-archive.yaml modules.<name>.pattern)

    def __init__(self, pattern: str | None = None) -> None:
        self.pattern = pattern

    def supports(self, path: Path) -> bool:
        suffix = path.suffix.lower()
        if suffix in RAW_EXTENSIONS:                 # a raw on its own is filed as a photo; with its JPG it follows it
            from mindit.services.validateit.validateit_file_types import is_lone_raw  # pylint: disable=import-outside-toplevel

            return is_lone_raw(path)
        return suffix in PHOTO_EXTENSIONS

    def create_or_refresh_sidecar(self, path: Path, sha256: str | None = None) -> bool:
        metadata_path = _default_metadata_path(path)
        sha256 = sha256 or _compute_sha256(path)

        payload = _build_metadata_payload(
            source_path=path,
            current_path=path,
            sha256=sha256,
            original_file_name=path.name,
            original_source_path=str(path.resolve()),
        )

        _write_metadata_json(metadata_path, payload)
        record_camera_info(path)             # camera, lens, owner fields and GPS, read once, kept for tags
        return True

    def expected_name(self, path: Path) -> str | None:
        sidecar_path = self._sidecar_path_for_file(path)

        if not sidecar_path.exists():
            return None

        capture = self.capture_date(path)
        if not capture.certain:
            return None

        existing_metadata = _load_metadata_json(sidecar_path)
        placed = self._edit_place(path, existing_metadata)
        if placed:                                   # a photographer's edit: named after its RAW
            return None if placed[1] == path.name else placed[1]
        capture_dt = capture.value
        sha256 = stored_or_computed_sha256(path)

        # Use default PhotoIt pattern (or inject later)
        default_pattern = get_rename_pattern(self.rename_module) or "{date_taken:%Y%m%d}_{hash:8}"
        options = RenameFormatOptions(pattern=default_pattern)

        new_name = _build_target_filename(
            source_path=path,
            capture_dt=capture_dt,
            existing_names=None,  # IMPORTANT: we are only planning
            rename_options=options,
            existing_metadata=existing_metadata,
            sha256=sha256,
        )

        if new_name == path.name:
            return None  # already correct

        return new_name

    def capture_date(self, path: Path) -> CaptureDate:
        """Return the file's capture date and where it came from."""
        return resolve_capture_date(path)

    def expected_folder(self, path: Path) -> Path | None:
        capture = self.capture_date(path)
        if not capture.certain:
            return None

        from mindit.services.naming.folders import expected_folder, in_place  # pylint: disable=import-outside-toplevel

        kind = "video" if self.rename_module == "video" else "photo"
        metadata = _load_metadata_json(self._sidecar_path_for_file(path)) or {}
        placed = self._edit_place(path, metadata)
        if placed:                                   # a photographer's edit: beside its RAW (edits.folder under it)
            return None if path.parent.resolve() == placed[0].resolve() else placed[0]
        expected, _missing = expected_folder(path, resolve_photoit_organized_path(), capture.value, metadata, kind)

        # Where the folder pattern puts it, or a folder beside that named like it plus more
        # (a location folder: "2019-04 Easter (springfield-il)" for "2019-04").
        if in_place(path.resolve(), expected.resolve()):
            return None

        return expected

    def _edit_place(self, path: Path, metadata: dict[str, Any] | None) -> tuple[Path, str] | None:
        """Return (folder, name) beside its RAW for an edit paired with one (sidecar `edit` block), or None."""
        if self.rename_module != "photoit" or not metadata or not isinstance(metadata.get("edit"), dict):
            return None
        from mindit.config.settings import resolve_database_path  # pylint: disable=import-outside-toplevel
        from mindit.services.similar.edit_names import edit_place  # pylint: disable=import-outside-toplevel

        settings = load_settings()
        return edit_place(path, metadata, self, resolve_database_path(settings), settings.modules.photoit)

    def _sidecar_path_for_file(self, path: Path) -> Path:
        return Path(f"{path}.meta.json")

    def _load_sidecar(self, sidecar_path: Path) -> dict[str, Any]:
        try:
            return json.loads(sidecar_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def _load_photoit_pattern(self) -> str | None:
        settings = load_settings()

        # Adjust this if your actual config key is different.
        return getattr(settings.modules.photoit, "pattern", None)
