from __future__ import annotations

from pathlib import Path

import typer
from rich import print_json
from rich.console import Console
from rich.prompt import Confirm

from mindit.commands.progress import ConsoleProgressReporter

from mindit.services.sidecar import SidecarMigrationService

app = typer.Typer(help="Sidecars (the .meta.json beside each file): bring older ones up to date.")
console = Console()


@app.command("upgrade")
def upgrade(
    folder: Path = typer.Argument(None, help="Where to look (default: this whole archive)."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before rewriting."),
    restore_from: Path = typer.Option(None, "--restore", help="Put back the originals an upgrade kept (its backup folder)."),
) -> None:
    """Bring older sidecars up to the current layout (a copy of each is kept); the photos aren't touched."""
    from mindit.commands.workflow_cli import _interactive  # pylint: disable=import-outside-toplevel
    from mindit.config.settings import get_archive_root  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.archive_index_service import default_areas  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import upgrade as up  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar.sidecar_schema import SIDECAR_SCHEMA_VERSION  # pylint: disable=import-outside-toplevel

    layout = default_layout()
    base = get_archive_root() or layout.data_root
    if restore_from is not None:
        if not restore_from.is_dir():
            raise typer.BadParameter(f"No such folder: {restore_from}")
        n = up.restore(restore_from, base)
        from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

        log_event("sidecar_restore", f"put back {n} sidecars from {restore_from}", path=str(restore_from), restored=n)
        console.print(f"Put back {n:,} sidecar{'s' if n != 1 else ''} from {restore_from}.")
        return
    roots = [folder] if folder else [area.root for area in default_areas()]
    where = folder or base
    console.print(f"Reading the sidecars in {where} ...")
    plan = up.plan_upgrade(roots, progress=lambda n: console.print(f"  {n:,} sidecars ...", end="\r"))
    total = len(plan.outdated) + plan.current
    console.print(f"{total:,} sidecars: {plan.current:,} up to date (schema {SIDECAR_SCHEMA_VERSION}), "
                  f"{len(plan.outdated):,} older.")
    for change, n in plan.changes.most_common():
        console.print(f"  {n:>8,}  {change}")
    if plan.orphans:
        console.print(f"  ({len(plan.orphans):,} sidecars whose file is gone are left alone, "
                      f"e.g. {plan.orphans[0].name})")
    if plan.unreadable:
        console.print(f"  ({len(plan.unreadable):,} couldn't be read, e.g. {plan.unreadable[0]})")
    if not plan.outdated:
        console.print("Nothing to upgrade.")
        return
    console.print("Only the .meta.json files change; a copy of each is kept first. Your tags, dates, places "
                  "and titles stay as they are.")
    if not yes and not _interactive():
        console.print("Nothing changed. To upgrade them: add --yes.")
        return
    if not yes and not Confirm.ask(f"Upgrade {len(plan.outdated):,} sidecars?", default=True):
        return
    backup = layout.run_dir("sidecars") / "backup"
    progress = ConsoleProgressReporter(console=console, update_every=1000)
    progress.start(label="Upgrading", total=len(plan.outdated))
    try:
        stats = up.apply_upgrade(plan, backup, base=base, progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    console.print(f"Upgraded {stats['upgraded']:,} sidecar{'s' if stats['upgraded'] != 1 else ''}"
                  + (f" ({stats['failed']:,} couldn't be written)" if stats["failed"] else "") + ".")
    console.print(f'The originals are in {backup}. To put them back: da sidecar upgrade --restore "{backup}"')


@app.command("normalize", hidden=True)
def normalize_sidecars(
    folder: Path = typer.Argument(..., help="Folder containing sidecars to normalize."),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    service = SidecarMigrationService()
    result = service.normalize_folder(
        folder=folder,
        recursive=recursive,
        dry_run=dry_run,
    )
    print_json(data=result)
