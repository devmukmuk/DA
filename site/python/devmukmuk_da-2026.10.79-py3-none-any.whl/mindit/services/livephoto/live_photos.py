# src/mindit/services/livephoto/live_photos.py

"""iPhone Live Photos and HEIC photos.

Pairing: a Live Photo is IMG_1234.HEIC (or .JPG) plus IMG_1234.MOV. When DA files the photo, the
video now follows it (validateit_file_types.motion_companions). Videos left in intake by earlier
runs - their photo already filed and renamed - are found here through the index: each filed photo's
sidecar remembers where it came from (source_path), so intake\\x\\IMG_1234.MOV pairs with the photo
that was intake\\x\\IMG_1234.HEIC, and moves next to it under its new name (photo_..._ab12.mov).

HEIC to JPG: JPG copies of HEIC photos, with the date taken kept, for sharing. The HEIC originals
stay where they are.
"""

from __future__ import annotations

import csv
import json
import os
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from mindit.core.long_paths import TOO_LONG, too_long
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.dbit.intake_service import LOG_FIELDS
from mindit.services.validateit.validateit_file_types import (
    LIVE_PHOTO_STILL_EXTENSIONS,
    live_photo_key,
    PAIRED_MOTION_EXTENSIONS,
    VOICE_NOTE_EXTENSIONS,
)

SIDECAR_SUFFIX = ".meta.json"
PAIR_FIELDS = ["movie", "photo", "destination", "matched_by"]
HEIC_EXTENSIONS = {".heic", ".heif"}


_UNIQUE_ID = re.compile(r"^[0-9a-f]{16}$")      # backup apps' asset ids: unique across the whole archive


def _key(path: Path) -> tuple[str, str] | None:
    """Return the name a Live Photo's two halves share, or a voice note and its photo share."""
    if path.suffix.lower() in VOICE_NOTE_EXTENSIONS:
        return path.stem.lower(), ""
    return live_photo_key(path)


def _keys(path: str | Path) -> tuple[tuple, tuple, tuple | None] | None:
    """Return the full, folder-and-name, and (for unique ids) name-only keys of a Live Photo half or voice note."""
    p = Path(path)
    key = _key(p)
    if key is None:
        return None
    unique = key if _UNIQUE_ID.match(key[0]) else None
    return (os.path.normcase(str(p.parent)), *key), (p.parent.name.lower(), *key), unique


@dataclass
class PairPlan:
    """Which left-behind videos pair with which filed photos."""

    pairs: list[dict[str, str]] = field(default_factory=list)
    unmatched: list[Path] = field(default_factory=list)
    not_orphans: int = 0
    already_there: list[Path] = field(default_factory=list)
    other_copies: list[Path] = field(default_factory=list)   # a second copy of a video already paired


def left_behind_movies(folder: Path) -> tuple[list[Path], int]:
    """Return the Live Photo videos and voice notes under folder with no photo beside them, and how many had one."""
    movies, with_photo = [], 0
    for dirpath, _dirs, files in os.walk(folder):
        stills = {live_photo_key(Path(f)) for f in files if Path(f).suffix.lower() in LIVE_PHOTO_STILL_EXTENSIONS}
        for name in files:
            if Path(name).suffix.lower() not in PAIRED_MOTION_EXTENSIONS | VOICE_NOTE_EXTENSIONS:
                continue
            key = _key(Path(name))
            if key is None:
                continue                                # an ordinary video (<id>-video.MOV)
            if key in stills:
                with_photo += 1                         # DA files these two together
            else:
                movies.append(Path(dirpath, name))
    return sorted(movies), with_photo


def plan_pairs(folder: Path, photo_rows: list[tuple[str, str]]) -> PairPlan:
    """Match each left-behind video under folder with the filed photo that came from beside it.

    photo_rows are (path, source_path) of filed photos. Tried in order: the same original folder;
    the same last folder name (the archive moved drives); and, for backup apps' unique asset ids
    only, the name alone. A match that isn't unique is left alone.
    """
    by_full: dict[tuple, list[str]] = defaultdict(list)
    by_folder: dict[tuple, list[str]] = defaultdict(list)
    by_id: dict[tuple, list[str]] = defaultdict(list)
    for path, source in photo_rows:
        keys = _keys(source) if source and Path(source).suffix.lower() in LIVE_PHOTO_STILL_EXTENSIONS else None
        if keys is None:
            continue
        by_full[keys[0]].append(path)
        by_folder[keys[1]].append(path)
        if keys[2]:
            by_id[keys[2]].append(path)

    plan = PairPlan()
    movies, plan.not_orphans = left_behind_movies(folder)
    paired_photos: set[str] = set()
    for movie in movies:
        full, in_folder, unique = _keys(movie)
        photo, how = None, ""
        for table, key, label in ((by_full, full, "original path"), (by_folder, in_folder, "folder and name"),
                                  (by_id, unique, "unique name")):
            found = set(table.get(key, [])) if key else set()
            if len(found) == 1:
                photo, how = found.pop(), label
                break
            if len(found) > 1:
                break                                   # more than one photo fits: don't guess
        if photo is None:
            plan.unmatched.append(movie)
            continue
        destination = Path(photo).with_suffix(movie.suffix.lower())
        if destination.exists():
            plan.already_there.append(movie)
            continue
        if photo in paired_photos:                      # the same video in two intake folders
            plan.other_copies.append(movie)
            continue
        paired_photos.add(photo)
        plan.pairs.append({"movie": str(movie), "photo": photo, "destination": str(destination), "matched_by": how})
    return plan


def filed_photo_rows(db: DbitService) -> list[tuple[str, str]]:
    """Return (path, source_path) for every filed photo in the index."""
    with db.connect() as conn:
        return conn.execute(
            "SELECT path, source_path FROM files WHERE area = 'photos' AND source_path IS NOT NULL").fetchall()


def write_pair_plan(plan: PairPlan, path: Path) -> Path:
    """Write the pairs as a CSV (movie, photo, destination, matched_by)."""
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=PAIR_FIELDS)
        writer.writeheader()
        writer.writerows(plan.pairs)
    return path


def apply_pairs(db: DbitService, plan: PairPlan, log_path: Path) -> Counter:
    """Move each video (and its sidecar) next to its photo; log like a set-aside, so `da intake undo` reverses it."""
    stats: Counter = Counter()
    moved_rows: list[tuple[str, str]] = []
    try:
        with log_path.open("w", newline="", encoding="utf-8") as f:
            log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
            log.writeheader()
            for pair in plan.pairs:
                src, dst = Path(pair["movie"]), Path(pair["destination"])
                voice = src.suffix.lower() in VOICE_NOTE_EXTENSIONS
                entry = {"class": "voice_note" if voice else "live_photo_video", "source": str(src), "destination": str(dst), "size_bytes": "",
                         "sha256": "", "kept": pair["photo"], "sidecar_source": "", "sidecar_destination": "",
                         "note": ""}
                if not src.exists() or dst.exists() or not Path(pair["photo"]).exists():
                    entry["result"], entry["note"] = "skipped", "changed since plan"
                    stats["skipped"] += 1
                elif too_long(dst, f"{dst}{SIDECAR_SUFFIX}"):
                    entry["result"], entry["note"] = "skipped", TOO_LONG
                    stats["skipped"] += 1
                else:
                    try:
                        entry["size_bytes"] = str(src.stat().st_size)
                        os.rename(src, dst)             # same archive drive; fails rather than overwrite
                    except OSError as error:            # one file can't stop the rest
                        entry["result"], entry["note"] = "failed", str(error)
                        stats["failed"] += 1
                        log.writerow(entry)
                        continue
                    side_src, side_dst = Path(f"{src}{SIDECAR_SUFFIX}"), Path(f"{dst}{SIDECAR_SUFFIX}")
                    if side_src.exists() and not side_dst.exists():
                        try:
                            os.rename(side_src, side_dst)
                            entry["sidecar_source"], entry["sidecar_destination"] = str(side_src), str(side_dst)
                        except OSError as error:
                            entry["note"] = f"sidecar not moved: {error}"
                    entry["result"] = "moved"
                    stats["moved"] += 1
                    moved_rows.append((str(dst), str(src)))
                log.writerow(entry)
    finally:                                            # what moved is recorded, whatever happens
        if moved_rows:
            with db.connect() as conn:
                conn.executemany("UPDATE files SET path = ?, area = 'photos', sidecar_path = NULL WHERE path = ?",
                                 moved_rows)
    db.log_event("live_photos_paired", json.dumps({"log": str(log_path), **stats}))
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("pair_movies", f"paired {stats['moved']} Live Photo videos and voice notes with their photos (undo: {log_path})",
              path=str(log_path))
    return stats


# --------------------------------------------------------------------------- HEIC to JPG

@dataclass
class ConvertResult:
    """What a HEIC-to-JPG conversion did."""

    made: list[Path] = field(default_factory=list)
    skipped: int = 0
    failed: list[tuple[Path, str]] = field(default_factory=list)


def heic_files(folder: Path) -> list[Path]:
    """Return every HEIC/HEIF photo under folder."""
    return sorted(Path(d, f) for d, _dirs, files in os.walk(folder) for f in files
                  if Path(f).suffix.lower() in HEIC_EXTENSIONS)


def heic_to_jpg(source: Path, target: Path, quality: int = 92) -> None:
    """Write a JPG copy of a HEIC photo, keeping its EXIF (date taken) and its file times."""
    from PIL import Image  # pylint: disable=import-outside-toplevel
    from pillow_heif import register_heif_opener  # pylint: disable=import-outside-toplevel

    register_heif_opener()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + ".tmp")
    with Image.open(source) as img:
        exif = img.getexif()
        if 0x0112 in exif:                              # pillow-heif hands over the image already upright
            exif[0x0112] = 1
        img.convert("RGB").save(tmp, "JPEG", quality=quality, exif=exif.tobytes())
    os.replace(tmp, target)
    st = source.stat()
    os.utime(target, (st.st_atime, st.st_mtime))


def convert_folder(folder: Path, out_root: Path, *, progress: Callable[[str], None] | None = None) -> ConvertResult:
    """Make JPG copies of every HEIC photo under folder, in the same subfolders under out_root."""
    result = ConvertResult()
    for heic in heic_files(folder):
        target = out_root / heic.relative_to(folder).with_suffix(".jpg")
        if target.exists() and target.stat().st_mtime >= heic.stat().st_mtime:
            result.skipped += 1
            continue
        try:
            heic_to_jpg(heic, target)
        except Exception as exc:  # pylint: disable=broad-except
            result.failed.append((heic, f"{type(exc).__name__}: {exc}"))
            continue
        result.made.append(target)
        if progress and len(result.made) % 100 == 0:
            progress(f"{len(result.made):,} converted")
    return result
