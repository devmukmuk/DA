"""The two face models (OpenCV model zoo, Apache 2.0), downloaded once into %LOCALAPPDATA%\\DA\\models and checked.

YuNet finds faces (a box and 5 points); SFace turns a face into 128 numbers. Design: docs/da-docs/FACES-DESIGN.md.
"""

from __future__ import annotations

import hashlib
import os
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

ZOO = "https://media.githubusercontent.com/media/opencv/opencv_zoo/main/models/"


@dataclass(frozen=True)
class Model:
    """One model file: where it comes from and its SHA-256 (fixed, so a changed file is never used)."""

    name: str
    url: str
    sha256: str
    size: int


DETECTOR = Model("face_detection_yunet_2023mar.onnx", ZOO + "face_detection_yunet/face_detection_yunet_2023mar.onnx",
                 "8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4", 232_589)
RECOGNIZER = Model("face_recognition_sface_2021dec.onnx", ZOO + "face_recognition_sface/face_recognition_sface_2021dec.onnx",
                   "0ba9fbfa01b5270c96627c4ef784da859931e02f04419c829e83484087c34e79", 38_696_353)


class ModelError(RuntimeError):
    """A model couldn't be downloaded or didn't match its fixed SHA-256."""


def models_dir() -> Path:
    """Return where the models are kept: DA_FACE_MODELS, else %LOCALAPPDATA%\\DA\\models."""
    if os.environ.get("DA_FACE_MODELS"):
        return Path(os.environ["DA_FACE_MODELS"])
    return Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "DA" / "models"


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def model_path(model: Model, say: Callable[[str], None] | None = None) -> Path:
    """Return the model file, downloading it the first time (and checking its SHA-256 every time it's fetched)."""
    folder = models_dir()
    path = folder / model.name
    if path.exists() and path.stat().st_size == model.size:
        return path
    folder.mkdir(parents=True, exist_ok=True)
    if say:
        say(f"Downloading {model.name} ({model.size / 1e6:,.1f} MB, once) from the OpenCV model zoo ...")
    part = path.with_name(path.name + ".part")
    from mindit import __version__  # pylint: disable=import-outside-toplevel

    request = urllib.request.Request(model.url, headers={"User-Agent": f"DA/{__version__}"})
    try:
        with urllib.request.urlopen(request, timeout=120) as answer, part.open("wb") as out:  # noqa: S310 (fixed URL)
            for chunk in iter(lambda: answer.read(1 << 20), b""):
                out.write(chunk)
    except OSError as exc:
        part.unlink(missing_ok=True)
        raise ModelError(f"Couldn't download {model.name}: {exc}") from exc
    if _sha256(part) != model.sha256:
        part.unlink(missing_ok=True)
        raise ModelError(f"{model.name} didn't match its fingerprint - not used. Try again later.")
    os.replace(part, path)
    return path
