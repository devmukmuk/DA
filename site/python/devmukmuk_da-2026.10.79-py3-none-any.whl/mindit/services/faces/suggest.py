"""Suggest names for unnamed faces from each person's examples (Picasa's and yours), and group the unknown ones.

Tried on a 4,000-photo archive with Picasa's names: the same person's faces are a median 0.57 alike, different people's
0.10; naming each face by its most alike faces got 97% right. A suggestion is only a suggestion: you confirm it.
"""

from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from mindit.services.faces import store

PROBABLY = 0.45                    # this alike to a person's examples (and clearly more than to anyone else): probably them
MAYBE = 0.363                      # SFace's own threshold for "the same person"
MARGIN = 0.05                      # how much more like the best person than the next
GROUP = 0.55                       # an unknown face this alike, on average, to a group's faces joins it
TOP = 3                            # a person's score: the mean of their 3 most alike examples


@dataclass
class Person:
    """One name: its faces by how they were named, and the photos it is in."""

    name: str
    picasa: int = 0
    confirmed: int = 0
    probably: int = 0
    maybe: int = 0
    photos: set[str] = field(default_factory=set)


def people(db_path: Path) -> list[Person]:
    """Return everyone with a face, most photos first."""
    found: dict[str, Person] = {}
    with store.connect(db_path) as conn:
        for row in conn.execute("SELECT sha256, name, status, similarity FROM faces WHERE name IS NOT NULL"):
            p = found.setdefault(row["name"].lower(), Person(row["name"]))
            if row["status"] in store.NAMED:
                setattr(p, row["status"], getattr(p, row["status"]) + 1)
                p.photos.add(row["sha256"])
            elif row["status"] == "suggested":
                if (row["similarity"] or 0) >= PROBABLY:
                    p.probably += 1
                else:
                    p.maybe += 1
    return sorted(found.values(), key=lambda p: (-len(p.photos), p.name.lower()))


def suggest(db_path: Path) -> dict[str, int]:
    """Suggest a name for every face not named by you or Picasa, and group the faces nobody is like; return counts."""
    import numpy as np  # pylint: disable=import-outside-toplevel

    with store.connect(db_path) as conn:
        rows = conn.execute("SELECT * FROM faces WHERE vector IS NOT NULL").fetchall()
        examples: dict[str, list[Any]] = defaultdict(list)
        names: dict[str, str] = {}
        for r in rows:
            if r["status"] in store.NAMED and r["name"]:
                examples[r["name"].lower()].append(store.vector_of(r))
                names.setdefault(r["name"].lower(), r["name"])
        people_list = sorted(examples)
        matrices = {p: np.stack(examples[p]) for p in people_list}
        open_faces = [r for r in rows if r["status"] not in (*store.NAMED, "not_a_face")]   # you said: not a face
        counts = {"probably": 0, "maybe": 0, "unknown": 0, "groups": 0}
        unknown = []
        for r in open_faces:
            v = store.vector_of(r)
            refused = {n.lower() for n in store.rejected_names(r)}
            scores = []
            for p in people_list:
                if p in refused:
                    continue
                sims = np.sort(matrices[p] @ v)[::-1][:TOP]
                scores.append((float(sims.mean()), p))
            scores.sort(reverse=True)
            best, second = (scores + [(-1.0, ""), (-1.0, "")])[:2]
            if best[0] >= MAYBE and best[0] - second[0] >= MARGIN:
                level = "probably" if best[0] >= PROBABLY else "maybe"
                counts[level] += 1
                conn.execute("UPDATE faces SET name = ?, status = 'suggested', similarity = ?, group_id = NULL WHERE id = ?",
                             (names[best[1]], round(best[0], 3), r["id"]))
            else:
                counts["unknown"] += 1
                unknown.append((r["id"], v, r["score"] or 0))
                conn.execute("UPDATE faces SET name = NULL, status = NULL, similarity = ? WHERE id = ?",
                             (round(best[0], 3) if best[1] else None, r["id"]))
        counts["groups"] = _group(conn, unknown)
    return counts


def _group(conn: Any, unknown: list[tuple[int, Any, float]]) -> int:
    """Put alike unknown faces in groups (the clearest faces first); return how many groups of two or more.

    A face joins the group it is most alike to on average (its mean similarity to the group's faces - kept as a
    running sum, so it stays quick), when that is 0.55 or more. Comparing with a group's average face instead let one
    group drift across many people (45 different children in one group, in a test).
    """
    import numpy as np  # pylint: disable=import-outside-toplevel

    sums: list[Any] = []
    members: list[list[int]] = []
    for face_id, v, _score in sorted(unknown, key=lambda u: -u[2]):
        if sums:
            means = (np.stack(sums) @ v) / np.array([len(m) for m in members])
            best = int(means.argmax())
            if means[best] >= GROUP:
                members[best].append(face_id)
                sums[best] = sums[best] + v
                continue
        sums.append(v.copy())
        members.append([face_id])
    kept = sorted((m for m in members if len(m) >= 2), key=len, reverse=True)
    conn.execute("UPDATE faces SET group_id = NULL WHERE status IS NULL")
    for number, ids in enumerate(kept, 1):
        conn.executemany("UPDATE faces SET group_id = ? WHERE id = ?", [(number, i) for i in ids])
    return len(kept)


def looks_like_an_id(name: str) -> bool:
    """Return whether a Picasa contact's 'name' is really an account id (matt.smith_lh,4d616da98daf82d3)."""
    import re  # pylint: disable=import-outside-toplevel

    return bool(re.fullmatch(r"\S+,[0-9a-f]{8,}", name.strip())) or (" " not in name.strip() and "_lh" in name)


def rename(db_path: Path, old: str, new: str) -> tuple[int, list[str]]:
    """Make one person of two names: every face named `old` is named `new`; return faces changed and their photos."""
    with store.connect(db_path) as conn:
        shas = [r[0] for r in conn.execute("SELECT DISTINCT sha256 FROM faces WHERE name = ? COLLATE NOCASE", (old,))]
        n = conn.execute("UPDATE faces SET name = ? WHERE name = ? COLLATE NOCASE", (new, old)).rowcount
        for r in conn.execute("SELECT id, rejected FROM faces WHERE rejected LIKE ?", (f"%{old}%",)).fetchall():
            names = [new if x.lower() == old.lower() else x for x in json.loads(r["rejected"] or "[]")]
            conn.execute("UPDATE faces SET rejected = ? WHERE id = ?", (json.dumps(names), r["id"]))
    return n, shas


def rename_in_sidecars(db_path: Path, old: str, new: str, shas: list[str]) -> dict[str, str]:
    """Rename a person in those photos' sidecars (Picasa's names) and person: tags; return the index tag changes."""
    import sqlite3  # pylint: disable=import-outside-toplevel

    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import AUTO_BLOCK, all_tags, slug  # pylint: disable=import-outside-toplevel

    with sqlite3.connect(db_path) as conn:
        paths = [p for (p,) in conn.execute(
            f"SELECT path FROM files WHERE area = 'photos' AND sha256 IN ({','.join('?' * len(shas))})", shas)] if shas else []
    changed = {}
    for path in paths:
        if not Path(f"{path}.meta.json").exists():
            continue
        data = SidecarService.load(Path(path))
        dirty = False
        for block in ("picasa", "faces"):                    # Picasa's names, and the ones you confirmed
            for face in (data.get(block) or {}).get("faces") or [] if isinstance(data.get(block), dict) else []:
                if (face.get("name") or "").lower() == old.lower():
                    face["name"] = new
                    dirty = True
        auto = data.get(AUTO_BLOCK) if isinstance(data.get(AUTO_BLOCK), dict) else {}
        tags = [f"person:{slug(new)}" if t == f"person:{slug(old)}" else t for t in auto.get("tags") or []]
        if tags != (auto.get("tags") or []):
            auto["tags"] = list(dict.fromkeys(tags))
            data[AUTO_BLOCK] = auto
            dirty = True
        if dirty:
            import json as _json  # pylint: disable=import-outside-toplevel

            SidecarService.save(Path(path), data)
            changed[path] = _json.dumps(all_tags(data))
    return changed


def report(db_path: Path, target: Path, say: Callable[[str], None] | None = None, per_person: int = 48,
           groups: int = 30) -> Path:
    """Write a PDF of the suggestions (by person) and the groups of unknown faces, each face cut from its photo."""
    import io  # pylint: disable=import-outside-toplevel
    import sqlite3  # pylint: disable=import-outside-toplevel

    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    with sqlite3.connect(db_path) as conn:
        paths = {s: p for p, s in conn.execute("SELECT path, sha256 FROM files WHERE area = 'photos'")}
    with store.connect(db_path) as conn:
        suggested = conn.execute("SELECT * FROM faces WHERE status = 'suggested' ORDER BY name, similarity DESC").fetchall()
        unknown = conn.execute("SELECT * FROM faces WHERE group_id IS NOT NULL ORDER BY group_id").fetchall()
    sections: list[tuple[str, list[Any]]] = []
    by_name: dict[str, list[Any]] = defaultdict(list)
    for r in suggested:
        by_name[r["name"]].append(r)
    for name, faces in sorted(by_name.items(), key=lambda kv: -len(kv[1])):
        sections.append((f"Suggested: {name} ({len(faces)} faces)", faces[:per_person]))
    by_group: dict[int, list[Any]] = defaultdict(list)
    for r in unknown:
        by_group[r["group_id"]].append(r)
    for number in sorted(by_group)[:groups]:
        sections.append((f"Who is this? Group {number} ({len(by_group[number])} faces)", by_group[number][:per_person]))

    def crop(row: Any) -> bytes | None:
        path = paths.get(row["sha256"])
        if not path:
            return None
        try:
            with Image.open(path) as img:
                if img.format == "JPEG":
                    img.draft("RGB", (1600, 1600))
                img = ImageOps.exif_transpose(img).convert("RGB")
            l, t, r, b = json.loads(row["box"])
            pad_x, pad_y = (r - l) * 0.3, (b - t) * 0.3
            w, h = img.size
            face = img.crop((int(max(0, l - pad_x) * w), int(max(0, t - pad_y) * h),
                             int(min(1, r + pad_x) * w), int(min(1, b + pad_y) * h)))
            face.thumbnail((160, 160))
            out = io.BytesIO()
            face.save(out, "JPEG", quality=82)
            return out.getvalue()
        except Exception:  # pylint: disable=broad-except
            return None

    target.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(target), pagesize=letter)
    width, height = letter
    margin, cols, cell = 36, 6, 86.0
    for title, faces in sections or [("No suggestions or unknown groups yet", [])]:
        if say:
            say(f"  {title}")
        y = height - margin
        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(margin, y - 14, title[:80])
        y -= 30
        for i, row in enumerate(faces):
            if i and i % cols == 0:
                y -= cell + 14
            if y - cell < margin:
                pdf.showPage()
                y = height - margin
            x = margin + (i % cols) * (cell + 6)
            data = crop(row)
            if data:
                image = ImageReader(io.BytesIO(data))
                iw, ih = image.getSize()
                scale = min(cell / iw, cell / ih)
                pdf.drawImage(image, x + (cell - iw * scale) / 2, y - cell + (cell - ih * scale) / 2, iw * scale, ih * scale)
            pdf.setFont("Helvetica", 6.5)
            sim = row["similarity"]
            label = (("probably" if sim >= PROBABLY else "maybe") + f" {sim:.2f}") if row["status"] == "suggested" else f"face {row['id']}"
            pdf.drawString(x, y - cell - 8, label)
        pdf.showPage()
    pdf.save()
    return target
