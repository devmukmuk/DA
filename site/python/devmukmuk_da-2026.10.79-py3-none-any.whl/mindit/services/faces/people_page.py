"""What the dashboard's People page shows and does: confirm or reject suggestions, name groups, rename people.

A name you confirm (or give a group) is written to the photo's sidecar (`faces` block: each named face's box, name
and where the name came from) and becomes a `person:` tag; a rejected name is never suggested for that face again.
"""

from __future__ import annotations

import io
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.faces import store
from mindit.services.faces.suggest import MAYBE, PROBABLY, people

FACES_BLOCK = "faces"
WAITING_PER_PERSON = 40
GROUPS_SHOWN = 30
FACES_PER_GROUP = 24
NOT_A_FACE = "not_a_face"


def overview(db_path: Path) -> dict[str, Any]:
    """Return everyone, the suggestions waiting for each person, and the groups of unknown faces."""
    everyone = [{"name": p.name, "photos": len(p.photos), "picasa": p.picasa, "confirmed": p.confirmed,
                 "waiting": p.probably + p.maybe} for p in people(db_path)]
    with store.connect(db_path) as conn:
        waiting: dict[str, list[dict[str, Any]]] = {}
        for r in conn.execute("SELECT id, name, similarity FROM faces WHERE status = 'suggested' "
                              "ORDER BY name COLLATE NOCASE, similarity DESC"):
            faces = waiting.setdefault(r["name"], [])
            if len(faces) < WAITING_PER_PERSON:
                faces.append({"id": r["id"], "similarity": r["similarity"],
                              "level": "probably" if (r["similarity"] or 0) >= PROBABLY else "maybe"})
        counts = {r[0]: r[1] for r in conn.execute(
            "SELECT name, COUNT(*) FROM faces WHERE status = 'suggested' GROUP BY name")}
        groups = []
        for (group, total) in conn.execute("SELECT group_id, COUNT(*) FROM faces WHERE group_id IS NOT NULL AND "
                                           "status IS NULL GROUP BY group_id ORDER BY COUNT(*) DESC, group_id "
                                           "LIMIT ?", (GROUPS_SHOWN,)).fetchall():
            ids = [r[0] for r in conn.execute("SELECT id FROM faces WHERE group_id = ? AND status IS NULL "
                                              "ORDER BY score DESC LIMIT ?", (group, FACES_PER_GROUP))]
            groups.append({"group": group, "count": total, "faces": ids})
        open_groups = conn.execute("SELECT COUNT(DISTINCT group_id) FROM faces WHERE group_id IS NOT NULL "
                                   "AND status IS NULL").fetchone()[0]
        scanned = conn.execute("SELECT COUNT(*) FROM face_scans").fetchone()[0]
        found = conn.execute("SELECT COUNT(*) FROM faces").fetchone()[0]
    order = sorted(waiting, key=lambda n: -counts.get(n, 0))
    return {"people": everyone,
            "waiting": [{"name": n, "count": counts.get(n, 0), "faces": waiting[n]} for n in order],
            "groups": groups, "groups_total": open_groups, "photos_scanned": scanned, "faces_found": found,
            "names": sorted({p["name"] for p in everyone}, key=str.lower), "probably": PROBABLY, "maybe": MAYBE}


def _photo_of(db_path: Path, sha256: str) -> Path | None:
    with sqlite3.connect(db_path) as conn:
        row = conn.execute("SELECT path FROM files WHERE sha256 = ? AND area = 'photos' LIMIT 1", (sha256,)).fetchone()
    return Path(row[0]) if row and Path(row[0]).is_file() else None


def crop(db_path: Path, face_id: int, cache_dir: Path | None = None) -> bytes | None:
    """Return one face cut from its photo (a little room around it), as a small JPEG; kept in .da\\faces once made."""
    from PIL import ImageOps  # pylint: disable=import-outside-toplevel

    from mindit.services.validateit.raw_files import open_picture  # pylint: disable=import-outside-toplevel

    with store.connect(db_path) as conn:
        row = conn.execute("SELECT sha256, n, box FROM faces WHERE id = ?", (face_id,)).fetchone()
    if row is None:
        return None
    cached = cache_dir / row["sha256"][:2] / f"{row['sha256']}-{row['n']}.jpg" if cache_dir else None
    if cached is not None and cached.exists():
        return cached.read_bytes()
    photo = _photo_of(db_path, row["sha256"])
    if photo is None:
        return None
    try:
        with open_picture(photo) as img:
            if img.format == "JPEG":
                img.draft("RGB", (1600, 1600))
            img = ImageOps.exif_transpose(img).convert("RGB")
        left, top, right, bottom = json.loads(row["box"])
        pad_x, pad_y = (right - left) * 0.3, (bottom - top) * 0.3
        w, h = img.size
        face = img.crop((int(max(0.0, left - pad_x) * w), int(max(0.0, top - pad_y) * h),
                         int(min(1.0, right + pad_x) * w), int(min(1.0, bottom + pad_y) * h)))
        face.thumbnail((180, 180))
        out = io.BytesIO()
        face.save(out, "JPEG", quality=84)
    except Exception:  # pylint: disable=broad-except
        return None
    data = out.getvalue()
    if cached is not None:
        try:
            cached.parent.mkdir(parents=True, exist_ok=True)
            cached.write_bytes(data)
        except OSError:
            pass
    return data


def _ids(conn: sqlite3.Connection, ids: list[Any]) -> list[sqlite3.Row]:
    clean = [int(i) for i in ids if str(i).isdigit()][:2000]
    if not clean:
        return []
    return conn.execute(f"SELECT * FROM faces WHERE id IN ({','.join('?' * len(clean))})", clean).fetchall()


def act(db_path: Path, action: str, ids: list[Any], name: str = "") -> dict[str, Any]:
    """Do one People-page button: confirm, reject, name, not_a_face; return {ok, message, photos changed}."""
    name = " ".join((name or "").split())[:80]
    with store.connect(db_path) as conn:
        rows = _ids(conn, ids)
        if not rows:
            return {"ok": False, "message": "Those faces aren't here any more (scan again?)."}
        if action in ("confirm", "name"):
            for r in rows:
                who = name or (r["name"] if r["status"] == "suggested" else "")
                if not who:
                    return {"ok": False, "message": "Type a name first."}
                conn.execute("UPDATE faces SET name = ?, status = 'confirmed', similarity = NULL, group_id = NULL "
                             "WHERE id = ?", (who, r["id"]))
            message = f"{len(rows)} face{'s' if len(rows) != 1 else ''} named {name or 'as suggested'}."
        elif action == "reject":
            for r in rows:
                refused = store.rejected_names(r)
                if r["name"] and r["name"] not in refused:
                    refused.append(r["name"])
                conn.execute("UPDATE faces SET name = NULL, status = NULL, similarity = NULL, rejected = ? WHERE id = ?",
                             (json.dumps(refused), r["id"]))
            message = f"{len(rows)} face{'s' if len(rows) != 1 else ''}: not them (won't be suggested again)."
        elif action == NOT_A_FACE:
            conn.executemany("UPDATE faces SET name = NULL, status = ?, group_id = NULL WHERE id = ?",
                             [(NOT_A_FACE, r["id"]) for r in rows])
            message = f"{len(rows)} marked: not a face."
        else:
            return {"ok": False, "message": f"Not something this page does: {action}"}
        shas = sorted({r["sha256"] for r in rows})
    changed = write_sidecars(db_path, shas)
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("facial_people", f"People page: {action} {len(rows)} faces" + (f" as {name}" if name else ""),
              faces=len(rows), photos=len(shas))
    return {"ok": True, "message": message, "photos": len(changed),
            "folders": sorted({str(Path(p).parent) for p in changed})}


def write_sidecars(db_path: Path, shas: list[str]) -> dict[str, str]:
    """Write each photo's `faces` block (its named faces) and `person:` tags; return the index tag changes."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import AUTO_BLOCK, all_tags, update_index  # pylint: disable=import-outside-toplevel

    changed: dict[str, str] = {}
    now = datetime.now().isoformat(timespec="seconds")
    with store.connect(db_path) as conn:
        for sha in shas:
            photo = _photo_of(db_path, sha)
            if photo is None or not Path(f"{photo}.meta.json").exists():
                continue
            named = [{"box": json.loads(r["box"]), "name": r["name"],
                      "source": "you" if r["status"] == "confirmed" else "picasa"}
                     for r in conn.execute("SELECT box, name, status FROM faces WHERE sha256 = ? AND status IN "
                                           "('confirmed', 'picasa') ORDER BY n", (sha,))]
            data = SidecarService.load(photo)
            old = data.get(FACES_BLOCK) if isinstance(data.get(FACES_BLOCK), dict) else {}
            if (old.get("faces") or []) == named:
                continue
            if named:
                data[FACES_BLOCK] = {"faces": named, "updated_at": now}
            else:
                data.pop(FACES_BLOCK, None)
            auto = data.get(AUTO_BLOCK) if isinstance(data.get(AUTO_BLOCK), dict) else {}
            kept = [t for t in auto.get("tags") or [] if not t.startswith("person:")]
            from mindit.services.tagging.tags import picasa_tags  # pylint: disable=import-outside-toplevel

            auto["tags"] = kept + [t for t in dict.fromkeys(picasa_tags(data) + face_tags(data)) if t.startswith("person:")]
            data[AUTO_BLOCK] = auto
            SidecarService.save(photo, data)
            changed[str(photo)] = json.dumps(all_tags(data))
    update_index(db_path, changed)
    return changed


def face_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the person: tags a sidecar's `faces` block gives (names you confirmed; `da tag` keeps them)."""
    from mindit.services.tagging.tags import slug  # pylint: disable=import-outside-toplevel

    block = sidecar.get(FACES_BLOCK) if isinstance(sidecar.get(FACES_BLOCK), dict) else {}
    return list(dict.fromkeys(f"person:{slug(f['name'])}" for f in block.get("faces") or []
                              if isinstance(f, dict) and f.get("name")))
