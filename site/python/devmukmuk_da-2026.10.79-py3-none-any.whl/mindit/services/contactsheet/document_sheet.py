# src/mindit/services/contactsheet/document_sheet.py

"""A year's document contact sheet: `_contact-sheet.pdf` in the year folder (documents\\organized\\2009\\), every
document of the year (its month folders too) as a picture of its first page.

Page 1 sums the year up (documents, pages, months, what `da ocr` found, copies in holding, sidecars) with the legend;
then the documents follow, 2x2 by default. On each tile: the number of pages in a square at the top left, the
sidecar's schema version in a circle at the top right, SECRETS YES / NO / NOT CHECKED reading up the left edge, and
under it the file name, its SHA-256 and the dates written in it (from `da ocr`). A document `da ocr` hasn't read yet
(or that changed since) has a blue border. A document with copies in `_duplicates-holding` says so, as photos do.
The PDF records a fingerprint of what it shows, so DA can tell when the sheet needs making again.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import zipfile
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

from mindit.services.contactsheet import contact_sheet as cs

SUBJECT_PREFIX = "da-document-sheet "
DESIGN = "1"                          # bump when the drawing changes, so old sheets are made again
DEFAULT_LAYOUT = "2x2"
SKIP_NAMES = {cs.SHEET_NAME, "desktop.ini", "thumbs.db"}
BLUE = (0.12, 0.40, 0.85)             # the border of a document da ocr hasn't read
INK = (0.17, 0.43, 0.57)


def _document_extensions() -> set[str]:
    from mindit.services.validateit.validateit_file_types import DOCUMENT_EXTENSIONS  # pylint: disable=import-outside-toplevel

    return set(DOCUMENT_EXTENSIONS) | {".pptx", ".ppt", ".rtf"}


def is_document(path: Path) -> bool:
    """Return True for a file a document sheet shows (not a sidecar or DA's own files)."""
    name = path.name.lower()
    return path.suffix.lower() in _document_extensions() and name not in SKIP_NAMES and not name.endswith(".meta.json")


def documents_in_year(year_folder: Path) -> list[Path]:
    """Return the year folder's documents, its month folders included, in name order (date order for DA's names)."""
    found: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(year_folder):
        dirnames[:] = [d for d in dirnames if not d.startswith((".", "_"))]
        found.extend(Path(dirpath, f) for f in filenames if is_document(Path(f)))
    return sorted(found, key=lambda p: (p.name.lower(), str(p).lower()))


def year_folders(root: Path) -> list[Path]:
    """Return root when it's a year folder (2009), else every year folder under it that has documents."""
    if re.fullmatch(r"\d{4}", root.name):
        return [root]
    years = []
    for dirpath, dirnames, _files in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith((".", "_"))]
        for d in list(dirnames):
            if re.fullmatch(r"\d{4}", d):
                years.append(Path(dirpath, d))
                dirnames.remove(d)                           # a year inside a year isn't another sheet
    return sorted(y for y in years if documents_in_year(y))


# --------------------------------------------------------------------------- facts

@dataclass(frozen=True)
class DocFacts:
    """What a document sheet shows about one document."""

    schema: str
    sha256: str | None
    pages: int | None
    secrets: str                      # "yes", "no", or "" when da ocr hasn't read it
    dates: tuple[str, ...]
    read: bool                        # da ocr's blocks are there and the file hasn't changed since
    duplicates: tuple[cs.HeldCopy, ...] = ()

    def key(self) -> str:
        """Return these facts as text, for the fingerprint."""
        copies = ";".join(f"{c.path}|{c.size_bytes}" for c in self.duplicates)
        return f"{self.schema}|{self.sha256 or ''}|{self.pages}|{self.secrets}|{','.join(self.dates)}|{int(self.read)}|{copies}"


def page_count(path: Path) -> int | None:
    """Return how many pages a document has (PDF, TIFF frames, Word/PowerPoint's own count), or None."""
    suffix = path.suffix.lower()
    try:
        if suffix == ".pdf":
            import pypdfium2 as pdfium  # pylint: disable=import-outside-toplevel

            doc = pdfium.PdfDocument(str(path))
            try:
                return len(doc)
            finally:
                doc.close()
        if suffix in (".tif", ".tiff"):
            from PIL import Image  # pylint: disable=import-outside-toplevel

            with Image.open(path) as img:
                return int(getattr(img, "n_frames", 1))
        if suffix in (".jpg", ".jpeg", ".png", ".bmp", ".txt", ".md", ".csv", ".rtf"):
            return 1
        if suffix in (".docx", ".pptx"):
            with zipfile.ZipFile(path) as z:
                app = z.read("docProps/app.xml").decode("utf-8", errors="replace")
            m = re.search(r"<(?:Pages|Slides)>(\d+)</", app)
            return int(m.group(1)) if m else None
    except Exception:  # pylint: disable=broad-except
        return None
    return None


def is_read(path: Path) -> bool:
    """Return whether da ocr has read this document as it is now (from its sidecar alone)."""
    from mindit.services.ocr.text_facts import DATES_BLOCK, SECRETS_BLOCK, is_current  # pylint: disable=import-outside-toplevel

    try:
        raw = json.loads(Path(f"{path}.meta.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    blocks = [b for b in (DATES_BLOCK, SECRETS_BLOCK) if isinstance(raw, dict) and isinstance(raw.get(b), dict)]
    return bool(blocks) and is_current(raw, path, blocks)


def document_facts(path: Path) -> DocFacts:
    """Return a document's sidecar facts: schema, SHA-256, da ocr's dates and secrets; and its page count."""
    from mindit.services.ocr.text_facts import DATES_BLOCK, SECRETS_BLOCK, is_current  # pylint: disable=import-outside-toplevel

    try:
        raw = json.loads(Path(f"{path}.meta.json").read_text(encoding="utf-8"))
        raw = raw if isinstance(raw, dict) else {}
        has_sidecar = True
    except (OSError, ValueError):
        raw, has_sidecar = {}, False
    schema = raw.get("schema") if isinstance(raw.get("schema"), dict) else {}
    dates_block = raw.get(DATES_BLOCK) if isinstance(raw.get(DATES_BLOCK), dict) else {}
    secrets_block = raw.get(SECRETS_BLOCK) if isinstance(raw.get(SECRETS_BLOCK), dict) else {}
    read = bool(dates_block or secrets_block) and is_current(raw, path, [b for b, blk in (
        (DATES_BLOCK, dates_block), (SECRETS_BLOCK, secrets_block)) if blk])
    secrets = "" if not secrets_block else ("yes" if secrets_block.get("found") else "no")
    return DocFacts(schema=str(schema.get("version")) if has_sidecar and schema.get("version") else
                    ("?" if has_sidecar else "-"), sha256=cs._sidecar_sha256(raw), pages=page_count(path),  # pylint: disable=protected-access
                    secrets=secrets, dates=tuple(d for d in dates_block.get("found") or [] if isinstance(d, str)),
                    read=read)


def _facts_for(docs: list[Path], held: dict[str, list[cs.HeldCopy]]) -> dict[Path, DocFacts]:
    out = {}
    for doc in docs:
        fact = document_facts(doc)
        try:
            size = doc.stat().st_size
        except OSError:
            size = -1
        sha256 = fact.sha256 or _sha256(doc)                # a sidecar without one: work it out (documents are small)
        copies = tuple(c for c in held.get(sha256 or "", ()) if c.size_bytes == size
                       and c.path.resolve() != doc.resolve())
        out[doc] = DocFacts(**{**fact.__dict__, "sha256": sha256, "duplicates": copies})
    return out


def _sha256(path: Path) -> str | None:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
                digest.update(chunk)
    except OSError:
        return None
    return digest.hexdigest()


def held_documents(holding_root: Path | None = None) -> dict[str, list[cs.HeldCopy]]:
    """Return the documents in holding by SHA-256 (for the 'copies in holding' notes)."""
    return cs._held_duplicates_by_hash(holding_root or cs._holding_root(), accept=is_document)  # pylint: disable=protected-access


def fingerprint(docs: list[Path], layout: str, facts: dict[Path, DocFacts], year_folder: Path) -> str:
    """Return a short fingerprint of the documents, their facts and the layout."""
    digest = hashlib.sha1(f"documents design {DESIGN} {layout}\n".encode("utf-8"))
    for doc in docs:
        try:
            stat = doc.stat()
            size, modified = stat.st_size, round(stat.st_mtime)
        except OSError:
            size, modified = -1, 0
        rel = os.path.relpath(doc, year_folder).lower()
        digest.update(f"{rel}\t{size}\t{modified}\t{facts[doc].key()}\n".encode("utf-8"))
    return digest.hexdigest()[:16]


def recorded_fingerprint(sheet: Path) -> str | None:
    """Return the fingerprint a document sheet carries, or None."""
    try:
        from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

        subject = str((PdfReader(sheet, strict=False).metadata or {}).get("/Subject") or "")
    except Exception:  # pylint: disable=broad-except
        return None
    return subject[len(SUBJECT_PREFIX):].strip() if subject.startswith(SUBJECT_PREFIX) else None


# --------------------------------------------------------------------------- first pages

def _first_page(doc: Path, box: tuple[int, int]):
    """Return a PIL picture of a document's first page, or None (Office files without a picture, text files)."""
    suffix = doc.suffix.lower()
    try:
        if suffix == ".pdf":
            import pypdfium2 as pdfium  # pylint: disable=import-outside-toplevel

            pdf = pdfium.PdfDocument(str(doc))
            try:
                page = pdf[0]
                width, height = page.get_size()
                return page.render(scale=max(box) / max(width, height, 1)).to_pil()
            finally:
                pdf.close()
        if suffix in (".docx", ".pptx", ".xlsx"):
            from PIL import Image  # pylint: disable=import-outside-toplevel

            with zipfile.ZipFile(doc) as z:
                name = next((n for n in z.namelist() if n.lower().startswith("docprops/thumbnail.")), None)
                if name is None:
                    return None
                return Image.open(io.BytesIO(z.read(name))).convert("RGB")
        if suffix in (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"):
            small = cs._small_copy(doc, (box[0] * 2, box[1] * 2))  # pylint: disable=protected-access
            if small is None:
                return None
            from PIL import Image  # pylint: disable=import-outside-toplevel

            return Image.open(small)
    except Exception:  # pylint: disable=broad-except
        return None
    return None


def _thumbnail(doc: Path, box: tuple[int, int], sha256: str | None):
    """Return a reportlab ImageReader of the first page (kept in .da\\thumbs by SHA-256), or None."""
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel

    cache = cs._THUMB_DIR[0] / sha256[:2] / f"{sha256}.jpg" if cs._THUMB_DIR[0] and sha256 else None  # pylint: disable=protected-access
    if cache is not None and cache.exists():
        return ImageReader(str(cache))
    picture = _first_page(doc, (cs.THUMB_SIZE, cs.THUMB_SIZE))
    if picture is None:
        return None
    picture.thumbnail((cs.THUMB_SIZE, cs.THUMB_SIZE))
    out = io.BytesIO()
    picture.convert("RGB").save(out, "JPEG", quality=82)
    if cache is not None:
        try:
            cache.parent.mkdir(parents=True, exist_ok=True)
            part = cache.with_name(cache.name + ".part")
            part.write_bytes(out.getvalue())
            os.replace(part, cache)
        except OSError:
            pass
    out.seek(0)
    return ImageReader(out)


def _text_lines(doc: Path, count: int = 18) -> list[str]:
    """Return the first lines of a document's own text (for a tile with no picture of its page)."""
    from mindit.services.secure.passwords import OFFICE_SUFFIXES, TEXT_SUFFIXES, _office_text  # pylint: disable=import-outside-toplevel

    suffix = doc.suffix.lower()
    try:
        if suffix in TEXT_SUFFIXES:
            text = doc.read_text(encoding="utf-8", errors="replace")[:4000]
        elif suffix in OFFICE_SUFFIXES:
            text = _office_text(doc)[:4000]
        else:
            return []
    except OSError:
        return []
    words, lines, line = text.split(), [], ""
    for word in words:
        if len(line) + len(word) + 1 > 48:
            lines.append(line)
            line = word
            if len(lines) >= count:
                break
        else:
            line = f"{line} {word}".strip()
    if line and len(lines) < count:
        lines.append(line)
    return lines


# --------------------------------------------------------------------------- the sheet

def make_sheet(year_folder: Path, *, version: str = "", layout: str | None = None,
               held: dict[str, list[cs.HeldCopy]] | None = None) -> Path | None:
    """Write the year folder's document sheet; with no documents, remove an old one. Return the sheet or None."""
    sheet = year_folder / cs.SHEET_NAME
    docs = documents_in_year(year_folder)
    if not docs:
        sheet.unlink(missing_ok=True)
        return None
    cols, rows = cs.layout_size(layout or DEFAULT_LAYOUT)
    held = held if held is not None else held_documents()
    facts = _facts_for(docs, held)
    cs._THUMB_DIR[0] = cs.thumbs_dir(year_folder)  # pylint: disable=protected-access
    try:
        return _write(year_folder, sheet, docs, facts, (cols, rows), version)
    finally:
        cs._THUMB_DIR[0] = None  # pylint: disable=protected-access


def is_current(year_folder: Path, layout: str | None = None, held: dict[str, list[cs.HeldCopy]] | None = None) -> bool:
    """Return True when the year's sheet exists and shows exactly what the year holds now."""
    sheet = year_folder / cs.SHEET_NAME
    if not sheet.exists():
        return False
    cols, rows = cs.layout_size(layout or DEFAULT_LAYOUT)
    docs = documents_in_year(year_folder)
    facts = _facts_for(docs, held if held is not None else held_documents())
    return recorded_fingerprint(sheet) == fingerprint(docs, f"{cols}x{rows}", facts, year_folder)


def refresh_sheets(years: Iterable[Path], *, version: str = "", layout: str | None = None, force: bool = False,
                   progress: Callable[[str], None] | None = None) -> cs.SheetResult:
    """Make the document sheet of each year folder whose documents (or what da ocr found) changed."""
    result = cs.SheetResult()
    held = held_documents()
    for year in sorted(set(years)):
        if not force and is_current(year, layout, held):
            result.current += 1
            continue
        try:
            made = make_sheet(year, version=version, layout=layout, held=held)
        except Exception as exc:  # pylint: disable=broad-except
            result.failed.append((year, f"{type(exc).__name__}: {exc}"))
            continue
        if made is None:
            result.removed.append(year / cs.SHEET_NAME)
        else:
            result.made.append(made)
            if progress:
                progress(f"document sheet: {made}")
    return result


def _write(year_folder: Path, sheet: Path, docs: list[Path], facts: dict[Path, DocFacts], grid: tuple[int, int],
           version: str) -> Path:
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    cols, rows = grid
    per_page = cols * rows
    pages = 1 + (len(docs) + per_page - 1) // per_page
    label = f"{year_folder.name} documents"
    tmp = sheet.with_name(sheet.name + ".tmp")
    pdf = canvas.Canvas(str(tmp), pagesize=letter)
    pdf.setTitle(f"Document sheet: {year_folder.name}")
    pdf.setSubject(SUBJECT_PREFIX + fingerprint(docs, f"{cols}x{rows}", facts, year_folder))
    pdf.setCreator(f"DA v{version}" if version else "DA")
    footer = f"Made by DA{' v' + version if version else ''} on {datetime.now():%Y-%m-%d %H:%M}"
    _summary_page(pdf, letter, label, year_folder, docs, facts, pages, footer)
    for page, start in enumerate(range(0, len(docs), per_page), 2):
        _documents_page(pdf, letter, label, year_folder, docs[start:start + per_page], facts, grid, page, pages, footer)
    pdf.save()
    os.replace(tmp, sheet)
    return sheet


def _month_of(doc: Path, year_folder: Path) -> str:
    rel = Path(os.path.relpath(doc, year_folder)).parts
    return rel[0] if len(rel) > 1 else year_folder.name


def _summary_page(pdf, size, label: str, year_folder: Path, docs: list[Path], facts: dict[Path, DocFacts],
                  pages: int, footer: str) -> None:  # pylint: disable=too-many-locals,too-many-arguments,too-many-statements
    width, height = size
    margin = 40
    total_pages = sum(facts[d].pages or 0 for d in docs)
    unknown_pages = sum(1 for d in docs if facts[d].pages is None)
    read = [d for d in docs if facts[d].read]
    secrets = sum(1 for d in docs if facts[d].secrets == "yes")
    all_dates = sorted(x for d in docs for x in facts[d].dates)
    with_dates = sum(1 for d in docs if facts[d].dates)
    copies = sum(len(facts[d].duplicates) for d in docs)
    schemas = Counter(facts[d].schema for d in docs)
    months = Counter(_month_of(d, year_folder) for d in docs)

    pdf.setFillColorRGB(*INK)
    pdf.rect(0, height - 74, width, 74, stroke=0, fill=1)
    pdf.setFillGray(1)
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(margin, height - 40, label)
    pdf.setFont("Helvetica", 10.5)
    pdf.drawString(margin, height - 60, f"Document sheet   |   {len(docs):,} document{'s' if len(docs) != 1 else ''}   |   "
                                        f"{total_pages:,} pages   |   {pages} sheet pages")
    y = height - 104

    def heading(text: str) -> None:
        nonlocal y
        pdf.setFillColorRGB(*INK)
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawString(margin, y, text.upper())
        pdf.setStrokeGray(0.8)
        pdf.line(margin, y - 4, width - margin, y - 4)
        y -= 22

    def row(left: str, right: str, *, bold: bool = False, gray: float = 0.1) -> None:
        nonlocal y
        pdf.setFillGray(gray)
        pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 10.5)
        pdf.drawString(margin, y, left)
        pdf.drawRightString(width - margin, y, right)
        y -= 15

    heading("This year")
    row("Documents", f"{len(docs):,}")
    row("Pages", f"{total_pages:,}" + (f" (and {unknown_pages:,} documents that don't say)" if unknown_pages else ""))
    row("Read by da ocr", f"{len(read):,} of {len(docs):,}" + ("" if len(read) == len(docs) else
                                                                 f" - {len(docs) - len(read):,} not yet (blue border)"))
    row("Holding a secret (Secrets: Yes)", f"{secrets:,}")
    row("With dates in them", f"{with_dates:,}" + (f", {all_dates[0]} to {all_dates[-1]}" if all_dates else ""))
    if copies:
        row("Copies in holding", f"{sum(1 for d in docs if facts[d].duplicates):,} documents, {copies:,} copies")
    row("Sidecars", ", ".join(f"schema {v} ({n:,})" if v not in ("-", "?") else
                              ("no sidecar" if v == "-" else "no version") + f" ({n:,})"
                              for v, n in sorted(schemas.items(), reverse=True)))
    y -= 10
    heading("Months")
    for month, n in sorted(months.items()):
        month_pages = sum(facts[d].pages or 0 for d in docs if _month_of(d, year_folder) == month)
        row(month, f"{n:,} documents, {month_pages:,} pages")
        if y < 190:
            row(f"and {len(months)} months in all", "", gray=0.4)
            break
    y -= 14
    heading("On each document")
    legend = [("square", "The number in the square (top left): how many pages it has."),
              ("circle", "The number in the circle (top right): its sidecar's schema version."),
              ("secrets", "Up the left edge: SECRETS YES (a password, PIN or security answer in it), SECRETS NO, "
                          "or NOT CHECKED."),
              ("text", "Under it: its file name, its SHA-256, and the dates written in it."),
              ("blue", "A blue border: da ocr hasn't read it yet (or it changed since) - run da ocr on the year."),
              ("held", "In red: copies of it in _duplicates-holding.")]
    for kind, text in legend:
        _legend_mark(pdf, kind, margin + 8, y + 3)
        pdf.setFillGray(0.2)
        pdf.setFont("Helvetica", 9.5)
        pdf.drawString(margin + 24, y, text)
        y -= 16
    cs._footer(pdf, size, footer, 1, pages)  # pylint: disable=protected-access
    pdf.showPage()


def _legend_mark(pdf, kind: str, x: float, y: float) -> None:
    """Draw the small sample beside a legend line."""
    pdf.saveState()
    if kind == "square":
        pdf.setFillGray(1)
        pdf.setStrokeColorRGB(*INK)
        pdf.rect(x - 6, y - 6, 12, 12, stroke=1, fill=1)
        pdf.setFillColorRGB(*INK)
        pdf.setFont("Helvetica-Bold", 7)
        pdf.drawCentredString(x, y - 2.5, "3")
    elif kind == "circle":
        pdf.setFillGray(1)
        pdf.setStrokeColorRGB(*INK)
        pdf.circle(x, y, 6, stroke=1, fill=1)
        pdf.setFillColorRGB(*INK)
        pdf.setFont("Helvetica-Bold", 7)
        pdf.drawCentredString(x, y - 2.5, "2")
    elif kind == "secrets":
        pdf.setFillColorRGB(0.75, 0.1, 0.1)
        pdf.setFont("Helvetica-Bold", 7)
        pdf.drawCentredString(x, y - 2.5, "YES")
    elif kind == "blue":
        pdf.setStrokeColorRGB(*BLUE)
        pdf.setLineWidth(2.2)
        pdf.rect(x - 6, y - 7, 12, 14, stroke=1, fill=0)
    elif kind == "held":
        pdf.setFillColorRGB(0.65, 0.22, 0.08)
        pdf.setFont("Helvetica-Bold", 7)
        pdf.drawCentredString(x, y - 2.5, "1")
    else:
        pdf.setFillGray(0.4)
        pdf.setFont("Helvetica", 7)
        pdf.drawCentredString(x, y - 2.5, "abc")
    pdf.restoreState()


def _documents_page(pdf, size, label: str, year_folder: Path, items: list[Path], facts: dict[Path, DocFacts],
                    grid: tuple[int, int], page: int, pages: int, footer: str) -> None:  # pylint: disable=too-many-locals,too-many-arguments,too-many-statements
    width, height = size
    cols, rows = grid
    margin, head, foot = 36, 40, 20
    big = cols <= 2
    gutter = 14                                              # room for SECRETS up the left of each page picture
    caption_lines = 5                                        # name, SHA-256, dates (2 lines), held copies
    line = 8.5 if big else 7.5
    caption = caption_lines * line + 6
    cell_w = (width - 2 * margin) / cols
    cell_h = (height - 2 * margin - head - foot) / rows
    box_w = cell_w - gutter - 10

    top = height - margin
    months = sorted({_month_of(d, year_folder) for d in items})
    pdf.setFillGray(0)
    pdf.setFont("Helvetica-Bold", 13)
    pdf.drawString(margin, top - 14, label)
    pdf.setFont("Helvetica", 9)
    pdf.setFillGray(0.4)
    pdf.drawString(margin, top - 28, months[0] if len(months) == 1 else f"{months[0]} to {months[-1]}")
    pdf.setStrokeGray(0.7)
    pdf.line(margin, top - head + 4, width - margin, top - head + 4)

    for i, doc in enumerate(items):
        col, row = i % cols, i // cols
        x = margin + col * cell_w
        y = top - head - (row + 1) * cell_h
        fact = facts[doc]
        area_x, area_y = x + gutter, y + caption + 6            # room for the blue border above the name
        box_h = cell_h - caption - 16
        image = _thumbnail(doc, (int(box_w * 2), int(box_h * 2)), fact.sha256)
        if image is not None:
            iw, ih = image.getSize()
            scale = min(box_w / iw, box_h / ih)
            dw, dh = iw * scale, ih * scale
            ix, iy = area_x + (box_w - dw) / 2, area_y + (box_h - dh) / 2
            pdf.drawImage(image, ix, iy, dw, dh)
            pdf.setStrokeGray(0.75)
            pdf.setLineWidth(0.6)
            pdf.rect(ix, iy, dw, dh, stroke=1, fill=0)
        else:                                                # a card: the type and the first lines of its text
            dw, dh = min(box_w, box_h * 0.77), box_h
            ix, iy = area_x + (box_w - dw) / 2, area_y
            pdf.setFillGray(0.96)
            pdf.setStrokeGray(0.7)
            pdf.rect(ix, iy, dw, dh, stroke=1, fill=1)
            pdf.setFillColorRGB(*INK)
            pdf.setFont("Helvetica-Bold", 12 if big else 10)
            pdf.drawCentredString(ix + dw / 2, iy + dh - 22, doc.suffix.upper().lstrip("."))
            pdf.setFillGray(0.35)
            pdf.setFont("Helvetica", 6.5 if big else 5.5)
            ty = iy + dh - 38
            for text in _text_lines(doc):
                if ty < iy + 6:
                    break
                pdf.drawString(ix + 6, ty, text[:60])
                ty -= 8 if big else 7
        if not fact.read:                                    # not read by da ocr: a blue border
            pdf.setStrokeColorRGB(*BLUE)
            pdf.setLineWidth(3)
            pdf.rect(ix - 3, iy - 3, dw + 6, dh + 6, stroke=1, fill=0)
        pdf.setLineWidth(1)
        # SECRETS YES / NO / NOT CHECKED, bold, reading up the page's left edge
        word, colour = {"yes": ("SECRETS YES", (0.75, 0.1, 0.1)), "no": ("SECRETS NO", (0.05, 0.45, 0.2))}.get(
            fact.secrets, ("NOT CHECKED", (0.45, 0.45, 0.45)))
        pdf.saveState()
        pdf.setFillColorRGB(*colour)
        pdf.setFont("Helvetica-Bold", 8.5 if big else 7)
        pdf.translate(ix - 6, iy + dh / 2)
        pdf.rotate(90)
        pdf.drawCentredString(0, 0, word)
        pdf.restoreState()
        # the number of pages, in a square at the top left; the schema version, circled, at the top right
        side = 15 if big else 12
        sx, sy = ix + 3, iy + dh - side - 3
        pdf.setFillGray(1)
        pdf.setStrokeColorRGB(*INK)
        pdf.setLineWidth(1.2)
        pdf.rect(sx, sy, side, side, stroke=1, fill=1)
        pdf.setFillColorRGB(*INK)
        pages_text = "?" if fact.pages is None else str(fact.pages)
        pdf.setFont("Helvetica-Bold", (8 if big else 7) if len(pages_text) < 3 else 6)
        pdf.drawCentredString(sx + side / 2, sy + side / 2 - 3, pages_text)
        radius = 7.5 if big else 6.5
        cx, cy = ix + dw - radius - 3, iy + dh - radius - 3
        pdf.setFillGray(1)
        pdf.circle(cx, cy, radius, stroke=1, fill=1)
        pdf.setFillColorRGB(*INK)
        pdf.setFont("Helvetica-Bold", 8.5 if big else 7.5)
        pdf.drawCentredString(cx, cy - 3, fact.schema)
        pdf.setLineWidth(1)
        # under it: name, SHA-256, dates, copies in holding
        ty = y + caption - line - 2
        pdf.setFillGray(0)
        pdf.setFont("Helvetica-Bold", 8 if big else 7)
        limit = 58 if big else 40
        pdf.drawCentredString(x + cell_w / 2, ty, doc.name if len(doc.name) <= limit else doc.name[:limit - 3] + "...")
        ty -= line
        pdf.setFillGray(0.35)
        pdf.setFont("Courier", 5.6 if big else 4.4)
        pdf.drawCentredString(x + cell_w / 2, ty, fact.sha256 or "SHA-256 not recorded")
        ty -= line
        pdf.setFillGray(0.15)
        pdf.setFont("Helvetica", 7 if big else 6)
        for text in _dates_lines(fact, cell_w - 8, 7 if big else 6):
            pdf.drawCentredString(x + cell_w / 2, ty, text)
            ty -= line
        if fact.duplicates:
            count = len(fact.duplicates)
            pdf.setFillColorRGB(0.65, 0.22, 0.08)
            pdf.setFont("Helvetica-Bold", 6.5 if big else 6)
            pdf.drawCentredString(x + cell_w / 2, y + 2, f"{count} duplicate{'s' if count != 1 else ''} in holding")
    cs._footer(pdf, size, footer, page, pages)  # pylint: disable=protected-access
    pdf.showPage()


def _dates_lines(fact: DocFacts, width: float, font_size: float) -> list[str]:
    """Return at most two lines of a document's dates ('Dates: 2009-01-04, 2009-02-10 ... +12 more')."""
    from reportlab.pdfbase import pdfmetrics  # pylint: disable=import-outside-toplevel

    if not fact.read and not fact.dates:
        return ["Dates: not read yet"]
    if not fact.dates:
        return ["Dates: none found"]
    lines, current, shown = [], "Dates: ", 0
    for i, day in enumerate(fact.dates):
        piece = day + (", " if i < len(fact.dates) - 1 else "")
        if pdfmetrics.stringWidth(current + piece, "Helvetica", font_size) > width:
            lines.append(current.rstrip(", "))
            if len(lines) == 2:
                break
            current = ""
        current += piece
        shown = i + 1
    else:
        lines.append(current.rstrip(", "))
    if shown < len(fact.dates):
        rest = len(fact.dates) - shown
        lines[-1] = lines[-1][:max(0, len(lines[-1]) - 14)].rstrip(", ") + f" ... +{rest} more"
    return lines[:2]
