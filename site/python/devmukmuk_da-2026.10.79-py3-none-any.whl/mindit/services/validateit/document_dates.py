# src/mindit/services/validateit/document_dates.py

"""The date stored inside a document - the document equivalent of a photo's EXIF date.

PDF: the Info dictionary's /CreationDate (when it was scanned, printed or exported).
Word / Excel / PowerPoint (.docx .xlsx .pptx and macro variants): docProps/core.xml's
dcterms:created - when the document was first created.
Older Word / Excel / PowerPoint (.doc .xls .ppt): the SummaryInformation stream's creation time (via olefile).
"""

from __future__ import annotations

import logging
import re
import warnings
import zipfile
from datetime import datetime, timezone
from pathlib import Path

OFFICE_EXTENSIONS = {".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm"}
OLE_EXTENSIONS = {".doc", ".xls", ".ppt"}
PDF_EXTENSIONS = {".pdf"}
DOCUMENT_DATE_EXTENSIONS = OFFICE_EXTENSIONS | OLE_EXTENSIONS | PDF_EXTENSIONS

# pypdf reports every small flaw in a PDF ("Ignoring wrong pointing object ...", "invalid pdf header")
# as a warning on the screen, one per file. It reads past them; a PDF it can't read just has no date.
logging.getLogger("pypdf").setLevel(logging.ERROR)

# D:YYYYMMDDHHmmSS followed by Z, +hh'mm' or -hh'mm' (all parts after the year optional).
_PDF_DATE = re.compile(r"D?:?(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?(Z|[+-]\d{2}'?\d{2}'?)?")
_CORE_CREATED = re.compile(r"<dcterms:created[^>]*>\s*([^<\s]+)\s*<")


def read_document_date(path: Path) -> datetime | None:
    """Return the creation date stored inside a PDF or Office file, as local wall-clock time, or None."""
    suffix = Path(path).suffix.lower()
    try:
        if suffix in PDF_EXTENSIONS:
            return _pdf_created(Path(path))
        if suffix in OFFICE_EXTENSIONS:
            return _office_created(Path(path))
        if suffix in OLE_EXTENSIONS:
            return _ole_created(Path(path))
    except Exception:  # noqa: BLE001 - a damaged or encrypted file just has no readable date
        return None
    return None


def _pdf_created(path: Path) -> datetime | None:
    from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        info = PdfReader(path, strict=False).metadata or {}
    return parse_pdf_date(str(info.get("/CreationDate") or ""))


def parse_pdf_date(raw: str) -> datetime | None:
    """Parse a PDF date (D:20100310190725-06'00'). The time is the clock time written; a Z time becomes local."""
    m = _PDF_DATE.fullmatch(raw.strip())
    if not m:
        return None
    year, month, day, hour, minute, second, tz = m.groups()
    try:
        value = datetime(int(year), int(month or 1), int(day or 1), int(hour or 0), int(minute or 0), int(second or 0))
    except ValueError:
        return None
    if tz == "Z":
        value = value.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)
    return value


def _ole_created(path: Path) -> datetime | None:
    import olefile  # pylint: disable=import-outside-toplevel

    if not olefile.isOleFile(str(path)):
        return None
    with olefile.OleFileIO(str(path)) as ole:
        value = ole.get_metadata().create_time
    if not isinstance(value, datetime) or value.year < 1980:
        return None
    return value.replace(tzinfo=timezone.utc).astimezone().replace(tzinfo=None)   # stored as UTC


def _office_created(path: Path) -> datetime | None:
    with zipfile.ZipFile(path) as z:
        try:
            core = z.read("docProps/core.xml").decode("utf-8", "ignore")
        except KeyError:
            return None
    m = _CORE_CREATED.search(core)
    if not m:
        return None
    text = m.group(1).replace("Z", "+00:00")
    try:
        value = datetime.fromisoformat(text)
    except ValueError:
        return None
    if value.tzinfo is not None:                      # stored as UTC: show the local time it was
        value = value.astimezone().replace(tzinfo=None)
    return value
