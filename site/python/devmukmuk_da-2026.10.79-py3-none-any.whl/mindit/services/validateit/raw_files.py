"""Camera raw files as pictures: their date, camera and built-in preview, for filing, contact sheets and comparing.

CR2 (Canon, 2004-2018), NEF, ARW, DNG and other TIFF-based raws: Pillow reads their EXIF and their big built-in preview.
CR3 (Canon, 2018 on) is an ISO media file like a HEIC: its EXIF is in the `CMT1` (main) and `CMT2` (Exif) records of
Canon's `uuid` box in `moov`, and a 1620 px JPEG preview is in the `PRVW` record of another `uuid` box. open_picture()
returns that preview with the EXIF attached, so everything that reads a photo reads a CR3 the same way.
"""

from __future__ import annotations

import io
import struct
from pathlib import Path
from typing import Any

CANON_META = bytes.fromhex("85c0b687820f11e08111f4ce462b6a48")      # moov/uuid: CNCV, CMT1-4, THMB
CANON_PREVIEW = bytes.fromhex("eaf42b5e1c984b88b9fbb7dc406e4d16")   # uuid: PRVW (the JPEG preview)


def _boxes(data: bytes, start: int = 0, end: int | None = None):
    """Yield (type, payload start, box end) for the ISO media boxes in data[start:end]."""
    end = len(data) if end is None else end
    at = start
    while at + 8 <= end:
        size, kind = struct.unpack(">I4s", data[at:at + 8])
        head = 8
        if size == 1:
            size = struct.unpack(">Q", data[at + 8:at + 16])[0]
            head = 16
        elif size == 0:
            size = end - at
        if size < head or at + size > end:
            return
        yield kind, at + head, at + size
        at += size


def cr3_parts(path: Path) -> dict[str, bytes]:
    """Return a CR3's EXIF records (CMT1 main, CMT2 Exif, both TIFF) and its JPEG preview (PRVW), where found."""
    with Path(path).open("rb") as f:
        data = f.read(8_000_000)                                  # the boxes DA needs come before the raw data
    parts: dict[str, bytes] = {}
    for kind, start, end in _boxes(data):
        if kind == b"moov":
            for inner, s, e in _boxes(data, start, end):
                if inner == b"uuid" and data[s:s + 16] == CANON_META:
                    for rec, rs, re_ in _boxes(data, s + 16, e):
                        if rec in (b"CMT1", b"CMT2"):
                            parts[rec.decode()] = data[rs:re_]
        elif kind == b"uuid" and data[start:start + 16] == CANON_PREVIEW:
            for rec, rs, re_ in _boxes(data, start + 16 + 8, end):     # 8 bytes after the uuid before PRVW
                if rec == b"PRVW":
                    jpeg = data.find(b"\xff\xd8\xff", rs, re_)
                    if jpeg >= 0:
                        parts["PRVW"] = data[jpeg:re_]
    return parts


def cr3_size(path: Path) -> tuple[int, int] | None:
    """Return a CR3's full picture size (from its EXIF), not its preview's - or None (not a CR3, or not recorded)."""
    if not is_cr3(path):
        return None
    from PIL import Image  # pylint: disable=import-outside-toplevel

    parts = cr3_parts(path)
    if "CMT2" not in parts:
        return None
    sub = Image.Exif()
    sub.load(parts["CMT2"])
    w, h = sub.get(0xA002), sub.get(0xA003)                   # PixelXDimension, PixelYDimension
    return (int(w), int(h)) if w and h else None


def is_cr3(path: Path) -> bool:
    """Return whether a file is a Canon CR3 (by its name, then its ISO media brand)."""
    if Path(path).suffix.lower() != ".cr3":
        return False
    try:
        with Path(path).open("rb") as f:
            head = f.read(12)
    except OSError:
        return False
    return head[4:12] == b"ftypcrx "


def _exif_bytes(parts: dict[str, bytes]) -> bytes | None:
    from PIL import Image  # pylint: disable=import-outside-toplevel

    if "CMT1" not in parts:
        return None
    exif = Image.Exif()
    exif.load(parts["CMT1"])
    if "CMT2" in parts:
        sub = Image.Exif()
        sub.load(parts["CMT2"])
        exif[0x8769] = dict(sub)
    return exif.tobytes()


def open_picture(path: Path) -> Any:
    """Open a photo with Pillow; a CR3 opens as its built-in preview with its own EXIF (date, camera, orientation)."""
    from PIL import Image  # pylint: disable=import-outside-toplevel

    if not is_cr3(path):
        return Image.open(path)
    parts = cr3_parts(path)
    if "PRVW" not in parts:
        raise OSError(f"no preview found in {Path(path).name}")
    img = Image.open(io.BytesIO(parts["PRVW"]))
    exif = _exif_bytes(parts)
    if exif:
        img.info["exif"] = exif
    return img
