# src/mindit/services/sidecar/origin.py

"""Where a file came in from: the folder levels under intake, kept in the sidecar's `origin` block.

    "origin": {"intake": "photos", "folders": ["Jones Family Photos", "Scans"], "file_name": "IMG_0003.JPG",
               "recorded_at": "2026-10-22T10:15:00"}

Worked out from `file.source_path` the first time a sidecar is saved with one, and never replaced, so a file that
goes through intake again (an undo, a split or merge into intake\\<kind>\\from-<archive>) keeps its true origin. The
levels become {from:1} {from:-1} {from} tokens and `folder:` tags. Design: docs/da-docs/ORIGIN-DESIGN.md.
"""

from __future__ import annotations

import fnmatch
import re
from datetime import datetime
from pathlib import PurePath, PureWindowsPath
from typing import Any, Iterable

ORIGIN_BLOCK = "origin"
FOLDER_TAG = "folder"
_DA_AREAS = {"organized", "_duplicates-holding", "_secure-holding"}   # DA's own folders: not where a file came from
_FROM_ARCHIVE = re.compile(r"(?i)^from-")                             # intake\<kind>\from-<archive>: made by split/merge
# Folder names that never become tags (they stay in the block): a camera's or phone's own folders, plain numbers
# (years, months), and folders every PC has. da-archive.yaml's origin: skip: adds to them.
SKIP_NAMES = ("DCIM", "Camera", "Camera Roll", "Camera Uploads", "Pictures", "My Pictures", "Photos", "Documents",
              "My Documents", "Downloads", "Desktop", "New folder", "New folder (*)", "NoExifDate", "Users")
_SKIP_PATTERNS = (re.compile(r"^\d{3}[A-Za-z0-9_]{5}$"),          # 100CANON, 101APPLE, 100_PANA, 100NIKON
                  re.compile(r"^[\d\s._-]+$"),                     # 2016, 07, 2009-01, 2009.01.12
                  re.compile(r"^\d{1,2}\s*-\s*[A-Za-z]{3,9}$"))     # 06 - Jun


def _parts(path: str) -> list[str]:
    pure: PurePath = PureWindowsPath(path) if ("\\" in path or ":" in path) else PurePath(path)
    return list(pure.parts)


def derive(source_path: str | None) -> dict[str, Any] | None:
    """Return the origin of a file from the path it came in with, or None when that isn't known."""
    if not source_path:
        return None
    parts = _parts(str(source_path))
    if len(parts) < 2:
        return None
    folders, name = parts[1:-1], parts[-1]
    lower = [f.lower() for f in folders]
    if "intake" in lower:
        i = lower.index("intake")
        intake, folders = (folders[i + 1], folders[i + 2:]) if i + 1 < len(folders) else ("", [])
    elif _DA_AREAS & set(lower):
        return None                                     # first seen already filed: its origin isn't known
    else:
        intake = ""
    while folders and _FROM_ARCHIVE.match(folders[0]):
        folders = folders[1:]
    return {"intake": intake, "folders": [f.strip() for f in folders if f.strip()], "file_name": name}


def ensure(data: dict[str, Any]) -> bool:
    """Add the origin block to a sidecar's data when it has none and its source path is known; return whether it did."""
    if isinstance(data.get(ORIGIN_BLOCK), dict):
        return False
    file_block = data.get("file") if isinstance(data.get("file"), dict) else {}
    found = derive(file_block.get("source_path"))
    if found is None:
        return False
    data[ORIGIN_BLOCK] = {**found, "recorded_at": datetime.now().isoformat(timespec="seconds")}
    return True


def levels(data: dict[str, Any] | None) -> list[str]:
    """Return the folders a file came in from, top first (from its origin block, else its source path)."""
    data = data or {}
    block = data.get(ORIGIN_BLOCK)
    if isinstance(block, dict) and isinstance(block.get("folders"), list):
        return [str(f) for f in block["folders"] if str(f).strip()]
    file_block = data.get("file") if isinstance(data.get("file"), dict) else {}
    found = derive(file_block.get("source_path"))
    return found["folders"] if found else []


def skipped(name: str, extra: Iterable[str] = ()) -> bool:
    """Return whether a folder name never becomes a tag."""
    lowered = name.strip().lower()
    if any(p.match(name.strip()) for p in _SKIP_PATTERNS):
        return True
    return any(fnmatch.fnmatch(lowered, s.strip().lower()) for s in (*SKIP_NAMES, *extra) if s.strip())


def folder_tags(data: dict[str, Any] | None, extra_skip: Iterable[str] = ()) -> list[str]:
    """Return a `folder:` tag for each level a file came in from, leaving out the skipped names."""
    from mindit.services.tagging.tags import slug  # pylint: disable=import-outside-toplevel

    extra = list(extra_skip)
    tags: list[str] = []
    for level in levels(data):
        tag = f"{FOLDER_TAG}:{slug(level)}"
        if not skipped(level, extra) and slug(level) and tag not in tags:
            tags.append(tag)
    return tags


def level_token(token: str, context: dict[str, Any]) -> str | None:
    """Return what {from:1} / {from:-1} stand for in a pattern ('' past the last level), or None for other tokens."""
    match = re.fullmatch(r"from\s*:\s*(-?\d+)", token.strip())
    if not match:
        return None
    found = context.get("from_levels") or []
    n = int(match.group(1))
    index = n - 1 if n > 0 else n
    return found[index] if n and -len(found) <= index < len(found) else ""
