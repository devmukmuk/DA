# src/mindit/services/tagging/camera_info.py

"""What a photo says about itself: its camera, lens, owner fields, date and GPS position.

Read once from the photo's EXIF and kept in its sidecar's "camera" block (and the GPS position in
"photoit.gps"), so tags, search and later features never have to open the photo again.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any

from PIL import ExifTags, Image

try:  # iPhone HEIC photos
    from pillow_heif import register_heif_opener

    register_heif_opener()
except ImportError:  # pragma: no cover - pillow-heif is in requirements
    pass

CAMERA_BLOCK = "camera"

# EXIF tag ids (main image IFD, then the Exif sub-IFD).
_MAIN = {"make": 271, "model": 272, "software": 305, "artist": 315, "copyright": 33432, "orientation": 274}
_EXIF = {"date_taken": 0x9003, "offset": 0x9011, "owner": 0xA430, "body_serial": 0xA431,
         "lens_make": 0xA433, "lens_model": 0xA434, "lens_serial": 0xA435}


def _text(value: Any) -> str | None:
    """Return a clean string from an EXIF value (bytes, padded text), or None when empty."""
    if value is None:
        return None
    if isinstance(value, bytes):
        value = value.decode("utf-8", "ignore")
    text = str(value).replace("\x00", " ").strip()
    return text or None


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def _degrees(dms: Any, ref: Any) -> float | None:
    """Return decimal degrees from EXIF (degrees, minutes, seconds) and N/S/E/W, or None."""
    try:
        d, m, s = (float(x) for x in dms)
    except (TypeError, ValueError, ZeroDivisionError):
        return None
    value = d + m / 60 + s / 3600
    if _text(ref) in ("S", "W"):
        value = -value
    return round(value, 6)


def read_gps(gps_ifd: dict) -> dict[str, float | None]:
    """Return latitude, longitude and altitude (metres) from an EXIF GPS IFD; missing parts are None."""
    lat = _degrees(gps_ifd.get(2), gps_ifd.get(1))
    lon = _degrees(gps_ifd.get(4), gps_ifd.get(3))
    if lat == 0 and lon == 0:                   # 0,0 is a camera with no fix, not the Gulf of Guinea
        lat = lon = None
    alt = _number(gps_ifd.get(6))
    if alt is not None and gps_ifd.get(5) in (1, b"\x01"):
        alt = -alt
    return {"latitude": lat, "longitude": lon, "altitude": round(alt, 1) if alt is not None else None}


def read_camera_info(path: Path) -> dict[str, Any] | None:
    """Return the photo's camera details and GPS position, or None when it can't be read at all."""
    from mindit.services.validateit.raw_files import cr3_size, open_picture  # pylint: disable=import-outside-toplevel

    try:
        with open_picture(path) as img:                   # a CR3 too: its preview, with its own EXIF
            width, height = cr3_size(path) or img.size
            exif = img.getexif()
            sub = exif.get_ifd(ExifTags.IFD.Exif) if exif else {}
            gps = exif.get_ifd(ExifTags.IFD.GPSInfo) if exif else {}
    except Exception:  # pylint: disable=broad-except
        return None
    info: dict[str, Any] = {name: _text(exif.get(tag)) for name, tag in _MAIN.items() if name != "orientation"}
    info.update({name: _text(sub.get(tag)) for name, tag in _EXIF.items()})
    info["orientation"] = exif.get(_MAIN["orientation"]) if exif else None
    info["width"], info["height"] = width, height
    info["gps"] = read_gps(gps) if gps else {"latitude": None, "longitude": None, "altitude": None}
    info["read_at"] = datetime.now().isoformat(timespec="seconds")
    return info


def record_camera_info(path: Path) -> dict[str, Any] | None:
    """Read the photo's camera details into its sidecar ("camera", and "photoit.gps"); return them."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    info = read_camera_info(path)
    if info is None:
        return None
    data = SidecarService.load(path)
    apply_camera_info(data, info)
    SidecarService.save(path, data)
    return info


def apply_camera_info(data: dict[str, Any], info: dict[str, Any]) -> None:
    """Put camera details into a loaded sidecar: the "camera" block, and the position in photoit.gps."""
    data[CAMERA_BLOCK] = info
    photoit = data.get("photoit") if isinstance(data.get("photoit"), dict) else {}
    if info["gps"]["latitude"] is not None:
        photoit["gps"] = info["gps"]
    data["photoit"] = photoit


_MAKERS = {"eastman": "Kodak", "hmd": "Nokia", "lg": "LG", "research": "BlackBerry"}


def maker_name(make: str | None) -> str | None:
    """Return the maker's short name: 'NIKON CORPORATION' -> 'Nikon', 'EASTMAN KODAK COMPANY' -> 'Kodak'."""
    if not make:
        return None
    first = make.split()[0].strip(",.").lower()
    return _MAKERS.get(first) or first.capitalize()


def camera_name(info: dict[str, Any]) -> str | None:
    """Return 'Apple iPhone 12 Pro' or 'Nikon D90' from make + model, without repeating the maker."""
    maker, model = maker_name(info.get("make")), info.get("model")
    if not model:
        return maker
    if maker and not model.lower().startswith(maker.lower()):
        return f"{maker} {model}"
    return model
