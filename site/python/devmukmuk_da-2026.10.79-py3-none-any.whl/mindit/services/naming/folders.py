# src/mindit/services/naming/folders.py

"""Where a filed file belongs: its kind's folder pattern (modules.<kind>.folder) rendered with its tokens.

The default, {YYYY}\\{YYYY}-{MM}, is the layout DA always used. Levels are split at '\\' (or '/'); a level
whose tokens are all empty is dropped. A photo in a location group goes in its location folder: in place of
the pattern's last level, or where the pattern puts {location}. A folder named like the expected one plus
more ("2019-04 Easter at grandma's" for "2019-04") is accepted, as location folders always were.
"""

from __future__ import annotations

import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.naming.tokens import missing_tokens, slug

DEFAULT_FOLDER = "{YYYY}\\{YYYY}-{MM}"
MODULES = {"photo": "photoit", "video": "video", "document": "scanit"}
_FORBIDDEN = re.compile(r'[<>:"/\\|?*\x00-\x1f]+')


def folder_pattern(kind: str, settings: Any | None = None) -> str:
    """Return a kind's folder pattern from da-archive.yaml (videos use the photos' unless they have one)."""
    from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

    modules = (settings or load_settings()).modules
    own = getattr(getattr(modules, MODULES[kind], None), "folder", None)
    if not own and kind == "video":
        own = getattr(modules.photoit, "folder", None)
    return own or DEFAULT_FOLDER


def location_folder(path: Path, metadata: dict[str, Any] | None) -> str:
    """Return the name of the location folder a photo was grouped into, or '' when it wasn't grouped."""
    block = (metadata or {}).get("location")
    if not isinstance(block, dict) or not block.get("group"):
        return ""
    if slug(path.parent.name) == block["group"]:
        return path.parent.name                         # it's in it now
    if block.get("folder"):
        return str(block["folder"])                     # the name it was given
    title = str(block.get("title") or "").strip()
    match = re.match(r"^(\d{4}-\d{2})", block["group"])
    return f"{match.group(1)} {title}".strip() if match and title else ""


def _level(text: str) -> str:
    text = _FORBIDDEN.sub(" ", text)                     # characters Windows won't have in a folder name
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\(\s*\)", "", text)
    return text.strip(" .-_")


def render_folder(pattern: str, context: dict[str, Any], location: str = "") -> tuple[list[str], list[str]]:
    """Return the folder levels for one file, and the tokens it had nothing for."""
    from mindit.services.photoit.photoit_workflows import _render_rename_pattern  # pylint: disable=import-outside-toplevel

    context = {**context, "location": location}
    if context.get("from_levels"):
        context["from"] = "\\".join(context["from_levels"])     # {from}: every level it came in from, as folders
    raw_levels = [lv for lv in re.split(r"[\\/]", pattern) if lv.strip()]
    missing = [t for t in missing_tokens(pattern, context) if t != "location"]
    levels = [_level(part) for lv in raw_levels for part in _render_rename_pattern(lv, context).split("\\")]
    if location and "{location}" not in pattern and levels:
        levels[-1] = _level(location)                   # a location folder takes the last level's place
    return [lv for lv in levels if lv], missing


def expected_folder(path: Path, root: Path, capture_dt: datetime, metadata: dict[str, Any] | None,
                    kind: str, *, pattern: str | None = None, sha256: str = "") -> tuple[Path, list[str]]:
    """Return the folder a file belongs in under root, and the folder tokens it had nothing for."""
    from mindit.services.naming.tokens import TOKEN, sidecar_tokens  # pylint: disable=import-outside-toplevel

    pattern = pattern or folder_pattern(kind)
    context: dict[str, Any] = sidecar_tokens(path, metadata or {}, capture_dt)
    used = {m.group(1).split(":", 1)[0].strip() for m in TOKEN.finditer(pattern)}
    if used - set(context) - {"location", "state", "country"}:   # {tag}, {gps_*}, {orig_*}...: the full set
        from mindit.services.photoit.photoit_workflows import _build_rename_context  # pylint: disable=import-outside-toplevel

        context = _build_rename_context(path, capture_dt, sha256, metadata or {})
    levels, missing = render_folder(pattern, context, location_folder(path, metadata))
    return root.joinpath(*levels) if levels else root, missing


def in_place(path: Path, expected: Path) -> bool:
    """Return True when path is in expected, or in a folder beside it named like it plus more."""
    here, there = os.path.normcase(os.path.abspath(path.parent)), os.path.normcase(os.path.abspath(expected))
    if here == there:
        return True
    if os.path.dirname(here) != os.path.dirname(there):
        return False
    name, base = os.path.basename(here), os.path.basename(there)
    return name.startswith(base + " ") or re.match(re.escape(base) + r"-\d\d( |$)", name) is not None
