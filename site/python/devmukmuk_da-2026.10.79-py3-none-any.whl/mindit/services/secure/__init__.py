"""Secure: documents that hold passwords, set aside for a vault."""
