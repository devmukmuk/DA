# src/mindit/services/workflow/archive_delete.py

"""`da archives delete`: delete an archive only when every file in it also exists somewhere else.

Every photo, video, document and raw file (organized, intake and holding) is looked for, by its SHA-256, in the
other archives on this PC and in any folders named with --also. A file is only hashed when something elsewhere
has the same size (a file with no same-sized file anywhere can't have a copy). A sample of the copies found is
re-read, to be sure they're still what their index says. Only when nothing would be lost does the whole folder
go to the Recycle Bin. Design: docs/da-docs/LIFECYCLE-DESIGN.md section 4.
"""

from __future__ import annotations

import csv
import os
import sqlite3
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

SAMPLE = 100                             # 1 in SAMPLE of the copies found are re-read (at least MIN_SAMPLE)
MIN_SAMPLE = 20
SKIP = {"_contact-sheet.pdf", "desktop.ini", "thumbs.db"}
REPORT_FIELDS = ["path", "size_bytes", "sha256", "copy"]


@dataclass
class Check:
    """What deleting an archive would lose."""

    archive: Path
    files: int = 0
    found: int = 0
    missing: list[Path] = field(default_factory=list)
    rows: list[dict[str, str]] = field(default_factory=list)
    sampled: int = 0
    sample_bad: int = 0
    gb: float = 0.0

    @property
    def safe(self) -> bool:
        """Return True when every file has a copy elsewhere (and the sampled copies are sound)."""
        return not self.missing and self.sample_bad == 0


def _sha256(path: Path) -> str | None:
    import hashlib  # pylint: disable=import-outside-toplevel

    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
                h.update(chunk)
    except OSError:
        return None
    return h.hexdigest()


def index_archive(root: Path, progress: Callable[[str], None] | None = None) -> Path:
    """Index an archive (its own areas, from its own da-archive.yaml) and return its database."""
    from mindit.services.dbit.archive_index_service import Area, ArchiveIndexService  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.merge import layout_of  # pylint: disable=import-outside-toplevel

    layout = layout_of(root)
    db_path = Path(root) / ".da" / "da.sqlite"
    db = DbitService(db_path)
    db.initialize(log=False)
    ArchiveIndexService(db).build([Area("photos", layout.photos), Area("documents", layout.documents),
                                   Area("intake", layout.intake), Area("holding", Path(root) / "_duplicates-holding")],
                                  progress=progress)
    return db_path


def _rows(db_path: Path) -> list[tuple[str, int, str | None]]:
    with sqlite3.connect(db_path) as conn:
        return [(p, s or 0, h) for p, s, h in conn.execute("SELECT path, size_bytes, sha256 FROM files")]


def _remember_hash(db_path: Path, path: str, sha: str) -> None:
    with sqlite3.connect(db_path) as conn:
        conn.execute("UPDATE files SET sha256 = ?, hash_status = 'computed' WHERE path = ?", (sha, path))


def _walk(folder: Path) -> Iterable[Path]:
    for dirpath, _dirs, files in os.walk(folder):
        for name in files:
            if not name.endswith(".meta.json") and name.lower() not in SKIP:
                yield Path(dirpath, name)


def check_delete(archive: Path, others: list[Path], also: list[Path] | None = None,
                 progress: Callable[[str], None] | None = None) -> Check:
    """Work out, file by file, whether `archive` can be deleted without losing anything."""
    say = progress or (lambda _m: None)
    check = Check(Path(archive))
    say(f"Indexing {Path(archive).name} ...")
    mine = index_archive(archive)
    items = [(Path(p), size, sha) for p, size, sha in _rows(mine)
             if not p.endswith(".meta.json") and Path(p).name.lower() not in SKIP and Path(p).exists()]
    check.files = len(items)
    check.gb = round(sum(size for _p, size, _h in items) / 1e9, 2)
    if not items:
        return check

    # Everything elsewhere, by size first: only same-sized files can be copies.
    elsewhere: dict[int, list[tuple[Path, str | None, Path | None]]] = defaultdict(list)   # size -> (path, sha, db)
    for other in others:
        say(f"Indexing {Path(other).name} (to look for copies there) ...")
        db_path = index_archive(other)
        for p, size, sha in _rows(db_path):
            if not p.endswith(".meta.json"):
                elsewhere[size].append((Path(p), sha, db_path))
    for folder in also or []:
        say(f"Looking through {folder} ...")
        for path in _walk(folder):
            try:
                elsewhere[path.stat().st_size].append((path, None, None))
            except OSError:
                continue

    hashes: dict[str, Path] = {}                              # sha -> a copy elsewhere
    pending: dict[int, list] = {}
    for i, (path, size, sha) in enumerate(items, 1):
        if progress and i % 2000 == 0:
            say(f"  {i:,} / {len(items):,} files checked")
        candidates = elsewhere.get(size, [])
        if not candidates:
            check.missing.append(path)
            check.rows.append(_row(path, size, sha, ""))
            continue
        sha = sha or _sha256(path)
        if sha is None:
            check.missing.append(path)
            check.rows.append(_row(path, size, "", "couldn't be read"))
            continue
        copy = hashes.get(sha) or _copy_with(sha, size, candidates, pending)
        if copy is None:
            check.missing.append(path)
            check.rows.append(_row(path, size, sha, ""))
            continue
        hashes[sha] = copy
        check.found += 1
        check.rows.append(_row(path, size, sha, str(copy)))

    # Re-read a sample of the copies: still there and still the same.
    found = [r for r in check.rows if r["copy"] and r["copy"] != "couldn't be read"]
    every = max(1, min(SAMPLE, len(found) // MIN_SAMPLE or 1))
    for row in found[::every]:
        check.sampled += 1
        if _sha256(Path(row["copy"])) != row["sha256"]:
            check.sample_bad += 1
            check.missing.append(Path(row["path"]))
            row["copy"] = f"copy changed: {row['copy']}"
    return check


def _copy_with(sha: str, size: int, candidates: list, pending: dict) -> Path | None:
    """Return a file among candidates (same size) whose hash is sha; hash the ones without a recorded hash."""
    for path, their_sha, _db in candidates:
        if their_sha == sha and path.exists():
            return path
    if size not in pending:                                  # hash the unhashed same-sized ones once
        computed = []
        for path, their_sha, db_path in candidates:
            if their_sha is None and path.exists():
                got = _sha256(path)
                if got and db_path is not None:
                    _remember_hash(db_path, str(path), got)
                computed.append((path, got))
        pending[size] = computed
    for path, got in pending[size]:
        if got == sha:
            return path
    return None


def _row(path: Path, size: int, sha: str | None, copy: str) -> dict[str, str]:
    return {"path": str(path), "size_bytes": str(size), "sha256": sha or "", "copy": copy}


def write_report(check: Check, path: Path) -> Path:
    """Write delete-check.csv: each file and where its copy is (blank: no copy)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=REPORT_FIELDS)
        writer.writeheader()
        writer.writerows(check.rows)
    return path


# --------------------------------------------------------------------------- the Recycle Bin

def drive_has_recycle_bin(folder: Path) -> bool:
    """Return True for a fixed local drive (removable and network drives have no Recycle Bin)."""
    if os.name != "nt":
        return False
    import ctypes  # pylint: disable=import-outside-toplevel

    drive = os.path.splitdrive(str(Path(folder).resolve()))[0] + "\\"
    return ctypes.windll.kernel32.GetDriveTypeW(drive) == 3         # DRIVE_FIXED


def to_recycle_bin(folder: Path) -> bool:
    """Send a folder to the Recycle Bin; Windows asks first if it would have to delete it for good.

    Returns True when the folder is gone.
    """
    return recycle([Path(folder)]) and not Path(folder).exists()


def recycle(paths: list[Path]) -> bool:
    """Send files or folders to the Recycle Bin in one go; Windows asks first if they'd have to be deleted for good.

    Returns True when Windows did it without being stopped (check which paths are gone for the detail).
    """
    import ctypes  # pylint: disable=import-outside-toplevel
    from ctypes import wintypes  # pylint: disable=import-outside-toplevel

    class SHFILEOPSTRUCTW(ctypes.Structure):  # pylint: disable=too-few-public-methods
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", ctypes.c_void_p),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_uint16), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]

    if not paths:
        return True
    names = "".join(str(Path(p).resolve()) + "\0" for p in paths) + "\0"      # each path ends in \0, the list in \0\0
    buffer = (ctypes.c_wchar * len(names))(*names)
    fo_delete, allow_undo, no_confirmation, want_nuke_warning = 3, 0x40, 0x10, 0x4000
    op = SHFILEOPSTRUCTW(None, fo_delete, ctypes.cast(buffer, ctypes.c_void_p), None,
                         allow_undo | no_confirmation | want_nuke_warning, False, None, None)
    result = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    return result == 0 and not op.fAnyOperationsAborted


def forget(folder: Path) -> bool:
    """Take an archive off this PC's list; return True when it was on it."""
    from mindit.config.archive import registry_path  # pylint: disable=import-outside-toplevel

    path = registry_path()
    if not path.exists():
        return False
    key = os.path.normcase(str(Path(folder).resolve()))
    lines = path.read_text(encoding="utf-8").splitlines()
    kept = [line for line in lines if line.strip() and os.path.normcase(str(Path(line.strip()).resolve())) != key]
    path.write_text("".join(f"{line}\n" for line in kept), encoding="utf-8")
    return len(kept) != len([line for line in lines if line.strip()])
