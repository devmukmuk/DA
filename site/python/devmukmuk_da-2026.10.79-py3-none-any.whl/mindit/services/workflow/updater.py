# src/mindit/services/workflow/updater.py

"""Find out whether a newer DA is out, and put the newest DA.exe in place.

The newest release is asked of GitHub (the public devmukmuk/DA repository: its tag and DA.exe's size and SHA-256).
The new DA.exe is downloaded, checked against both, and run once (`version`) before anything changes. Windows won't
overwrite a running program but will rename it, so the installed DA.exe is renamed DA.exe.old-<time> and the new
one put in its place; windows (and the dashboard) still running the old one keep it until they're restarted, and the
old file is deleted by the next update.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

LATEST_URL = "https://api.github.com/repos/devmukmuk/DA/releases/latest"
CHECK_EVERY = 24 * 3600                  # the menu looks at most once a day
TIMEOUT = 3                              # seconds the menu's look may take (no internet: no notice)


class UpdateError(Exception):
    """The update couldn't be done; nothing was changed."""


@dataclass
class Release:
    """The newest DA release: its version and its DA.exe."""

    version: str                         # "2026.10.51"
    exe_url: str
    exe_size: int
    exe_sha256: str | None


def version_tuple(text: str) -> tuple[int, ...]:
    """Return (2026, 10, 51) for 'v2026.10.51' (a -dev suffix counts as that version)."""
    return tuple(int(n) for n in re.findall(r"\d+", text.split("-")[0])[:3])


def newer(latest: str, current: str) -> bool:
    """Return True when latest is a later version than current."""
    return version_tuple(latest) > version_tuple(current)


def _user_agent() -> str:
    from mindit import __version__  # pylint: disable=import-outside-toplevel

    return f"DA/{__version__}"


def latest_release(timeout: float = 15, fetch: Callable[[str, float], bytes] | None = None) -> Release:
    """Ask GitHub for the newest release (raise UpdateError when it can't be had)."""
    def get(url: str, wait: float) -> bytes:
        request = urllib.request.Request(url, headers={"User-Agent": _user_agent(),
                                                       "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(request, timeout=wait) as answer:  # noqa: S310 (a fixed https URL)
            return answer.read()

    try:
        data = json.loads((fetch or get)(LATEST_URL, timeout))
    except Exception as exc:  # pylint: disable=broad-except
        raise UpdateError(f"couldn't ask GitHub for the newest DA ({type(exc).__name__}: {exc})") from None
    exe = next((a for a in data.get("assets", []) if a.get("name") == "DA.exe"), None)
    if not data.get("tag_name") or exe is None:
        raise UpdateError("GitHub's newest release has no DA.exe")
    digest = str(exe.get("digest") or "")
    return Release(version=str(data["tag_name"]).lstrip("v"), exe_url=str(exe["browser_download_url"]),
                   exe_size=int(exe.get("size") or 0), exe_sha256=digest[7:] if digest.startswith("sha256:") else None)


def download(release: Release, folder: Path, progress: Callable[[int, int], None] | None = None,
             opener: Callable[[str], object] | None = None) -> Path:
    """Download the release's DA.exe into folder and check its size and SHA-256; return it."""
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"DA-v{release.version}.exe"
    part = target.with_suffix(".part")
    request = urllib.request.Request(release.exe_url, headers={"User-Agent": _user_agent()})
    h, got = hashlib.sha256(), 0
    try:
        with (opener(release.exe_url) if opener else urllib.request.urlopen(request, timeout=60)) as answer, \
                part.open("wb") as out:  # noqa: S310
            while True:
                chunk = answer.read(1 << 20)
                if not chunk:
                    break
                out.write(chunk)
                h.update(chunk)
                got += len(chunk)
                if progress:
                    progress(got, release.exe_size)
    except Exception as exc:  # pylint: disable=broad-except
        part.unlink(missing_ok=True)
        raise UpdateError(f"the download stopped ({type(exc).__name__}: {exc})") from None
    if release.exe_size and got != release.exe_size:
        part.unlink(missing_ok=True)
        raise UpdateError(f"the download is {got:,} bytes, GitHub says {release.exe_size:,}")
    if release.exe_sha256 and h.hexdigest() != release.exe_sha256:
        part.unlink(missing_ok=True)
        raise UpdateError("the download's fingerprint doesn't match GitHub's")
    os.replace(part, target)
    return target


def check_runs(exe: Path, version: str) -> None:
    """Run the new DA.exe once (`version`); raise UpdateError unless it starts and says the right version."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        done = subprocess.run([str(exe), "version"], capture_output=True, text=True, timeout=120,
                              creationflags=flags, check=False)
    except OSError as exc:
        raise UpdateError(f"Windows wouldn't run the new DA.exe ({exc}); Smart App Control? Then install DA with "
                          "Python instead (see the guide)") from None
    if version not in (done.stdout or "") + (done.stderr or ""):
        raise UpdateError(f"the new DA.exe didn't start as expected: {(done.stdout or done.stderr or '').strip()[:200]}")


def put_in_place(new: Path, installed: Path) -> Path | None:
    """Rename the installed DA.exe aside (a running one can be renamed) and move the new one in; return the old."""
    clean_old(installed.parent)
    old = None
    if installed.exists():
        old = installed.with_name(f"{installed.name}.old-{time.strftime('%Y%m%d-%H%M%S')}")
        os.replace(installed, old)
    try:
        os.replace(new, installed)
    except OSError:
        if old is not None:
            os.replace(old, installed)                   # put the old one back: nothing changed
        raise
    return old


def clean_old(folder: Path) -> int:
    """Delete DA.exe.old-* copies left by earlier updates (one still running stays until next time)."""
    gone = 0
    for path in folder.glob("DA.exe.old-*"):
        try:
            path.unlink()
            gone += 1
        except OSError:
            pass
    return gone


# --------------------------------------------------------------------------- the menu's notice

def notice(state: Path, current: str, fetch: Callable[[str, float], bytes] | None = None) -> str | None:
    """Return 'DA v… is out' when a newer release exists; asks GitHub at most once a day, never for long."""
    try:
        saved = json.loads(state.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        saved = {}
    if time.time() - float(saved.get("checked", 0)) > CHECK_EVERY:
        try:
            saved = {"checked": time.time(), "latest": latest_release(TIMEOUT, fetch).version}
        except UpdateError:
            saved = {"checked": time.time(), "latest": saved.get("latest", "")}
        try:
            state.parent.mkdir(parents=True, exist_ok=True)
            state.write_text(json.dumps(saved), encoding="utf-8")
        except OSError:
            pass
    latest = str(saved.get("latest") or "")
    return f"DA v{latest} is out (you have v{current}): da update" if latest and newer(latest, current) else None
