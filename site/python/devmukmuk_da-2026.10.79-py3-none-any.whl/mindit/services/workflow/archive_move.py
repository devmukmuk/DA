# src/mindit/services/workflow/archive_move.py

"""`da archives move <archive> <new place>`: move a whole archive, and keep everything that points into it working.

On one drive it's a folder rename. To another drive everything is copied (the index, logs, run records and
holding folder too), and every file is checked to have arrived: size and date for all, the full contents for a
sample (all with --full). Then the old place is replaced by the new one wherever DA wrote it down: the index rows,
the undo logs and run records in output\\runs (so `da intake undo` still works), and this PC's list of archives.
The old copy is sent to the Recycle Bin when asked, or else retired (its da-archive.yaml renamed, a note left), so
nobody files into it by mistake. Design: docs/da-docs/LIFECYCLE-DESIGN.md section 3.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

SAMPLE = 100                             # 1 in SAMPLE files is re-read in full (at least MIN_SAMPLE)
MIN_SAMPLE = 20
RETIRED = "da-archive.yaml.moved"


class MoveError(Exception):
    """The archive can't be moved there (nothing was changed)."""


@dataclass
class Copied:
    """What the copy check found."""

    files: int = 0
    bytes: int = 0
    rehashed: int = 0
    problems: list[str] = field(default_factory=list)


def _norm(path: Path | str) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def same_drive(a: Path, b: Path) -> bool:
    """Return True when both are on the same drive (a rename moves the folder)."""
    return os.path.splitdrive(_norm(a))[0] == os.path.splitdrive(_norm(b))[0]


def size_of(folder: Path) -> tuple[int, int]:
    """Return (files, bytes) under folder."""
    files = total = 0
    for dirpath, _dirs, names in os.walk(folder):
        for name in names:
            try:
                total += os.path.getsize(os.path.join(dirpath, name))
                files += 1
            except OSError:
                continue
    return files, total


def check_move(old: Path, new: Path, *, copy: bool) -> tuple[int, int]:
    """Raise MoveError unless old can move to new; return (files, bytes) to move."""
    if not (old / "da-archive.yaml").exists():
        raise MoveError(f"{old} isn't an archive (no da-archive.yaml).")
    if _norm(new) == _norm(old) or _norm(new).startswith(_norm(old) + os.sep):
        raise MoveError("The new place can't be the archive itself, or inside it.")
    if new.exists() and (not new.is_dir() or any(new.iterdir())):
        raise MoveError(f"{new} isn't empty. Give a new folder (DA makes it), or an empty one.")
    if not new.parent.exists():
        raise MoveError(f"{new.parent} doesn't exist.")
    files, total = size_of(old)
    if copy or not same_drive(old, new):
        free = shutil.disk_usage(new.parent).free
        if free < total * 1.02 + 200_000_000:
            raise MoveError(f"{new.parent} has {free / 1e9:,.1f} GB free; the archive needs {total / 1e9:,.1f} GB.")
    return files, total


def copy_archive(old: Path, new: Path, progress: Callable[[int, int], None] | None = None) -> list[str]:
    """Copy every file of old into new (dates kept); return the files that failed."""
    failed: list[str] = []
    done = 0
    for dirpath, dirnames, names in os.walk(old):
        rel = os.path.relpath(dirpath, old)
        target = new if rel == "." else new / rel
        target.mkdir(parents=True, exist_ok=True)
        for name in names:
            try:
                shutil.copy2(os.path.join(dirpath, name), target / name)
            except OSError as error:
                failed.append(f"{os.path.join(dirpath, name)}: {error}")
            done += 1
            if progress:
                progress(done, 0)
        dirnames.sort()
    return failed


def _sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_copy(old: Path, new: Path, *, full: bool = False,
                progress: Callable[[int, int], None] | None = None) -> Copied:
    """Check every file of old is in new with the same size and date; re-read a sample (or all) in full."""
    result = Copied()
    paths = [Path(d, n) for d, _dirs, names in os.walk(old) for n in names]
    every = 1 if full else max(1, min(SAMPLE, len(paths) // MIN_SAMPLE or 1))
    for i, src in enumerate(paths):
        dst = new / src.relative_to(old)
        result.files += 1
        if progress and i % 1000 == 0:
            progress(i, len(paths))
        try:
            a, b = src.stat(), dst.stat()
        except OSError:
            result.problems.append(f"missing: {dst}")
            continue
        result.bytes += a.st_size
        if a.st_size != b.st_size or abs(a.st_mtime - b.st_mtime) > 2:
            result.problems.append(f"size or date differ: {dst}")
            continue
        if i % every == 0:
            result.rehashed += 1
            if _sha(src) != _sha(dst):
                result.problems.append(f"contents differ: {dst}")
    return result


# --------------------------------------------------------------------------- the old place, written down

def _swap(text: str, old: str, new: str) -> str:
    """Return text with a leading old root replaced by new (case-insensitive, whole folder names only)."""
    if os.path.normcase(text[:len(old)]) == os.path.normcase(old) and (len(text) == len(old) or text[len(old)] in "\\/"):
        return new + text[len(old):]
    return text


def rewrite_index(db_path: Path, old: Path, new: Path) -> int:
    """Point the index rows at the new place; return how many rows changed."""
    if not db_path.exists():
        return 0
    o, n = str(old), str(new)
    changed = 0
    with sqlite3.connect(db_path) as conn:
        rows = conn.execute("SELECT rowid, path, sidecar_path FROM files").fetchall()
        updates = []
        for rowid, path, side in rows:
            new_path, new_side = _swap(path or "", o, n), _swap(side or "", o, n) if side else side
            if new_path != path or new_side != side:
                updates.append((new_path, new_side, rowid))
        conn.executemany("UPDATE files SET path = ?, sidecar_path = ? WHERE rowid = ?", updates)
        changed = len(updates)
    return changed


def rewrite_runs(output_root: Path, old: Path, new: Path) -> int:
    """Point the undo logs (CSV) and run records (JSON) in output\\runs at the new place; return files changed."""
    o, n = str(old), str(new)
    changed = 0
    runs = output_root / "runs"
    if not runs.is_dir():
        return 0
    for path in runs.rglob("*"):
        if path.suffix.lower() == ".csv":
            text = path.read_text(encoding="utf-8-sig", errors="replace")
            bom = path.read_bytes()[:3] == b"\xef\xbb\xbf"
            rows = list(csv.reader(text.splitlines()))
            new_rows = [[_swap(cell, o, n) for cell in row] for row in rows]
            if new_rows != rows:
                with path.open("w", newline="", encoding="utf-8-sig" if bom else "utf-8") as f:
                    csv.writer(f).writerows(new_rows)
                changed += 1
        elif path.suffix.lower() == ".json":
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            swapped = _swap_json(data, o, n)
            if swapped != data:
                path.write_text(json.dumps(swapped, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                changed += 1
    return changed


def _swap_json(value, old: str, new: str):
    if isinstance(value, str):
        return _swap(value, old, new)
    if isinstance(value, list):
        return [_swap_json(v, old, new) for v in value]
    if isinstance(value, dict):
        return {k: _swap_json(v, old, new) for k, v in value.items()}
    return value


def rewrite_registry(old: Path, new: Path) -> None:
    """Replace the old place with the new one in this PC's list of archives."""
    from mindit.config.archive import register_archive, registry_path  # pylint: disable=import-outside-toplevel

    path = registry_path()
    if path.exists():
        lines = [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        lines = [str(new) if _norm(line) == _norm(old) else line for line in lines]
        path.write_text("".join(f"{line}\n" for line in lines), encoding="utf-8")
    register_archive(new)


def retire(old: Path, new: Path) -> None:
    """Leave the old copy where it is but no longer an archive: rename its da-archive.yaml, leave a note."""
    os.replace(old / "da-archive.yaml", old / RETIRED)
    (old / "MOVED.txt").write_text(f"This archive moved to {new} on {datetime.now():%Y-%m-%d %H:%M}.\n"
                                   f"This folder is the old copy; it's no longer an archive. Delete it when you're "
                                   f"sure the new one is fine.\n", encoding="utf-8")


def move_archive(old: Path, new: Path, *, copy: bool = False, full: bool = False,
                 say: Callable[[str], None] | None = None) -> dict:
    """Move the archive; return a record of what was done (raise MoveError before anything changed)."""
    say = say or (lambda _m: None)
    old, new = Path(old).resolve(), Path(new).resolve()
    files, total = check_move(old, new, copy=copy)
    record: dict = {"from": str(old), "to": str(new), "files": files, "gb": round(total / 1e9, 2),
                    "started_at": datetime.now().isoformat(timespec="seconds")}
    (old / ".da" / "dashboard.json").unlink(missing_ok=True)
    if not copy and same_drive(old, new):
        say(f"Moving the folder (one rename on {os.path.splitdrive(str(old))[0]}) ...")
        if new.exists():
            new.rmdir()
        os.rename(old, new)
        record["how"] = "renamed"
    else:
        say(f"Copying {files:,} files ({total / 1e9:,.1f} GB) to {new} ...")
        failed = copy_archive(old, new, progress=lambda i, _n: i % 2000 == 0 and say(f"  {i:,} / {files:,} copied"))
        if failed:
            raise MoveError(f"{len(failed):,} files couldn't be copied (the archive is where it was): {failed[0]}")
        say("Checking the copy (every file's size and date; a sample re-read in full) ..." if not full else
            "Checking the copy (every file re-read in full) ...")
        checked = verify_copy(old, new, full=full,
                              progress=lambda i, n: i and i % 5000 == 0 and say(f"  {i:,} / {n:,} checked"))
        record["check"] = {"files": checked.files, "rehashed": checked.rehashed, "problems": checked.problems[:20]}
        if checked.problems:
            raise MoveError(f"The copy at {new} isn't right ({len(checked.problems):,} problems, e.g. "
                            f"{checked.problems[0]}). The archive is where it was; the copy is left for you to look at.")
        record["how"] = "copied"
    say("Pointing DA's records at the new place ...")
    record["index_rows"] = rewrite_index(new / ".da" / "da.sqlite", old, new)
    record["run_files"] = rewrite_runs(new / "output", old, new)
    rewrite_registry(old, new)
    record["finished_at"] = datetime.now().isoformat(timespec="seconds")
    runs = new / "output" / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-move"
    runs.mkdir(parents=True, exist_ok=True)
    (runs / "move.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    return record

