"""Share: simple contact sheets emailed from your own Gmail."""
