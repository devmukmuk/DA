# src/mindit/services/share/gmail.py

"""Send email from your own Gmail (the Gmail API, permission to send only).

You make a Google Cloud OAuth client once (a desktop app, Gmail API on) and save its file as
%LOCALAPPDATA%\\DA\\google-client.json; `da share --setup` signs you in once in the browser and keeps the token
in %LOCALAPPDATA%\\DA\\google-token.json. Nothing about Google is ever kept in an archive.
"""

from __future__ import annotations

import base64
from email.message import EmailMessage
from pathlib import Path
from typing import Any

SCOPES = ["https://www.googleapis.com/auth/gmail.send"]


class ShareSetupError(Exception):
    """Sending can't work yet: what to do is in the message."""


def config_dir() -> Path:
    """Return %LOCALAPPDATA%\\DA (where the client file and the token live)."""
    from mindit.config.archive import registry_path  # pylint: disable=import-outside-toplevel

    return registry_path().parent


def client_file() -> Path:
    """Return where the Google OAuth client file is expected."""
    return config_dir() / "google-client.json"


def token_file() -> Path:
    """Return where the sign-in token is kept."""
    return config_dir() / "google-token.json"


def credentials(interactive: bool) -> Any:
    """Return signed-in credentials; sign in with the browser when interactive and there's no usable token."""
    try:
        from google.auth.transport.requests import Request  # pylint: disable=import-outside-toplevel
        from google.oauth2.credentials import Credentials  # pylint: disable=import-outside-toplevel
        from google_auth_oauthlib.flow import InstalledAppFlow  # pylint: disable=import-outside-toplevel
    except ImportError:
        raise ShareSetupError("Google's sign-in isn't installed with this DA. DA installed with Python: "
                              "pip install \"devmukmuk-da[google]\"") from None
    creds = None
    if token_file().exists():
        try:
            creds = Credentials.from_authorized_user_file(str(token_file()), SCOPES)
        except (ValueError, OSError):
            creds = None
    if creds and creds.valid:
        return creds
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            _save(creds)
            return creds
        except Exception:  # pylint: disable=broad-except
            creds = None
    if not interactive:
        raise ShareSetupError("Not signed in to Gmail yet (or the sign-in ran out): run  da share --setup")
    if not client_file().exists():
        raise ShareSetupError(f"No Google client file at {client_file()}. See 'Set up sharing' in the guide "
                              "(da guide), then run da share --setup again.")
    flow = InstalledAppFlow.from_client_secrets_file(str(client_file()), SCOPES)
    creds = flow.run_local_server(port=0, open_browser=True)
    _save(creds)
    return creds


def _save(creds: Any) -> None:
    token_file().parent.mkdir(parents=True, exist_ok=True)
    token_file().write_text(creds.to_json(), encoding="utf-8")


def message(to: str, subject: str, body: str, attachments: list[tuple[str, bytes, str]]) -> EmailMessage:
    """Return an email to one person (each gets their own, so nobody sees anyone else's address)."""
    msg = EmailMessage()
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    for name, data, kind in attachments:
        main, sub = kind.split("/", 1)
        msg.add_attachment(data, maintype=main, subtype=sub, filename=name)
    return msg


SEND_URL = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"


def send_each(recipients: list[str], subject: str, body: str, attachments: list[tuple[str, bytes, str]],
              creds: Any = None, service: Any = None) -> int:
    """Send the email to each person separately (Gmail refuses an undisclosed-recipients To line); return how many.

    If one fails, say who already got it, so a second try doesn't surprise them.
    """
    sent: list[str] = []
    for person in recipients:
        try:
            send(message(person, subject, body, attachments), creds, service)
        except ShareSetupError as exc:
            already = f" (already sent to {len(sent)} of {len(recipients)})" if sent else ""
            raise ShareSetupError(f"{exc}{already}") from None
        sent.append(person)
    return len(sent)


def send(msg: EmailMessage, creds: Any = None, service: Any = None) -> str:
    """Send through the Gmail API as you; return the message id.

    A plain HTTPS call with the sign-in (no Google API client and its bundled API descriptions, which a
    Python install can lack: "UnknownApiNameOrVersion: name: gmail version: v1").
    """
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode("ascii")
    if service is not None:                                   # tests hand in a stand-in
        return str(service.users().messages().send(userId="me", body={"raw": raw}).execute().get("id", ""))
    from google.auth.transport.requests import AuthorizedSession  # pylint: disable=import-outside-toplevel

    answer = AuthorizedSession(creds).post(SEND_URL, json={"raw": raw}, timeout=120)
    if answer.status_code >= 400:
        try:
            why = answer.json().get("error", {}).get("message") or answer.text
        except ValueError:
            why = answer.text
        raise ShareSetupError(f"Gmail didn't send it ({answer.status_code}): {why[:300]}")
    return str(answer.json().get("id", ""))
