"""Bursts (shots of the same thing taken one after another) and blurry photos - marked, never moved (decided 2026-10-19).

A burst: the same camera, each shot within 2 minutes of the one before, and alike - fingerprints within 64 bits and
pixels within 35 (or pixels within 15 alone). Tried on a 4,000-photo archive: 74 bursts of 163 photos, nearly all pairs,
the biggest a 10-frame beach session. Its sharpest shot is its `best`.
Blurry: the sharpest parts of the photo (the 3 sharpest of 16 tiles, Laplacian variance at 640 px) under a fifth of
what is typical for that camera (its median, from 20 photos or more): out-of-focus and accidental shots, not foggy or
plain ones that have a sharp part.
"""

from __future__ import annotations

import statistics
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit.services.similar.fingerprints import PICTURE_EXTENSIONS, Print, _Groups, connect, distance, ensure, pixel_difference

BURST_SECONDS = 120
BURST_BITS = 64
BURST_PIXELS = 35.0
BURST_PIXELS_ALONE = 15.0
BLURRY = 0.2                       # under a fifth of the camera's typical sharpness
CAMERA_PHOTOS = 20                 # a camera needs this many photos to know what's typical
SERIES_BLOCK, QUALITY_BLOCK = "similar", "quality"


def sharpness(path: Path) -> float | None:
    """Return how sharp the sharpest parts of a photo are (the mean of its 3 sharpest tiles of 16), or None."""
    import numpy as np  # pylint: disable=import-outside-toplevel
    from PIL import Image, ImageFilter, ImageOps  # pylint: disable=import-outside-toplevel

    laplace = ImageFilter.Kernel((3, 3), [0, 1, 0, 1, -4, 1, 0, 1, 0], 1, 128)
    try:
        with Image.open(path) as img:
            if img.format == "JPEG":
                img.draft("L", (1024, 1024))
            img = ImageOps.exif_transpose(img).convert("L")
            img.thumbnail((640, 640))
            a = np.asarray(img.filter(ImageFilter.GaussianBlur(0.6)).filter(laplace), dtype=np.float32) - 128
        h, w = a.shape
        th, tw = h // 4, w // 4
        if th < 8 or tw < 8:
            return None
        tiles = sorted(float(a[i * th:(i + 1) * th, j * tw:(j + 1) * tw].var()) for i in range(4) for j in range(4))
        return float(sum(tiles[-3:]) / 3)
    except Exception:  # pylint: disable=broad-except
        return None


def ensure_sharpness(db_path: Path, files: dict[str, str], progress: Callable[[int, int], None] | None = None,
                     workers: int = 6) -> dict[str, float]:
    """Return the sharpness of each sha256 -> path, working out (in threads) and keeping the ones not known yet."""
    with connect(db_path) as conn:
        known = {s: v for s, v in conn.execute("SELECT sha256, sharpness FROM pictures WHERE sharpness IS NOT NULL")}
    todo = [(s, p) for s, p in files.items() if s not in known]
    if todo:
        with ThreadPoolExecutor(max_workers=workers) as pool, connect(db_path) as conn:
            for i, ((sha, _p), value) in enumerate(zip(todo, pool.map(lambda item: sharpness(Path(item[1])), todo)), 1):
                if value is not None:
                    known[sha] = value
                    conn.execute("UPDATE pictures SET sharpness = ? WHERE sha256 = ?", (value, sha))
                if progress and (i % 200 == 0 or i == len(todo)):
                    progress(i, len(todo))
    return {s: known[s] for s in files if s in known}


def _when(taken: str) -> datetime | None:
    try:
        return datetime.strptime(taken[:19], "%Y:%m:%d %H:%M:%S")
    except ValueError:
        return None


def bursts(rows: list[dict[str, Any]], prints: dict[str, Print],
           pixels: Callable[[Path, Path], float | None] = pixel_difference) -> list[list[dict[str, Any]]]:
    """Return the bursts among filed photos: each a list of rows in the order they were taken."""
    by_sha = {r["sha256"]: r for r in rows if r["sha256"] in prints}
    timed = sorted((prints[s].camera, _when(prints[s].taken), s) for s in by_sha
                   if prints[s].camera and prints[s].taken and _when(prints[s].taken))
    joined = _Groups(by_sha)
    for (cam_a, at_a, a), (cam_b, at_b, b) in zip(timed, timed[1:]):
        if cam_a != cam_b or not 0 < (at_b - at_a).total_seconds() <= BURST_SECONDS:
            continue
        bits = distance(prints[a].fingerprint, prints[b].fingerprint)
        if bits > 128:
            continue                                   # nothing alike at all: don't even open them
        diff = pixels(Path(by_sha[a]["path"]), Path(by_sha[b]["path"]))
        if diff is not None and ((bits <= BURST_BITS and diff <= BURST_PIXELS) or diff <= BURST_PIXELS_ALONE):
            joined.join(a, b)
    order = {s: i for i, (_c, _t, s) in enumerate(timed)}
    return [[by_sha[s] for s in sorted(g, key=order.get)] for g in joined.groups()]


def blurry(sharp: dict[str, float], prints: dict[str, Print]) -> dict[str, dict[str, float]]:
    """Return the blurry photos (sha256 -> sharpness, typical, ratio): far softer than their camera's typical photo."""
    by_camera: dict[str, list[str]] = defaultdict(list)
    for sha, value in sharp.items():
        if sha in prints and prints[sha].camera:
            by_camera[prints[sha].camera].append(sha)
    out = {}
    for shas in by_camera.values():
        if len(shas) < CAMERA_PHOTOS:
            continue
        typical = statistics.median(sharp[s] for s in shas)
        for sha in shas:
            if typical and sharp[sha] < BLURRY * typical:
                out[sha] = {"sharpness": round(sharp[sha], 1), "typical": round(typical, 1),
                            "ratio": round(sharp[sha] / typical, 3)}
    return out


def plan(db: Any, progress: Callable[[str], None] | None = None) -> tuple[list[list[dict[str, Any]]], dict[str, Any],
                                                                          dict[str, float]]:
    """Return (bursts, blurry photos by sha256, sharpness by sha256) among the filed photos."""
    db.initialize(log=False)
    with db.connect() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT path, sha256, area FROM files WHERE area = 'photos' AND sha256 IS NOT NULL")]
    rows = [r for r in rows if Path(r["path"]).suffix.lower() in PICTURE_EXTENSIONS]
    prints = ensure(db.db_path, [(r["path"], r["sha256"]) for r in rows],
                    progress=(lambda d, n: progress(f"fingerprints: {d:,} of {n:,} new")) if progress else None)
    sharp = ensure_sharpness(db.db_path, {r["sha256"]: r["path"] for r in rows if r["sha256"] in prints},
                             progress=(lambda d, n: progress(f"sharpness: {d:,} of {n:,} new")) if progress else None)
    found = bursts(rows, prints, pixels=_remembered(db.db_path, {r["path"]: r["sha256"] for r in rows}))
    for group in found:
        best = max(group, key=lambda r: sharp.get(r["sha256"], 0.0))
        for i, r in enumerate(group, 1):
            r["position"], r["of"], r["best"], r["best_sha256"] = i, len(group), r is best, best["sha256"]
            r["best_name"] = Path(best["path"]).name
    soft = blurry(sharp, prints)
    paths = {r["sha256"]: r["path"] for r in rows}
    return found, {s: {**v, "path": paths[s]} for s, v in soft.items()}, sharp


def _remembered(db_path: Path, shas: dict[str, str]) -> Callable[[Path, Path], float | None]:
    """Return pixel_difference that keeps its answers in the index (by both pictures' SHA-256), so a rerun is quick."""
    with connect(db_path) as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS pixel_pairs (a TEXT, b TEXT, diff REAL, PRIMARY KEY (a, b))")
        known = {(a, b): d for a, b, d in conn.execute("SELECT a, b, diff FROM pixel_pairs")}

    def pixels(x: Path, y: Path) -> float | None:
        a, b = sorted((shas.get(str(x), str(x)), shas.get(str(y), str(y))))
        if (a, b) not in known:
            known[(a, b)] = pixel_difference(x, y)
            with connect(db_path) as conn:
                conn.execute("INSERT OR REPLACE INTO pixel_pairs VALUES (?, ?, ?)", (a, b, known[(a, b)]))
        return known[(a, b)]
    return pixels


def series_tags(sidecar: dict[str, Any]) -> list[str]:
    """Return the automatic tags a sidecar's burst / quality blocks give (`da tag` keeps them)."""
    tags = []
    burst = sidecar.get(SERIES_BLOCK)
    if isinstance(burst, dict) and burst.get("of"):
        tags.append("burst")
        if burst.get("best"):
            tags.append("burst:best")
    quality = sidecar.get(QUALITY_BLOCK)
    if isinstance(quality, dict) and quality.get("blurry"):
        tags.append("blurry")
    return tags


def write(groups: list[list[dict[str, Any]]], soft: dict[str, Any], db_path: Path) -> dict[str, str]:
    """Mark each burst and blurry photo in its sidecar (and take old marks off); return index tag changes."""
    import json  # pylint: disable=import-outside-toplevel
    import sqlite3  # pylint: disable=import-outside-toplevel

    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import AUTO_BLOCK, all_tags  # pylint: disable=import-outside-toplevel

    now = datetime.now().isoformat(timespec="seconds")
    marks: dict[str, dict[str, Any]] = {}
    for group in groups:
        for r in group:
            marks.setdefault(r["path"], {})[SERIES_BLOCK] = {
                "group": group[0]["sha256"][:12], "position": r["position"], "of": r["of"], "best": r["best"],
                "best_sha256": r["best_sha256"], "best_name": r["best_name"], "found_at": now}
    for sha, info in soft.items():
        marks.setdefault(info["path"], {})[QUALITY_BLOCK] = {
            "blurry": True, "sharpness": info["sharpness"], "camera_typical": info["typical"], "ratio": info["ratio"],
            "found_at": now}
    with sqlite3.connect(db_path) as conn:                       # photos marked before that aren't any more
        before = [p for (p,) in conn.execute("SELECT path FROM files WHERE area = 'photos' AND (tags LIKE '%\"burst%' "
                                             "OR tags LIKE '%\"blurry\"%')")]
    changed = {}
    for path in set(marks) | set(before):
        photo = Path(path)
        if not photo.exists() or not Path(f"{photo}.meta.json").exists():
            continue
        data = SidecarService.load(photo)
        new = marks.get(path, {})
        dirty = False
        for block in (SERIES_BLOCK, QUALITY_BLOCK):
            old = data.get(block) if isinstance(data.get(block), dict) else None
            if block in new:
                if not old or {k: v for k, v in old.items() if k != "found_at"} != \
                        {k: v for k, v in new[block].items() if k != "found_at"}:
                    data[block] = new[block]
                    dirty = True
            elif old is not None:
                del data[block]
                dirty = True
        auto = data.get(AUTO_BLOCK) if isinstance(data.get(AUTO_BLOCK), dict) else {}
        kept = [t for t in auto.get("tags") or [] if t not in ("burst", "burst:best", "blurry")]
        tags = kept + series_tags(data)
        if tags != (auto.get("tags") or []):
            auto["tags"] = tags
            data[AUTO_BLOCK] = auto
            dirty = True
        if dirty:
            SidecarService.save(photo, data)
            changed[path] = json.dumps(all_tags(data))
    return changed
