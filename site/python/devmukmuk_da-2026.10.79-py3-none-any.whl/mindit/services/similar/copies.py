"""The copies of a photo DA set aside (exact, resized, re-saved) and its other versions still filed (edited, cropped)."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any

from mindit.services.similar.resized import kept_of


def _key(path: Any) -> str:
    return os.path.normcase(str(Path(path).resolve()))


def noted_copies(db_path: Path) -> dict[str, list[dict[str, Any]]]:
    """Return the resized and re-saved copies still in holding, by the kept photo where it is now (its key)."""
    out: dict[str, list[dict[str, Any]]] = {}
    if not Path(db_path).exists():
        return out
    from mindit.services.history.events import connect, follow  # pylint: disable=import-outside-toplevel

    with connect(db_path) as conn:
        try:
            rows = conn.execute("SELECT destination, note, sha256 FROM events WHERE (note LIKE 'a resized copy of %' "
                                "OR note LIKE 'a re-saved copy of %') AND undone_at IS NULL").fetchall()
        except sqlite3.Error:
            return out
        for destination, note, sha in rows:
            if not destination or not Path(destination).is_file():
                continue
            kind = "resized copy" if note.startswith("a resized") else "re-saved copy"
            out.setdefault(_key(follow(conn, kept_of(note) or "")), []).append(
                {"kind": kind, "path": Path(destination), "size_bytes": Path(destination).stat().st_size,
                 "sha256": sha or "", "pixels": _pixels(destination)})
    return out


def other_versions(photo: Path, db_path: Path) -> list[dict[str, Any]]:
    """Return the photo's other versions still filed (from its sidecar's `versions` block, found by SHA-256)."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.similar.versions import VERSIONS_BLOCK, describe  # pylint: disable=import-outside-toplevel

    if not Path(f"{photo}.meta.json").exists() or not Path(db_path).exists():
        return []
    block = SidecarService.load(photo).get(VERSIONS_BLOCK)
    if not isinstance(block, dict) or not block.get("others"):
        return []
    out = []
    with sqlite3.connect(db_path) as conn:
        for other in block["others"]:
            row = conn.execute("SELECT path FROM files WHERE sha256 = ? AND area = 'photos' LIMIT 1",
                               (other.get("sha256"),)).fetchone()
            if row and Path(row[0]).is_file():
                out.append({"kind": describe(block.get("role", ""), other), "path": Path(row[0]),
                            "size_bytes": Path(row[0]).stat().st_size, "pixels": other.get("size", ""),
                            "filed": True})
    return out


def copies_of(pictures: list[tuple[Path, str]], data_root: Path, db_path: Path) -> dict[str, list[dict[str, Any]]]:
    """Return, for each (photo, sha256): its copies in _duplicates-holding still there, then its other versions."""
    from mindit.services.contactsheet.contact_sheet import held_copies  # pylint: disable=import-outside-toplevel

    wanted = {_key(p): (p, sha) for p, sha in pictures}
    out: dict[str, list[dict[str, Any]]] = {k: [] for k in wanted}
    holding = data_root / "_duplicates-holding"
    if holding.is_dir():
        held = held_copies(holding)
        for k, (_photo, sha) in wanted.items():
            for copy in held.get(sha, []) if sha else []:
                if _key(copy.path) != k:
                    out[k].append({"kind": "exact copy", "path": copy.path, "size_bytes": copy.size_bytes})
        for k, copies in noted_copies(db_path).items():
            if k in out:
                out[k] += copies
    for k, (photo, _sha) in wanted.items():
        out[k] += other_versions(Path(photo), db_path)
    return out


def _pixels(path: Any) -> str:
    try:
        from PIL import Image  # pylint: disable=import-outside-toplevel

        with Image.open(path) as img:
            return f"{img.width} x {img.height}"
    except Exception:  # pylint: disable=broad-except
        return ""


def describe(copy: dict[str, Any]) -> str:
    """Return 'resized copy in holding (800 x 600)', 'exact copy in holding' or 'cropped version - also filed'."""
    if copy.get("filed"):
        return f"{copy['kind']} - also filed" + (f" ({copy['pixels']})" if copy.get("pixels") else "")
    return f"{copy['kind']} in holding" + (f" ({copy['pixels']})" if copy.get("pixels") else "")
