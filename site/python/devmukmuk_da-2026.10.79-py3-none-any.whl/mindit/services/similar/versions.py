"""Link the versions of one picture that all stay filed: an original and its edited or cropped copies (decided 2026-10-19).

Each version's sidecar gets a `versions` block: its role (original / edited / cropped) and the others by SHA-256 (a
rename or move doesn't break the link), name, role, size and the software that saved them. Nothing is moved.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from mindit.services.similar.fingerprints import PICTURE_EXTENSIONS, ensure, versions

VERSIONS_BLOCK = "versions"


def plan_versions(db: Any, progress: Callable[[str], None] | None = None) -> list[list[dict[str, Any]]]:
    """Return the groups of versions among the filed photos (fingerprints worked out first where missing)."""
    db.initialize(log=False)
    with db.connect() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT path, sha256, area, size_bytes, source_path FROM files WHERE area = 'photos' AND sha256 IS NOT NULL")]
    rows = [r for r in rows if Path(r["path"]).suffix.lower() in PICTURE_EXTENSIONS]
    prints = ensure(db.db_path, [(r["path"], r["sha256"]) for r in rows],
                    progress=(lambda d, n: progress(f"fingerprints: {d:,} of {n:,} new")) if progress else None)
    return versions(rows, prints)


def block_for(member: dict[str, Any], group: list[dict[str, Any]], now: str) -> dict[str, Any]:
    """Return one version's `versions` block."""
    return {"role": member["role"], "group": group[0]["sha256"][:12], "found_at": now,
            "others": [{"sha256": o["sha256"], "file_name": Path(o["path"]).name, "role": o["role"],
                        "size": o["size"], "software": o["software"]} for o in group if o is not member]}


def write_versions(groups: list[list[dict[str, Any]]]) -> int:
    """Write each version's `versions` block; return how many sidecars changed."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    now = datetime.now().isoformat(timespec="seconds")
    changed = 0
    for group in groups:
        for member in group:
            path = Path(member["path"])
            if not path.exists():
                continue
            data = SidecarService.load(path)
            block = block_for(member, group, now)
            old = data.get(VERSIONS_BLOCK) if isinstance(data.get(VERSIONS_BLOCK), dict) else {}
            if {k: v for k, v in old.items() if k != "found_at"} == {k: v for k, v in block.items() if k != "found_at"}:
                continue
            data[VERSIONS_BLOCK] = block
            SidecarService.save(path, data)
            changed += 1
    return changed


def describe(role: str, other: dict[str, Any]) -> str:
    """Return 'edited version (Picasa 3.0)', 'cropped version' or 'the original' for another version of a picture."""
    if other["role"] == "original":
        return "the original"
    return f"{other['role']} version" + (f" ({other['software']})" if other.get("software") else "")
