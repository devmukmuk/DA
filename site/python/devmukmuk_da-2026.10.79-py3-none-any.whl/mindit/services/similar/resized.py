"""Plan setting copies aside that are the same picture but not the same file (decided 2026-10-19).

Resized copies (the same picture, smaller): the largest stays. Re-saved copies (the same pixels, other bytes - often
one lost its date): the dated one stays. Both go to `_duplicates-holding\\<date>\\resized|resaved\\`.
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any, Callable

from mindit.services.similar.fingerprints import PICTURE_EXTENSIONS, Pairs, ensure, resaved_copies, resized_copies

NOTE = "a resized copy of "                    # + the kept picture's path: history, --duplicates and da picasa read it
RESAVED_NOTE = "a re-saved copy of "
NOTES = (NOTE, RESAVED_NOTE)
KINDS = {"resized_copy": ("resized", NOTE), "resaved_copy": ("resaved", RESAVED_NOTE)}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def kept_of(note: str | None) -> str | None:
    """Return the kept picture a set-aside copy's log note names, or None."""
    for prefix in NOTES:
        if note and note.startswith(prefix):
            return note[len(prefix):]
    return None


def _rows(db: Any, progress: Callable[[str], None] | None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    db.initialize(log=False)
    with db.connect() as conn:
        rows = [dict(r) for r in conn.execute(
            "SELECT path, sha256, area, size_bytes FROM files WHERE area IN ('photos', 'intake')")]
    rows = [r for r in rows if Path(r["path"]).suffix.lower() in PICTURE_EXTENSIONS]
    missing = [r for r in rows if not r["sha256"] and r["area"] == "intake"]
    if missing:
        if progress:
            progress(f"fingerprinting: hashing {len(missing):,} intake pictures first")
        updates = []
        for r in missing:
            try:
                r["sha256"] = _sha256(Path(r["path"]))
                updates.append((r["sha256"], r["path"]))
            except OSError:
                continue
        with db.connect() as conn:
            conn.executemany("UPDATE files SET sha256 = ?, hash_status = 'computed' WHERE path = ?", updates)
    rows = [r for r in rows if r["sha256"]]
    prints = ensure(db.db_path, [(r["path"], r["sha256"]) for r in rows],
                    progress=(lambda d, n: progress(f"fingerprints: {d:,} of {n:,} new")) if progress else None)
    return rows, prints


def plan_copies(db: Any, layout: Any, prefix: str | None = None, *, areas: tuple[str, ...] = ("intake",),
                progress: Callable[[str], None] | None = None) -> list[dict[str, Any]]:
    """Plan moving resized and re-saved copies into holding: those in `areas` (and under prefix), against every photo.

    Intake pictures with no SHA-256 yet are hashed first (and remembered in the index); fingerprints are kept by hash.
    """
    rows, prints = _rows(db, progress)
    pairs = Pairs(rows, prints)
    plan, planned = [], set()
    for cls, found in (("resized_copy", resized_copies(rows, prints, pairs)),
                       ("resaved_copy", resaved_copies(rows, prints, pairs))):
        folder, note = KINDS[cls]
        for r in found:
            if r["area"] not in areas or (prefix and not r["path"].startswith(prefix)) or r["path"] in planned:
                continue
            if r["kept"] in planned:
                continue                                   # its keeper is itself going aside: next time
            src = Path(r["path"])
            try:
                mtime = src.stat().st_mtime
            except OSError:
                continue
            planned.add(r["path"])
            plan.append({"class": cls, "source": r["path"],
                         "destination": str(layout.holding_root / folder / src.relative_to(layout.data_root)),
                         "size_bytes": r["size_bytes"], "sha256": r["sha256"], "kept": r["kept"],
                         "source_mtime": mtime, "note": f"{note}{r['kept']}", "pixels": r["size"],
                         "kept_pixels": r["kept_size"], "bits": r["bits"]})
    return plan


def plan_resized(db: Any, layout: Any, prefix: str | None = None, *, areas: tuple[str, ...] = ("intake",),
                 progress: Callable[[str], None] | None = None) -> list[dict[str, Any]]:
    """Plan moving resized and re-saved copies into holding (the name kept from phase 1)."""
    return plan_copies(db, layout, prefix, areas=areas, progress=progress)


def keywords_in(path: Path) -> tuple[list[str], str]:
    """Return the keywords and title an editor (Photoshop Elements, Lightroom) wrote into a photo's XMP."""
    try:
        with Path(path).open("rb") as f:
            data = f.read(512_000)
    except OSError:
        return [], ""
    start = data.find(b"<x:xmpmeta")
    if start < 0:
        return [], ""
    xmp = data[start:data.find(b"</x:xmpmeta>", start) + 12].decode("utf-8", "replace")
    subject = re.search(r"<dc:subject>(.*?)</dc:subject>", xmp, re.S)
    words = [html_unescape(w).strip() for w in re.findall(r"<rdf:li[^>]*>([^<]+)</rdf:li>", subject.group(1))] \
        if subject else []
    title = re.search(r"<dc:title>.*?<rdf:li[^>]*>([^<]*)</rdf:li>", xmp, re.S)
    return [w for w in words if w], html_unescape(title.group(1)).strip() if title else ""


def html_unescape(text: str) -> str:
    """Return XML text with its entities (&amp; ...) turned back."""
    import html  # pylint: disable=import-outside-toplevel

    return html.unescape(text)


def give_details(plan: list[dict[str, Any]]) -> int:
    """Give each kept picture what only its copy had (Picasa faces, your tags, an editor's keywords); return how many."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import clean_tag  # pylint: disable=import-outside-toplevel

    gained = 0
    for p in plan:
        src, kept = Path(p["source"]), Path(p["kept"])
        if not kept.exists():
            continue
        copy = SidecarService.load(src) if Path(f"{src}.meta.json").exists() else {}
        keep = SidecarService.load(kept)
        changed = False
        if isinstance(copy.get("picasa"), dict) and not isinstance(keep.get("picasa"), dict):
            keep["picasa"] = copy["picasa"]                     # boxes are fractions: the same on the bigger picture
            changed = True
        mine = list((copy.get("user") or {}).get("tags") or []) if isinstance(copy.get("user"), dict) else []
        words, title = keywords_in(src)
        if words or title:
            have, own = keywords_in(kept)
            block = keep.get("keywords") if isinstance(keep.get("keywords"), dict) else {}
            new_words = [w for w in words if w not in have and w not in (block.get("words") or [])]
            if new_words or (title and not own and not block.get("title")):
                keep["keywords"] = {"words": list(block.get("words") or []) + new_words,
                                    "title": block.get("title") or (title if not own else ""), "from": src.name}
                changed = True
            mine += [clean_tag(w) for w in words]
        if mine:
            user = keep.get("user") if isinstance(keep.get("user"), dict) else {}
            tags = list(user.get("tags") or [])
            new = [t for t in dict.fromkeys(mine) if t and t not in tags]
            if new:
                user["tags"] = tags + new
                keep["user"] = user
                changed = True
        if changed:
            SidecarService.save(kept, keep)
            gained += 1
    return gained
