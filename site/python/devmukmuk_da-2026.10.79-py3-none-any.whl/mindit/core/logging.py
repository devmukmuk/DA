"""Shared logging configuration for DA."""
# src/mindit/core/logging.py

from __future__ import annotations

from contextlib import contextmanager
import json
import logging
import os
import socket
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from time import perf_counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from mindit.config.settings import LogSettings


HOST = os.environ.get("COMPUTERNAME") or socket.gethostname() or "?"
EVENT_FIELDS = ("path", "log", "run")              # an event's own fields; anything else it says goes in counts


class JsonFormatter(logging.Formatter):
    """Format log records as JSON lines."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "host": HOST,                               # which computer did it (archives move between PCs)
        }

        for attr in (
            "app",
            "command",
            "event",
            "status",
            "room_abbr",
            "box_name",
            "path",
            "duration_seconds",
            "auth_type",
            "with_counts",
            "write_updates",
            "room_name",
            "key",
            "profile",
            "log",
            "run",
            "counts",
        ):
            value = getattr(record, attr, None)
            if value is not None:
                payload[attr] = value

        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)

        return json.dumps(payload, ensure_ascii=False)


class TextFormatter(logging.Formatter):
    """Format log records for CLI console output."""

    def format(self, record: logging.LogRecord) -> str:
        app = getattr(record, "app", None)
        command = getattr(record, "command", None)

        prefix_parts = [record.levelname]
        if app and command:
            prefix_parts.append(f"{app}.{command}")
        elif app:
            prefix_parts.append(app)

        prefix = " ".join(f"[{part}]" for part in prefix_parts)
        return f"{prefix} {record.getMessage()}"


def _resolve_path(path_str: str) -> Path:
    """Resolve a configured path into an absolute Path."""
    return Path(path_str).expanduser().resolve()


def _build_json_handler(
    file_path: Path,
    settings: LogSettings,
) -> logging.Handler:
    """Build a JSON file handler with optional rotation."""
    file_path.parent.mkdir(parents=True, exist_ok=True)

    if not settings.rotate_enabled:
        handler: logging.Handler = logging.FileHandler(file_path, encoding="utf-8")
    elif settings.rotate_when == "size":
        handler = RotatingFileHandler(
            file_path,
            maxBytes=settings.rotate_max_bytes,
            backupCount=settings.rotate_backup_count,
            encoding="utf-8",
        )
    elif settings.rotate_when == "daily":
        handler = TimedRotatingFileHandler(
            file_path,
            when="midnight",
            interval=1,
            backupCount=settings.rotate_backup_count,
            encoding="utf-8",
            utc=False,
        )
    else:
        raise ValueError(f"Unsupported rotate_when: {settings.rotate_when}")

    handler.setFormatter(JsonFormatter())
    return handler


def _clear_logger_handlers(logger: logging.Logger) -> None:
    """Remove and close all handlers from a logger."""
    for handler in list(logger.handlers):
        logger.removeHandler(handler)
        try:
            handler.close()
        except Exception:
            pass


def configure_logging(settings: LogSettings) -> None:
    """Configure DA logging from application settings."""
    log_level = getattr(logging, settings.level.upper(), logging.INFO)
    log_root = _resolve_path(settings.root)

    # Main DA namespace logger (named "mindit", the Python package)
    root = logging.getLogger("mindit")
    root.setLevel(log_level)
    root.propagate = False
    _clear_logger_handlers(root)

    if settings.console_enabled:
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(TextFormatter())
        console_handler.setLevel(logging.WARNING)       # the screen gets problems; the log file gets everything
        root.addHandler(console_handler)

    if settings.json_enabled and settings.shared_log_enabled:
        shared_log_path = log_root / settings.shared_log_name
        root.addHandler(_build_json_handler(shared_log_path, settings))

    # Optional per-app namespace loggers
    app_names = ("config", "packit", "validateit", "db", "findit", "sidecar")

    for app_name in app_names:
        app_logger = logging.getLogger(f"mindit.{app_name}")
        app_logger.setLevel(log_level)
        app_logger.propagate = True
        _clear_logger_handlers(app_logger)

        if settings.json_enabled and settings.per_app_logs_enabled:
            app_log_path = log_root / f"{app_name}.jsonl"
            app_logger.addHandler(_build_json_handler(app_log_path, settings))
            app_logger.propagate = True


def get_logger(name: str) -> logging.Logger:
    """Return a namespaced DA logger."""
    if name.startswith("mindit"):
        return logging.getLogger(name)
    return logging.getLogger(f"mindit.{name}")


class ContextLogger(logging.LoggerAdapter):
    """Logger adapter that injects shared structured context."""

    def process(self, msg: str, kwargs: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        extra = kwargs.setdefault("extra", {})
        extra.update(self.extra)
        return msg, kwargs


def get_context_logger(
    name: str,
    *,
    app: str,
    command: str | None = None,
    **context: Any,
) -> ContextLogger:
    """Return a logger with shared app/command context attached."""
    extra = {"app": app}
    if command:
        extra["command"] = command
    extra.update(context)
    return ContextLogger(get_logger(name), extra)


@contextmanager
def log_command(
    logger: logging.LoggerAdapter,
    event: str,
    **context: Any,
) -> Iterator[None]:
    """Log a command start / finish / failure block with duration."""
    start = perf_counter()
    logger.info(
        f"{event} started",
        extra={"event": event, "status": "start", **context},
    )
    try:
        yield
    except Exception:
        logger.exception(
            f"{event} failed",
            extra={"event": event, "status": "error", **context},
        )
        raise
    else:
        duration_seconds = round(perf_counter() - start, 3)
        logger.info(
            f"{event} completed",
            extra={
                "event": event,
                "status": "ok",
                "duration_seconds": duration_seconds,
                **context,
            },
        )


# --------------------------------------------------------------------------- every command, in the archive's log

_COMMAND = {"line": "", "start": 0.0}


def log_command_start(argv: list[str], archive: str | None) -> None:
    """Log the command being run (`da split --to ...`) and the archive it runs in."""
    _COMMAND["line"] = " ".join(["da", *argv]).strip() or "da"
    _COMMAND["start"] = perf_counter()
    get_logger("da").info(f"{_COMMAND['line']} started",
                          extra={"event": "command", "status": "start", "command": _COMMAND["line"],
                                 "path": archive})


def log_command_end(code: int | None, error: BaseException | None = None) -> None:
    """Log how the command ended: ok, stopped (a non-zero exit) or failed (with the traceback)."""
    if not _COMMAND["line"]:
        return                                        # logging was never set up (e.g. --help outside an archive)
    seconds = round(perf_counter() - _COMMAND["start"], 1)
    logger = get_logger("da")
    extra = {"event": "command", "command": _COMMAND["line"], "duration_seconds": seconds}
    if error is not None:
        logger.error(f"{_COMMAND['line']} failed after {seconds}s: {type(error).__name__}: {error}",
                     exc_info=(type(error), error, error.__traceback__), extra={**extra, "status": "error"})
    elif code:
        logger.info(f"{_COMMAND['line']} stopped (exit {code}) after {seconds}s",
                    extra={**extra, "status": f"exit {code}"})
    else:
        logger.info(f"{_COMMAND['line']} finished in {seconds}s", extra={**extra, "status": "ok"})


def log_event(event: str, message: str, **context: Any) -> None:
    """Log one thing a command did (files moved, a run's summary) to the archive's log.

    path / log / run point at what it worked on and its records; any other keyword is a count (moved=12).
    """
    get_logger("da").info(message, extra={"event": event, "status": "ok", **_event_extra(context)})


def _event_extra(context: dict[str, Any]) -> dict[str, Any]:
    extra = {k: (str(v) if v is not None else None) for k, v in context.items() if k in EVENT_FIELDS}
    counts = {k: v for k, v in context.items() if k not in EVENT_FIELDS}
    if counts:
        extra["counts"] = counts
    return {k: v for k, v in extra.items() if v is not None}


def log_to_archive(root: Path, event: str, message: str, **context: Any) -> None:
    """Add one event to an archive's own log, when the command didn't run inside it (da setup making it)."""
    line = {"ts": datetime.now(timezone.utc).isoformat(), "level": "INFO", "logger": "mindit.da", "message": message,
            "host": HOST, "event": event, "status": "ok", **_event_extra(context)}
    path = Path(root) / "logs" / "da.jsonl"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(line, ensure_ascii=False) + "\n")
    except OSError:
        pass
