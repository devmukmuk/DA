# src/mindit/commands/workflow_cli.py

"""Top-level workflow commands: setup, run, status, archives, install, check, verify."""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import sys
from collections import Counter
from enum import StrEnum
from pathlib import Path

import typer
from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.table import Table

from mindit.commands.progress import ConsoleProgressReporter
from mindit.config.archive import known_archives
from mindit.config.settings import get_archive_root, load_settings, resolve_database_path
from mindit.services.dbit.dbit_service import DbitService
from mindit.services.dbit.intake_service import default_layout
from mindit.services.workflow.archive_setup import LAUNCHER, exe_path, inspect_target, parse_years, setup_archive
from mindit.services.workflow.checks import check_plan, check_report, load_report, verify_report
from mindit.services.workflow.run_workflow import copy_into_intake, free_intake_name, run_workflow

console = Console()
INSTALL_DIR = Path(r"C:\Scripts\DA")


class KindChoice(StrEnum):
    AUTO = "auto"
    PHOTO = "photo"
    DOCUMENT = "document"


# --------------------------------------------------------------------------- setup

def setup(
    folder: Path = typer.Argument(..., help="The archive folder, e.g. D:\\jane-archive-199x."),
    name: str = typer.Option(None, "--name", help="A display name (default: the folder name)."),
    years: str = typer.Option(None, "--years", help="Capture years this archive takes, e.g. 1990-1999."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask."),
) -> None:
    """Make FOLDER an archive: da-archive.yaml, intake\\ and organized\\ folders, and an "Open DA.cmd" launcher.

    An existing archive is reused; a folder that already has files in it is adopted (they move into intake\\).
    """
    try:
        parse_years(years)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc
    state = inspect_target(folder)
    if state.kind == "archive":
        console.print(f"{state.root} is already an archive.")
        if not (yes or Confirm.ask("Use the existing archive? (keeps its settings, adds anything missing)", default=True)):
            raise typer.Exit(1)
    elif state.kind == "folder":
        files = sum(1 for item in state.items for _ in (_walk_files(item) if item.is_dir() else [item]))
        console.print(f"{state.root} already has {len(state.items)} items ({files:,} files):")
        for item in state.items[:15]:
            console.print(f"   {'[dir] ' if item.is_dir() else '      '}{item.name}")
        if len(state.items) > 15:
            console.print(f"   ... and {len(state.items) - 15} more")
        if not (yes or Confirm.ask(f"Make it an archive and move these {len(state.items)} items into intake\\?",
                                   default=False)):
            raise typer.Exit(1)

    result = setup_archive(folder, name=name, years=years)
    console.print(f"Archive: [bold]{result.root}[/bold]")
    for f in result.created_folders:
        console.print(f"  created {f.relative_to(result.root)}\\")
    if result.moved:
        console.print(f"  moved {len(result.moved)} items into intake\\ (undo log: {result.move_log})")
    for item, why in result.skipped:
        console.print(f"  [yellow]left {item.name}: {why}[/yellow]")
    console.print(f"  config: {result.archive_file.name}   launcher: {result.launcher.name}")
    console.print(f"\nOpen [bold]{result.launcher}[/bold] (double-click), then:  da run")


def _walk_files(folder: Path):
    for _dirpath, _dirs, files in os.walk(folder):
        yield from files


# --------------------------------------------------------------------------- run / status

def run(
    folder: Path = typer.Argument(None, help="Folder to process (default: this archive's intake\\)."),
    kind: KindChoice = typer.Option(KindChoice.AUTO, "--kind", help="photo or document: treat every image as that. Default: by intake folder (scans, docs: document), else photo."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before moving files."),
) -> None:
    """Process a folder end to end: index, hash, set duplicates aside, preview, check, file, verify."""
    layout = default_layout()
    folder = folder or layout.intake_root
    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    if not folder.resolve().is_relative_to(Path(layout.data_root).resolve()):
        # Duplicates are found among indexed files, and a folder outside the archive isn't indexed.
        dest = free_intake_name(layout.intake_root, folder.resolve().name)
        console.print(f"{folder} is outside this archive ({layout.data_root}).")
        if not (yes or Confirm.ask(f"Copy it to {dest} and process the copy? The originals stay where they are",
                                   default=True)):
            console.print("Nothing done. Copy it into this archive's intake\\ yourself, then run `da run` on it.")
            raise typer.Exit(1)
        copied = copy_into_intake(folder, dest)
        console.print(f"Copied {copied:,} files to {dest}. Delete {folder} yourself once you're happy.")
        folder = dest
    console.print(f"Archive: {layout.data_root}   processing: {folder}")
    record = run_workflow(
        folder,
        DbitService(resolve_database_path()),
        layout,
        kind=None if kind == KindChoice.AUTO else kind.value,
        say=console.print,
        ask=(lambda q: True) if yes else (lambda q: Confirm.ask(q, default=False)),
        progress=ConsoleProgressReporter(console=console, update_every=1000),
    )
    if record.stopped_at_step:
        console.print(f"[yellow]Stopped at {record.stopped_at_step}. Nothing after that step was changed.[/yellow]")
        console.print(f"Record: {record.run_dir}")


def status(title: bool = typer.Option(True, hidden=True)) -> None:
    """Show this archive: name, years, what's waiting in intake, what's filed, and the last run."""
    settings = load_settings()
    layout = default_layout()
    root = get_archive_root() or layout.data_root
    years = settings.archive.years or "any"
    if title:                                       # the menu's box already shows the name and folder
        console.print(f"[bold]{settings.archive.name or root.name}[/bold]   {root}   years: {years}")

    db_path = resolve_database_path()
    counts = _db_counts(db_path, layout) if db_path.exists() else None
    if counts:
        console.print(f"  organized: {counts['photos']:,} photos, {counts['documents']:,} documents   "
                      f"(index from {counts['built'] or '?'}; refresh: da db build)")
    intake = _intake_counts_from_db(db_path, layout) if counts else None
    source = "from the index" if intake is not None else "counted now"
    if intake is None:
        intake = _intake_counts(layout.intake_root)
    total = sum(intake.values())
    console.print(f"  intake: {total:,} files ({source})" + (" - nothing waiting" if not total else ""))
    for top, n in sorted(intake.items(), key=lambda kv: -kv[1])[:10]:
        console.print(f"     {n:>8,}  {top}")
    runs = sorted((layout.output_root / "runs").glob("*-run/summary.json")) if (layout.output_root / "runs").exists() else []
    if runs:
        last = json.loads(runs[-1].read_text(encoding="utf-8"))
        filed = (last.get("steps", {}).get("6_file", {}).get("verify", {}) or {}).get("moved", 0)
        end = "stopped at " + last["stopped_at_step"] if last.get("stopped_at_step") else f"filed {filed:,}"
        console.print(f"  last run: {last.get('started_at')}  {end}")


def _intake_counts(intake: Path) -> dict[str, int]:
    """Count files (not sidecars) under intake by their top-level folder."""
    counts: dict[str, int] = {}
    if not intake.exists():
        return counts
    for dirpath, _dirs, files in os.walk(intake):
        n = sum(1 for f in files if not f.lower().endswith(".meta.json"))
        if n:
            rel = os.path.relpath(dirpath, intake)
            top = "(intake)" if rel == "." else rel.split(os.sep)[0]
            counts[top] = counts.get(top, 0) + n
    return counts


def _intake_counts_from_db(db_path: Path, layout) -> dict[str, int] | None:
    """Count indexed intake files by top-level folder, or None when the index has no intake rows."""
    try:
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute("SELECT folder, COUNT(*) FROM files WHERE area = 'intake' GROUP BY folder").fetchall()
    except sqlite3.Error:
        return None
    if not rows:
        return None
    counts: dict[str, int] = {}
    for folder, n in rows:
        top = (folder or "(intake)").split(os.sep)[0]
        counts[top] = counts.get(top, 0) + n
    return counts


def _db_counts(db_path: Path, layout) -> dict | None:
    try:
        with sqlite3.connect(db_path) as conn:
            rows = dict(conn.execute("SELECT area, COUNT(*) FROM files GROUP BY area").fetchall())
            built = conn.execute(
                "SELECT created_at FROM db_events WHERE event_type = 'db_build' ORDER BY id DESC LIMIT 1").fetchone()
    except sqlite3.Error:
        return None
    return {"photos": rows.get("photos", 0), "documents": rows.get("documents", 0), "built": built[0] if built else None}


# --------------------------------------------------------------------------- contact sheets

def contact_sheets(
    folder: Path = typer.Argument(..., help="A folder; every folder under it with photos gets a sheet."),
    force: bool = typer.Option(False, "--force", help="Make every sheet again, even ones that are up to date."),
    layout: str = typer.Option(None, "--layout", help="Pictures per page, columns x rows: 3x4 (bigger) or 4x5. "
                                                      "Default: the archive's setting, else 3x4."),
) -> None:
    """Make a contact sheet (_contact-sheet.pdf: small pictures of every photo) in each folder with photos."""
    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.services.contactsheet.contact_sheet import (  # pylint: disable=import-outside-toplevel
        SHEET_NAME, folders_with_photos, layout_size, refresh_sheets,
    )

    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    if layout is not None:
        try:
            layout_size(layout)
        except ValueError as error:
            raise typer.BadParameter(str(error)) from error
    folders = folders_with_photos(folder)
    console.print(f"{len(folders):,} folders with photos under {folder}")
    if force:
        for each in folders:
            (each / SHEET_NAME).unlink(missing_ok=True)
    result = refresh_sheets(folders, create=True, version=__version__, layout=layout,
                            progress=lambda m: console.print(f"  {m}"))
    console.print(f"Made or updated {len(result.made):,}; already up to date {result.current:,}"
                  + (f"; failed {len(result.failed)}" if result.failed else ""))
    for path, why in result.failed:
        console.print(f"  [red]{path}: {why}[/red]")


# --------------------------------------------------------------------------- Live Photos and HEIC

def pair_movies(
    folder: Path = typer.Argument(None, help="Where to look for left-behind videos (default: this archive's intake\\)."),
    apply: bool = typer.Option(False, "--apply", help="Move them (without it, only show what would move)."),
) -> None:
    """Find iPhone Live Photo videos (.MOV) left in intake after their photo was filed, and put them beside it."""
    from mindit.services.livephoto.live_photos import (  # pylint: disable=import-outside-toplevel
        apply_pairs, filed_photo_rows, plan_pairs, write_pair_plan,
    )

    layout = default_layout()
    folder = folder or layout.intake_root
    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    db = DbitService(resolve_database_path())
    console.print(f"Looking for Live Photo videos under {folder} ...")
    plan = plan_pairs(folder, filed_photo_rows(db))
    run_dir = layout.run_dir("pair-movies")
    plan_path = write_pair_plan(plan, run_dir / "pairs.csv")
    console.print(f"  {len(plan.pairs):,} videos found their filed photo (list: {plan_path})")
    for pair in plan.pairs[:5]:
        console.print(f"     {Path(pair['movie']).name}  ->  {pair['destination']}")
    if len(plan.pairs) > 5:
        console.print(f"     ... and {len(plan.pairs) - 5:,} more")
    if plan.already_there:
        console.print(f"  {len(plan.already_there):,} are already beside their photo (left alone)")
    if plan.other_copies:
        console.print(f"  {len(plan.other_copies):,} are another copy of a video above (left alone; "
                      "`da run` sets exact copies aside)")
    if plan.unmatched:
        console.print(f"  {len(plan.unmatched):,} have no filed photo yet (left alone; file the photos first)")
    if plan.not_orphans:
        console.print(f"  {plan.not_orphans:,} still have their photo beside them; `da run` files the two together")
    if not plan.pairs:
        return
    if not apply:
        console.print("Nothing moved. To move them: add --apply.")
        return
    stats = apply_pairs(db, plan, run_dir / "pair-movies-moved.csv")
    console.print(f"Moved {stats['moved']:,}" + (f", skipped {stats['skipped']:,}" if stats["skipped"] else "")
                  + f". Undo: da intake undo \"{run_dir / 'pair-movies-moved.csv'}\"")


def heic_to_jpg(
    folder: Path = typer.Argument(..., help="A folder; every HEIC photo in it (and its subfolders) gets a JPG copy."),
    out: Path = typer.Option(None, "--out", help="Where the JPGs go (default: a new folder next to it, <name>-jpg)."),
) -> None:
    """Make JPG copies of iPhone HEIC photos (for sharing); the HEIC originals stay where they are."""
    from mindit.services.livephoto.live_photos import convert_folder, heic_files  # pylint: disable=import-outside-toplevel

    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    folder = folder.resolve()
    out = (out or folder.with_name(f"{folder.name}-jpg")).resolve()
    if out.is_relative_to(folder):
        raise typer.BadParameter("--out can't be inside the folder being converted.")
    count = len(heic_files(folder))
    console.print(f"{count:,} HEIC photos under {folder}; JPG copies go to {out}")
    if not count:
        return
    result = convert_folder(folder, out, progress=lambda m: console.print(f"  {m}"))
    console.print(f"Made {len(result.made):,} JPGs" + (f"; {result.skipped:,} were already done" if result.skipped else "")
                  + (f"; {len(result.failed)} failed" if result.failed else ""))
    for path, why in result.failed[:10]:
        console.print(f"  [red]{path}: {why}[/red]")


# --------------------------------------------------------------------------- tags

def tag(
    items: list[str] = typer.Argument(
        None, help="Files or folders, then the tags to add to them (e.g. photos\\organized\\2021 beach grandma). "
                   "No files or folders: all of this archive's filed photos."),
    remove: list[str] = typer.Option(None, "--remove", "-x", help="A tag of yours to take off (repeat for more)."),
    cameras: bool = typer.Option(False, "--cameras",
                                 help="List the cameras found and ask who used each (saved in da-archive.yaml)."),
    owner: tuple[str, str] = typer.Option((None, None), "--owner", metavar="CAMERA NAME",
                                          help='Save who used a camera, e.g. --owner "Apple iPhone 8" jane.'),
    refresh: bool = typer.Option(False, "--refresh", help="Read the camera details from each photo again."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before tagging all filed photos."),
) -> None:
    """Tag photos: automatic tags from each photo's camera details, or your own tags on files and folders."""
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging import tags as tg  # pylint: disable=import-outside-toplevel

    targets, words = [], []
    for item in items or []:
        if not words and Path(item).exists():
            targets.append(Path(item))
        else:
            words.append(item)
    whole_archive = not targets
    if whole_archive:
        targets = [resolve_photoit_organized_path()]
    settings = load_settings()

    if owner[0]:
        if not owner[1] or not owner[1].strip():
            raise typer.BadParameter('Give the camera and the name: --owner "Apple iPhone 8" jane')
        if not _save_owners({owner[0]: owner[1].strip()}):
            raise typer.Exit(1)
        _retag(targets, tg, ask=not yes)
        return

    if cameras:
        photos = tg.files_under(targets, photos_only=True)
        seen = tg.cameras_seen(photos, settings.cameras)
        _list_cameras(seen, tg)
        missing = [cam for cam in seen if not cam.owner]
        if missing and _interactive() and not yes:
            console.print("\nWho used each camera? Type a name, or press Enter to skip.")
            names = {}
            for cam in missing:
                years = tg.camera_years(cam)
                try:
                    answer = Prompt.ask(f"  {cam.key}  ({cam.photos:,} photos{', ' + years if years else ''})",
                                        default="", show_default=False).strip()
                except (EOFError, KeyboardInterrupt):
                    console.print()
                    break
                if answer:
                    names[cam.key] = answer
            if names and _save_owners(names):
                _retag(targets, tg, ask=True)
        return

    if words or remove:
        files = tg.files_under(targets, photos_only=False)
        result = tg.change_user_tags(files, words, remove or [])
        rows = tg.update_index(resolve_database_path(), result.changed)
        console.print(f"Your tags on {len(files):,} files: "
                      + ", ".join([f"+{tg.clean_tag(w)}" for w in words] + [f"-{tg.clean_tag(r)}" for r in remove or []])
                      + f"  (index updated: {rows:,})")
        return

    photos = tg.files_under(targets, photos_only=True)
    where = ", ".join(str(t) for t in targets)
    if whole_archive and not yes and not Confirm.ask(
            f"Read camera details and make automatic tags for {len(photos):,} photos in {where}?", default=True):
        return
    console.print(f"Tagging {len(photos):,} photos in {where} ...")
    progress = ConsoleProgressReporter(console=console, update_every=1000)
    progress.start(label="Tagging", total=len(photos))
    try:
        result = tg.tag_photos(photos, settings.cameras, refresh=refresh,
                               progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    rows = tg.update_index(resolve_database_path(), result.changed)
    console.print(f"Tagged {result.files:,} photos; camera details read from {result.read:,}"
                  + (f"; {len(result.unreadable):,} couldn't be read" if result.unreadable else "")
                  + f"  (index updated: {rows:,})")
    if not settings.cameras:
        console.print("For owner: tags, see who used which camera: da tag --cameras")


def _interactive() -> bool:
    """Return True when someone is at the keyboard (not a script, and the output isn't captured)."""
    return sys.stdin.isatty() and sys.stdout.isatty()


def _save_owners(owners: dict[str, str]) -> bool:
    """Write camera owners into this archive's da-archive.yaml; say what happened."""
    from mindit.config.settings import ARCHIVE_FILE  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.owners import set_owners  # pylint: disable=import-outside-toplevel

    root = get_archive_root()
    if root is None:
        console.print("[yellow]Not inside an archive, so there's no da-archive.yaml to save owners in.[/yellow]")
        return False
    try:
        backup = set_owners(root / ARCHIVE_FILE, owners)
    except RuntimeError as error:
        console.print(f"[red]{error}[/red]")
        return False
    for camera, name in owners.items():
        console.print(f"  saved: {camera} -> {name}")
    console.print(f"  in {root / ARCHIVE_FILE} (the old one is kept as {backup.name})")
    return True


def _retag(targets: list[Path], tg, *, ask: bool) -> None:
    """Make the automatic tags again so new owners show up (camera details are already kept: quick)."""
    if ask and not Confirm.ask("Update the owner: tags now?", default=True):
        console.print("Later: run `da tag` (only tags change; photos aren't read again).")
        return
    photos = tg.files_under(targets, photos_only=True)
    result = tg.tag_photos(photos, load_settings().cameras)
    rows = tg.update_index(resolve_database_path(), result.changed)
    console.print(f"Tags updated on {result.files:,} photos  (index updated: {rows:,})")


def _list_cameras(seen, tg) -> None:
    if not seen:
        console.print("No camera details yet. Run `da tag` first; it reads them from the photos.")
        return
    table = Table(show_header=True, box=None)
    for column in ("camera", "serial", "photos", "years", "owner"):
        table.add_column(column, justify="right" if column == "photos" else "left")
    for cam in seen:
        table.add_row(cam.name, cam.serial or "", f"{cam.photos:,}", tg.camera_years(cam), cam.owner or "-")
    console.print(table)
    missing = [cam for cam in seen if not cam.owner]
    if missing and not _interactive():
        console.print("\nTo name an owner (saved in da-archive.yaml for you):")
        console.print(f'  da tag --owner "{missing[0].key}" <name>')


# --------------------------------------------------------------------------- split

def split(
    to: Path = typer.Option(None, "--to", help="The archive to move them to; its years pick which files go."),
    years: str = typer.Option(None, "--years", help="Only files taken in these years, e.g. 2000-2004."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before moving."),
) -> int:
    """Move what intake holds from other years into the archive for those years (no --to: just show where)."""
    from mindit.config.archive import is_archive  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import split as sp  # pylint: disable=import-outside-toplevel

    here = get_archive_root()
    if here is None:
        console.print("[yellow]Run this inside an archive (the one whose intake holds the files).[/yellow]")
        raise typer.Exit(1)
    given = sp.parse_years(years) if years else None
    if years and not given:
        raise typer.BadParameter(f"--years must look like 2000-2009, not {years!r}")
    here_years = sp.archive_years(here)
    if not here_years and not given:
        console.print(f"{sp.archive_name(here)} takes any year (no years: in its da-archive.yaml), so nothing in "
                      "its intake belongs elsewhere. To move some anyway, give --years, e.g. --years 2000-2009.")
        return 0

    layout = default_layout()
    console.print(f"Working out the dates of what's in {layout.intake_root} ...")
    strays, undated = sp.find_strays(layout.intake_root, here_years, intake_names=set(load_settings().intake),
                                     progress=lambda n: console.print(f"  {n:,} files ...", end="\r"))
    if given:
        strays = [s for s in strays if given[0] <= s.year <= given[1]]
    where = f"outside {here_years[0]}-{here_years[1]}" if here_years else f"from {given[0]}-{given[1]}"
    console.print(f"{len(strays):,} files in intake were taken {where}."
                  + (f" ({undated:,} have no sure date and stay; see 3 What needs review.)" if undated else ""))
    if not strays:
        return 0

    if to is None:
        placed, nowhere = sp.by_archive(strays, known_archives(), here)
        for archive, items in placed.items():
            yrs = sp.archive_years(archive)
            console.print(f"  {len(items):,} belong in {sp.archive_name(archive)} ({yrs[0]}-{yrs[1]}):  "
                          f'da split --to "{archive}"')
        decades = Counter(s.year // 10 * 10 for s in nowhere)
        for decade, n in sorted(decades.items()):
            console.print(f"  {n:,} from the {decade}s have no archive on this PC yet. Make one: "
                          f"da setup <folder> --years {decade}-{decade + 9}")
        return len(strays)

    to = to.resolve()
    if not is_archive(to):
        raise typer.BadParameter(f"{to} isn't an archive (no da-archive.yaml). Make it with da setup first.")
    if os.path.normcase(str(to)) == os.path.normcase(str(here.resolve())):
        raise typer.BadParameter("That's this archive. Give the other one.")
    target_years = given or sp.archive_years(to)
    if not target_years:
        console.print(f"[yellow]{sp.archive_name(to)} takes any year, so give the years to move: "
                      "--years 2000-2009.[/yellow]")
        raise typer.Exit(1)
    plan = sp.plan_split(strays, to, here.name, target_years)
    if not plan.moves:
        console.print(f"None of them were taken in {target_years[0]}-{target_years[1]}."
                      + (" (Run without --to to see where they belong.)" if not given else ""))
        return 0
    other = sp.archive_years(to)
    if given and other and not (other[0] <= given[0] and given[1] <= other[1]):
        console.print(f"[yellow]Note: {sp.archive_name(to)} takes {other[0]}-{other[1]}; files outside that "
                      "will wait in its intake too.[/yellow]")
    console.print(f"\nMove {plan.photos:,} photos and {plan.documents:,} documents taken "
                  f"{target_years[0]}-{target_years[1]} to {sp.archive_name(to)}:")
    for move in [m for m in plan.moves if m.companion_of is None][:5]:
        console.print(f"  {move.source.relative_to(layout.intake_root)}  ->  {move.destination}")
    if plan.photos + plan.documents > 5:
        console.print(f"  ... and {plan.photos + plan.documents - 5:,} more")
    extras = sum(1 for m in plan.moves if m.companion_of)
    if extras:
        console.print(f"  (with {extras:,} raw files and Live Photo videos that go with them; sidecars too)")
    if plan.conflicts:
        console.print(f"[yellow]  {len(plan.conflicts):,} stay: a file with the same name is already there.[/yellow]")
    if not yes and not _interactive():
        console.print("Nothing moved. To move them: add --yes.")
        return 0
    if not yes and not Confirm.ask("Move them?", default=True):
        return 0

    run_dir = layout.run_dir("split")
    log = run_dir / "split-moved.csv"
    stats = sp.apply_split(plan, log, resolve_database_path())
    console.print(f"Moved {stats['files']:,} file{'s' if stats['files'] != 1 else ''}"
                  + (f" ({stats['skipped'] + stats['failed']:,} couldn't be moved; see the log)"
                     if stats["skipped"] or stats["failed"] else "") + ".")
    console.print(f'Undo: da intake undo "{log}"')
    console.print(f"Next: open {sp.archive_name(to)} (its Open DA.cmd, or 6 Switch archive in the menu) and "
                  "choose 1 Process intake.")
    return stats["files"]


# --------------------------------------------------------------------------- report

def report(
    open_it: bool = typer.Option(False, "--open", help="Open the PDF when it's made."),
    refresh: bool = typer.Option(False, "--refresh", help="Refresh the index first, so the numbers are current."),
) -> None:
    """Make a one-page PDF about this archive (what it holds, by year, cameras, places) in its output folder."""
    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.services.report import archive_report as ar  # pylint: disable=import-outside-toplevel

    settings = load_settings()
    layout = default_layout()
    root = get_archive_root() or layout.data_root
    db_path = resolve_database_path()
    if refresh:
        from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel

        console.print("Refreshing the index ...")
        ArchiveIndexService(DbitService(db_path)).build(default_areas(),
                                                        progress=lambda m: console.print(f"  {m}"))
    console.print("Counting ...")
    data = ar.gather(db_path, name=settings.archive.name or root.name, folder=str(root),
                     years=settings.archive.years or "", output_root=layout.output_root, version=f"v{__version__}")
    path = ar.make_pdf(data, ar.report_path(layout.output_root, data.name, data.made_at))
    console.print(f"  {data.photos:,} photo{'s' if data.photos != 1 else ''} and {data.documents:,} "
                  f"document{'s' if data.documents != 1 else ''} filed"
                  + (f", taken {data.first_year} to {data.last_year}" if data.first_year else "")
                  + f"; {data.intake:,} waiting in intake.")
    if data.cameras:
        console.print(f"  {data.camera_count:,} cameras; most photos: "
                      + ", ".join(ar.nice_name(c) for c, _ in data.cameras[:3]) + ".")
    console.print("  " + ar.places_sentence(data))
    if not data.indexed:
        console.print("[yellow]  Not indexed yet: run da db build (or menu 5), then make the report again.[/yellow]")
    console.print(f"Report: {path}")
    if open_it:
        try:
            os.startfile(path)  # type: ignore[attr-defined]  # pylint: disable=no-member
        except (AttributeError, OSError):
            pass


# --------------------------------------------------------------------------- dashboard

def dashboard(
    port: int = typer.Option(8765, "--port", help="The port (the next free one is used if it's taken)."),
    open_it: bool = typer.Option(True, "--open/--no-open", help="Open the page in the browser."),
) -> None:
    """Show this archive's dashboard in the browser (a page on this PC only), until Ctrl+C."""
    import webbrowser  # pylint: disable=import-outside-toplevel

    from mindit import __version__  # pylint: disable=import-outside-toplevel
    from mindit.config.settings import get_logs_root_path  # pylint: disable=import-outside-toplevel
    from mindit.services.dashboard import dashboard as dash  # pylint: disable=import-outside-toplevel

    settings = load_settings()
    layout = default_layout()
    root = get_archive_root() or layout.data_root
    board = dash.Dashboard(dash.Archive(
        name=settings.archive.name or root.name, folder=root, years=settings.archive.years or "",
        db_path=resolve_database_path(), output_root=layout.output_root,
        log_path=get_logs_root_path(settings) / settings.logs.shared_log_name, version=f"v{__version__}"))
    server = dash.make_server(board, port)
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    board.recount()                                    # years, cameras, places: in the background
    console.print(f"Dashboard for [bold]{board.archive.name}[/bold]: {url}")
    console.print("  It only reads the archive, and only this PC can open it. Press Ctrl+C to stop it.")
    if open_it:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        console.print("  Dashboard stopped.")
    finally:
        server.server_close()


# --------------------------------------------------------------------------- merge

def merge(
    other: Path = typer.Option(..., "--from", help="The other archive, whose files this one should have too."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before copying."),
) -> None:
    """Copy into this archive what another archive has and this one doesn't (the other is never changed)."""
    from mindit.config.archive import is_archive  # pylint: disable=import-outside-toplevel
    from mindit.services.contactsheet.contact_sheet import refresh_sheets  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.archive_index_service import ArchiveIndexService, default_areas  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow import merge as mg  # pylint: disable=import-outside-toplevel
    from mindit.services.workflow.split import archive_name  # pylint: disable=import-outside-toplevel

    here = get_archive_root()
    if here is None:
        console.print("[yellow]Run this inside the archive to keep (the one that gets the files).[/yellow]")
        raise typer.Exit(1)
    other = other.resolve()
    if not is_archive(other):
        raise typer.BadParameter(f"{other} isn't an archive (no da-archive.yaml).")
    if os.path.normcase(str(other)) == os.path.normcase(str(here.resolve())):
        raise typer.BadParameter("That's this archive. Give the other one.")

    db = DbitService(resolve_database_path())
    console.print(f"Indexing {archive_name(here)} so DA knows what it has ...")
    ArchiveIndexService(db).build(default_areas(), progress=lambda m: console.print(f"  {m}"))
    with sqlite3.connect(db.db_path) as conn:
        known = {row[0] for row in conn.execute("SELECT sha256 FROM files WHERE sha256 IS NOT NULL")}
        unhashed = [Path(row[0]) for row in conn.execute("SELECT path FROM files WHERE sha256 IS NULL")]
    if unhashed:                                     # e.g. intake files with no sidecar yet
        console.print(f"Fingerprinting {len(unhashed):,} files here that don't have one yet ...")
        known |= {digest for digest in map(mg.file_hash, unhashed) if digest}
    console.print(f"Comparing {archive_name(other)} ({other}) with it, file by file ...")
    plan = mg.plan_merge(here, other, known,
                         progress=lambda n: console.print(f"  {n:,} files looked at ...", end="\r"))
    console.print(f"{plan.looked_at:,} files in {archive_name(other)}: {plan.already_here:,} already here"
                  + (f", {plan.repeats:,} repeated there (copied once)" if plan.repeats else "")
                  + (f", {len(plan.unreadable):,} couldn't be read" if plan.unreadable else "") + ".")
    if not plan.copies:
        console.print(f"Nothing to copy: {archive_name(here)} already has everything {archive_name(other)} has.")
        return
    gb = plan.bytes / 1e9
    console.print(f"\nCopy {len(plan.copies):,} files ({gb:,.1f} GB) into {archive_name(here)}:")
    for reason, n in plan.reasons().most_common():
        where = ("to the same folder and name here" if reason == "filed"
                 else f"to intake\\...\\{mg._from_folder(other)} ({reason}; da run files them)")
        console.print(f"  {n:,} {where}")
    free = shutil.disk_usage(here).free
    if plan.bytes > free * 0.95:
        console.print(f"[red]Not enough room: {gb:,.1f} GB to copy, {free / 1e9:,.1f} GB free on that drive.[/red]")
        raise typer.Exit(1)
    console.print(f"  ({free / 1e9:,.0f} GB free there. {archive_name(other)} isn't changed.)")
    if not yes and not _interactive():
        console.print("Nothing copied. To copy them: add --yes.")
        return
    if not yes and not Confirm.ask("Copy them?", default=True):
        return

    run_dir = default_layout().run_dir("merge")
    log = run_dir / "merge-copied.csv"
    progress = ConsoleProgressReporter(console=console, update_every=200)
    progress.start(label="Copying", total=len(plan.copies))
    try:
        stats = mg.apply_merge(plan, log, progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    filed_folders = {c.destination.parent for c in plan.copies if c.reason == "filed"}
    sheets = refresh_sheets(filed_folders, create=True)
    ArchiveIndexService(db).build(default_areas())
    console.print(f"Copied {stats['copied']:,} files: {stats['filed']:,} filed, {stats['to_intake']:,} to intake"
                  + (f"; {stats['skipped'] + stats['failed']:,} not copied (see the log)"
                     if stats["skipped"] or stats["failed"] else "")
                  + f". {len(sheets.made):,} contact sheets updated.")
    console.print(f'Undo (removes the copies): da intake undo "{log}"')
    if stats["to_intake"]:
        console.print("Next: choose 1 Process intake (or da run) to file what went to intake.")


# --------------------------------------------------------------------------- guide

GUIDE_URL = "https://da.gamenightbymike.com"
GUIDE_PDF_URL = f"{GUIDE_URL}/DA-User-Guide.pdf"


def guide(
    pdf: bool = typer.Option(False, "--pdf", help="Open the PDF version instead of the web page."),
) -> None:
    """Open the DA user guide in your web browser (or its PDF)."""
    import webbrowser  # pylint: disable=import-outside-toplevel

    url = GUIDE_PDF_URL if pdf else GUIDE_URL
    console.print(f"Opening {url}")
    if not webbrowser.open(url):
        console.print("Couldn't open a browser here. Open that address yourself.")


# --------------------------------------------------------------------------- archives / install

def archives(
    open_: int = typer.Option(None, "--open", "-o", help="Open archive number N in its own window."),
) -> None:
    """List the archives set up on this PC; --open N opens one."""
    found = known_archives()
    if not found:
        console.print("No archives yet. Create one:  da setup D:\\jane-archive-199x --years 1990-1999")
        return
    if open_:
        if not 1 <= open_ <= len(found):
            raise typer.BadParameter(f"pick 1-{len(found)}")
        launcher = found[open_ - 1] / LAUNCHER
        os.startfile(str(launcher))  # type: ignore[attr-defined]  # Windows
        console.print(f"Opened {launcher}")
        return
    table = Table(title="Archives on this PC")
    for col in ("#", "name", "years", "folder"):
        table.add_column(col)
    for i, folder in enumerate(found, 1):
        name, years = _archive_label(folder)
        table.add_row(str(i), name, years, str(folder))
    console.print(table)
    console.print("Open one:  da archives --open N   (or double-click Open DA.cmd in its folder)")


def _archive_label(folder: Path) -> tuple[str, str]:
    import yaml  # pylint: disable=import-outside-toplevel

    try:
        data = yaml.safe_load((folder / "da-archive.yaml").read_text(encoding="utf-8")) or {}
    except (OSError, yaml.YAMLError):
        return folder.name, "?"
    archive = data.get("archive") or {}
    return str(archive.get("name") or folder.name), str(archive.get("years") or "any")


PYTHON_REQUIREMENTS_URL = "https://da.gamenightbymike.com/python/requirements.txt"
DA_EXE_URL = "https://github.com/devmukmuk/DA/releases/latest/download/DA.exe"
PYTHON_LAUNCHER = """\
@echo off
rem DA, run by Python ({python}). Made by `da install`. Python is signed, so Windows'
rem Smart App Control runs it even where it blocks the DA.exe download.
"{python}" -m mindit %*
exit /b %ERRORLEVEL%
"""


def install() -> None:
    """Put DA in C:\\Scripts\\DA and on your PATH, so `da` works in any new terminal (and every Open DA.cmd)."""
    from mindit.services.workflow.archive_setup import refresh_launchers  # pylint: disable=import-outside-toplevel

    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    exe = exe_path()
    if exe is not None:                                       # the DA.exe
        target = INSTALL_DIR / "DA.exe"
        if exe != target.resolve():
            shutil.copy2(exe, target)
        _set_aside(INSTALL_DIR / "da.cmd")                    # one DA at a time: the exe now
        installed = f"{target}"
    else:                                                     # DA run by Python
        launcher = INSTALL_DIR / "da.cmd"
        launcher.write_text(PYTHON_LAUNCHER.format(python=Path(sys.executable).resolve()), encoding="utf-8",
                            newline="\r\n")
        # `da` would find DA.exe before da.cmd (Windows tries .exe first), and Smart App Control may block it.
        _set_aside(INSTALL_DIR / "DA.exe")
        installed = f"{launcher} (DA run by Python {sys.version.split()[0]})"
    added = _add_to_user_path(INSTALL_DIR)
    refreshed = refresh_launchers(known_archives())
    console.print(f"Installed {installed}" + (" and added it to your PATH." if added else " (already on your PATH)."))
    if refreshed:
        console.print(f"Updated Open DA.cmd in {len(refreshed)} archive{'s' if len(refreshed) != 1 else ''}.")
    console.print("New terminal windows know `da` from now on. In THIS window, run first:")
    console.print(f"    $env:Path += ';{INSTALL_DIR}'      (PowerShell)    or    set PATH=%PATH%;{INSTALL_DIR}   (cmd)")
    console.print("VS Code's terminals need VS Code restarted. Archives' Open DA.cmd files work either way.")


def _set_aside(path: Path) -> None:
    """Rename the other kind of DA (path -> path.off), so `da` and Open DA.cmd use the one just installed."""
    if path.exists():
        off = path.with_name(path.name + ".off")
        off.unlink(missing_ok=True)
        path.rename(off)
        console.print(f"Set aside {path.name} (now {off.name}).")


def update() -> None:
    """Update DA to the newest version (DA run by Python updates itself; the DA.exe says where to get it)."""
    import subprocess  # pylint: disable=import-outside-toplevel

    from mindit import __version__  # pylint: disable=import-outside-toplevel

    console.print(f"This is DA v{__version__}.")
    if exe_path() is not None:
        console.print(f"Download the newest DA.exe ({DA_EXE_URL}), close DA, and run  .\\DA.exe install  "
                      "in the folder it downloaded to (see Update DA in the guide).")
        return
    command = [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet", "-r", PYTHON_REQUIREMENTS_URL]
    console.print("Downloading the newest DA ...")
    done = subprocess.run(command, check=False)
    if done.returncode != 0:
        console.print("[red]The update didn't finish.[/red] Close every DA window and run this in a new one:")
        console.print("    " + " ".join(f'"{c}"' if " " in c else c for c in command))
        raise typer.Exit(1)
    newest = subprocess.run([sys.executable, "-m", "mindit", "version"], capture_output=True, text=True, check=False)
    console.print(f"Now: {newest.stdout.strip() or 'updated'}.")


def _add_to_user_path(folder: Path) -> bool:
    if sys.platform != "win32":
        return False
    import ctypes  # pylint: disable=import-outside-toplevel
    import winreg  # pylint: disable=import-outside-toplevel

    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment", 0, winreg.KEY_READ | winreg.KEY_WRITE) as key:
        try:
            current, kind = winreg.QueryValueEx(key, "Path")
        except FileNotFoundError:
            current, kind = "", winreg.REG_EXPAND_SZ
        parts = [p for p in current.split(";") if p]
        if any(os.path.normcase(p.rstrip("\\")) == os.path.normcase(str(folder)) for p in parts):
            return False
        winreg.SetValueEx(key, "Path", 0, kind, ";".join(parts + [str(folder)]))
    ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x001A, 0, "Environment", 0x0002, 5000, None)
    return True


# --------------------------------------------------------------------------- check / verify

def check(
    file: Path = typer.Argument(..., help="A set-aside plan (.csv) or a validate report (.json)."),
) -> None:
    """Check a set-aside plan (re-hash a sample) or a validate report (what would move, and any warnings)."""
    result = check_plan(file) if file.suffix.lower() == ".csv" else check_report(load_report(file))
    console.print_json(json.dumps(result, default=str))


def verify(
    report: Path = typer.Argument(..., help="A validate report from a repair run."),
) -> None:
    """Re-check every file a repair run moved: in place, gone from the source, hash matches its sidecar."""
    console.print("Re-hashing every filed file and comparing it with its sidecar ...")
    result = verify_report(load_report(report), progress=lambda m: console.print(f"  {m}"))
    console.print_json(json.dumps(result, default=str))
    if not result["ok"]:
        raise typer.Exit(1)
