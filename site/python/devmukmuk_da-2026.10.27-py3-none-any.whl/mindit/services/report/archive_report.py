# src/mindit/services/report/archive_report.py

"""`da report`: one dated page about an archive - what it holds, by year, the cameras, and the places.

Everything comes from the archive's index (.da\\da.sqlite) with SQL totals, so a big archive's report takes
seconds, not a walk of every file. The PDF goes in the archive's output folder:
output\\<archive>-report-YYYY-MM-DD.pdf.
"""

from __future__ import annotations

import json
import re
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

US_STATES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California", "CO": "Colorado",
    "CT": "Connecticut", "DE": "Delaware", "DC": "Washington DC", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas",
    "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts",
    "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri", "MT": "Montana",
    "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico",
    "NY": "New York", "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma",
    "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota",
    "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont", "VA": "Virginia", "WA": "Washington",
    "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming", "PR": "Puerto Rico",
}
_SMALL_WORDS = {"of", "and", "the"}
_MODEL_WORDS = {"dmc", "dsc", "eos", "slt", "ilce", "dslr", "nex", "fz", "se", "xr", "xs"}


@dataclass
class ReportData:  # pylint: disable=too-many-instance-attributes
    """What the report says."""

    name: str
    folder: str
    years: str
    made_at: datetime
    version: str = ""
    indexed: bool = False
    index_built: str | None = None
    photos: int = 0
    documents: int = 0
    raw: int = 0
    videos: int = 0
    other: int = 0
    gigabytes: float = 0.0
    intake: int = 0
    holding: int = 0
    problems: int = 0
    last_run: str | None = None
    by_year: list[tuple[str, int, int]] = field(default_factory=list)       # year (or decade), photos, docs
    first_year: str | None = None
    last_year: str | None = None
    undated: int = 0
    cameras: list[tuple[str, int]] = field(default_factory=list)
    camera_count: int = 0
    owners: list[tuple[str, int]] = field(default_factory=list)
    with_gps: int = 0
    with_place: int = 0
    countries: list[tuple[str, int]] = field(default_factory=list)         # name, photos
    states: list[tuple[str, int]] = field(default_factory=list)            # US states
    places: list[tuple[str, int]] = field(default_factory=list)            # place:city-st tags
    location_folders: int = 0


def nice_name(slug: str) -> str:
    """Return 'apple-iphone-12-pro' as 'Apple iPhone 12 Pro' (good enough for camera and place slugs)."""
    words = []
    for word in slug.split("-"):
        if word in _SMALL_WORDS and words:
            words.append(word)
        elif word.startswith("iphone") or word.startswith("ipad"):
            words.append("i" + word[1:].capitalize())
        elif word in _MODEL_WORDS or re.fullmatch(r"[a-z]{1,3}\d+[a-z]?|\d+[a-z]{1,2}|[a-z]{1,2}", word):
            words.append(word.upper())                     # d90, zs100, g991u, 5d, sm, dmc, eos
        else:
            words.append(word.capitalize())
    return " ".join(words)


def place_label(slug: str) -> str:
    """Return 'springfield-il' as 'Springfield, IL' (and 'paris-fr' as 'Paris, FR')."""
    head, _, code = slug.rpartition("-")
    if head and len(code) == 2:
        return f"{nice_name(head)}, {code.upper()}"
    return nice_name(slug)


def size_text(gigabytes: float) -> str:
    """Return '12.3 GB', or '45 MB' under a gigabyte."""
    return f"{gigabytes:,.1f} GB" if gigabytes >= 1 else f"{gigabytes * 1000:,.0f} MB"


def _rows(conn: sqlite3.Connection, sql: str, *args) -> list[tuple]:
    try:
        return conn.execute(sql, args).fetchall()
    except sqlite3.Error:
        return []


def _one(conn: sqlite3.Connection, sql: str, *args, default=0):
    rows = _rows(conn, sql, *args)
    return rows[0][0] if rows and rows[0][0] is not None else default


def _tag_counts(conn: sqlite3.Connection, labels: tuple[str, ...]) -> dict[str, list[tuple[str, int]]]:
    """Return, for each label, its tags on filed photos (value, photos), most used first - in one pass."""
    found: dict[str, list[tuple[str, int]]] = {label: [] for label in labels}
    rows = _rows(conn, "SELECT j.value, COUNT(*) FROM files, json_each(files.tags) AS j "
                       "WHERE files.area = 'photos' AND files.tags LIKE '%:%' AND ("
                       + " OR ".join("j.value LIKE ?" for _ in labels) + ") "
                       "GROUP BY j.value ORDER BY COUNT(*) DESC", *(f"{label}:%" for label in labels))
    for value, n in rows:
        label, _, rest = value.partition(":")
        if label in found:
            found[label].append((rest, n))
    return found


def gather(db_path: Path, *, name: str, folder: str, years: str, output_root: Path | None = None,
           version: str = "") -> ReportData:
    """Return the report's numbers from the archive's index (zeros when it hasn't been built yet)."""
    data = ReportData(name=name, folder=folder, years=years or "any year", made_at=datetime.now(), version=version)
    if output_root is not None:
        data.last_run = last_run(output_root)
    if not Path(db_path).exists():
        return data
    with sqlite3.connect(f"file:{Path(db_path).as_posix()}?mode=ro", uri=True) as conn:
        data.indexed = True
        data.index_built = _one(conn, "SELECT MAX(created_at) FROM db_events WHERE event_type = 'db_build'",
                                default=None)
        for area, kind, n, size in _rows(conn, "SELECT area, media_type, COUNT(*), SUM(size_bytes) FROM files "
                                               "GROUP BY area, media_type"):
            if area in ("photos", "documents"):
                data.gigabytes += (size or 0) / 1e9
                if kind == "photo":
                    data.photos += n
                elif kind == "document":
                    data.documents += n
                elif kind == "raw":
                    data.raw += n
                elif kind == "video":
                    data.videos += n
                else:
                    data.other += n
            elif area == "intake":
                data.intake += n
            elif area == "holding":
                data.holding += n
        data.problems = _one(conn, "SELECT COUNT(*) FROM files WHERE area IN ('photos', 'documents') "
                                   "AND validation_status = 'problems'")

        years_found = _rows(conn, "SELECT substr(captured_at, 1, 4), media_type, COUNT(*) FROM files "
                                  "WHERE area IN ('photos', 'documents') AND media_type IN ('photo', 'document') "
                                  "GROUP BY 1, 2")
        per_year: dict[str, list[int]] = {}
        for year, kind, n in years_found:
            if not year or not year.isdigit():
                data.undated += n
                continue
            per_year.setdefault(year, [0, 0])[0 if kind == "photo" else 1] += n
        if per_year:
            data.first_year, data.last_year = min(per_year), max(per_year)
        if len(per_year) > 14:                              # many years: show decades instead
            decades: dict[str, list[int]] = {}
            for year, (p, d) in per_year.items():
                key = f"{year[:3]}0s"
                decades.setdefault(key, [0, 0])
                decades[key][0] += p
                decades[key][1] += d
            per_year = decades
        data.by_year = [(y, p, d) for y, (p, d) in sorted(per_year.items())]

        tags = _tag_counts(conn, ("camera", "owner", "place"))
        data.cameras, data.camera_count = tags["camera"][:10], len(tags["camera"])
        data.owners, data.places = tags["owner"][:6], tags["place"][:10]

        data.with_gps = _one(conn, "SELECT COUNT(*) FROM files WHERE area = 'photos' AND gps_present = 1")
        data.with_place = _one(conn, "SELECT COUNT(*) FROM files WHERE area = 'photos' AND "
                                     "(city IS NOT NULL OR country_code IS NOT NULL)")
        country_names = {code.lower(): country for code, country in
                         _rows(conn, "SELECT country_code, country FROM places WHERE country_code IS NOT NULL "
                                     "AND country IS NOT NULL GROUP BY country_code") if code}
        data.countries = [(country_names.get((code or "").lower(), (code or "?").upper()), n) for code, n in
                          _rows(conn, "SELECT country_code, COUNT(*) FROM files WHERE area = 'photos' AND "
                                      "country_code IS NOT NULL GROUP BY country_code ORDER BY COUNT(*) DESC")]
        data.states = [(US_STATES.get((code or "").upper(), code), n) for code, n in
                       _rows(conn, "SELECT state_code, COUNT(*) FROM files WHERE area = 'photos' AND "
                                   "country_code = 'us' AND state_code IS NOT NULL GROUP BY state_code "
                                   "ORDER BY COUNT(*) DESC")]
        data.location_folders = _one(conn, "SELECT COUNT(DISTINCT title) FROM files WHERE area = 'photos' "
                                           "AND title IS NOT NULL")
    return data


def last_run(output_root: Path) -> str | None:
    """Return the last `da run`: when, and how many files it filed (or where it stopped)."""
    runs_dir = Path(output_root) / "runs"
    runs = sorted(runs_dir.glob("*-run/summary.json")) if runs_dir.exists() else []
    if not runs:
        return None
    try:
        last = json.loads(runs[-1].read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    filed = ((last.get("steps", {}).get("6_file") or {}).get("verify") or {}).get("moved", 0)
    end = f"stopped at {last['stopped_at_step']}" if last.get("stopped_at_step") else f"filed {filed:,}"
    return f"{(last.get('started_at') or '')[:16].replace('T', ' ')} ({end})"


def places_sentence(data: ReportData) -> str:
    """Return 'Photos were taken in 2 countries (United States, France) and 5 US states (Florida, ...).'."""
    if not data.countries and not data.states:
        if data.with_gps:
            return (f"{data.with_gps:,} photos have a GPS position, but their places haven't been looked up "
                    "yet: run `da location lookup`.")
        return "No photos with a GPS position yet (older photos may need `da tag` first)."
    parts = []
    if data.countries:
        names = ", ".join(name for name, _ in data.countries[:8]) + (" ..." if len(data.countries) > 8 else "")
        parts.append(f"{len(data.countries)} {'country' if len(data.countries) == 1 else 'countries'} ({names})")
    if data.states:
        names = ", ".join(name for name, _ in data.states[:12]) + (" ..." if len(data.states) > 12 else "")
        parts.append(f"{len(data.states)} US {'state' if len(data.states) == 1 else 'states'} ({names})")
    return "This archive includes photos taken in " + " and ".join(parts) + "."


def report_path(output_root: Path, name: str, day: datetime) -> Path:
    """Return output\\<archive>-report-YYYY-MM-DD.pdf (a second report the same day replaces the first)."""
    safe = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-") or "archive"
    return Path(output_root) / f"{safe}-report-{day:%Y-%m-%d}.pdf"


# --------------------------------------------------------------------------- the page

def make_pdf(data: ReportData, path: Path) -> Path:  # pylint: disable=too-many-locals,too-many-statements
    """Draw the one-page report."""
    from reportlab.lib.colors import HexColor  # pylint: disable=import-outside-toplevel
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.lib.utils import simpleSplit  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    path.parent.mkdir(parents=True, exist_ok=True)
    width, height = letter
    margin = 40
    ink, soft, accent, rule = HexColor("#1f2933"), HexColor("#52606d"), HexColor("#2c6e91"), HexColor("#cbd2d9")
    pdf = canvas.Canvas(str(path), pagesize=letter)
    pdf.setTitle(f"{data.name} - archive report {data.made_at:%Y-%m-%d}")
    pdf.setAuthor("DA")

    # Heading band
    pdf.setFillColor(accent)
    pdf.rect(0, height - 78, width, 78, stroke=0, fill=1)
    pdf.setFillColor(HexColor("#ffffff"))
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(margin, height - 42, data.name)
    pdf.setFont("Helvetica", 10)
    pdf.drawString(margin, height - 58, f"Archive report, {data.made_at:%d %B %Y}   |   years: {data.years}")
    pdf.setFont("Helvetica", 8)
    shown = data.folder if len(data.folder) <= 110 else "..." + data.folder[-107:]
    pdf.drawString(margin, height - 71, shown)

    y = height - 100

    def heading(text: str, x: float, top: float) -> float:
        pdf.setFillColor(accent)
        pdf.setFont("Helvetica-Bold", 11)
        pdf.drawString(x, top, text.upper())
        pdf.setStrokeColor(rule)
        pdf.line(x, top - 4, x + col_w, top - 4)
        return top - 18

    def line(text: str, x: float, top: float, *, size: float = 9.5, color=ink, bold: bool = False,
             wrap: float | None = None) -> float:
        pdf.setFillColor(color)
        font = "Helvetica-Bold" if bold else "Helvetica"
        pdf.setFont(font, size)
        for part in simpleSplit(text, font, size, wrap or col_w):
            pdf.drawString(x, top, part)
            top -= size + 3.5
        return top

    def pair(label: str, value: str, x: float, top: float) -> float:
        pdf.setFillColor(soft)
        pdf.setFont("Helvetica", 9.5)
        pdf.drawString(x, top, label)
        pdf.setFillColor(ink)
        pdf.setFont("Helvetica-Bold", 9.5)
        pdf.drawRightString(x + col_w, top, value)
        return top - 13

    col_w = (width - 2 * margin - 24) / 2
    left, right = margin, margin + col_w + 24

    if not data.indexed:
        y = line("This archive hasn't been indexed yet, so there's nothing to count. Process intake "
                 "(menu 1) or refresh the index (menu 5), then make the report again.", left, y,
                 wrap=width - 2 * margin)

    # Left column: what's here, and by year
    top = heading("What's in the archive", left, y)
    top = pair("Photos filed", f"{data.photos:,}", left, top)
    top = pair("Documents filed", f"{data.documents:,}", left, top)
    if data.videos:
        top = pair("Videos filed", f"{data.videos:,}", left, top)
    if data.raw:
        top = pair("Camera raw files", f"{data.raw:,}", left, top)
    if data.other:
        top = pair("Other files", f"{data.other:,}", left, top)
    top = pair("Space used", size_text(data.gigabytes), left, top)
    if data.first_year:
        top = pair("Taken", f"{data.first_year} to {data.last_year}", left, top)
    top -= 6
    top = heading("Waiting for you", left, top)
    top = pair("In intake", f"{data.intake:,}", left, top)
    top = pair("Duplicates set aside", f"{data.holding:,}", left, top)
    top = pair("Filed, with notes to review", f"{data.problems:,}", left, top)
    top = pair("Last run", data.last_run or "never", left, top)
    top -= 6
    top = heading("By year", left, top)
    if data.by_year:
        pdf.setFillColor(soft)
        pdf.setFont("Helvetica", 8.5)
        pdf.drawString(left, top, "year")
        pdf.drawRightString(left + col_w - 70, top, "photos")
        pdf.drawRightString(left + col_w, top, "documents")
        top -= 12
        biggest = max(p for _, p, _ in data.by_year) or 1
        for year, photos, docs in data.by_year[:16]:
            pdf.setFillColor(HexColor("#d9e8f0"))
            pdf.rect(left + 38, top - 2, (col_w - 160) * photos / biggest, 9, stroke=0, fill=1)
            pdf.setFillColor(ink)
            pdf.setFont("Helvetica", 9)
            pdf.drawString(left, top, year)
            pdf.drawRightString(left + col_w - 70, top, f"{photos:,}")
            pdf.drawRightString(left + col_w, top, f"{docs:,}")
            top -= 12
        if data.undated:
            top = line(f"Plus {data.undated:,} with no date.", left, top - 2, size=8.5, color=soft)
    else:
        top = line("Nothing filed yet.", left, top, color=soft)

    # Right column: cameras and places
    top = heading("Cameras", right, y)
    if data.cameras:
        for camera, n in data.cameras:
            top = pair(nice_name(camera), f"{n:,}", right, top)
        if data.camera_count > len(data.cameras):
            top = line(f"and {data.camera_count - len(data.cameras)} more", right, top, size=8.5, color=soft)
        if data.owners:
            top = line("Taken by: " + ", ".join(f"{nice_name(o)} ({n:,})" for o, n in data.owners),
                       right, top - 2, size=9)
    else:
        top = line("No camera details yet. `da tag` reads them from the photos.", right, top, color=soft)
    top -= 6
    top = heading("Places", right, top)
    top = pair("Photos with a GPS position", f"{data.with_gps:,}", right, top)
    top = pair("... with a place looked up", f"{data.with_place:,}", right, top)
    if data.location_folders:
        top = pair("Location folders", f"{data.location_folders:,}", right, top)
    top = line(places_sentence(data), right, top - 4, size=9.5)
    if data.places:
        top -= 4
        top = line("Most photographed places", right, top, size=9, color=soft, bold=True)
        for place, n in data.places[:8]:
            top = pair(place_label(place), f"{n:,}", right, top)

    # Footer
    pdf.setStrokeColor(rule)
    pdf.line(margin, 46, width - margin, 46)
    pdf.setFillColor(soft)
    pdf.setFont("Helvetica", 8)
    built = f"index built {data.index_built[:16].replace('T', ' ')}" if data.index_built else "index not built"
    pdf.drawString(margin, 34, f"Made by DA {data.version} on {data.made_at:%Y-%m-%d %H:%M}; {built}. "
                               "Numbers come from the index: refresh it (menu 5) after moving files yourself.")
    pdf.showPage()
    pdf.save()
    return path
