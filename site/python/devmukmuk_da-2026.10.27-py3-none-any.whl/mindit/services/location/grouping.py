# src/mindit/services/location/grouping.py

"""Group a month's GPS photos by time and place, name each group's folder, and move the photos there.

A group is a chain of photos each taken within 6 hours and about 2 km of the one before, so a trip across
midnight stays together. Photos without GPS stay in the month folder. The folder sits next to the month
folder: organized\\2019\\2019-04 Easter at grandma's (springfield-il). Every move is logged like a
set-aside, so `da intake undo <log>` puts the photos back.
"""

from __future__ import annotations

import csv
import json
import math
import os
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.dbit.intake_service import LOG_FIELDS
from mindit.services.location.places import LOCATION_BLOCK, place_name, place_of
from mindit.services.tagging.tags import is_photo, slug
from mindit.services.validateit.validateit_file_types import companions

SIDECAR_SUFFIX = ".meta.json"
LOG_CLASS = "location_folder"
MAX_NAME = 120                                   # keeps whole paths under Windows' 260-character limit
MAX_PLACES = 3
_ILLEGAL = re.compile(r'[\\/:*?"<>|\x00-\x1f]')
_TOKEN = re.compile(r"\{(\w+)(?::(\d+))?\}")
_PLACE_TOKENS = {"street", "neighbourhood", "city", "county", "state", "country", "place"}
_NAME_DATE = re.compile(r"^photo_(\d{8})_(\d{6})_")


# --------------------------------------------------------------------------- photos and groups

@dataclass
class Shot:
    """One photo with a GPS position: when and where it was taken."""

    path: Path
    taken: datetime
    lat: float
    lon: float
    place: dict[str, Any] | None = None


@dataclass
class Group:
    """Photos taken close together in time and place."""

    shots: list[Shot]
    title: str | None = None

    @property
    def start(self) -> datetime:
        """Return when the first photo was taken."""
        return self.shots[0].taken

    @property
    def end(self) -> datetime:
        """Return when the last photo was taken."""
        return self.shots[-1].taken

    def places(self) -> list[tuple[dict[str, Any], int]]:
        """Return each distinct place (one per place name) with its photo count, most photos first."""
        counts: Counter = Counter()
        first: dict[str, dict[str, Any]] = {}
        for shot in self.shots:
            name = place_name(shot.place)
            if name:
                counts[name] += 1
                first.setdefault(name, shot.place)
        return [(first[name], n) for name, n in counts.most_common()]


def taken_at(sidecar: dict[str, Any], path: Path) -> datetime | None:
    """Return when a photo was taken: the sidecar's capture time, the camera's, or its DA name."""
    photoit = sidecar.get("photoit") if isinstance(sidecar.get("photoit"), dict) else {}
    camera = sidecar.get("camera") if isinstance(sidecar.get("camera"), dict) else {}
    user = sidecar.get("user") if isinstance(sidecar.get("user"), dict) else {}
    video = sidecar.get("video") if isinstance(sidecar.get("video"), dict) else {}
    for value, fmt in ((user.get("captured_at"), None), (photoit.get("captured_at"), None),
                       (video.get("recorded_at"), None), (camera.get("date_taken"), "%Y:%m:%d %H:%M:%S")):
        if not value:
            continue
        try:
            moment = datetime.strptime(value, fmt) if fmt else datetime.fromisoformat(value)
        except (TypeError, ValueError):
            continue
        return moment.replace(tzinfo=None)
    m = _NAME_DATE.match(path.name)
    return datetime.strptime(m[1] + m[2], "%Y%m%d%H%M%S") if m else None


def month_shots(folder: Path) -> tuple[list[Shot], list[Path]]:
    """Return the folder's photos with a position and a time (oldest first), and the photos that stay put.

    A photo without GPS has a position when its place was set by hand (`da location set`).
    """
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    shots: list[Shot] = []
    staying: list[Path] = []
    for path in sorted(p for p in folder.iterdir() if p.is_file() and is_photo(p)):
        if not Path(f"{path}{SIDECAR_SUFFIX}").exists():
            staying.append(path)
            continue
        data = SidecarService.load(path)
        place, pos = place_of(data)
        when = taken_at(data, path)
        if pos is None or when is None:
            staying.append(path)
            continue
        shots.append(Shot(path, when, pos[0], pos[1], place))
    shots.sort(key=lambda s: (s.taken, s.path.name))
    return shots, staying


def folder_photos(folder: Path) -> tuple[list[Shot], str | None]:
    """Return a location folder's dated photos (with or without a position) and the title its photos keep."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    shots: list[Shot] = []
    titles: Counter = Counter()
    for path in sorted(p for p in folder.iterdir() if p.is_file() and is_photo(p)):
        data = SidecarService.load(path) if Path(f"{path}{SIDECAR_SUFFIX}").exists() else {}
        place, pos = place_of(data)
        when = taken_at(data, path)
        block = data.get(LOCATION_BLOCK) if isinstance(data.get(LOCATION_BLOCK), dict) else {}
        if block.get("title"):
            titles[block["title"]] += 1
        if when is not None:
            shots.append(Shot(path, when, *(pos or (math.nan, math.nan)), place))
    shots.sort(key=lambda s: (s.taken, s.path.name))
    return shots, (titles.most_common(1)[0][0] if titles else None)


def title_from_name(name: str) -> str:
    """Return the title in a location folder's name: "2019-04 Easter at grandma's (springfield-il)" -> "Easter at grandma's"."""
    text = re.sub(r"^\d{4}-\d{2}(-\d{2})?\s*", "", name)
    return re.sub(r"\s*\([^()]*\)\s*$", "", text).strip()


def location_folders(month: Path) -> dict[Path, str]:
    """Return the month's location folders next to it, each with its title."""
    from mindit.services.location.folders import is_month_folder  # pylint: disable=import-outside-toplevel

    if not month.parent.is_dir():
        return {}
    found = {}
    for folder in sorted(p for p in month.parent.iterdir() if p.is_dir()):
        if folder.name.lower() != month.name.lower() and is_month_folder(folder, month):
            _shots, title = folder_photos(folder)
            found[folder] = title or title_from_name(folder.name)
    return found


def matching_folder(group: Group, folders: dict[Path, list[Shot]], *, hours: float = 6.0,
                    km: float = 2.0) -> Path | None:
    """Return the existing location folder these photos belong with: one taken within hours and km of them."""
    for folder, shots in folders.items():
        for new in group.shots:
            for old in shots:
                if math.isnan(old.lat):
                    continue
                if abs((new.taken - old.taken).total_seconds()) <= hours * 3600 and distance_km(new, old) <= km:
                    return folder
    return None


def distance_km(a: Shot, b: Shot) -> float:
    """Return the distance between two photos in kilometres."""
    lat1, lat2 = math.radians(a.lat), math.radians(b.lat)
    dlat, dlon = lat2 - lat1, math.radians(b.lon - a.lon)
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 6371.0 * 2 * math.asin(math.sqrt(min(1.0, h)))


def group_shots(shots: list[Shot], *, hours: float = 6.0, km: float = 2.0) -> list[Group]:
    """Return the photos in groups: each photo within `hours` and `km` of the one before joins its group."""
    groups: list[Group] = []
    for shot in shots:
        if groups:
            prev = groups[-1].shots[-1]
            if (shot.taken - prev.taken).total_seconds() <= hours * 3600 and distance_km(prev, shot) <= km:
                groups[-1].shots.append(shot)
                continue
        groups.append(Group([shot]))
    return groups


def merge_titled(groups: list[Group]) -> list[Group]:
    """Return the groups with a title, those given the same title joined into one (that's how to merge)."""
    merged: dict[str, Group] = {}
    for group in groups:
        title = clean_title(group.title or "")
        if not title:
            continue
        if title.lower() in merged:
            merged[title.lower()].shots.extend(group.shots)
        else:
            merged[title.lower()] = Group(list(group.shots), title)
    for group in merged.values():
        group.shots.sort(key=lambda s: (s.taken, s.path.name))
    return list(merged.values())


# --------------------------------------------------------------------------- folder names

def clean_title(title: str) -> str:
    """Return a title as typed, without the characters Windows doesn't allow in a folder name."""
    return re.sub(r"\s+", " ", _ILLEGAL.sub("", title)).strip().rstrip(". ")


def _place_values(place: dict[str, Any] | None) -> dict[str, str]:
    place = place or {}
    return {
        "street": slug(place.get("street") or ""),
        "neighbourhood": slug(place.get("neighbourhood") or ""),
        "city": slug(place.get("city") or ""),
        "county": slug(place.get("county") or ""),
        "state": slug(place.get("state") or ""),
        "state:2": slug(place.get("state_code") or ""),
        "country": slug(place.get("country") or ""),
        "country:2": slug(place.get("country_code") or ""),
        "place": place_name(place) or "",
    }


def _render(text: str, values: dict[str, str]) -> str:
    def one(m: re.Match) -> str:
        name, arg = m.group(1), m.group(2)
        if arg and f"{name}:{arg}" in values:
            return values[f"{name}:{arg}"]
        return values.get(name, m.group(0))
    return _TOKEN.sub(one, text)


def _tidy_place(text: str) -> str:
    """Drop the separators an empty token left behind: '-springfield-il' -> 'springfield-il'."""
    text = re.sub(r"-{2,}", "-", text)
    text = re.sub(r"(,\s*){2,}", ", ", text)
    return text.strip(" -,_.")


def _has_place_token(text: str) -> bool:
    return any(m.group(1) in _PLACE_TOKENS for m in _TOKEN.finditer(text))


def folder_name(pattern: str, group: Group, *, max_places: int = MAX_PLACES, max_len: int = MAX_NAME) -> str:
    """Return the group's folder name from the pattern, e.g. "2019-04 Easter at grandma's (springfield-il)".

    The bracket holding place tokens lists each of the group's places, most photos first, at most three.
    Too long a name drops places first, then shortens the title.
    """
    title = clean_title(group.title or "")
    places = [p for p, _ in group.places()]
    for keep in range(min(max_places, len(places)), -1, -1):
        name = _folder_name(pattern, group.start, title, places[:keep])
        if len(name) <= max_len:
            return name
    name = _folder_name(pattern, group.start, "", [])
    room = max(1, max_len - len(name) - 1)
    return _folder_name(pattern, group.start, title[:room].rstrip(), [])


def _folder_name(pattern: str, start: datetime, title: str, places: list[dict[str, Any]]) -> str:
    dates = {"YYYY": f"{start:%Y}", "MM": f"{start:%m}", "DD": f"{start:%d}", "title": title}

    def bracket(m: re.Match) -> str:
        inner = m.group(1)
        if not _has_place_token(inner):
            return m.group(0)
        parts: list[str] = []
        for place in places:
            part = _tidy_place(_render(inner, {**dates, **_place_values(place)}))
            if part and part not in parts:
                parts.append(part)
        return f"({', '.join(parts)})" if parts else ""

    text = re.sub(r"\(([^()]*)\)", bracket, pattern)
    if _has_place_token(text):                        # place tokens outside brackets: the main place
        text = _render(text, _place_values(places[0] if places else None))
    text = _render(text, dates)
    text = re.sub(r"\(\s*\)", "", text)
    return clean_title(re.sub(r"\s+", " ", text))


# --------------------------------------------------------------------------- moving

@dataclass
class Move:
    """One file going into a location folder."""

    source: Path
    destination: Path
    title: str
    companion_of: Path | None = None


@dataclass
class GroupPlan:
    """The folders to make and what goes in each."""

    month: Path
    folders: dict[Path, Group] = field(default_factory=dict)
    moves: list[Move] = field(default_factory=list)
    conflicts: list[Path] = field(default_factory=list)


def plan_groups(month: Path, groups: list[Group], pattern: str,
                existing: dict[Path, str] | None = None) -> GroupPlan:
    """Return what to move where for the titled groups (each photo with its raw file and Live Photo video).

    A title that is an existing location folder's title adds the photos to that folder.
    """
    plan = GroupPlan(month)
    by_title = {title.lower(): folder for folder, title in (existing or {}).items() if title}
    for group in merge_titled(groups):
        folder = by_title.get(group.title.lower()) or month.parent / folder_name(pattern, group)
        if folder.resolve() == month.resolve():
            continue
        if folder in plan.folders:                   # two titles that make the same name: one folder
            plan.folders[folder].shots.extend(group.shots)
        else:
            plan.folders[folder] = group
        for shot in group.shots:
            files = [shot.path] + [_on_disk(c) for c in companions(shot.path)]
            targets = [folder / f.name for f in files]
            if any(t.exists() for t in targets):
                plan.conflicts.append(shot.path)
                continue
            for i, (src, dst) in enumerate(zip(files, targets)):
                plan.moves.append(Move(src, dst, group.title or "", None if i == 0 else shot.path))
    return plan


def _on_disk(path: Path) -> Path:
    """Return the path spelled as it is on disk (a case-insensitive drive finds IMG_1.MOV as IMG_1.mov)."""
    wanted = path.name.lower()
    for entry in os.scandir(path.parent):
        if entry.name.lower() == wanted:
            return path.with_name(entry.name)
    return path


def apply_plan(db_path: Path | None, plan: GroupPlan, log_path: Path) -> Counter:
    """Move the files and their sidecars, set each sidecar's title, update the index; log every move."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    stats: Counter = Counter()
    moved: list[tuple[str, str, str, str]] = []           # new path, new sidecar path, title, old path
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w", newline="", encoding="utf-8") as f:
        log = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        log.writeheader()
        for move in plan.moves:
            src, dst = move.source, move.destination
            entry = {"class": LOG_CLASS, "source": str(src), "destination": str(dst), "size_bytes": "",
                     "sha256": "", "kept": str(move.companion_of or ""), "sidecar_source": "",
                     "sidecar_destination": "", "note": move.title}
            if not src.exists() or dst.exists():
                entry["result"] = "skipped"
                stats["skipped"] += 1
                log.writerow(entry)
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            entry["size_bytes"] = str(src.stat().st_size)
            os.rename(src, dst)                             # same drive; fails rather than overwrite
            side_src, side_dst = Path(f"{src}{SIDECAR_SUFFIX}"), Path(f"{dst}{SIDECAR_SUFFIX}")
            if side_src.exists() and not side_dst.exists():
                os.rename(side_src, side_dst)
                entry["sidecar_source"], entry["sidecar_destination"] = str(side_src), str(side_dst)
                data = SidecarService.load(dst)
                block = data.get(LOCATION_BLOCK) if isinstance(data.get(LOCATION_BLOCK), dict) else {}
                block.update({"title": move.title, "group": slug(dst.parent.name),
                              "updated_at": datetime.now().isoformat(timespec="seconds")})
                data[LOCATION_BLOCK] = block
                SidecarService.save(dst, data)
            entry["result"] = "moved"
            stats["moved"] += 1
            if move.companion_of is None:
                stats["photos"] += 1
            moved.append((str(dst), entry["sidecar_destination"] or "", move.title, str(src)))
            log.writerow(entry)
    if db_path and Path(db_path).exists() and moved:
        move_index_rows(db_path, [(new, side, title, old) for new, side, title, old in moved])
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("location_group", f"moved {stats['photos']} photos from {plan.month.name} into "
              + ", ".join(f.name for f in plan.folders) + f" (undo: {log_path})", path=str(log_path))
    return stats


def move_index_rows(db_path: Path, rows: list[tuple[str, str, str | None, str]]) -> None:
    """Point index rows at their new place: (new path, new sidecar path, title, old path)."""
    import sqlite3  # pylint: disable=import-outside-toplevel

    from mindit.services.dbit.dbit_service import DbitService  # pylint: disable=import-outside-toplevel

    DbitService(db_path).initialize(log=False)
    with sqlite3.connect(db_path) as conn:
        for new, side, title, old in rows:
            row = conn.execute("SELECT folder FROM files WHERE path = ?", (old,)).fetchone()
            folder = None
            if row and row[0] is not None:
                folder = str(Path(row[0]).parent / Path(new).parent.name) if row[0] else Path(new).parent.name
            conn.execute("UPDATE files SET path = ?, folder = COALESCE(?, folder), file_name = ?, "
                         "sidecar_path = CASE WHEN ? = '' THEN sidecar_path ELSE ? END, title = ? WHERE path = ?",
                         (new, folder, Path(new).name, side, side, title, old))


def undo_rows(db_path: Path | None, rows: list[dict[str, str]]) -> None:
    """After `da intake undo` put location-folder moves back: clear the titles, fix the index, tidy folders."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    folders = set()
    back = []
    for r in rows:
        original = Path(r["source"])
        if Path(f"{original}{SIDECAR_SUFFIX}").exists():
            data = SidecarService.load(original)
            block = data.get(LOCATION_BLOCK)
            if isinstance(block, dict) and ("title" in block or "group" in block):
                block.pop("title", None)
                block.pop("group", None)
                SidecarService.save(original, data)
        folders.add(Path(r["destination"]).parent)
        back.append((str(original), r["sidecar_source"] or "", None, r["destination"]))
    if db_path and Path(db_path).exists():
        move_index_rows(db_path, back)
    remove_empty_folders(folders)
    from mindit.services.contactsheet.contact_sheet import refresh_sheets  # pylint: disable=import-outside-toplevel

    refresh_sheets({Path(r["source"]).parent for r in rows}, create=False)


def remove_empty_folders(folders: set[Path] | list[Path]) -> list[Path]:
    """Remove folders left with nothing but a contact sheet (and the sheet); return those removed."""
    from mindit.services.contactsheet.contact_sheet import SHEET_NAME  # pylint: disable=import-outside-toplevel

    removed = []
    for folder in folders:
        if not folder.is_dir():
            continue
        rest = [p for p in folder.iterdir() if p.name.lower() != SHEET_NAME]
        if not rest:
            (folder / SHEET_NAME).unlink(missing_ok=True)
            folder.rmdir()
            removed.append(folder)
    return removed


def summary(group: Group) -> dict[str, Any]:
    """Return a group's dates, size and places, for showing and for the run record."""
    return {"photos": len(group.shots), "start": group.start.isoformat(), "end": group.end.isoformat(),
            "places": [{"place": place_name(p), "photos": n} for p, n in group.places()],
            "first": group.shots[0].path.name, "title": group.title}


def write_plan(plan: GroupPlan, path: Path) -> Path:
    """Save the plan as JSON beside the move log."""
    path.write_text(json.dumps({
        "month": str(plan.month),
        "folders": {str(f): summary(g) for f, g in plan.folders.items()},
        "moves": [{"source": str(m.source), "destination": str(m.destination)} for m in plan.moves],
        "conflicts": [str(p) for p in plan.conflicts],
    }, indent=2), encoding="utf-8")
    return path


# --------------------------------------------------------------------------- renaming

class RenameError(Exception):
    """A location folder can't be renamed (not a location folder, no dated photos, or the name is taken)."""


def month_of(folder: Path) -> Path:
    """Return the month folder a location folder belongs to; raise RenameError if it isn't one."""
    from mindit.services.location.folders import is_month_folder  # pylint: disable=import-outside-toplevel

    m = re.match(r"^(\d{4}-\d{2})", folder.name)
    month = folder.parent / m.group(1) if m else None
    if (month is None or not re.match(r"^\d{4}$", folder.parent.name) or folder.name == month.name
            or not is_month_folder(folder, month)):
        raise RenameError(f"{folder.name} isn't a location folder (like 2019-04 Easter (springfield-il)).")
    return month


def plan_rename(folder: Path, title: str, pattern: str) -> Path:
    """Return the folder's new path for a new title (its places and month stay); raise RenameError."""
    month_of(folder)
    title = clean_title(title)
    if not title:
        raise RenameError("Give a title.")
    shots, _old = folder_photos(folder)
    if not shots:
        raise RenameError(f"No dated photos in {folder.name}, so DA can't work out its name.")
    target = folder.parent / folder_name(pattern, Group(shots, title))
    if target != folder and target.exists() and os.path.normcase(str(target)) != os.path.normcase(str(folder)):
        raise RenameError(f"{target.name} already exists.")
    return target


def rename_folder(folder: Path, title: str, target: Path, db_path: Path | None) -> int:
    """Rename a location folder, set the new title in its sidecars and the index; return the sidecars changed."""
    from mindit.services.contactsheet.contact_sheet import make_sheet  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    title = clean_title(title)
    if target != folder:
        os.rename(folder, target)
    changed = 0
    rows = []
    for side in sorted(target.glob(f"*{SIDECAR_SUFFIX}")):
        path = side.with_name(side.name[: -len(SIDECAR_SUFFIX)])
        data = SidecarService.load(path)
        block = data.get(LOCATION_BLOCK) if isinstance(data.get(LOCATION_BLOCK), dict) else {}
        block.update({"title": title, "group": slug(target.name),
                      "updated_at": datetime.now().isoformat(timespec="seconds")})
        data[LOCATION_BLOCK] = block
        SidecarService.save(path, data)
        changed += 1
    for path in sorted(p for p in target.iterdir() if p.is_file() and not p.name.endswith(SIDECAR_SUFFIX)):
        side = Path(f"{path}{SIDECAR_SUFFIX}")
        rows.append((str(path), str(side) if side.exists() else "", title, str(folder / path.name)))
    if db_path and Path(db_path).exists():
        move_index_rows(db_path, rows)
    make_sheet(target)                                   # its heading is the folder's name
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("location_rename", f"renamed {folder.name} -> {target.name}", path=str(target))
    return changed
