# src/mindit/core/long_paths.py

"""Windows' 260-character path limit: is it lifted on this PC, would a path hit it, and lift it (as admin).

DA.exe and Python both say they can use long paths, but Windows only lets them when the PC's
LongPathsEnabled setting is 1. Until then a move to a path of 260 characters or more fails with
"The system cannot find the path specified".
"""

from __future__ import annotations

import os
import subprocess
from functools import lru_cache
from pathlib import Path

MAX_PATH = 260
KEY = r"SYSTEM\CurrentControlSet\Control\FileSystem"
COMMAND = ("New-ItemProperty -Path HKLM:\\SYSTEM\\CurrentControlSet\\Control\\FileSystem "
           "-Name LongPathsEnabled -Value 1 -PropertyType DWORD -Force")
TOO_LONG = "path too long for Windows (260 characters); turn on long paths: da install"


@lru_cache(maxsize=1)
def enabled() -> bool:
    """Return True when paths may be 260 characters or longer (always, away from Windows)."""
    if os.name != "nt":
        return True
    import winreg  # pylint: disable=import-outside-toplevel

    try:
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, KEY) as key:
            return winreg.QueryValueEx(key, "LongPathsEnabled")[0] == 1
    except OSError:
        return False


def too_long(*paths: Path | str) -> bool:
    """Return True when one of the paths is past Windows' limit and long paths are off."""
    return not enabled() and any(len(str(p)) >= MAX_PATH for p in paths)


def enable() -> bool:
    """Turn long paths on through an admin PowerShell (Windows asks first); return True when they're on."""
    if enabled():
        return True
    inner = COMMAND.replace("'", "''")
    try:
        subprocess.run(["powershell.exe", "-NoProfile", "-Command",
                        f"Start-Process powershell.exe -Verb RunAs -Wait -WindowStyle Hidden "
                        f"-ArgumentList '-NoProfile','-Command','{inner}'"],
                       check=False, capture_output=True, timeout=300)
    except (OSError, subprocess.TimeoutExpired):
        return False
    enabled.cache_clear()
    return enabled()
