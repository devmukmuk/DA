# src/mindit/__main__.py

from __future__ import annotations

import os
import sys
from pathlib import Path

from mindit import __app_name__
from mindit.config.archive import register_archive, resolve_archive
from mindit.config.bootstrap import get_env_config_dir, read_bootstrap_config_dir, resolve_user_config_dir
from mindit.config.settings import set_archive_root, set_config_root, set_profile_chosen
from mindit.commands import cli
from mindit.core.logging import log_command_end


def _extract_arg(argv: list[str], name: str) -> str | None:
    for index, arg in enumerate(argv):
        if arg == name and index + 1 < len(argv):
            return argv[index + 1]

        if arg.startswith(f"{name}="):
            return arg.split("=", 1)[1]

    return None


def _hoist_arg(argv: list[str], name: str) -> list[str]:
    """Move `name value` (or name=value) to the front, so it works after the command too."""
    for index, arg in enumerate(argv):
        if arg == name and index + 1 < len(argv):
            return [arg, argv[index + 1], *argv[:index], *argv[index + 2:]]
        if arg.startswith(f"{name}="):
            return [arg, *argv[:index], *argv[index + 1:]]
    return argv


# Options naming another archive (`da split --to ...`, `da merge --from ...`): never the one to work in.
OTHER_ARCHIVE_OPTIONS = {"--to", "--from"}


def _existing_paths(argv: list[str]) -> list[Path]:
    """Return the arguments that name an existing file or folder (what a command works on)."""
    paths = []
    skip = False
    for arg in argv:
        if skip:
            skip = False
            continue
        if arg in OTHER_ARCHIVE_OPTIONS:
            skip = True
            continue
        if arg.startswith("-"):
            continue
        try:
            if Path(arg).exists():
                paths.append(Path(arg))
        except (OSError, ValueError):
            continue
    return paths


def _allow_big_pictures() -> None:
    """Let Pillow open very large scans and panoramas (its 89-megapixel guard is for pictures from the web)."""
    try:
        from PIL import Image  # pylint: disable=import-outside-toplevel

        Image.MAX_IMAGE_PIXELS = 1_000_000_000
    except ImportError:
        pass


def main() -> None:
    _allow_big_pictures()
    argv = _hoist_arg(sys.argv[1:], "--archive")   # da validate S:\more-fotos --archive D:\jane-archive-198x
    cli_config_dir = _extract_arg(argv, "--config-dir")
    resolved_config_dir = resolve_user_config_dir(cli_config_dir=cli_config_dir)
    set_config_root(resolved_config_dir)

    # An archive (a folder with da-archive.yaml) wins over profiles: --archive (before or after the
    # command), else the archive a folder named on the command line is in, else the current folder's
    # (or one above it), else the exe's own folder. An explicit --config-dir keeps the old way.
    if not cli_config_dir:
        exe_dir = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else None
        root = set_archive_root(resolve_archive(_extract_arg(argv, "--archive"), Path(os.getcwd()), exe_dir,
                                                targets=_existing_paths(argv)))
        if root is not None:
            # Opening an archive (e.g. its Open DA.cmd on a new PC) makes it one of this PC's archives.
            try:
                register_archive(root)
            except OSError:
                pass
    set_profile_chosen(bool(cli_config_dir or get_env_config_dir() or read_bootstrap_config_dir()))

    try:
        cli.app(args=argv, prog_name=__app_name__)
    except SystemExit as done:                       # Typer always ends with one
        log_command_end(done.code if isinstance(done.code, int) else (0 if done.code is None else 1))
        raise
    except BaseException as error:                   # pylint: disable=broad-except
        log_command_end(1, error)
        raise
    log_command_end(0)


if __name__ == "__main__":
    main()
