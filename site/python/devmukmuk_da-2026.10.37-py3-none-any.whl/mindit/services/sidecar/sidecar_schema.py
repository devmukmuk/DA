# src/mindit/services/sidecar/sidecar_schema.py

from __future__ import annotations

from copy import deepcopy
from typing import Any


SIDECAR_SCHEMA_NAME = "mindit.sidecar"
# 1: PhotoIt-era sidecars kept their old fields at the top level beside the blocks.
# 2: blocks only. The old top-level fields live in their blocks (where a value disagreed, under "legacy"),
#    and an empty "photoit"/"scanit" block isn't written (a photo has no scanit details, a document no photoit).
SIDECAR_SCHEMA_VERSION = 2

# Old top-level field -> (block, field) it belongs in. "imported_by" just goes.
LEGACY_FIELDS: dict[str, tuple[str, str] | None] = {
    "source_path": ("file", "source_path"),
    "current_path": ("file", "current_path"),
    "file_name": ("file", "file_name"),
    "extension": ("file", "extension"),
    "size_bytes": ("file", "size_bytes"),
    "created_at": ("file", "created_at"),
    "modified_at": ("file", "modified_at"),
    "sha256": ("file", "sha256"),
    "hash_sha256": ("file", "sha256"),
    "module": ("classification", "module"),
    "media_type": ("classification", "media_type"),
    "captured_at": ("photoit", "captured_at"),
    "original_file_name": ("photoit", "original_file_name"),
    "gps": ("photoit", "gps"),
    "tags": ("photoit", "tags"),
    "exif": ("photoit", "exif"),
    "dimensions": ("photoit", "dimensions"),
    "mime_type": ("photoit", "mime_type"),
    "paired_motion_file": ("photoit", "paired_motion_file"),
    "converted_jpeg": ("photoit", "converted_jpeg"),
    "duplicate_status": ("quarantine", "duplicate_status"),
    "duplicate_of": ("quarantine", "duplicate_of"),
    "meta_ref": ("scanit", "meta_ref"),
    "imported_by": None,
}
# The old fields that held a dict; any other top-level dict is a block of its own and stays.
DICT_FIELDS = {"gps", "exif", "dimensions", "meta_ref"}
# Blocks written only when they hold something.
OPTIONAL_BLOCKS = ("photoit", "scanit")


DEFAULT_SIDECAR: dict[str, Any] = {
    "schema": {
        "name": SIDECAR_SCHEMA_NAME,
        "version": SIDECAR_SCHEMA_VERSION,
    },
    "file": {
        "source_path": None,
        "current_path": None,
        "file_name": None,
        "extension": None,
        "size_bytes": None,
        "created_at": None,
        "modified_at": None,
        "sha256": None,
    },
    "classification": {
        "module": None,
        "media_type": None,
        "status": "active",
    },
    "photoit": {
        "captured_at": None,
        "original_file_name": None,
        "exif": {},
        "gps": {},
        "tags": [],
    },
    "scanit": {
        "document_date": None,
        "document_type": None,
        "ocr_status": None,
        "tags": [],
    },
    "validation": {
        "checked_at": None,
        "status": None,
        "problem_count": 0,
        "problems": [],
    },
    "quarantine": {
        "hash_status": "missing",
        "duplicate_status": "unknown",
        "duplicate_group_id": None,
        "duplicate_of": None,
        "duplicate_paths": [],
        "checked_at": None,
    },
    "history": [],
}


def default_sidecar() -> dict[str, Any]:
    return deepcopy(DEFAULT_SIDECAR)