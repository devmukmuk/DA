# src/mindit/services/sidecar/upgrade.py

"""`da sidecar upgrade`: bring older sidecars (.meta.json) up to the current schema, with a copy of each kept.

Any sidecar DA writes is already in the current schema; this does the rest at once: PhotoIt-era fields at the top
level move into their blocks (a value that disagrees is kept under "legacy"), empty photoit/scanit blocks go,
and a video's sidecar says "video". The photos and documents themselves are never touched. Each original
.meta.json is copied to output\\runs\\<time>-sidecars\\backup\\ first; `--restore <that folder>` puts them back.
"""

from __future__ import annotations

import json
import os
import shutil
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from mindit.services.sidecar.sidecar_schema import DICT_FIELDS, LEGACY_FIELDS, OPTIONAL_BLOCKS, SIDECAR_SCHEMA_VERSION
from mindit.services.sidecar.sidecar_service import SidecarService, _empty

SIDECAR_SUFFIX = ".meta.json"
SKIP_DIRS = {"$RECYCLE.BIN", "System Volume Information", ".da", ".mindit", ".validateit-quarantine"}


@dataclass
class UpgradePlan:
    """What an upgrade would change."""

    outdated: list[Path] = field(default_factory=list)      # sidecar files to rewrite
    current: int = 0
    orphans: list[Path] = field(default_factory=list)       # sidecars whose file is gone (left alone)
    unreadable: list[Path] = field(default_factory=list)
    changes: Counter = field(default_factory=Counter)       # what kind of change, how many sidecars
    versions: Counter = field(default_factory=Counter)


def _needs(raw: dict, file_path: Path) -> list[str]:
    """Return what's out of date in a stored sidecar (empty: nothing)."""
    from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS  # pylint: disable=import-outside-toplevel

    found = []
    schema = raw.get("schema") if isinstance(raw.get("schema"), dict) else {}
    if schema.get("version") != SIDECAR_SCHEMA_VERSION:
        found.append(f"schema {schema.get('version', 'none')} -> {SIDECAR_SCHEMA_VERSION}")
    old = [k for k in LEGACY_FIELDS if k in raw and (not isinstance(raw[k], dict) or k in DICT_FIELDS)]
    if old:
        found.append("old fields at the top moved into their blocks")
    for name in OPTIONAL_BLOCKS:
        block = raw.get(name)
        if isinstance(block, dict) and all(_empty(v) for v in block.values()):
            found.append(f"empty {name} block left out")
    classification = raw.get("classification") if isinstance(raw.get("classification"), dict) else {}
    if file_path.suffix.lower() in VIDEO_EXTENSIONS and classification.get("module") == "photoit" \
            and "video" in raw:
        found.append("video marked as a photo")
    return found


def sidecars_under(roots: list[Path]):
    """Yield every sidecar file under the folders given."""
    for root in roots:
        if not Path(root).is_dir():
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for name in filenames:
                if name.lower().endswith(SIDECAR_SUFFIX):
                    yield Path(dirpath, name)


def plan_upgrade(roots: list[Path], *, progress: Callable[[int], None] | None = None) -> UpgradePlan:
    """Look at every sidecar under the folders (reading only them) and say which are out of date, and how."""
    plan = UpgradePlan()
    for i, side in enumerate(sidecars_under(roots), 1):
        if progress and i % 2000 == 0:
            progress(i)
        try:
            raw = json.loads(side.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            plan.unreadable.append(side)
            continue
        if not isinstance(raw, dict):
            plan.unreadable.append(side)
            continue
        target = side.with_name(side.name[: -len(SIDECAR_SUFFIX)])
        plan.versions[str((raw.get("schema") or {}).get("version") if isinstance(raw.get("schema"), dict) else None)] += 1
        if not target.exists():
            plan.orphans.append(side)
            continue
        needs = _needs(raw, target)
        if not needs:
            plan.current += 1
            continue
        plan.outdated.append(side)
        for need in needs:
            plan.changes[need] += 1
    return plan


def apply_upgrade(plan: UpgradePlan, backup_root: Path, *, base: Path,
                  progress: Callable[[int, int], None] | None = None) -> Counter:
    """Copy each outdated sidecar to backup_root, then rewrite it in the current schema."""
    from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS  # pylint: disable=import-outside-toplevel
    from mindit.services.validateit.video_repair_provider import VideoRepairProvider  # pylint: disable=import-outside-toplevel

    stats: Counter = Counter()
    video = VideoRepairProvider()
    for i, side in enumerate(plan.outdated, 1):
        if progress:
            progress(i, len(plan.outdated))
        target = side.with_name(side.name[: -len(SIDECAR_SUFFIX)])
        try:
            keep = backup_root / _relative(side, base)
            keep.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(side, keep)
            if target.suffix.lower() in VIDEO_EXTENSIONS and video.supports(target):
                video.create_or_refresh_sidecar(target)
            else:
                SidecarService.save(target, SidecarService.load(target))
            stats["upgraded"] += 1
        except OSError as error:
            stats["failed"] += 1
            stats[f"failed: {type(error).__name__}"] += 1
    from mindit.core.logging import log_event  # pylint: disable=import-outside-toplevel

    log_event("sidecar_upgrade", f"upgraded {stats['upgraded']} sidecars (originals: {backup_root})",
              path=str(backup_root))
    return stats


def restore(backup_root: Path, base: Path) -> int:
    """Put the sidecars an upgrade kept back where they were; return how many."""
    count = 0
    for kept in sidecars_under([backup_root]):
        original = base / kept.relative_to(backup_root)
        if original.parent.exists():
            shutil.copy2(kept, original)
            count += 1
    return count


def _relative(path: Path, base: Path) -> Path:
    try:
        return path.resolve().relative_to(base.resolve())
    except ValueError:                                   # outside the archive: keep its drive and folders
        return Path(*[p.replace(":", "") for p in path.resolve().parts])
