# src/mindit/services/ocr/windows_ocr.py

"""Read the text in pictures with Windows' own OCR (Windows.Media.Ocr): nothing to install, signed by Microsoft.

One hidden Windows PowerShell (5.1, which can call Windows' WinRT classes) reads every picture of a run: DA sends
it a path per line and gets back a line of JSON - the words found, how much of the picture they cover, the text.
"""

from __future__ import annotations

import base64
import json
import os
import subprocess
from pathlib import Path
from typing import Any

# Pictures Windows can open for OCR (HEIC with the HEIF extension, which Windows 11 has).
OCR_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff", ".heic", ".heif", ".webp"}

SCRIPT = r"""
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [Text.Encoding]::UTF8
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
function Await($op, [type]$type) {
    $task = $asTask.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait(-1) | Out-Null
    $task.Result
}
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) { [Console]::Out.WriteLine('{"fatal":"Windows has no OCR language installed"}'); exit 2 }
$max = [Windows.Media.Ocr.OcrEngine]::MaxImageDimension
[Console]::Out.WriteLine((@{ ready = $true; language = $engine.RecognizerLanguage.LanguageTag } | ConvertTo-Json -Compress))
[Console]::Out.Flush()
while ($null -ne ($line = [Console]::In.ReadLine())) {
    if (-not $line) { continue }
    $out = [ordered]@{ path = $line }
    $stream = $null; $bitmap = $null
    try {
        $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($line)) ([Windows.Storage.StorageFile])
        $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $w = $decoder.OrientedPixelWidth; $h = $decoder.OrientedPixelHeight
        $scale = [Math]::Min(1.0, $max / [Math]::Max($w, $h))
        $transform = New-Object Windows.Graphics.Imaging.BitmapTransform
        $transform.ScaledWidth = [uint32][Math]::Max(1, [Math]::Floor($w * $scale))
        $transform.ScaledHeight = [uint32][Math]::Max(1, [Math]::Floor($h * $scale))
        $bitmap = Await ($decoder.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8,
            [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied, $transform,
            [Windows.Graphics.Imaging.ExifOrientationMode]::RespectExifOrientation,
            [Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
        $area = 0.0; $words = 0
        foreach ($l in $result.Lines) { foreach ($wd in $l.Words) { $words++; $area += $wd.BoundingRect.Width * $wd.BoundingRect.Height } }
        $out.words = $words
        $out.coverage = [Math]::Round($area / ([double]$transform.ScaledWidth * $transform.ScaledHeight), 4)
        $out.text = $result.Text
    } catch {
        $out.error = $_.Exception.InnerException.Message
        if (-not $out.error) { $out.error = $_.Exception.Message }
    } finally {
        if ($stream) { $stream.Dispose() }
        if ($bitmap) { $bitmap.Dispose() }
    }
    [Console]::Out.WriteLine(($out | ConvertTo-Json -Compress))
    [Console]::Out.Flush()
}
"""


class OcrUnavailable(RuntimeError):
    """Windows' OCR can't be used here."""


class WindowsOcr:
    """Read pictures one at a time through one hidden PowerShell; use it with `with`."""

    engine = "windows"

    def __init__(self) -> None:
        self._process: subprocess.Popen | None = None
        self.language = ""

    def __enter__(self) -> "WindowsOcr":
        self.start()
        return self

    def __exit__(self, *_exc: Any) -> None:
        self.close()

    def start(self) -> None:
        """Start PowerShell and wait until the OCR engine is ready."""
        if os.name != "nt":
            raise OcrUnavailable("reading text in pictures needs Windows (10 or 11)")
        encoded = base64.b64encode(SCRIPT.encode("utf-16-le")).decode("ascii")
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        try:
            self._process = subprocess.Popen(  # pylint: disable=consider-using-with
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                encoding="utf-8", errors="replace", bufsize=1, creationflags=flags)
        except OSError as exc:
            raise OcrUnavailable(f"Windows PowerShell couldn't be started: {exc}") from None
        first = json.loads(self._read_line() or '{"fatal": "PowerShell stopped"}')
        if not first.get("ready"):
            self.close()
            raise OcrUnavailable(first.get("fatal") or "Windows' OCR didn't start")
        self.language = first.get("language") or ""

    def read(self, path: Path) -> dict[str, Any]:
        """Return {words, coverage, text} for one picture, or {error}."""
        if self._process is None or self._process.poll() is not None:
            self.close()
            self.start()                               # it stopped (a bad file can do that): start again
        assert self._process is not None and self._process.stdin is not None
        self._process.stdin.write(str(Path(path).resolve()) + "\n")
        self._process.stdin.flush()
        line = self._read_line()
        if not line:
            self.close()
            return {"error": "Windows' OCR stopped on this file"}
        try:
            return json.loads(line)
        except ValueError:
            return {"error": f"unexpected answer: {line[:80]}"}

    def _read_line(self) -> str:
        assert self._process is not None and self._process.stdout is not None
        return self._process.stdout.readline().strip()

    def close(self) -> None:
        """Stop PowerShell."""
        if self._process is not None:
            try:
                if self._process.stdin:
                    self._process.stdin.close()
                self._process.wait(timeout=10)
            except (OSError, subprocess.TimeoutExpired):
                self._process.kill()
            self._process = None
