"""Naming: the tokens and patterns DA names files and folders with."""
