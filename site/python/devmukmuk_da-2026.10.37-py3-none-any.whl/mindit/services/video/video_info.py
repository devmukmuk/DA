# src/mindit/services/video/video_info.py

"""When and how a video was recorded, read from the file itself - no extra programs needed.

MOV / MP4 / M4V / 3GP (the QuickTime family, which phones and most cameras write) keep it in "atoms": the
movie header (`mvhd`: created, in UTC, and the length), Apple's metadata keys (`com.apple.quicktime.creationdate`
with the local time and zone, make, model, the GPS position, and the content identifier that marks the video
half of a Live Photo) and the older `©day`/`©xyz` entries. AVI keeps a date in its `IDIT` chunk. Anything else
(MPG, MTS, WMV, MKV) has no date DA reads; its file name may still have one.
"""

from __future__ import annotations

import re
import struct
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, BinaryIO

from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS  # noqa: F401  (re-exported)

QUICKTIME_EXTENSIONS = {".mov", ".mp4", ".m4v", ".3gp", ".3g2"}
LIVE_PHOTO_MAX_SECONDS = 4.0          # a Live Photo's video is about 3 seconds

_EPOCH_1904 = datetime(1904, 1, 1, tzinfo=timezone.utc)
_CONTAINERS = {b"moov", b"trak", b"mdia", b"minf", b"udta", b"meta", b"ilst", b"edts", b"stbl"}
_ISO6709 = re.compile(r"([+-]\d+(?:\.\d+)?)([+-]\d+(?:\.\d+)?)([+-]\d+(?:\.\d+)?)?")
_MAX_ATOM_READ = 1 << 20              # metadata atoms are small; never read a media atom into memory


def read_video_info(path: Path) -> dict[str, Any] | None:
    """Return what the video says about itself (created, duration, make, model, gps, live_photo), or None."""
    suffix = Path(path).suffix.lower()
    try:
        with open(path, "rb") as handle:
            if suffix in QUICKTIME_EXTENSIONS:
                return _quicktime(handle)
            if suffix == ".avi":
                return _avi(handle)
    except (OSError, struct.error, ValueError):
        return None
    return None


def utc_only(info: dict[str, Any] | None) -> bool:
    """Return True when the only date is the movie header's UTC time (converted with this PC's time zone)."""
    info = info or {}
    return info.get("local_created") is None and info.get("created") is not None


def recorded_at(info: dict[str, Any] | None, now: datetime | None = None) -> datetime | None:
    """Return when the video was recorded, as local wall-clock time (like a photo's EXIF), or None."""
    info = info or {}
    value = info.get("local_created") or info.get("created")
    if value is None:
        return None
    if value.tzinfo is not None:                       # mvhd's UTC: this PC's time zone is the best guess
        value = value.astimezone().replace(tzinfo=None)
    now = now or datetime.now()
    if not datetime(1980, 1, 2) <= value <= now + timedelta(days=1):   # an unset camera clock, or nonsense
        return None
    return value


def is_live_photo_video(info: dict[str, Any] | None) -> bool:
    """Return True for the video half of an iPhone Live Photo (Apple's content id, and only a few seconds)."""
    info = info or {}
    duration = info.get("duration")
    return bool(info.get("content_id")) and duration is not None and duration <= LIVE_PHOTO_MAX_SECONDS


# --------------------------------------------------------------------------- QuickTime / MP4

def _atoms(handle: BinaryIO, start: int, end: int):
    """Yield (type, payload start, payload end) for the atoms between start and end."""
    pos = start
    while pos + 8 <= end:
        handle.seek(pos)
        header = handle.read(8)
        if len(header) < 8:
            return
        size, kind = struct.unpack(">I4s", header)
        head = 8
        if size == 1:                                  # a 64-bit size follows
            size = struct.unpack(">Q", handle.read(8))[0]
            head = 16
        elif size == 0:                                # to the end of the file
            size = end - pos
        if size < head:
            return
        yield kind, pos + head, min(pos + size, end)
        pos += size


def _quicktime(handle: BinaryIO) -> dict[str, Any] | None:
    handle.seek(0, 2)
    end = handle.tell()
    info: dict[str, Any] = {}
    found_moov = False
    for kind, start, stop in _atoms(handle, 0, end):
        if kind == b"moov":
            found_moov = True
            _walk_moov(handle, start, stop, info)
    return info if found_moov else None


def _walk_moov(handle: BinaryIO, start: int, stop: int, info: dict[str, Any]) -> None:
    keys: list[str] = []
    for kind, a, b in _atoms(handle, start, stop):
        if kind == b"mvhd":
            _mvhd(handle, a, info)
        elif kind == b"meta":
            inner = a
            handle.seek(a)
            if handle.read(4) == b"\x00\x00\x00\x00":     # an MP4-style meta has a version/flags word
                inner = a + 4
            for kind2, c, d in _atoms(handle, inner, b):
                if kind2 == b"keys":
                    keys = _keys(handle, c, d)
                elif kind2 == b"ilst":
                    _ilst(handle, c, d, keys, info)
        elif kind == b"udta":
            for kind2, c, d in _atoms(handle, a, b):
                if kind2 in (b"\xa9day", b"\xa9xyz") and d - c < _MAX_ATOM_READ:
                    handle.seek(c)
                    raw = handle.read(d - c)
                    text = raw[4:].decode("utf-8", "ignore") if len(raw) > 4 else ""
                    _set_value(info, "day" if kind2 == b"\xa9day" else "xyz", text)
                elif kind2 == b"meta":
                    _walk_moov(handle, c + 4, d, info)      # some cameras put an ilst here
        elif kind in _CONTAINERS and kind != b"meta":
            _walk_moov(handle, a, b, info)


def _mvhd(handle: BinaryIO, start: int, info: dict[str, Any]) -> None:
    handle.seek(start)
    version = handle.read(1)[0]
    handle.read(3)
    if version == 1:
        created, _modified, scale, duration = struct.unpack(">QQIQ", handle.read(28))
    else:
        created, _modified, scale, duration = struct.unpack(">IIII", handle.read(16))
    if created:
        info["created"] = _EPOCH_1904 + timedelta(seconds=created)
    if scale:
        info["duration"] = round(duration / scale, 2)


def _keys(handle: BinaryIO, start: int, stop: int) -> list[str]:
    handle.seek(start + 4)                             # version + flags
    count = struct.unpack(">I", handle.read(4))[0]
    names = []
    for _ in range(min(count, 512)):
        size, _namespace = struct.unpack(">I4s", handle.read(8))
        if size < 8 or handle.tell() + size - 8 > stop:
            break
        names.append(handle.read(size - 8).decode("utf-8", "ignore"))
    return names


def _ilst(handle: BinaryIO, start: int, stop: int, keys: list[str], info: dict[str, Any]) -> None:
    for kind, a, b in _atoms(handle, start, stop):
        index = struct.unpack(">I", kind)[0]
        name = keys[index - 1] if keys and 1 <= index <= len(keys) else kind.decode("latin-1")
        for kind2, c, d in _atoms(handle, a, b):
            if kind2 == b"data" and d - c < _MAX_ATOM_READ:
                handle.seek(c + 8)                     # type + locale
                text = handle.read(d - c - 8).decode("utf-8", "ignore")
                _set_value(info, name, text)


def _set_value(info: dict[str, Any], name: str, text: str) -> None:
    text = text.strip("\x00 ").strip()
    if not text:
        return
    key = name.rsplit(".", 1)[-1].lower() if name.startswith("com.apple.") else name.lstrip("\xa9").lower()
    if key in ("creationdate", "day"):
        when = _parse_when(text)
        if when is not None and ("local_created" not in info or key == "creationdate"):
            info["local_created"] = when
    elif key in ("make", "model", "software"):
        info.setdefault(key, text)
    elif key in ("location.iso6709", "iso6709", "xyz"):
        m = _ISO6709.match(text)
        if m:
            lat, lon = float(m.group(1)), float(m.group(2))
            if (lat, lon) != (0.0, 0.0):
                info["gps"] = {"latitude": round(lat, 6), "longitude": round(lon, 6),
                               "altitude": float(m.group(3)) if m.group(3) else None}
    elif key in ("content.identifier", "identifier"):
        info["content_id"] = text


def _parse_when(text: str) -> datetime | None:
    """Return the local wall-clock time from '2021-06-01T10:00:00-0700' (or '2021-06-01'), zone dropped."""
    text = text.strip()
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?", text)
    if not m:
        return None
    try:
        return datetime(*(int(v) for v in m.groups(default="0")))
    except ValueError:
        return None


# --------------------------------------------------------------------------- AVI

def _avi(handle: BinaryIO) -> dict[str, Any] | None:
    head = handle.read(12)
    if len(head) < 12 or head[:4] != b"RIFF" or head[8:12] != b"AVI ":
        return None
    handle.seek(0)
    data = handle.read(1 << 16)                        # the header list is at the start
    header = data.split(b"movi", 1)[0]                # the picture data starts at "movi"
    pos = header.find(b"IDIT")
    if pos >= 0:
        size = struct.unpack("<I", header[pos + 4:pos + 8])[0]
        text = header[pos + 8:pos + 8 + min(size, 64)].decode("latin-1", "ignore").strip("\x00\r\n ")
        for fmt in ("%a %b %d %H:%M:%S %Y", "%Y:%m:%d %H:%M:%S", "%Y-%m-%d %H:%M:%S"):
            try:
                return {"local_created": datetime.strptime(text, fmt)}
            except ValueError:
                continue
    # Many cameras (Casio, Nikon, Fuji) put a photo-style EXIF date in the header instead.
    m = re.search(rb"(?<!\d)((?:19|20)\d\d):(\d\d):(\d\d) (\d\d):(\d\d):(\d\d)(?!\d)", header)
    if m:
        try:
            return {"local_created": datetime(*(int(v) for v in m.groups()))}
        except ValueError:
            pass
    return {}
