# src/mindit/services/contactsheet/contact_sheet.py

"""A folder's contact sheet: `_contact-sheet.pdf`, small pictures of every photo in the folder.

Page 1 sums the folder up (dates, counts, GPS, places, the cameras and who used them, sidecar versions);
then the photos follow, one section per camera, each page headed "<folder> - <camera> / <owner>". A photo
with a GPS position has "GPS" down its left edge, and every picture has its sidecar's schema version in a
circle at its top right.

Everything but the pictures comes from the sidecars (one small JSON read per photo): no database, and no
photo is opened except to draw its thumbnail. The PDF records a fingerprint of what it shows (names, sizes,
those sidecar details, the layout) in its Subject, so DA can tell when the sheet needs making again. `da run`
makes one for each folder it files into; `da validate` remakes changed ones; `da contact-sheets <folder>` makes
them for a whole tree. Layout: `--layout 3x4` (the default, bigger pictures) or `4x5`, or `contact_sheets:
layout:` in da-archive.yaml.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

SHEET_NAME = "_contact-sheet.pdf"
SUBJECT_PREFIX = "da-contact-sheet "
SHEET_DESIGN = "2"                   # bump when the drawing changes, so old sheets are made again
DEFAULT_LAYOUT = "3x4"

# What Pillow can draw (camera raw files aren't shown).
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".tif", ".tiff", ".bmp", ".gif"}
# Videos get a tile too (a "video" card with its length; DA doesn't decode video frames).
VIDEO_TILE_EXTENSIONS = {".mov", ".mp4", ".m4v", ".3gp", ".3g2", ".avi", ".mpg", ".mpeg", ".mts", ".m2ts",
                         ".wmv", ".mkv", ".webm"}
UNKNOWN_CAMERA = "Unknown camera"

_NAME_DATE = re.compile(r"(?:photo|doc|video)_(\d{4}|\d{2})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})")
_LAYOUT = re.compile(r"^([1-6])x([1-8])$")

try:  # iPhone HEIC photos
    from pillow_heif import register_heif_opener

    register_heif_opener()
except ImportError:  # pragma: no cover - pillow-heif is in requirements
    pass


@dataclass
class SheetResult:
    """What a refresh did."""

    made: list[Path] = field(default_factory=list)
    removed: list[Path] = field(default_factory=list)
    current: int = 0
    failed: list[tuple[Path, str]] = field(default_factory=list)

    def as_dict(self) -> dict:
        """Return counts and the paths made, for run records."""
        return {"made": len(self.made), "removed": len(self.removed), "current": self.current,
                "failed": [f"{p}: {why}" for p, why in self.failed], "sheets": [str(p) for p in self.made]}


@dataclass(frozen=True)
class Facts:
    """What a sheet shows about one picture, all from its sidecar."""

    camera: str
    owner: str | None
    gps: bool
    schema: str                      # "2", "1", or "-" when there's no sidecar
    place: str | None
    seconds: float | None            # a video's length

    def key(self) -> str:
        """Return these facts as text, for the fingerprint."""
        return f"{self.camera}|{self.owner or ''}|{int(self.gps)}|{self.schema}|{self.place or ''}"


def is_sheet(path: Path) -> bool:
    """Return True for a contact sheet file (never validated, indexed or filed)."""
    return path.name.lower() == SHEET_NAME


def photos_in(folder: Path) -> list[Path]:
    """Return the pictures directly in folder, in name order (that's date order for filed photos)."""
    try:
        entries = [e for e in folder.iterdir() if e.is_file() and _on_sheet(e)]
    except OSError:
        return []
    return sorted(entries, key=lambda p: p.name.lower())


def layout_size(layout: str | None = None) -> tuple[int, int]:
    """Return (columns, rows) for "3x4"; with no layout given, the archive's setting, else 3x4."""
    if layout is None:
        try:
            from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

            layout = load_settings().contact_sheets.layout
        except Exception:  # pylint: disable=broad-except
            layout = DEFAULT_LAYOUT
    m = _LAYOUT.match(str(layout).strip().lower())
    if not m:
        raise ValueError(f"a layout looks like 3x4 or 4x5 (columns x rows), not {layout!r}")
    return int(m.group(1)), int(m.group(2))


# --------------------------------------------------------------------------- facts from sidecars

def photo_facts(path: Path) -> Facts:
    """Return a picture's camera, owner, GPS, sidecar version and place - from its sidecar alone."""
    try:
        raw = json.loads(Path(f"{path}.meta.json").read_text(encoding="utf-8"))
        raw = raw if isinstance(raw, dict) else {}
        has_sidecar = True
    except (OSError, ValueError):
        raw, has_sidecar = {}, False
    schema = raw.get("schema") if isinstance(raw.get("schema"), dict) else {}
    camera_block = raw.get("camera") if isinstance(raw.get("camera"), dict) else {}
    video = raw.get("video") if isinstance(raw.get("video"), dict) else {}
    auto = raw.get("auto_tags") if isinstance(raw.get("auto_tags"), dict) else {}
    tags = [t for t in auto.get("tags") or [] if isinstance(t, str)]
    return Facts(camera=_camera(camera_block, video, tags), owner=_owner(camera_block, tags),
                 gps=_has_gps(raw), schema=str(schema.get("version")) if has_sidecar and schema.get("version") else
                 ("?" if has_sidecar else "-"), place=_place(raw), seconds=video.get("duration_seconds"))


def _camera(camera_block: dict, video: dict, tags: list[str]) -> str:
    from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel

    name = camera_name(camera_block) if (camera_block.get("make") or camera_block.get("model")) else None
    if not name:
        name = camera_name(video) if (video.get("make") or video.get("model")) else None
    if not name:
        slug = next((t.split(":", 1)[1] for t in tags if t.startswith("camera:")), None)
        if slug:
            from mindit.services.report.archive_report import nice_name  # pylint: disable=import-outside-toplevel

            name = nice_name(slug)
    return name or UNKNOWN_CAMERA


def _owner(camera_block: dict, tags: list[str]) -> str | None:
    owner = next((t.split(":", 1)[1] for t in tags if t.startswith("owner:")), None)
    return owner or camera_block.get("owner") or camera_block.get("artist") or None


def _has_gps(raw: dict) -> bool:
    from mindit.services.location.places import manual_position, position  # pylint: disable=import-outside-toplevel

    return position(raw) is not None or manual_position(raw) is not None


def _place(raw: dict) -> str | None:
    location = raw.get("location") if isinstance(raw.get("location"), dict) else {}
    if not isinstance(location.get("place"), dict):
        return None
    from mindit.services.location.places import place_name  # pylint: disable=import-outside-toplevel

    return place_name(location["place"])


def fingerprint(photos: Iterable[Path], layout: str | None = None, facts: dict[Path, Facts] | None = None) -> str:
    """Return a short fingerprint of what a sheet shows: the design, layout, names, sizes and sidecar facts."""
    cols, rows = layout_size(layout)
    digest = hashlib.sha1(f"design {SHEET_DESIGN} {cols}x{rows}\n".encode("utf-8"))
    for photo in photos:
        try:
            size = photo.stat().st_size
        except OSError:
            size = -1
        fact = (facts or {}).get(photo) or photo_facts(photo)
        digest.update(f"{photo.name.lower()}\t{size}\t{fact.key()}\n".encode("utf-8"))
    return digest.hexdigest()[:16]


def recorded_fingerprint(sheet: Path) -> str | None:
    """Return the fingerprint stored in a sheet, or None when it has none or can't be read."""
    try:
        from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

        subject = str((PdfReader(sheet, strict=False).metadata or {}).get("/Subject") or "")
    except Exception:  # pylint: disable=broad-except
        return None
    return subject[len(SUBJECT_PREFIX):].strip() if subject.startswith(SUBJECT_PREFIX) else None


def is_current(folder: Path, layout: str | None = None) -> bool:
    """Return True when folder's sheet exists and shows exactly what the folder holds now."""
    sheet = folder / SHEET_NAME
    return sheet.exists() and recorded_fingerprint(sheet) == fingerprint(photos_in(folder), layout)


def caption_date(name: str) -> str:
    """Return 'YYYY-MM-DD HH:MM' from a DA name (photo_19980704_101500_ab12.jpg), else ''."""
    m = _NAME_DATE.search(name)
    if not m:
        return ""
    year = m.group(1) if len(m.group(1)) == 4 else f"20{m.group(1)}"
    return f"{year}-{m.group(2)}-{m.group(3)} {m.group(4)}:{m.group(5)}"


def _on_sheet(path: Path) -> bool:
    """Return True for a photo, or a video that isn't a Live Photo's (that one shows as its photo)."""
    suffix = path.suffix.lower()
    if suffix in IMAGE_EXTENSIONS:
        return True
    if suffix in VIDEO_TILE_EXTENSIONS:
        from mindit.services.validateit.validateit_file_types import still_for_video  # pylint: disable=import-outside-toplevel

        return still_for_video(path) is None
    return False


def _length_text(seconds: float | None, video: Path | None = None) -> str:
    """Return '1:06' for a video's length (from the sidecar's figure, else the file), or ''."""
    if seconds is None and video is not None:
        from mindit.services.video.video_info import read_video_info  # pylint: disable=import-outside-toplevel

        seconds = (read_video_info(video) or {}).get("duration")
    if not seconds:
        return ""
    minutes, secs = divmod(int(round(seconds)), 60)
    return f"{minutes // 60}:{minutes % 60:02d}:{secs:02d}" if minutes >= 60 else f"{minutes}:{secs:02d}"


def _thumbnail(photo: Path, box: tuple[int, int]):
    """Return a reportlab ImageReader of a small copy of photo, or None when it can't be read."""
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel

    try:
        with Image.open(photo) as img:
            if img.format == "JPEG":
                img.draft("RGB", (box[0] * 2, box[1] * 2))       # decode at reduced size: much faster
            img = ImageOps.exif_transpose(img)
            img.thumbnail((box[0] * 2, box[1] * 2))
            out = io.BytesIO()
            img.convert("RGB").save(out, "JPEG", quality=80)
        out.seek(0)
        return ImageReader(out)
    except Exception:  # pylint: disable=broad-except
        return None


# --------------------------------------------------------------------------- the sheet

def camera_groups(photos: list[Path], facts: dict[Path, Facts]) -> list[tuple[str, str | None, list[Path]]]:
    """Return the photos by camera and owner, most photos first (an unknown camera last), each in date order."""
    groups: dict[tuple[str, str | None], list[Path]] = {}
    for photo in photos:
        fact = facts[photo]
        groups.setdefault((fact.camera, fact.owner), []).append(photo)
    order = sorted(groups.items(), key=lambda kv: (kv[0][0] == UNKNOWN_CAMERA, -len(kv[1]), kv[0][0].lower()))
    return [(camera, owner, items) for (camera, owner), items in order]


def make_sheet(folder: Path, *, title: str | None = None, version: str = "", layout: str | None = None) -> Path | None:
    """Write folder's contact sheet; with no photos left, remove an old sheet. Return the sheet or None."""
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    sheet = folder / SHEET_NAME
    photos = photos_in(folder)
    if not photos:
        sheet.unlink(missing_ok=True)
        return None

    cols, rows = layout_size(layout)
    facts = {photo: photo_facts(photo) for photo in photos}
    groups = camera_groups(photos, facts)
    per_page = cols * rows
    first_page: dict[tuple[str, str | None], int] = {}
    page_no = 2
    for camera, owner, items in groups:
        first_page[(camera, owner)] = page_no
        page_no += (len(items) + per_page - 1) // per_page
    pages = page_no - 1
    label = title or folder.name

    tmp = sheet.with_name(sheet.name + ".tmp")
    pdf = canvas.Canvas(str(tmp), pagesize=letter)
    pdf.setTitle(f"Contact sheet: {label}")
    pdf.setSubject(SUBJECT_PREFIX + fingerprint(photos, f"{cols}x{rows}", facts))
    pdf.setCreator(f"DA v{version}" if version else "DA")
    made_on = datetime.now().strftime("%Y-%m-%d %H:%M")
    footer = f"Made by DA{' v' + version if version else ''} on {made_on}"

    _summary_page(pdf, letter, label, photos, facts, groups, first_page, pages, footer)
    page = 1
    for camera, owner, items in groups:
        for start in range(0, len(items), per_page):
            page += 1
            _photo_page(pdf, letter, f"{label} - {camera}" + (f" / {owner}" if owner else ""),
                        items[start:start + per_page], facts, (cols, rows), page, pages,
                        f"{len(items):,} {'picture' if len(items) == 1 else 'pictures'} from this camera", footer)
    pdf.save()
    os.replace(tmp, sheet)
    return sheet


def _summary_page(pdf, size, label: str, photos: list[Path], facts: dict[Path, Facts],
                  groups, first_page: dict, pages: int, footer: str) -> None:  # pylint: disable=too-many-locals,too-many-arguments
    width, height = size
    margin = 40
    videos = sum(1 for p in photos if p.suffix.lower() in VIDEO_TILE_EXTENSIONS)
    stills = len(photos) - videos
    dates = sorted(d for d in (caption_date(p.name) for p in photos) if d)
    with_gps = sum(1 for p in photos if facts[p].gps)
    places = Counter(facts[p].place for p in photos if facts[p].place)
    schemas = Counter(facts[p].schema for p in photos)

    pdf.setFillColorRGB(0.17, 0.43, 0.57)
    pdf.rect(0, height - 74, width, 74, stroke=0, fill=1)
    pdf.setFillGray(1)
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(margin, height - 40, label)
    pdf.setFont("Helvetica", 10.5)
    counts = f"{stills:,} photo{'s' if stills != 1 else ''}" + (f", {videos:,} video{'s' if videos != 1 else ''}" if videos else "")
    span = (f"{dates[0][:10]} to {dates[-1][:10]}" if dates and dates[0][:10] != dates[-1][:10]
            else (dates[0][:10] if dates else "no dates in the names"))
    pdf.drawString(margin, height - 60, f"Contact sheet   |   {counts}   |   {span}   |   {pages} pages")

    y = height - 104

    def heading(text: str) -> None:
        nonlocal y
        pdf.setFillColorRGB(0.17, 0.43, 0.57)
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawString(margin, y, text.upper())
        pdf.setStrokeGray(0.8)
        pdf.line(margin, y - 4, width - margin, y - 4)
        y -= 22

    def row(cells: list[tuple[float, str, str]], *, bold: bool = False, gray: float = 0.1) -> None:
        nonlocal y
        pdf.setFillGray(gray)
        pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 10.5)
        for x, text, align in cells:
            if align == "r":
                pdf.drawRightString(x, y, text)
            else:
                pdf.drawString(x, y, text)
        y -= 15

    heading("This month")
    row([(margin, "Pictures with a GPS position", "l"), (width - margin, f"{with_gps:,} of {len(photos):,}", "r")])
    if places:
        shown = ", ".join(f"{name} ({n:,})" for name, n in places.most_common(6))
        more = f" and {len(places) - 6} more" if len(places) > 6 else ""
        row([(margin, "Places", "l"), (width - margin, shown + more, "r")])
    sidecars = ", ".join(f"schema {v} ({n:,})" if v not in ("-", "?") else
                         ("no sidecar" if v == "-" else "no version") + f" ({n:,})"
                         for v, n in sorted(schemas.items(), reverse=True))
    row([(margin, "Sidecars", "l"), (width - margin, sidecars, "r")])
    y -= 10

    heading("Cameras")
    cam_x, own_x, num_x, date_x, page_x = margin, margin + 210, margin + 330, margin + 440, width - margin
    row([(cam_x, "Camera", "l"), (own_x, "Taken by", "l"), (num_x, "Pictures", "r"), (date_x, "Dates", "r"),
         (page_x, "Page", "r")], bold=True, gray=0.35)
    for camera, owner, items in groups[:24]:
        days = sorted(d[:10] for d in (caption_date(p.name) for p in items) if d)
        when = (f"{days[0][5:]} to {days[-1][5:]}" if days and days[0] != days[-1] else (days[0][5:] if days else ""))
        row([(cam_x, camera[:38], "l"), (own_x, (owner or "-")[:20], "l"), (num_x, f"{len(items):,}", "r"),
             (date_x, when, "r"), (page_x, str(first_page[(camera, owner)]), "r")])
    if len(groups) > 24:
        row([(cam_x, f"and {len(groups) - 24} more cameras", "l")], gray=0.4)
    y -= 12
    pdf.setFillGray(0.4)
    pdf.setFont("Helvetica", 9)
    pdf.drawString(margin, y, "On each picture: GPS down the left edge = it has a position; the number in the circle "
                              "= its sidecar's schema version.")
    _footer(pdf, size, footer, 1, pages)
    pdf.showPage()


def _photo_page(pdf, size, header: str, items: list[Path], facts: dict[Path, Facts], grid: tuple[int, int],
                page: int, pages: int, subheader: str, footer: str) -> None:  # pylint: disable=too-many-locals,too-many-arguments,too-many-statements
    width, height = size
    cols, rows = grid
    margin, head, foot = 36, 40, 20
    big = cols <= 3
    name_size, date_size = (8.5, 8.0) if big else (7.0, 7.0)
    caption = name_size + date_size + 10
    gutter = 13                                              # room for "GPS" down the left of each picture
    cell_w = (width - 2 * margin) / cols
    cell_h = (height - 2 * margin - head - foot) / rows
    box_w, box_h = cell_w - gutter - 8, cell_h - caption - 8

    top = height - margin
    pdf.setFillGray(0)
    pdf.setFont("Helvetica-Bold", 13)
    pdf.drawString(margin, top - 14, header[:90])
    pdf.setFont("Helvetica", 9)
    pdf.setFillGray(0.4)
    pdf.drawString(margin, top - 28, subheader)
    pdf.setStrokeGray(0.7)
    pdf.line(margin, top - head + 4, width - margin, top - head + 4)

    for i, photo in enumerate(items):
        col, row = i % cols, i // cols
        x = margin + col * cell_w
        y = top - head - (row + 1) * cell_h
        area_x, area_y = x + gutter, y + caption
        fact = facts[photo]
        image = _thumbnail(photo, (int(box_w * 2), int(box_h * 2))) if photo.suffix.lower() in IMAGE_EXTENSIONS else None
        if image is not None:
            iw, ih = image.getSize()
            scale = min(box_w / iw, box_h / ih)
            dw, dh = iw * scale, ih * scale
            ix, iy = area_x + (box_w - dw) / 2, area_y + (box_h - dh) / 2
            pdf.drawImage(image, ix, iy, dw, dh)
        else:
            dw, dh = box_w, box_h * 0.75
            ix, iy = area_x, area_y + (box_h - dh) / 2
            is_video = photo.suffix.lower() in VIDEO_TILE_EXTENSIONS
            pdf.setFillGray(0.18 if is_video else 0.9)
            pdf.rect(ix, iy, dw, dh, stroke=0, fill=1)
            pdf.setFillGray(1 if is_video else 0.4)
            if is_video:
                pdf.setFont("Helvetica-Bold", 13 if big else 11)
                pdf.drawCentredString(ix + dw / 2, iy + dh / 2 + 3, "VIDEO")
                pdf.setFont("Helvetica", 9 if big else 8)
                pdf.drawCentredString(ix + dw / 2, iy + dh / 2 - 11, _length_text(fact.seconds, photo))
            else:
                pdf.setFont("Helvetica", 8)
                pdf.drawCentredString(ix + dw / 2, iy + dh / 2, "(can't show this one)")
        if fact.gps:                                         # GPS, bold, reading up the picture's left edge
            pdf.saveState()
            pdf.setFillColorRGB(0.05, 0.45, 0.2)
            pdf.setFont("Helvetica-Bold", 9 if big else 8)
            pdf.translate(ix - 3, iy + dh / 2)
            pdf.rotate(90)
            pdf.drawCentredString(0, 0, "GPS")
            pdf.restoreState()
        radius = 7.5 if big else 6.5                         # the sidecar's schema version, circled, top right
        cx, cy = ix + dw - radius - 2, iy + dh - radius - 2
        pdf.setFillGray(1)
        pdf.setStrokeColorRGB(0.17, 0.43, 0.57)
        pdf.setLineWidth(1.2)
        pdf.circle(cx, cy, radius, stroke=1, fill=1)
        pdf.setFillColorRGB(0.17, 0.43, 0.57)
        pdf.setFont("Helvetica-Bold", 8.5 if big else 7.5)
        pdf.drawCentredString(cx, cy - 3, fact.schema)
        pdf.setLineWidth(1)

        pdf.setFillGray(0)
        pdf.setFont("Helvetica", name_size)
        limit = 38 if big else 34
        name = photo.name if len(photo.name) <= limit else photo.name[:limit - 3] + "..."
        pdf.drawCentredString(x + cell_w / 2, y + date_size + 6, name)
        when = caption_date(photo.name)
        if when:
            pdf.setFillGray(0.35)
            pdf.setFont("Helvetica", date_size)
            pdf.drawCentredString(x + cell_w / 2, y + 3, when)
    _footer(pdf, size, footer, page, pages)
    pdf.showPage()


def _footer(pdf, size, text: str, page: int, pages: int) -> None:
    width, _height = size
    pdf.setFont("Helvetica", 7.5)
    pdf.setFillGray(0.45)
    pdf.drawString(36, 22, text)
    pdf.drawRightString(width - 36, 22, f"page {page} of {pages}")
    pdf.setFillGray(0)


def refresh_sheets(folders: Iterable[Path], *, create: bool, version: str = "", layout: str | None = None,
                   progress: Callable[[str], None] | None = None) -> SheetResult:
    """Make sheets for folders whose photos changed; create=False only updates sheets that exist."""
    result = SheetResult()
    for folder in sorted(set(folders)):
        sheet = folder / SHEET_NAME
        if not create and not sheet.exists():
            continue
        if is_current(folder, layout):
            result.current += 1
            continue
        try:
            made = make_sheet(folder, version=version, layout=layout)
        except Exception as exc:  # pylint: disable=broad-except
            result.failed.append((folder, f"{type(exc).__name__}: {exc}"))
            continue
        if made is None:
            result.removed.append(sheet)
        else:
            result.made.append(made)
            if progress:
                progress(f"contact sheet: {made}")
    return result


def folders_with_photos(root: Path) -> list[Path]:
    """Return root and every folder under it that has photos directly in it."""
    found = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d != "_duplicates-holding"]
        if any(Path(f).suffix.lower() in IMAGE_EXTENSIONS | VIDEO_TILE_EXTENSIONS for f in filenames):
            found.append(Path(dirpath))
    return found


def folders_with_sheets(root: Path) -> list[Path]:
    """Return every folder under root (and root) that already has a contact sheet."""
    return [Path(d) for d, _dirs, files in os.walk(root) if any(f.lower() == SHEET_NAME for f in files)]
