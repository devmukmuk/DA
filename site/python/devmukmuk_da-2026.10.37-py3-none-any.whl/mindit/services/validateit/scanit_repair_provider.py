from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from datetime import datetime


from mindit.services.photoit.photoit_workflows import (
    _build_target_filename,
    _build_metadata_payload,
    _compute_sha256,
    _load_metadata_json,
    _default_metadata_path,
    _write_metadata_json,
    RenameFormatOptions,
)

from mindit.services.validateit.quarantine_hash_service import stored_or_computed_sha256
from mindit.services.validateit.capture_date import CaptureDate, resolve_capture_date
from mindit.config.settings import (
    load_settings,
    resolve_scanit_organized_path,
    resolve_scanit_quarantine_path,
    resolve_scanit_intake_path,
    get_rename_pattern,
)

from mindit.services.sidecar import SidecarService
from mindit.services.validateit.validateit_file_types import DOCUMENT_EXTENSIONS, MediaKind

class ScanItRepairProvider:
    name = "scanit"
    media_kind = MediaKind.DOCUMENT

    def __init__(self, pattern: str | None = None) -> None:
        self.pattern = pattern

    def supports(self, path: Path) -> bool:
        return path.suffix.lower() in DOCUMENT_EXTENSIONS

    def create_or_refresh_sidecar(self, path: Path, sha256: str | None = None) -> bool:
        metadata_path = _default_metadata_path(path)
        sha256 = sha256 or _compute_sha256(path)

        payload = _build_metadata_payload(
            source_path=path,
            current_path=path,
            sha256=sha256,
            original_file_name=path.name,
            original_source_path=str(path.resolve()),
        )

        _write_metadata_json(metadata_path, payload)

        # _write_metadata_json is PhotoIt's writer and labels the sidecar "photoit".
        classification = SidecarService.get_block(path, "classification")
        SidecarService.update_block(
            path,
            "classification",
            {**classification, "module": "scanit", "media_type": "document"},
        )
        return True

    def expected_name(self, path: Path) -> str | None:
        sidecar_path = self._sidecar_path_for_file(path)

        if not sidecar_path.exists():
            return None

        capture = self.capture_date(path)
        if not capture.certain:
            return None

        existing_metadata = _load_metadata_json(sidecar_path)
        capture_dt = capture.value
        sha256 = stored_or_computed_sha256(path)

        # Use default ScanIt pattern (or inject later)
        default_pattern = get_rename_pattern("scanit") or "{date_taken:%Y%m}_{hash:8}"
        options = RenameFormatOptions(pattern=default_pattern)

        new_name = _build_target_filename(
            source_path=path,
            capture_dt=capture_dt,
            existing_names=None,  # IMPORTANT: we are only planning
            rename_options=options,
            existing_metadata=existing_metadata,
            sha256=sha256,
        )

        if new_name == path.name:
            return None  # already correct

        return new_name

    def capture_date(self, path: Path) -> CaptureDate:
        """Return the file's capture date and where it came from."""
        return resolve_capture_date(path)

    def expected_folder(self, path: Path) -> Path | None:
        capture = self.capture_date(path)
        if not capture.certain:
            return None

        from mindit.services.naming.folders import expected_folder, in_place  # pylint: disable=import-outside-toplevel

        metadata = _load_metadata_json(self._sidecar_path_for_file(path)) or {}
        expected, _missing = expected_folder(path, resolve_scanit_organized_path(), capture.value, metadata, "document")

        if in_place(path.resolve(), expected.resolve()):
            return None

        return expected

    def _sidecar_path_for_file(self, path: Path) -> Path:
        return Path(f"{path}.meta.json")

    def _load_sidecar(self, sidecar_path: Path) -> dict[str, Any]:
        try:
            return json.loads(sidecar_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}

    def _load_photoit_pattern(self) -> str | None:
        settings = load_settings()

        # Adjust this if your actual config key is different.
        return getattr(settings.modules.photoit, "pattern", None)
