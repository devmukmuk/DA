# src/mindit/services/validateit/capture_date.py

"""Resolve a file's capture date and how much to trust it."""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import StrEnum
from pathlib import Path

from mindit.services.photoit.photoit_workflows import _read_exif_capture_datetime
from mindit.services.validateit.document_dates import DOCUMENT_DATE_EXTENSIONS, read_document_date
from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS
from mindit.utils.timestamps import UNREADABLE_FILE_TIME, safe_fromtimestamp


class CaptureDateSource(StrEnum):
    USER = "user"                      # set by hand (da date set / shift): wins over everything
    FILENAME = "filename"
    EXIF = "exif"
    DOCUMENT = "document"              # the creation date stored inside a PDF / Office file
    VIDEO = "video"                    # when a video was recorded, from the video file itself
    FILENAME_MONTH = "filename_month"
    FILENAME_YEAR = "filename_year"
    MODIFIED_TIME = "modified_time"


# Only these sources are trusted enough to rename or move a file automatically.
CERTAIN_SOURCES = {CaptureDateSource.USER, CaptureDateSource.FILENAME, CaptureDateSource.EXIF, CaptureDateSource.DOCUMENT,
                   CaptureDateSource.VIDEO}


@dataclass(frozen=True, slots=True)
class CaptureDate:
    value: datetime
    source: CaptureDateSource

    @property
    def certain(self) -> bool:
        return self.source in CERTAIN_SOURCES


# 2021_01_14, 2021-01-14, 20210114, optionally followed by a time: 20210201_094024.
_FULL_DATE = re.compile(
    r"(?<!\d)(?P<y>19\d{2}|20\d{2})[-_.]?(?P<m>0[1-9]|1[0-2])[-_.]?(?P<d>0[1-9]|[12]\d|3[01])"
    r"(?:[ _T-]?(?P<H>[01]\d|2[0-3])[-_.:]?(?P<M>[0-5]\d)[-_.:]?(?P<S>[0-5]\d))?(?!\d)"
)

# yymmdd_hhmmss, as in ScanIt's own doc_210203_140935_d7e9.pdf names. The time is required so
# arbitrary six-digit numbers aren't read as dates.
_SHORT_DATE_TIME = re.compile(
    r"(?<!\d)(?P<y>\d{2})(?P<m>0[1-9]|1[0-2])(?P<d>0[1-9]|[12]\d|3[01])"
    r"_(?P<H>[01]\d|2[0-3])(?P<M>[0-5]\d)(?P<S>[0-5]\d)(?!\d)"
)

# US-style month-day-year: 04-27-2010, 4.27.2010 (a date, no time).
_US_DATE = re.compile(
    r"(?<!\d)(?P<m>0?[1-9]|1[0-2])[-_.](?P<d>0?[1-9]|[12]\d|3[01])[-_.](?P<y>19\d{2}|20\d{2})(?!\d)"
)

# A month name and a year: April-2010, Apr 2010, "Resume, April 2010".
_MONTH_YEAR = re.compile(
    r"(?<![A-Za-z])(?P<mon>jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?"
    r"|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)(?![A-Za-z])[-_ .,]*"
    r"(?P<y>19\d{2}|20\d{2})(?!\d)",
    re.IGNORECASE,
)
_MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

# Default dates cameras write when their clock was never set. Treated as no EXIF date at all.
_UNSET_CAMERA_CLOCKS = {datetime(1970, 1, 1), datetime(1980, 1, 1)}

_BARE_YEAR = re.compile(r"(?<!\d)(?P<y>19\d{2}|20\d{2})(?!\d)")


def resolve_capture_date(path: Path, now: datetime | None = None) -> CaptureDate:
    """Return the best capture date for path, with the source it came from.

    Order: a date set by hand (`da date`), then a full date in the file name, then EXIF, then a bare year in the file name, then
    the file's modified time. A name with a date but no time (2022-05-11_EASTOW_1711.jpg)
    gives way to EXIF from that same day, which has the time too. A bare year that
    disagrees with EXIF wins over EXIF, because that is usually an old photo scanned or
    edited years later.
    """
    now = now or datetime.now()
    stem = path.stem

    # A date set by hand (`da date`) is kept in the sidecar and wins over everything.
    from mindit.services.dates.user_dates import read_user_date  # pylint: disable=import-outside-toplevel

    by_hand = read_user_date(path)
    if by_hand is not None:
        return CaptureDate(by_hand, CaptureDateSource.USER)

    # The date inside the file: EXIF for photos, the stored creation date for PDF / Office files.
    is_document = path.suffix.lower() in DOCUMENT_DATE_EXTENSIONS
    is_video = path.suffix.lower() in VIDEO_EXTENSIONS
    inside_source = (CaptureDateSource.DOCUMENT if is_document else
                     CaptureDateSource.VIDEO if is_video else CaptureDateSource.EXIF)

    filename_date, has_time = _filename_full_date(stem, now)
    exif_date = None
    if filename_date is not None and not has_time:
        exif_date = _inside_date(path, now, is_document)
        if exif_date is not None and exif_date.date() == filename_date.date():
            return CaptureDate(exif_date, inside_source)
    if filename_date is not None:
        return CaptureDate(filename_date, CaptureDateSource.FILENAME)

    exif_date = exif_date or _inside_date(path, now, is_document)

    month = _filename_month(stem, now)
    if month is not None:
        # "Resume April-2010": the date inside wins when it's from that month, else only the month is known.
        if exif_date is not None and (exif_date.year, exif_date.month) == month:
            return CaptureDate(exif_date, inside_source)
        return CaptureDate(datetime(month[0], month[1], 1), CaptureDateSource.FILENAME_MONTH)

    year = _filename_year(stem, now)

    if exif_date is not None and (year is None or year == exif_date.year):
        return CaptureDate(exif_date, inside_source)

    if year is not None:
        return CaptureDate(datetime(year, 1, 1), CaptureDateSource.FILENAME_YEAR)

    modified = safe_fromtimestamp(path.stat().st_mtime)
    return CaptureDate(modified or UNREADABLE_FILE_TIME, CaptureDateSource.MODIFIED_TIME)


def describe(capture: CaptureDate) -> str:
    """Return a short human description of an uncertain capture date."""
    if capture.source == CaptureDateSource.FILENAME_YEAR:
        return f"only a year ({capture.value.year}) is known, from the file name"
    if capture.source == CaptureDateSource.FILENAME_MONTH:
        return f"only a month ({capture.value:%B %Y}) is known, from the file name"
    if capture.source == CaptureDateSource.MODIFIED_TIME and capture.value == UNREADABLE_FILE_TIME:
        return "no date in the file or its name, and its modified time can't be read"
    if capture.source == CaptureDateSource.MODIFIED_TIME:
        return (
            f"no date in the file or its name; modified time "
            f"{capture.value:%Y-%m-%d %H:%M} is probably when it was copied"
        )
    return f"{capture.value:%Y-%m-%d %H:%M:%S} from {capture.source}"


def _filename_full_date(stem: str, now: datetime) -> tuple[datetime | None, bool]:
    """Return the first plausible date in the name and whether it included a time."""
    for pattern, short_year in ((_FULL_DATE, False), (_SHORT_DATE_TIME, True), (_US_DATE, False)):
        for match in pattern.finditer(stem):
            parts = match.groupdict()
            year = int(parts["y"])
            if short_year:
                year += 2000 if 2000 + year <= now.year else 1900

            try:
                value = datetime(
                    year,
                    int(parts["m"]),
                    int(parts["d"]),
                    int(parts.get("H") or 0),
                    int(parts.get("M") or 0),
                    int(parts.get("S") or 0),
                )
            except ValueError:
                continue

            if _plausible(value, now):
                return value, parts.get("H") is not None
    return None, False


def name_and_exif_taken(path: Path, now: datetime | None = None) -> tuple[datetime, datetime] | None:
    """Return (date+time in the name, EXIF date taken) when both exist and disagree, else None.

    Only a name with a full date and time counts (a DA photo_YYYYMMDD_HHMMSS_ name), and
    only EXIF's date-taken fields, not "last saved", which changes on every edit.
    """
    now = now or datetime.now()
    named, has_time = _filename_full_date(path.stem, now)
    if named is None or not has_time:
        return None
    raw = _read_exif_capture_datetime(path, include_last_saved=False)
    if not raw:
        return None
    try:
        taken = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if not _plausible(taken, now) or taken == named:
        return None
    return named, taken


_DATE_HHMM = re.compile(r"(?<!\d)(?P<y>19\d{2}|20\d{2})(?P<m>0[1-9]|1[0-2])(?P<d>0[1-9]|[12]\d|3[01])"
                        r"[-_ ](?P<H>[01]\d|2[0-3])(?P<M>[0-5]\d)(?!\d)")


def _name_date_hhmm(stem: str, now: datetime) -> datetime | None:
    """Return the date and hour-minute in a phone video's name (VID 00000-20091016-2017), or None."""
    m = _DATE_HHMM.search(stem)
    if not m:
        return None
    try:
        value = datetime(*(int(m[k]) for k in ("y", "m", "d", "H", "M")))
    except ValueError:
        return None
    return value if _plausible(value, now) else None


def _filename_year(stem: str, now: datetime) -> int | None:
    for match in _BARE_YEAR.finditer(stem):
        year = int(match["y"])
        if 1900 <= year <= now.year:
            return year
    return None


def _filename_month(stem: str, now: datetime) -> tuple[int, int] | None:
    """Return (year, month) for a month name and year in the name ("April-2010"), or None."""
    for match in _MONTH_YEAR.finditer(stem):
        year, month = int(match["y"]), _MONTHS[match["mon"].lower()[:3]]
        if 1900 <= year <= now.year:
            return year, month
    return None


def _inside_date(path: Path, now: datetime, is_document: bool) -> datetime | None:
    """The date stored inside the file: a document's creation date, a video's recording date, else EXIF."""
    if path.suffix.lower() in VIDEO_EXTENSIONS:
        from mindit.services.video.video_info import read_video_info, recorded_at, utc_only  # pylint: disable=import-outside-toplevel

        info = read_video_info(path)
        value = recorded_at(info, now)
        named = _name_date_hhmm(path.stem, now)
        # A UTC header time was turned into local time with THIS PC's time zone; a phone's name
        # (VID 00000-20091016-2017) has the local time where it was recorded. Same day or so: the name wins.
        if value is not None and named is not None and utc_only(info) and abs(value - named) < timedelta(hours=26):
            return named.replace(second=value.second)
        return value
    if not is_document:
        return _exif_date(path, now)
    value = read_document_date(path)
    if value is None or value in _UNSET_CAMERA_CLOCKS:
        return None
    return value if _plausible(value, now) else None


def _exif_date(path: Path, now: datetime) -> datetime | None:
    raw = _read_exif_capture_datetime(path)
    if not raw:
        return None

    try:
        value = datetime.fromisoformat(raw)
    except ValueError:
        return None

    if value in _UNSET_CAMERA_CLOCKS:
        return None                      # a camera whose clock was never set, not a real date
    return value if _plausible(value, now) else None


def _plausible(value: datetime, now: datetime) -> bool:
    return datetime(1900, 1, 1) <= value <= now
