# src/mindit/services/validateit/video_repair_provider.py

"""Videos: dated by when they were recorded (from the video file), named video_YYYYMMDD_HHMMSS_xxxx.ext and
filed in the photos tree beside that month's photos. A Live Photo's video isn't one of these: it follows its photo.
"""

from __future__ import annotations

import mimetypes
from datetime import datetime
from pathlib import Path
from typing import Any

from mindit.services.photoit.photoit_workflows import _compute_sha256
from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider
from mindit.services.validateit.validateit_file_types import VIDEO_EXTENSIONS, MediaKind, is_live_photo_part
from mindit.utils.timestamps import safe_fromtimestamp

VIDEO_BLOCK = "video"


class VideoRepairProvider(PhotoItRepairProvider):
    """Name and file videos the way photos are, by the date they were recorded."""

    name = "video"
    media_kind = MediaKind.VIDEO
    rename_module = "video"

    def supports(self, path: Path) -> bool:
        return path.suffix.lower() in VIDEO_EXTENSIONS and not is_live_photo_part(path)

    def create_or_refresh_sidecar(self, path: Path, sha256: str | None = None) -> bool:
        from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
        from mindit.services.validateit.capture_date import resolve_capture_date  # pylint: disable=import-outside-toplevel
        from mindit.services.video.video_info import read_video_info  # pylint: disable=import-outside-toplevel

        stat = path.stat()
        info = read_video_info(path) or {}
        capture = resolve_capture_date(path)               # the date DA files it by (name rule, a date set by hand)
        data = SidecarService.load(path)
        file_block = data["file"]
        file_block.update({
            "source_path": file_block.get("source_path") or str(path.resolve()),
            "current_path": str(path.resolve()),
            "file_name": path.name,
            "extension": path.suffix.lower(),
            "size_bytes": int(stat.st_size),
            "modified_at": _iso(safe_fromtimestamp(stat.st_mtime)),
            "sha256": sha256 or file_block.get("sha256") or _compute_sha256(path),
        })
        data["classification"].update({"module": "video", "media_type": "video", "status": "active"})
        data[VIDEO_BLOCK] = {**video_block(info, capture.value if capture.certain else None),
                             "original_file_name": (data.get(VIDEO_BLOCK) or {}).get("original_file_name") or path.name,
                             "mime_type": mimetypes.guess_type(str(path))[0]}
        if info.get("make") or info.get("model") or info.get("gps"):
            # Like a photo's camera details, so tags and places can use them later.
            data["camera"] = {"make": info.get("make"), "model": info.get("model"),
                              "gps": info.get("gps") or {"latitude": None, "longitude": None, "altitude": None},
                              "read_at": datetime.now().isoformat(timespec="seconds")}
        SidecarService.save(path, data)
        return True


def video_block(info: dict[str, Any], recorded: datetime | None) -> dict[str, Any]:
    """Return the sidecar's "video" block: when it was recorded, how long it is, and what recorded it."""
    return {
        "recorded_at": _iso(recorded),
        "duration_seconds": info.get("duration"),
        "make": info.get("make"),
        "model": info.get("model"),
        "software": info.get("software"),
        "read_at": datetime.now().isoformat(timespec="seconds"),
    }


def _iso(value: datetime | None) -> str | None:
    return value.isoformat(timespec="seconds") if value else None
