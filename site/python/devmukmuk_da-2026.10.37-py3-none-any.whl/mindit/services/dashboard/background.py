# src/mindit/services/dashboard/background.py

"""Run the dashboard on its own, in the background: start it, find the one already running, stop it.

The running dashboard writes `.da\\dashboard.json` in its archive (its process id, port and address) and deletes it
when it stops. `da dashboard` starts a hidden copy of DA (`da dashboard --foreground`), waits for that file, and
opens the browser; a second `da dashboard` finds the running one and only opens the browser.
"""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Any

STATE_NAME = "dashboard.json"


def state_path(root: Path) -> Path:
    """Return the archive's `.da\\dashboard.json`."""
    return Path(root) / ".da" / STATE_NAME


def write_state(root: Path, port: int) -> dict[str, Any]:
    """Record the dashboard running in this process."""
    info = {"pid": os.getpid(), "port": port, "url": f"http://127.0.0.1:{port}/",
            "started": datetime.now().isoformat(timespec="seconds"), "archive": str(Path(root))}
    path = state_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(info, indent=2), encoding="utf-8")
    return info


def clear_state(root: Path, pid: int | None = None) -> None:
    """Delete the record (only this process's, when pid is given)."""
    path = state_path(root)
    try:
        if pid is None or json.loads(path.read_text(encoding="utf-8")).get("pid") == pid:
            path.unlink()
    except (OSError, ValueError):
        pass


def running(root: Path, timeout: float = 2.0) -> dict[str, Any] | None:
    """Return the dashboard running for this archive, or None (a stale record is deleted)."""
    try:
        info = json.loads(state_path(root).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{int(info['port'])}/api/hello", timeout=timeout) as answer:
            hello = json.loads(answer.read())
    except (OSError, ValueError, KeyError):
        hello = None
    if not hello or os.path.normcase(str(hello.get("archive"))) != os.path.normcase(str(Path(root))):
        clear_state(root)                             # it stopped without tidying up (PC restarted, killed)
        return None
    return info


def launch_command(root: Path, port: int) -> list[str]:
    """Return the command that runs this same DA as a dashboard for root."""
    args = ["dashboard", "--foreground", "--no-open", "--port", str(port), "--archive", str(root)]
    if getattr(sys, "frozen", False):                  # DA.exe
        return [sys.executable, *args]
    return [sys.executable, "-m", "mindit", *args]     # DA run by Python


def start(root: Path, port: int, wait: float = 30.0) -> dict[str, Any]:
    """Start a hidden dashboard for root and return its record once it answers."""
    flags = 0
    if os.name == "nt":                               # no window, and it outlives the terminal that started it
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    process = subprocess.Popen(launch_command(root, port), cwd=str(root), stdin=subprocess.DEVNULL,  # pylint: disable=consider-using-with
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=flags,
                               start_new_session=os.name != "nt", close_fds=True)
    deadline = time.monotonic() + wait
    while time.monotonic() < deadline:
        info = running(root, timeout=1.0)
        if info:                    # (its pid can differ from process.pid: a venv's python.exe is a launcher)
            return info
        if process.poll() is not None:
            raise RuntimeError(f"the dashboard stopped as it started (exit {process.returncode}); "
                               "try `da dashboard --foreground` to see why")
        time.sleep(0.3)
    process.kill()
    raise RuntimeError(f"the dashboard didn't answer within {int(wait)} seconds")


def stop(root: Path) -> dict[str, Any] | None:
    """Stop the dashboard running for root; return its record, or None when none was running."""
    info = running(root)
    if info is None:
        return None
    try:
        os.kill(int(info["pid"]), signal.SIGTERM)       # on Windows: ends the process
    except (OSError, ValueError):
        pass
    clear_state(root)
    return info
