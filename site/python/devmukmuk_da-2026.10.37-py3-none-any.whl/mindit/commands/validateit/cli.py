# src/mindit/cli/validateit_cli.py

from __future__ import annotations

from enum import StrEnum
from pathlib import Path

import typer
from rich.table import Table
from rich.console import Console
from collections import defaultdict

from mindit.services.validateit.video_repair_provider import VideoRepairProvider
from mindit.services.validateit.validateit_models import ValidationMode
from mindit.services.validateit.validateit_service import ValidateItService
from mindit.services.validateit.validateit_file_types import MediaClassifier, MediaKind

from mindit.config.settings import get_archive_root, get_intake_path, load_settings, resolve_data_path
from mindit.services.validateit.validateit_reports import write_validation_report
from mindit.services.validateit.photoit_repair_provider import PhotoItRepairProvider
from mindit.services.validateit.scanit_repair_provider import ScanItRepairProvider
from mindit.services.validateit.validateit_repair_providers import (
    RepairProviderRegistry,
)
from mindit.core.progress import NullProgressReporter
from mindit.commands.progress import ConsoleProgressReporter
from mindit.utils.file_utils import remove_empty_folders_workflow

class KindOption(StrEnum):
    AUTO = "auto"
    PHOTO = "photo"
    DOCUMENT = "document"


app = typer.Typer(help="Validate folders, sidecars, file placement, and metadata.")
console = Console()


@app.command("remove-empty-folders")
def remove_empty_folders(
    folder: str = typer.Argument(..., help="Root folder to clean up."),
    dry_run: bool = typer.Option(
        False,
        "--dry-run/--no-dry-run",
        help="Preview only or actually remove empty folders.",
    ),
) -> None:
    """Remove empty folders under a root folder."""
    print(
        remove_empty_folders_workflow(
            folder=folder,
            dry_run=dry_run,
        )
    )


def repair_refusal(target: Path) -> str | None:
    """Return why repair shouldn't run on target (intake, or outside the archive), or None when it may."""
    root = get_archive_root()
    if root is None:                                  # an old-style profile: no archive to protect
        return None
    target = target.resolve()
    intake = get_intake_path().resolve()
    run_hint = f'Use `da run "{target}"`: it sets duplicates aside against the whole archive first.'
    if not target.is_relative_to(root):
        return f"{target} is outside this archive ({root}). {run_hint} (Or add --force.)"
    if target.is_relative_to(intake) or intake.is_relative_to(target):
        return f"{target} includes intake, where new files are filed. {run_hint} (Or add --force.)"
    return None


@app.command("validate")
def validate_folder(
    target_folder: str = typer.Argument(..., help="Folder to validate."),
    mode: ValidationMode = typer.Option(
        ValidationMode.PREVIEW,
        "--mode",
        help=(
            "preview (default) never moves, renames, or removes files, but does create "
            "missing sidecars and record hashes; repair also moves/renames/removes files."
        ),
    ),
    write_report: bool = typer.Option(
        True,
        "--write-report/--no-write-report",
        help="Write a dated JSON validation report.",
    ),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive"),
    kind: KindOption = typer.Option(
        KindOption.AUTO,
        "--kind",
        help=(
            "How to treat image files that can be photos or scans (.jpg .jpeg .png .tif "
            ".tiff .bmp). auto uses the intake folder (scans, docs: document), then the "
            "sidecar's module, then a 'documents' folder in the path, then photo."
        ),
    ),
    show_progress: bool = typer.Option(
        True,
        "--progress/--no-progress",
        help="Show validation progress while scanning files.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Repair intake or a folder outside the archive anyway, without da run's duplicate check.",
    ),
) -> None:
    """Check a folder (usually organized\\): names, folders, sidecars. To file new files, use `da run`."""
    if mode == ValidationMode.REPAIR and not force:
        refusal = repair_refusal(Path(target_folder))
        if refusal:
            console.print(f"[yellow]{refusal}[/yellow]")
            raise typer.Exit(1)
    service = ValidateItService(
        repair_provider_registry=RepairProviderRegistry(
            providers=[
                PhotoItRepairProvider(),
                ScanItRepairProvider(),
                VideoRepairProvider(),
            ]
        ),
        media_classifier=MediaClassifier(
            force_kind=None if kind == KindOption.AUTO else MediaKind(kind.value)
        ),
    )

    progress_reporter = (
        ConsoleProgressReporter(console=console, update_every=500)
        if show_progress
        else NullProgressReporter()
    )

    result = service.validate_folder(
        target_folder=Path(target_folder),
        mode=mode,
        recursive=recursive,
        progress=progress_reporter,
    )

    report_path = _write_report_if_enabled(result, write_report)

    _print_validate_summary(result, console)

    sheets = service.last_contact_sheets
    if sheets and (sheets.made or sheets.removed or sheets.failed):
        console.print(f"\n[bold]Contact sheets[/bold]: {len(sheets.made)} updated, {len(sheets.removed)} removed"
                      + (f", {len(sheets.failed)} failed" if sheets.failed else ""))

    if report_path:
        console.print("\n[bold]Report[/bold]")
        console.print(str(report_path))

def _print_sidecar_writeback(result, console):
    console.print("\n[bold]Sidecar Writeback[/bold]")
    console.print(f"Created: {len(result.sidecars_created)}")
    console.print(f"Updated: {len(result.sidecars_updated)}")
    console.print(f"Skipped: {len(result.sidecars_skipped)}")

def _print_summary(result, console, title: str, summary: dict[str, int]):
    if not summary:
        console.print(f"\n[green]{title}: none[/green]")
        return

    table = Table(title=title)
    table.add_column("Problem", style="cyan")
    table.add_column("Count", justify="right")

    for code, count in summary.items():
        table.add_row(code, str(count))

    console.print(table)

def _print_severity_summary(result, console):
    summary = result.severity_summary

    console.print("\n[bold]Severity[/bold]")
    console.print(f"Errors:   {summary.get('error', 0)}")
    console.print(f"Warnings: {summary.get('warning', 0)}")
    console.print(f"Info:     {summary.get('info', 0)}")


def _print_examples(result, console, limit=3):
    grouped = defaultdict(list)

    for p in result.problems:
        grouped[p.code].append(p)

    console.print("\n[bold]Examples[/bold]")

    for code, problems in grouped.items():
        console.print(f"\n[cyan]{code}[/cyan] ({len(problems)})")

        for p in problems[:limit]:
            console.print(f"  - {p.file_path or p.sidecar_path}")


def _write_report_if_enabled(result, write_report):
    if not write_report:
        return None

    settings = load_settings()
    output_root = resolve_data_path("output/validateit", settings)

    return write_validation_report(
        state=result,
        output_root=output_root,
    )


def _print_validate_summary(result, console):
    console.print("[bold]ValidateIt Summary[/bold]")
    console.print(f"Target: {result.target_folder}")
    console.print(f"Mode: {result.mode.upper()}")
    console.print(f"Problems found: {result.problem_count}")

    if result.mode == ValidationMode.REPAIR:
        console.print(f"Repairs completed: {result.repaired_problem_count}")
        console.print(f"Problems remaining: {result.remaining_problem_count}")

    _print_change_summary(result, console)
    _print_hash_summary(result, console)
    _print_duplicate_groups(result, console)
    _print_severity_summary(result, console)

    _print_summary(
        result,
        console,
        title="Problems Found",
        summary=result.problem_summary,
    )

    if result.mode == ValidationMode.REPAIR:
        _print_summary(
            result,
            console,
            title="Problems Remaining",
            summary=result.remaining_problem_summary,
        )

    _print_repair_actions(result, console)


def _print_change_summary(result, console):
    if result.mode == ValidationMode.REPAIR:
        console.print("\n[bold]Sidecar Writeback[/bold]")
    else:
        console.print("\n[bold]Changes Made[/bold]")

    console.print(f"Created: {len(result.sidecars_created)}")
    console.print(f"Updated: {len(result.sidecars_updated)}")
    console.print(f"Skipped: {len(result.sidecars_skipped)}")


def _print_hash_summary(result, console):
    summary = result.hash_summary
    if not summary:
        return

    console.print("\n[bold]Hashes[/bold]")
    console.print(f"Hashed:     {summary['hashed']}")
    console.print(f"Computed:   {summary['computed']}")
    console.print(f"Recomputed: {summary['recomputed']}")
    console.print(f"Reused:     {summary['reused']}")
    if summary["skipped_no_sidecar"]:
        console.print(
            f"Skipped:    {summary['skipped_no_sidecar']} (no sidecar yet; not checked for duplicates)"
        )


def _print_duplicate_groups(result, console, limit: int = 10) -> None:
    if not result.duplicate_groups:
        console.print("\n[green]Duplicates: none[/green]")
        return

    table = Table(
        title=(
            f"Duplicate Groups ({len(result.duplicate_groups)} groups, "
            f"{result.duplicate_file_count} duplicate files)"
        ),
    )
    table.add_column("Keep (primary)", style="cyan", overflow="fold")
    table.add_column("Duplicates", overflow="fold")

    def _relative(path: str) -> str:
        try:
            return str(Path(path).relative_to(result.target_folder))
        except ValueError:
            return path

    for group in result.duplicate_groups[:limit]:
        table.add_row(
            _relative(group["primary"]),
            "\n".join(_relative(path) for path in group["duplicates"]),
        )

    console.print(table)
    console.print("Report only. Nothing is moved or deleted.")

    remaining = len(result.duplicate_groups) - limit
    if remaining > 0:
        console.print(f"... {remaining} more groups in the JSON report")


def _print_repair_actions(result, console, limit: int = 10) -> None:
    if not result.repair_actions:
        return

    table = Table(title="Repair Actions")
    table.add_column("Action", style="cyan")
    table.add_column("Problem")
    table.add_column("Safe")
    table.add_column("Executed")
    table.add_column("Source")
    table.add_column("Target")

    for action in result.repair_actions[:limit]:
        table.add_row(
            action.action_type.value,
            action.problem_code.value,
            "yes" if action.safe_auto else "no",
            "yes" if action.executed else "no",
            action.source_path or "",
            action.target_path or "",
        )

    console.print(table)

    remaining = len(result.repair_actions) - limit
    if remaining > 0:
        console.print(f"[dim]... {remaining} more repair actions not shown[/dim]")
