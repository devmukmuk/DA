# src/mindit/commands/location_cli.py

"""`da location`: where GPS photos were taken, as places (and, coming soon, location folders)."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.prompt import Confirm, Prompt

from mindit.commands.progress import ConsoleProgressReporter
from mindit.config.settings import load_settings, resolve_database_path

app = typer.Typer(help="Places for GPS photos: look up the town and state each was taken in.",
                  no_args_is_help=True)
console = Console()


@app.command("lookup")
def lookup(
    targets: list[Path] = typer.Argument(
        None, help="Photos or folders. None: all of this archive's filed photos."),
    force: bool = typer.Option(False, "--force", help="Ask the service again for spots already looked up."),
    offline: bool = typer.Option(False, "--offline", help="Use only places already looked up; send nothing."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before starting."),
) -> None:
    """Look up the town and state of each GPS photo; adds place:, state: and country: tags."""
    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel
    from mindit.services.location import places as pl  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel

    settings = load_settings().location
    missing = [t for t in targets or [] if not t.exists()]
    if missing:
        raise typer.BadParameter(f"not found: {missing[0]}")
    targets = list(targets or []) or [resolve_photoit_organized_path()]
    db_path = resolve_database_path()
    cache = pl.PlaceCache(db_path)
    photos = files_under(targets, photos_only=True)
    with_gps, new_spots = pl.spots_to_look_up(photos, cache, digits=settings.spot_digits)
    where = ", ".join(str(t) for t in targets)

    use_service = settings.lookup != "off" and not offline
    if not with_gps:
        console.print(f"No photos with a GPS position in {where}."
                      " (Older photos may need `da tag` first, which reads their camera details.)")
        return
    console.print(f"{with_gps:,} of {len(photos):,} photos in {where} have a GPS position;"
                  f" {new_spots:,} new spots to look up.")
    if settings.lookup == "off" and not offline:
        console.print("Lookups are off in da-archive.yaml (location: lookup: off); using places already known.")
    if use_service and (new_spots or force):
        minutes = max(1, round((with_gps if force else new_spots) / 60))
        console.print(f"Looking up sends each spot's position (rounded to about 100 m, never the photo) to "
                      f"OpenStreetMap. About one a second: roughly {minutes:,} minute{'s' if minutes != 1 else ''}.")
        if not yes and not Confirm.ask("Start?", default=True):
            return

    progress = ConsoleProgressReporter(console=console, update_every=500)
    progress.start(label="Places", total=len(photos))
    try:
        result = pl.lookup_places(photos, pl.NominatimGeocoder() if use_service else None, cache,
                                  digits=settings.spot_digits, force=force,
                                  progress=lambda i, n: progress.advance(current_item=""))
    finally:
        progress.finish()
    rows = pl.update_index(db_path, result.changed)

    console.print(f"{result.placed:,} of {result.with_gps:,} GPS photos have a place"
                  f" ({result.looked_up:,} spots looked up now; index updated: {rows:,}).")
    if result.no_place:
        console.print(f"  {result.no_place:,} were taken where there's no town to name (at sea, in the wild).")
    if result.manual:
        console.print(f"  {result.manual:,} have a place you set by hand; left as they are.")
    if result.waiting:
        why = f" ({result.stopped})" if result.stopped else ""
        console.print(f"[yellow]  {result.waiting:,} still need a place{why}. "
                      "Run `da location lookup` again later.[/yellow]")
    for name, count in sorted(result.places.items(), key=lambda kv: -kv[1])[:10]:
        console.print(f"  place:{name}  {count:,}")
    if len(result.places) > 10:
        console.print(f"  ... and {len(result.places) - 10:,} more places")


MONTH_NAME = r"^\d{4}-\d{2}$"


@app.command("group")
def group(
    month: Path = typer.Argument(..., help="A month: 2019-04, or its folder, e.g. photos\\organized\\2019\\2019-04."),
    title: list[str] = typer.Option(None, "--title", "-t", metavar="N=TITLE",
                                    help='Title for group N, e.g. --title "1=Easter at grandma\'s" (repeat).'),
    hours: float = typer.Option(6.0, "--hours", help="Photos further apart in time start a new group."),
    km: float = typer.Option(2.0, "--km", help="Photos further apart than this start a new group."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask before moving."),
) -> None:
    """Group a month's GPS photos by time and place into folders you name, e.g. "2019-04 Easter (springfield-il)"."""
    import re  # pylint: disable=import-outside-toplevel

    from mindit.commands.workflow_cli import _interactive  # pylint: disable=import-outside-toplevel
    from mindit.services.contactsheet.contact_sheet import refresh_sheets  # pylint: disable=import-outside-toplevel
    from mindit.services.dbit.intake_service import default_layout  # pylint: disable=import-outside-toplevel
    from mindit.services.location import grouping as gp  # pylint: disable=import-outside-toplevel
    from mindit.services.location import places as pl  # pylint: disable=import-outside-toplevel

    from mindit.config.settings import resolve_photoit_organized_path  # pylint: disable=import-outside-toplevel

    db_path = resolve_database_path()
    root = resolve_photoit_organized_path()
    by_index = re.match(r"^\d{4}-\d{2}$", str(month)) is not None and not month.is_dir()
    if by_index:                                    # a month wherever the folder pattern filed it
        if not db_path.exists():
            raise typer.BadParameter("DA's index isn't built yet: run da db build first.")
        label = str(month)
        month = root / label[:4] / label             # where the default layout has it (for names shown)
    else:
        month = month.resolve()
        if not month.is_dir() or not re.match(MONTH_NAME, month.name) or not re.match(r"^\d{4}$", month.parent.name):
            raise typer.BadParameter(f"{month} isn't a month folder (like photos\\organized\\2019\\2019-04);"
                                     " or give the month itself: da location group 2019-04")
        label = month.name
    settings = load_settings().location

    def gather() -> tuple[list, list, dict, dict]:
        if by_index:
            return gp.month_from_index(db_path, label)
        found, stay = gp.month_shots(month)
        folders = gp.location_folders(month)
        return found, stay, folders, {folder: gp.folder_photos(folder)[0] for folder in folders}

    # Places first, so each group can be named by them.
    shots, staying, existing, existing_shots = gather()
    unplaced = [s.path for s in shots if not s.place]
    if unplaced:
        geocoder = pl.NominatimGeocoder() if settings.lookup != "off" else None
        if geocoder:
            console.print(f"Looking up places for {len(unplaced):,} photos (about one new spot a second) ...")
        result = pl.lookup_places(unplaced, geocoder, pl.PlaceCache(db_path), digits=settings.spot_digits)
        pl.update_index(db_path, result.changed)
        if result.waiting:
            console.print(f"[yellow]{result.waiting:,} photos have no place yet ({result.stopped or 'lookups off'});"
                          " their groups are named without it.[/yellow]")
        shots, staying, existing, existing_shots = gather()

    if not shots:
        console.print(f"No photos with a GPS position and a date in {label}. Nothing to group."
                      " (Older photos may need `da tag` first.)")
        return
    groups = gp.group_shots(shots, hours=hours, km=km)
    fits: dict[int, Path] = {}
    for i, grp in enumerate(groups, 1):
        match = gp.matching_folder(grp, existing_shots, hours=hours, km=km)
        if match is not None:
            fits[i] = match
    console.print(f"\n{len(shots):,} GPS photos in {label} make {len(groups):,} group"
                  f"{'s' if len(groups) != 1 else ''} (within {hours:g} hours and {km:g} km of the one before):\n")
    for i, grp in enumerate(groups, 1):
        places = ", ".join(f"{pl.place_name(p)} ({n})" for p, n in grp.places()[:4]) or "no place found"
        when = (f"{grp.start:%a %d %b %H:%M}" + (f" - {grp.end:%a %d %b %H:%M}" if grp.end != grp.start else ""))
        console.print(f"  [bold]{i}[/bold]  {_photos(len(grp.shots))}  {when}  {places}")
        console.print(f"      first: {grp.shots[0].path.name}")
        if i in fits:
            console.print(f"      fits the folder already there: {fits[i].name}")
    if staying:
        console.print(f"\n  {len(staying):,} photos without GPS stay where they are.")

    titles: dict[int, str] = {}
    for item in title or []:
        number, sep, text = item.partition("=")
        if not sep or not number.strip().isdigit() or not 1 <= int(number) <= len(groups):
            raise typer.BadParameter(f'--title wants N=TITLE with N from 1 to {len(groups)}, e.g. --title "1=Easter"')
        titles[int(number)] = text
    if not titles:
        if not _interactive():
            console.print(f'\nTo make folders, give titles: da location group "{label if by_index else month}" '
                          '--title "1=Easter" ...')
            return
        console.print("\nType a title for each group (Enter: leave it in the month folder;"
                      " the same title twice joins those groups):")
        if fits:
            console.print("  For a group that fits a folder already there, Enter adds it there; - leaves it.")
        for i in range(1, len(groups) + 1):
            suggested = existing.get(fits[i], "") if i in fits else ""
            try:
                answer = Prompt.ask(f"  {i}", default=suggested, show_default=bool(suggested))
            except (EOFError, KeyboardInterrupt):
                console.print()
                return
            if answer.strip() and answer.strip() != "-":
                titles[i] = answer
    for i, grp in enumerate(groups, 1):
        grp.title = titles.get(i)

    plan = gp.plan_groups(month, groups, settings.folder, existing, root=root)
    if not plan.folders:
        console.print("No titles, so nothing moves.")
        return
    console.print("\nDA will:")
    for folder, grp in plan.folders.items():
        verb = "add to" if folder.exists() else "make  "
        shown = (folder.name if folder.parent == month.parent
                 else folder.relative_to(root) if folder.is_relative_to(root) else folder)
        console.print(f"  {verb} {shown}   ({_photos(len(grp.shots))})")
    if plan.conflicts:
        console.print(f"[yellow]  {len(plan.conflicts):,} photos stay: a file with the same name is already there.[/yellow]")
    others = sum(1 for m in plan.moves if m.companion_of)
    if others:
        console.print(f"  (with {others:,} raw files and Live Photo videos that go with them)")
    if not yes and not Confirm.ask("Move them?", default=True):
        return

    run_dir = default_layout().run_dir("location-group")
    gp.write_plan(plan, run_dir / "plan.json")
    log = run_dir / "location-moved.csv"
    stats = gp.apply_plan(db_path, plan, log)
    sources = {m.source.parent for m in plan.moves}
    sheets = refresh_sheets(list(plan.folders) + sorted(sources), create=True)
    removed = gp.remove_empty_folders(sources)
    console.print(f"Moved {_photos(stats['photos'])} into {len(plan.folders):,} folder"
                  f"{'s' if len(plan.folders) != 1 else ''}"
                  + (f" ({stats['skipped']:,} skipped)" if stats["skipped"] else "")
                  + f"; {len(sheets.made):,} contact sheets made."
                  + (f" {', '.join(r.name for r in removed)} {'was' if len(removed) == 1 else 'were'} empty"
                     " and removed." if removed else ""))
    console.print(f'Undo: da intake undo "{log}"')


@app.command("rename")
def rename(
    folder: Path = typer.Argument(..., help="A location folder, e.g. \"photos\\organized\\2019\\2019-04 Easter (springfield-il)\"."),
    title: str = typer.Argument(..., help="The new title."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Give a location folder a new title: renames it and updates its photos' sidecars and the index."""
    from mindit.services.location import grouping as gp  # pylint: disable=import-outside-toplevel

    folder = folder.resolve()
    if not folder.is_dir():
        raise typer.BadParameter(f"No such folder: {folder}")
    try:
        target = gp.plan_rename(folder, title, load_settings().location.folder)
    except gp.RenameError as error:
        console.print(f"[red]{error}[/red]")
        raise typer.Exit(1) from error
    old_title = gp.folder_photos(folder)[1] or gp.title_from_name(folder.name)
    console.print(f"  {folder.name}\n  -> {target.name}")
    if not yes and not Confirm.ask("Rename it?", default=True):
        return
    changed = gp.rename_folder(folder, title, target, resolve_database_path())
    console.print(f"Renamed; title set on {changed:,} sidecar{'s' if changed != 1 else ''}.")
    console.print(f'Undo: da location rename "{target}" "{old_title}"')


@app.command("set")
def set_place(
    targets: list[Path] = typer.Argument(..., help="Photos or folders."),
    place: str = typer.Option(None, "--place", "-p", help='Where they were taken, e.g. "Springfield, IL".'),
    same_as: Path = typer.Option(None, "--same-as", help="Use another photo's place."),
    clear: bool = typer.Option(False, "--clear", help="Take a place set by hand off again."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Don't ask first."),
) -> None:
    """Set where photos were taken by hand (also for photos with no GPS); lookups never replace it."""
    from mindit.services.location import places as pl  # pylint: disable=import-outside-toplevel
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel
    from mindit.services.tagging.tags import files_under  # pylint: disable=import-outside-toplevel

    if sum(bool(x) for x in (place, same_as, clear)) != 1:
        raise typer.BadParameter('Give one of --place "Springfield, IL", --same-as <photo> or --clear.')
    missing = [t for t in targets if not t.exists()]
    if missing:
        raise typer.BadParameter(f"not found: {missing[0]}")
    photos = files_under(targets, photos_only=True)
    if not photos:
        console.print("No photos there.")
        return

    found, where = None, None
    if same_as:
        if not same_as.exists() or not SidecarService.sidecar_path_for(same_as).exists():
            raise typer.BadParameter(f"{same_as} has no sidecar (file it with da run first).")
        found, where = pl.place_of(SidecarService.load(same_as))
        if not found:
            console.print(f"[yellow]{same_as.name} has no place yet. Run `da location lookup` on it first.[/yellow]")
            raise typer.Exit(1)
    elif place:
        if load_settings().location.lookup == "off":
            console.print("[yellow]Lookups are off in da-archive.yaml, so DA can't look the name up. "
                          "Use --same-as <photo> instead.[/yellow]")
            raise typer.Exit(1)
        try:
            answer = pl.NominatimGeocoder().search(place)
        except pl.LookupUnavailable as error:
            console.print(f"[red]Couldn't look it up: {error}. Try again later, or use --same-as <photo>.[/red]")
            raise typer.Exit(1) from error
        if not answer:
            console.print(f'[yellow]Nothing found for "{place}". Try "Town, State" or "Town, Country".[/yellow]')
            raise typer.Exit(1)
        found, lat, lon = answer
        where = (lat, lon)
        console.print(f"Found: {found.get('display') or pl.place_name(found)}")

    what = "Take the place off" if clear else f"Set place:{pl.place_name(found)} on"
    if not yes and not Confirm.ask(f"{what} {_photos(len(photos))}?", default=True):
        return
    changed = pl.set_places(photos, None if clear else found, where)
    rows = pl.update_index(resolve_database_path(), changed)
    console.print(f"Done: {_photos(len(changed))} (index updated: {rows:,})."
                  + ("" if clear else " Lookups won't replace it; `da location set ... --clear` takes it off."))


def _photos(n: int) -> str:
    return f"{n:,} photo{'s' if n != 1 else ''}"
