# src/mindit/services/workflow/holding.py

"""`da holding`: check that every copy in _duplicates-holding has its kept original, then empty it.

Each file DA set aside is matched to the one it's a copy of: an exact copy by its SHA-256 (in this archive's photos,
documents or intake, or with --everywhere in the other archives' indexes), a resized or re-saved copy by the original
DA's own log names (followed through later renames and moves). A sample of the originals is read again to be sure
they're still the same. Emptying sends only the files whose original was found, with their sidecars, to the
Recycle Bin; anything else stays.
"""

from __future__ import annotations

import csv
import os
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

from mindit.services.workflow.archive_delete import MIN_SAMPLE, SAMPLE, SKIP, _sha256, _walk, index_archive, recycle

HOLDING = "_duplicates-holding"
KEPT_AREAS = ("photos", "documents", "intake")
FIELDS = ["path", "size_bytes", "sha256", "kind", "original", "status"]
OK = "ok"
BATCH = 1000


@dataclass
class Held:
    """One file in holding and what it's a copy of."""

    path: Path
    size: int
    sha256: str
    kind: str = "exact"                  # exact, resized, re-saved
    original: str = ""
    status: str = "no original"          # ok, no original, couldn't be read, original changed


@dataclass
class HoldingCheck:
    """What emptying holding would remove, and what has no original."""

    root: Path
    files: list[Held] = field(default_factory=list)
    sampled: int = 0
    sample_bad: int = 0

    @property
    def ok(self) -> list[Held]:
        """Return the held files whose original was found."""
        return [h for h in self.files if h.status == OK]

    @property
    def not_ok(self) -> list[Held]:
        """Return the held files that stay: no original, unreadable, or an original that changed."""
        return [h for h in self.files if h.status != OK]

    def gb(self, which: Iterable[Held] | None = None) -> float:
        """Return the size of these held files (all of them by default) in GB."""
        return round(sum(h.size for h in (self.files if which is None else which)) / 1e9, 2)


def _key(path: str | Path) -> str:
    return os.path.normcase(os.path.abspath(str(path)))


def _originals(db_path: Path, root: Path | None,
                unhashed: dict[int, list[str]] | None = None) -> dict[str, list[str]]:
    """Return sha256 -> the files outside holding with that content, from an archive's index (read only).

    Files the index has no hash for go into unhashed (by size), to be hashed only if a held file of that size needs them.
    """
    out: dict[str, list[str]] = {}
    if not Path(db_path).exists():
        return out
    holding = _key(Path(root) / HOLDING) + os.sep if root else None
    with sqlite3.connect(db_path) as conn:
        try:
            rows = conn.execute("SELECT path, sha256, area, size_bytes FROM files").fetchall()
        except sqlite3.Error:
            return out
    for path, sha, area, size in rows:
        if area not in KEPT_AREAS or (holding and _key(path).startswith(holding)) or path.endswith(".meta.json") \
                or Path(path).name.lower() in SKIP:
            continue
        if sha:
            out.setdefault(sha, []).append(path)
        elif unhashed is not None and size:
            unhashed.setdefault(size, []).append(path)
    for paths in out.values():                                        # filed before intake
        paths.sort(key=lambda p: ("intake" in Path(p).parts, p))
    return out


def _hash_same_size(size: int, unhashed: dict[int, list[str]], originals: dict[str, list[str]]) -> None:
    """Hash (once) the unhashed files of this size and add them to originals."""
    for path in unhashed.pop(size, []):
        sha = _sha256(Path(path))
        if sha:
            originals.setdefault(sha, []).append(path)


def check_holding(root: Path, others: list[Path] | None = None,
                  progress: Callable[[str], None] | None = None) -> HoldingCheck:
    """Match every file in root's _duplicates-holding to its kept original."""
    from mindit.services.history import events as ev  # pylint: disable=import-outside-toplevel
    from mindit.services.similar.resized import kept_of  # pylint: disable=import-outside-toplevel

    say = progress or (lambda _m: None)
    root = Path(root)
    check = HoldingCheck(root)
    holding = root / HOLDING
    if not holding.is_dir():
        return check
    say(f"Indexing {root.name} ...")
    db_path = index_archive(root)
    ev.refresh(root, db_path, root / "output", root / "logs" / "da.jsonl")
    with sqlite3.connect(db_path) as conn:
        indexed = {_key(p): (size, sha) for p, size, sha in conn.execute(
            "SELECT path, size_bytes, sha256 FROM files WHERE area = 'holding'")}
    unhashed: dict[int, list[str]] = {}
    originals = _originals(db_path, root, unhashed)
    for other in others or []:
        say(f"Reading {Path(other).name}'s index (for originals there) ...")
        for sha, paths in _originals(Path(other) / ".da" / "da.sqlite", Path(other), unhashed).items():
            originals.setdefault(sha, []).extend(paths)

    with ev.connect(db_path) as conn:
        noted = {_key(dest): note for dest, note in conn.execute(
            "SELECT destination, note FROM events WHERE (note LIKE 'a resized copy of %' OR note LIKE "
            "'a re-saved copy of %') AND undone_at IS NULL AND destination IS NOT NULL")}
        held_paths = list(_walk(holding))
        for i, path in enumerate(held_paths, 1):
            if progress and i % 5000 == 0:
                say(f"  {i:,} / {len(held_paths):,} files checked")
            try:
                size = path.stat().st_size
            except OSError:
                continue
            known = indexed.get(_key(path))
            sha = known[1] if known and known[0] == size and known[1] else _sha256(path)
            held = Held(path, size, sha or "")
            check.files.append(held)
            note = noted.get(_key(path))
            if note:
                held.kind = "resized" if note.startswith("a resized") else "re-saved"
                original = ev.follow(conn, kept_of(note) or "")
                held.original = original
                held.status = OK if original and Path(original).is_file() else "no original"
                continue
            if not sha:
                held.status = "couldn't be read"
                continue
            found = next((p for p in originals.get(sha, []) if Path(p).is_file()), "")
            if not found and size in unhashed:
                _hash_same_size(size, unhashed, originals)
                found = next((p for p in originals.get(sha, []) if Path(p).is_file()), "")
            held.original = found
            held.status = OK if found else "no original"

    # Read a sample of the exact originals again: still there, still the same.
    exact = [h for h in check.ok if h.kind == "exact"]
    every = max(1, min(SAMPLE, len(exact) // MIN_SAMPLE or 1))
    for held in exact[::every]:
        check.sampled += 1
        if _sha256(Path(held.original)) != held.sha256:
            check.sample_bad += 1
            held.status = "original changed"
    return check


def write_report(check: HoldingCheck, path: Path) -> Path:
    """Write holding-check.csv: each held file, what it's a copy of, and whether it can go."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for h in check.files:
            writer.writerow({"path": str(h.path), "size_bytes": h.size, "sha256": h.sha256, "kind": h.kind,
                             "original": h.original, "status": h.status})
    return path


@dataclass
class Emptied:
    """What emptying did."""

    removed: list[Held] = field(default_factory=list)
    left: list[Held] = field(default_factory=list)          # Windows stopped, or a file couldn't go
    stopped: bool = False


def empty_holding(check: HoldingCheck, log_path: Path, *,
                  remove: Callable[[list[Path]], bool] = recycle,
                  progress: Callable[[str], None] | None = None) -> Emptied:
    """Send the held files whose original was found (and their sidecars) to the Recycle Bin, then tidy up."""
    say = progress or (lambda _m: None)
    done = Emptied()
    going = check.ok
    for start in range(0, len(going), BATCH):
        batch = going[start:start + BATCH]
        paths = [h.path for h in batch] + [Path(f"{h.path}.meta.json") for h in batch if Path(f"{h.path}.meta.json").exists()]
        finished = remove(paths)
        for h in batch:
            (done.left if h.path.exists() else done.removed).append(h)
        say(f"  {min(start + BATCH, len(going)):,} / {len(going):,}")
        if not finished:                                     # Windows was told No, or couldn't: stop here
            done.stopped = True
            done.left += going[start + BATCH:]
            break
    _write_emptied(done, log_path)
    _forget_rows(check.root, done.removed)
    _remove_empty_folders(check.root / HOLDING)
    return done


def _write_emptied(done: Emptied, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "kind", "original", "result"])
        writer.writeheader()
        for result, rows in (("recycled", done.removed), ("left", done.left)):
            for h in rows:
                writer.writerow({"path": str(h.path), "kind": h.kind, "original": h.original, "result": result})


def _forget_rows(root: Path, removed: list[Held]) -> None:
    db_path = Path(root) / ".da" / "da.sqlite"
    if not removed or not db_path.exists():
        return
    with sqlite3.connect(db_path) as conn:
        conn.executemany("DELETE FROM files WHERE path = ?", [(str(h.path),) for h in removed])


def forget_removed_holding(root: Path) -> int:
    """Drop the index rows left for a holding folder that is gone (emptied by hand); return how many."""
    db_path = Path(root) / ".da" / "da.sqlite"
    if (Path(root) / HOLDING).is_dir() or not db_path.exists():
        return 0
    prefix = str(Path(root) / HOLDING) + os.sep
    with sqlite3.connect(db_path) as conn:
        try:
            return conn.execute("DELETE FROM files WHERE substr(path, 1, ?) = ?", (len(prefix), prefix)).rowcount
        except sqlite3.OperationalError:                      # no files table yet
            return 0


def _remove_empty_folders(holding: Path) -> int:
    """Remove the folders in holding left with nothing but DA's own files (contact sheets, desktop.ini)."""
    removed = 0
    if not holding.is_dir():
        return removed
    for dirpath, _dirs, _files in sorted(os.walk(holding), key=lambda d: -len(d[0])):
        folder = Path(dirpath)
        try:
            leftovers = list(folder.iterdir())
            if all(p.is_file() and p.name.lower() in SKIP for p in leftovers):
                for p in leftovers:
                    p.unlink()
                folder.rmdir()
                removed += 1
        except OSError:
            continue
    return removed


def run_folder(root: Path) -> Path:
    """Return a new output\\runs\\<ts>-holding folder for this check's records."""
    folder = Path(root) / "output" / "runs" / f"{datetime.now():%Y%m%d-%H%M%S}-holding"
    folder.mkdir(parents=True, exist_ok=True)
    return folder
