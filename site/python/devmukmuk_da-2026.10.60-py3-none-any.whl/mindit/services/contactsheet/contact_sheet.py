# src/mindit/services/contactsheet/contact_sheet.py

"""A folder's contact sheet: `_contact-sheet.pdf`, small pictures of every photo in the folder.

Page 1 sums the folder up (dates, counts, GPS, places, the cameras and who used them, sidecar versions);
then the photos follow, one section per camera, each page headed "<folder> - <camera> / <owner>". A photo
with a GPS position has "GPS" down its left edge, and every picture has its sidecar's schema version in a
circle at its top right.

Camera and location facts come from sidecars; fresh indexed SHA-256 values link held copies when available.
No photo is opened except to draw its thumbnail. Copies in `_duplicates-holding` that share a SHA-256 with
a photo are shown in an appendix with their locations, sizes and hashes. The PDF records a fingerprint of
what it shows (names, sizes, sidecar details, held copies and layout) in its Subject, so DA can tell when
the sheet needs making again. `da run` makes one for each folder it files into; `da validate` remakes
changed ones; `da contact-sheets <folder>` makes them for a whole tree. Layout: `--layout 3x4` (the
default, bigger pictures) or `4x5`, or `contact_sheets: layout:` in da-archive.yaml.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import sqlite3
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

from mindit.services.faces.faces import Face, draw_faces, faces_of, people

SHEET_NAME = "_contact-sheet.pdf"
SUBJECT_PREFIX = "da-contact-sheet "
SHEET_DESIGN = "3"                   # bump when the drawing changes, so old sheets are made again
DEFAULT_LAYOUT = "3x4"

# What Pillow can draw (camera raw files aren't shown).
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".heic", ".heif", ".tif", ".tiff", ".bmp", ".gif"}
# Videos get a tile too (a "video" card with its length; DA doesn't decode video frames).
VIDEO_TILE_EXTENSIONS = {".mov", ".mp4", ".m4v", ".3gp", ".3g2", ".avi", ".mpg", ".mpeg", ".mts", ".m2ts",
                         ".wmv", ".mkv", ".webm"}
UNKNOWN_CAMERA = "Unknown camera"

_NAME_DATE = re.compile(r"(?:photo|doc|video)_(\d{4}|\d{2})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})")
_LAYOUT = re.compile(r"^([1-6])x([1-8])$")

try:  # iPhone HEIC photos
    from pillow_heif import register_heif_opener

    register_heif_opener()
except ImportError:  # pragma: no cover - pillow-heif is in requirements
    pass


@dataclass
class SheetResult:
    """What a refresh did."""

    made: list[Path] = field(default_factory=list)
    removed: list[Path] = field(default_factory=list)
    current: int = 0
    failed: list[tuple[Path, str]] = field(default_factory=list)

    def as_dict(self) -> dict:
        """Return counts and the paths made, for run records."""
        return {"made": len(self.made), "removed": len(self.removed), "current": self.current,
                "failed": [f"{p}: {why}" for p, why in self.failed], "sheets": [str(p) for p in self.made]}


@dataclass(frozen=True)
class HeldCopy:
    """A duplicate file in the archive's holding area."""

    path: Path
    size_bytes: int
    sha256: str
    kind: str = "exact copy"         # or "resized copy" / "re-saved copy" (the same picture, not the same file)


@dataclass(frozen=True)
class Facts:
    """What a sheet shows about one picture."""

    camera: str
    owner: str | None
    gps: bool
    schema: str                      # "2", "1", or "-" when there's no sidecar
    place: str | None
    seconds: float | None            # a video's length
    sha256: str | None
    duplicates: tuple[HeldCopy, ...] = ()
    faces: tuple[Face, ...] = ()     # from the sidecar (Picasa): a yellow box and the name on each
    versions: tuple[str, ...] = ()   # its role, then the other versions' roles (sidecar `versions`): still filed

    def key(self) -> str:
        """Return these facts as text, for the fingerprint."""
        duplicates = ";".join(
            f"{copy.path}|{copy.size_bytes}|{copy.sha256}" for copy in self.duplicates
        )
        return f"{self.camera}|{self.owner or ''}|{int(self.gps)}|{self.schema}|{self.place or ''}|" \
            f"{self.sha256 or ''}|{duplicates}" + "".join(f"|face {f.box} {f.name or ''}" for f in self.faces) \
            + "".join(f"|{copy.kind}" for copy in self.duplicates if copy.kind != "exact copy") \
            + (f"|versions {','.join(self.versions)}" if self.versions else "")


def is_sheet(path: Path) -> bool:
    """Return True for a contact sheet file (never validated, indexed or filed)."""
    return path.name.lower() == SHEET_NAME


def photos_in(folder: Path) -> list[Path]:
    """Return the pictures directly in folder, in name order (that's date order for filed photos)."""
    try:
        entries = [e for e in folder.iterdir() if e.is_file() and _on_sheet(e)]
    except OSError:
        return []
    return sorted(entries, key=lambda p: p.name.lower())


def layout_size(layout: str | None = None) -> tuple[int, int]:
    """Return (columns, rows) for "3x4"; with no layout given, the archive's setting, else 3x4."""
    if layout is None:
        try:
            from mindit.config.settings import load_settings  # pylint: disable=import-outside-toplevel

            layout = load_settings().contact_sheets.layout
        except Exception:  # pylint: disable=broad-except
            layout = DEFAULT_LAYOUT
    m = _LAYOUT.match(str(layout).strip().lower())
    if not m:
        raise ValueError(f"a layout looks like 3x4 or 4x5 (columns x rows), not {layout!r}")
    return int(m.group(1)), int(m.group(2))


# --------------------------------------------------------------------------- facts from sidecars

def photo_facts(path: Path) -> Facts:
    """Return a picture's camera, owner, GPS, sidecar version and place - from its sidecar alone."""
    try:
        raw = json.loads(Path(f"{path}.meta.json").read_text(encoding="utf-8"))
        raw = raw if isinstance(raw, dict) else {}
        has_sidecar = True
    except (OSError, ValueError):
        raw, has_sidecar = {}, False
    schema = raw.get("schema") if isinstance(raw.get("schema"), dict) else {}
    camera_block = raw.get("camera") if isinstance(raw.get("camera"), dict) else {}
    video = raw.get("video") if isinstance(raw.get("video"), dict) else {}
    auto = raw.get("auto_tags") if isinstance(raw.get("auto_tags"), dict) else {}
    tags = [t for t in auto.get("tags") or [] if isinstance(t, str)]
    return Facts(camera=_camera(camera_block, video, tags), owner=_owner(camera_block, tags),
                 gps=_has_gps(raw), schema=str(schema.get("version")) if has_sidecar and schema.get("version") else
                 ("?" if has_sidecar else "-"), place=_place(raw), seconds=video.get("duration_seconds"),
                 sha256=_sidecar_sha256(raw), faces=faces_of(raw), versions=_versions(raw))


def _versions(raw: dict) -> tuple[str, ...]:
    block = raw.get("versions") if isinstance(raw.get("versions"), dict) else {}
    others = [o.get("role", "") for o in block.get("others") or [] if isinstance(o, dict)]
    return (block.get("role", ""), *others) if others else ()


def _sidecar_sha256(raw: dict) -> str | None:
    """Return a valid SHA-256 value from a current or legacy sidecar."""
    file_block = raw.get("file") if isinstance(raw.get("file"), dict) else {}
    quarantine = raw.get("quarantine") if isinstance(raw.get("quarantine"), dict) else {}
    value = quarantine.get("hash_sha256") or file_block.get("sha256") or raw.get("sha256") or raw.get("hash_sha256")
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
        return None
    return value.lower()


def _holding_root() -> Path:
    """Return the configured archive's holding folder."""
    from mindit.config.settings import get_data_root_path  # pylint: disable=import-outside-toplevel

    return get_data_root_path() / "_duplicates-holding"


def _index_rows(holding_root: Path, *, area: str | None = None, paths: list[Path] | None = None) -> dict[str, dict]:
    """Read hash metadata from the existing archive index without creating or initializing it."""
    db_path = holding_root.parent / ".da" / "da.sqlite"
    if not db_path.is_file():
        return {}

    with sqlite3.connect(db_path) as conn:
        conn.row_factory = sqlite3.Row
        table = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'files'"
        ).fetchone()
        if table is None:
            return {}

        rows: list[sqlite3.Row] = []
        if area is not None:
            rows = conn.execute(
                "SELECT path, sha256, size_bytes, modified_at FROM files "
                "WHERE area = ? AND sha256 IS NOT NULL",
                (area,),
            ).fetchall()
        elif paths:
            for start in range(0, len(paths), 800):
                batch = paths[start:start + 800]
                placeholders = ",".join("?" for _ in batch)
                rows.extend(conn.execute(
                    f"SELECT path, sha256, size_bytes, modified_at FROM files "
                    f"WHERE path IN ({placeholders}) AND sha256 IS NOT NULL",
                    [str(path) for path in batch],
                ).fetchall())
        return {str(row["path"]).casefold(): dict(row) for row in rows}


def _fresh_index_hash(path: Path, row: dict | None) -> str | None:
    """Return an indexed hash only if the file size and modification time still match."""
    if not row or not isinstance(row.get("sha256"), str):
        return None
    try:
        stat = path.stat()
    except OSError:
        return None
    from mindit.utils.timestamps import safe_iso_timestamp  # pylint: disable=import-outside-toplevel

    if row.get("size_bytes") != stat.st_size or row.get("modified_at") != safe_iso_timestamp(stat.st_mtime):
        return None
    return _sidecar_sha256({"sha256": row["sha256"]})


def held_copies(holding_root: Path | None = None) -> dict[str, list[HeldCopy]]:
    """Return the holding folder's copies by hash, to hand to several refresh_sheets calls in a row.

    Looking through a big holding folder takes a while (~20 s for 80,000 files).
    """
    return _held_duplicates_by_hash(holding_root)


def _held_duplicates_by_hash(holding_root: Path | None = None) -> dict[str, list[HeldCopy]]:
    """Index image and video copies in holding by their fresh indexed or sidecar SHA-256."""
    from mindit.services.sidecar import SidecarService  # pylint: disable=import-outside-toplevel

    root = holding_root or _holding_root()
    if not root.is_dir():
        return {}

    indexed_rows = _index_rows(root, area="holding")
    result: dict[str, list[HeldCopy]] = {}
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            path = Path(dirpath, name)
            if not _on_sheet(path):
                continue
            try:
                size = path.stat().st_size
            except OSError:
                continue
            row = indexed_rows.get(str(path).casefold())
            sha256 = _fresh_index_hash(path, row)
            if sha256 is None:
                metadata = SidecarService.load_sidecar_path(Path(f"{path}.meta.json"))
                sha256 = _sidecar_sha256(metadata or {})
            if sha256 is None:
                continue
            result.setdefault(sha256, []).append(HeldCopy(path, size, sha256))

    for copies in result.values():
        copies.sort(key=lambda copy: str(copy.path).lower())
    return result


def _facts_for(
    photos: list[Path],
    held_duplicates: dict[str, list[HeldCopy]],
    holding_root: Path,
) -> dict[Path, Facts]:
    """Read photo facts and attach held files with a matching content hash."""
    indexed_rows = _index_rows(holding_root, paths=photos)
    noted = _noted_copies(holding_root)
    facts: dict[Path, Facts] = {}
    for photo in photos:
        fact = photo_facts(photo)
        try:
            size = photo.stat().st_size
        except OSError:
            size = -1
        sha256 = _fresh_index_hash(photo, indexed_rows.get(str(photo).casefold())) or fact.sha256
        duplicates = tuple(
            copy for copy in held_duplicates.get(sha256, ())
            if sha256 and copy.size_bytes == size and copy.path.resolve() != photo.resolve()
        )
        others = tuple(HeldCopy(c["path"], c["size_bytes"], c.get("sha256") or "", c["kind"])
                       for c in noted.get(os.path.normcase(str(photo.resolve())), []))
        facts[photo] = Facts(**{**fact.__dict__, "sha256": sha256, "duplicates": duplicates + others})
    return facts


def _noted_copies(holding_root: Path) -> dict[str, list[dict]]:
    """Return the resized and re-saved copies DA set aside, by the photo kept (from the archive's records)."""
    from mindit.services.similar.copies import noted_copies  # pylint: disable=import-outside-toplevel

    db = holding_root.parent / ".da" / "da.sqlite"
    try:
        return noted_copies(db) if db.exists() else {}
    except Exception:  # pylint: disable=broad-except
        return {}


def _camera(camera_block: dict, video: dict, tags: list[str]) -> str:
    from mindit.services.tagging.camera_info import camera_name  # pylint: disable=import-outside-toplevel

    name = camera_name(camera_block) if (camera_block.get("make") or camera_block.get("model")) else None
    if not name:
        name = camera_name(video) if (video.get("make") or video.get("model")) else None
    if not name:
        slug = next((t.split(":", 1)[1] for t in tags if t.startswith("camera:")), None)
        if slug:
            from mindit.services.report.archive_report import nice_name  # pylint: disable=import-outside-toplevel

            name = nice_name(slug)
    return name or UNKNOWN_CAMERA


def _owner(camera_block: dict, tags: list[str]) -> str | None:
    owner = next((t.split(":", 1)[1] for t in tags if t.startswith("owner:")), None)
    return owner or camera_block.get("owner") or camera_block.get("artist") or None


def _has_gps(raw: dict) -> bool:
    from mindit.services.location.places import manual_position, position  # pylint: disable=import-outside-toplevel

    return position(raw) is not None or manual_position(raw) is not None


def _place(raw: dict) -> str | None:
    location = raw.get("location") if isinstance(raw.get("location"), dict) else {}
    if not isinstance(location.get("place"), dict):
        return None
    from mindit.services.location.places import place_name  # pylint: disable=import-outside-toplevel

    return place_name(location["place"])


def fingerprint(
    photos: Iterable[Path],
    layout: str | None = None,
    facts: dict[Path, Facts] | None = None,
    held_duplicates: dict[str, list[HeldCopy]] | None = None,
    holding_root: Path | None = None,
) -> str:
    """Return a short fingerprint of the photos, sidecar facts, held copies and layout."""
    cols, rows = layout_size(layout)
    digest = hashlib.sha1(f"design {SHEET_DESIGN} {cols}x{rows}\n".encode("utf-8"))
    items = list(photos)
    if facts is None:
        holding_root = holding_root or _holding_root()
        held_duplicates = held_duplicates if held_duplicates is not None else _held_duplicates_by_hash(holding_root)
        facts = _facts_for(items, held_duplicates, holding_root)
    for photo in items:
        try:
            size = photo.stat().st_size
        except OSError:
            size = -1
        fact = facts.get(photo) or photo_facts(photo)
        digest.update(f"{photo.name.lower()}\t{size}\t{fact.key()}\n".encode("utf-8"))
    return digest.hexdigest()[:16]


def recorded_fingerprint(sheet: Path) -> str | None:
    """Return the fingerprint stored in a sheet, or None when it has none or can't be read."""
    try:
        from pypdf import PdfReader  # pylint: disable=import-outside-toplevel

        subject = str((PdfReader(sheet, strict=False).metadata or {}).get("/Subject") or "")
    except Exception:  # pylint: disable=broad-except
        return None
    return subject[len(SUBJECT_PREFIX):].strip() if subject.startswith(SUBJECT_PREFIX) else None


def is_current(
    folder: Path,
    layout: str | None = None,
    held_duplicates: dict[str, list[HeldCopy]] | None = None,
    holding_root: Path | None = None,
) -> bool:
    """Return True when folder's sheet exists and shows exactly what the folder holds now."""
    sheet = folder / SHEET_NAME
    if not sheet.exists():
        return False
    holding_root = holding_root or _holding_root()
    held_duplicates = held_duplicates if held_duplicates is not None else _held_duplicates_by_hash(holding_root)
    photos = photos_in(folder)
    facts = _facts_for(photos, held_duplicates, holding_root)
    return recorded_fingerprint(sheet) == fingerprint(photos, layout, facts)


def caption_date(name: str) -> str:
    """Return 'YYYY-MM-DD HH:MM' from a DA name (photo_19980704_101500_ab12.jpg), else ''."""
    m = _NAME_DATE.search(name)
    if not m:
        return ""
    year = m.group(1) if len(m.group(1)) == 4 else f"20{m.group(1)}"
    return f"{year}-{m.group(2)}-{m.group(3)} {m.group(4)}:{m.group(5)}"


def _on_sheet(path: Path) -> bool:
    """Return True for a photo, or a video that isn't a Live Photo's (that one shows as its photo)."""
    suffix = path.suffix.lower()
    if suffix in IMAGE_EXTENSIONS:
        return True
    if suffix in VIDEO_TILE_EXTENSIONS:
        from mindit.services.validateit.validateit_file_types import still_for_video  # pylint: disable=import-outside-toplevel

        return still_for_video(path) is None
    return False


def _length_text(seconds: float | None, video: Path | None = None) -> str:
    """Return '1:06' for a video's length (from the sidecar's figure, else the file), or ''."""
    if seconds is None and video is not None:
        from mindit.services.video.video_info import read_video_info  # pylint: disable=import-outside-toplevel

        seconds = (read_video_info(video) or {}).get("duration")
    if not seconds:
        return ""
    minutes, secs = divmod(int(round(seconds)), 60)
    return f"{minutes // 60}:{minutes % 60:02d}:{secs:02d}" if minutes >= 60 else f"{minutes}:{secs:02d}"


HEIF_PREVIEW_MIN = 240                   # px on the long side: smaller built-in previews aren't used


def _heif_preview(photo: Path):
    """Return the small preview a HEIC file carries (already turned the right way), or None."""
    try:
        import pillow_heif  # pylint: disable=import-outside-toplevel

        heif = pillow_heif.open_heif(str(photo))
        image = heif[heif.primary_index]
        if not image.info.get("thumbnails"):
            return None
        preview = image.get_thumbnail(0).to_pillow()
        return preview if max(preview.size) >= HEIF_PREVIEW_MIN else None
    except Exception:  # pylint: disable=broad-except
        return None


THUMB_SIZE = 400                         # px on the long side of a kept thumbnail (~25 KB)
THUMBS = Path(".da") / "thumbs"          # in the archive; safe to delete, DA makes them again
_THUMB_DIR: list[Path | None] = [None]   # the archive's thumbs folder while a sheet is being made


def thumbs_dir(folder: Path) -> Path | None:
    """Return the thumbnail folder of the archive folder is in (None outside an archive)."""
    for parent in [folder, *folder.parents]:
        if (parent / "da-archive.yaml").exists():
            return parent / THUMBS
    return None


def _thumbnail(photo: Path, box: tuple[int, int], sha256: str | None = None):
    """Return a reportlab ImageReader of a small copy of photo, or None when it can't be read.

    With the photo's SHA-256 (in an archive), the small copy is kept in .da\thumbs under that hash, so a
    sheet made again after a rename, a move or a regroup doesn't open the photo at all.
    """
    from reportlab.lib.utils import ImageReader  # pylint: disable=import-outside-toplevel

    cache = _THUMB_DIR[0] / sha256[:2] / f"{sha256}.jpg" if _THUMB_DIR[0] and sha256 else None
    if cache is not None:
        if cache.exists():
            return ImageReader(str(cache))
        small = _small_copy(photo, (THUMB_SIZE, THUMB_SIZE))
        if small is None:
            return None
        try:
            cache.parent.mkdir(parents=True, exist_ok=True)
            part = cache.with_name(cache.name + ".part")
            part.write_bytes(small.getvalue())
            os.replace(part, cache)                              # whole files only, never half a thumbnail
        except OSError:
            pass                                                 # can't keep it: still draw it
        small.seek(0)
        return ImageReader(small)
    small = _small_copy(photo, (box[0] * 2, box[1] * 2))
    return ImageReader(small) if small is not None else None


def _small_copy(photo: Path, size: tuple[int, int], preview: bool = True) -> io.BytesIO | None:
    """Return photo as a JPEG at most `size`, turned the right way up, or None when it can't be read.

    preview=False never uses a HEIC's own small preview (for pictures bigger than it, like da share's).
    """
    from PIL import Image, ImageOps  # pylint: disable=import-outside-toplevel

    box = (size[0] // 2, size[1] // 2)                           # the code below asks for twice its box
    try:
        small = _heif_preview(photo) if preview and photo.suffix.lower() in (".heic", ".heif") else None
        if small is not None:                                    # the phone's own preview: ~40x faster
            small.thumbnail((box[0] * 2, box[1] * 2))
            out = io.BytesIO()
            small.convert("RGB").save(out, "JPEG", quality=80)
            out.seek(0)
            return out
        with Image.open(photo) as img:
            if img.format == "JPEG":
                img.draft("RGB", (box[0] * 2, box[1] * 2))       # decode at reduced size: much faster
            img = ImageOps.exif_transpose(img)
            img.thumbnail((box[0] * 2, box[1] * 2))
            out = io.BytesIO()
            img.convert("RGB").save(out, "JPEG", quality=80)
        out.seek(0)
        return out
    except Exception:  # pylint: disable=broad-except
        return None


# --------------------------------------------------------------------------- the sheet

def camera_groups(photos: list[Path], facts: dict[Path, Facts]) -> list[tuple[str, str | None, list[Path]]]:
    """Return the photos by camera and owner, most photos first (an unknown camera last), each in date order."""
    groups: dict[tuple[str, str | None], list[Path]] = {}
    for photo in photos:
        fact = facts[photo]
        groups.setdefault((fact.camera, fact.owner), []).append(photo)
    order = sorted(groups.items(), key=lambda kv: (kv[0][0] == UNKNOWN_CAMERA, -len(kv[1]), kv[0][0].lower()))
    return [(camera, owner, items) for (camera, owner), items in order]


def make_sheet(
    folder: Path,
    *,
    title: str | None = None,
    version: str = "",
    layout: str | None = None,
    held_duplicates: dict[str, list[HeldCopy]] | None = None,
    holding_root: Path | None = None,
) -> Path | None:
    """Write folder's contact sheet; with no photos left, remove an old sheet. Return the sheet or None."""
    sheet = folder / SHEET_NAME
    photos = photos_in(folder)
    if not photos:
        sheet.unlink(missing_ok=True)
        return None

    _THUMB_DIR[0] = thumbs_dir(folder)
    try:
        return _write_sheet(folder, sheet, photos, title=title, version=version, layout=layout,
                            held_duplicates=held_duplicates, holding_root=holding_root)
    finally:
        _THUMB_DIR[0] = None


def _write_sheet(folder: Path, sheet: Path, photos: list[Path], *, title: str | None, version: str,
                 layout: str | None, held_duplicates: dict[str, list[HeldCopy]] | None,
                 holding_root: Path | None) -> Path:
    from reportlab.lib.pagesizes import letter  # pylint: disable=import-outside-toplevel
    from reportlab.pdfgen import canvas  # pylint: disable=import-outside-toplevel

    cols, rows = layout_size(layout)
    holding_root = holding_root or _holding_root()
    held_duplicates = held_duplicates if held_duplicates is not None else _held_duplicates_by_hash(holding_root)
    facts = _facts_for(photos, held_duplicates, holding_root)
    groups = camera_groups(photos, facts)
    per_page = cols * rows
    first_page: dict[tuple[str, str | None], int] = {}
    page_no = 2
    for camera, owner, items in groups:
        first_page[(camera, owner)] = page_no
        page_no += (len(items) + per_page - 1) // per_page
    camera_pages = page_no - 1
    duplicate_groups = [(photo, facts[photo].duplicates) for photo in photos if facts[photo].duplicates]
    duplicate_pages = sum(_duplicate_page_count(copies) for _photo, copies in duplicate_groups)
    pages = camera_pages + duplicate_pages
    label = title or folder.name

    tmp = sheet.with_name(sheet.name + ".tmp")
    pdf = canvas.Canvas(str(tmp), pagesize=letter)
    pdf.setTitle(f"Contact sheet: {label}")
    pdf.setSubject(SUBJECT_PREFIX + fingerprint(photos, f"{cols}x{rows}", facts))
    pdf.setCreator(f"DA v{version}" if version else "DA")
    made_on = datetime.now().strftime("%Y-%m-%d %H:%M")
    footer = f"Made by DA{' v' + version if version else ''} on {made_on}"

    _summary_page(pdf, letter, label, photos, facts, groups, first_page, pages, footer)
    page = 1
    for camera, owner, items in groups:
        for start in range(0, len(items), per_page):
            page += 1
            _photo_page(pdf, letter, f"{label} - {camera}" + (f" / {owner}" if owner else ""),
                        items[start:start + per_page], facts, (cols, rows), page, pages,
                        f"{len(items):,} {'picture' if len(items) == 1 else 'pictures'} from this camera", footer)
    page = camera_pages
    for primary, copies in duplicate_groups:
        for start in range(0, len(copies), 3):
            page += 1
            _draw_duplicate_page(pdf, letter, label, primary, list(copies[start:start + 3]),
                                 facts[primary], page, pages, footer)
    pdf.save()
    os.replace(tmp, sheet)
    return sheet


def _duplicate_page_count(copies: tuple[HeldCopy, ...]) -> int:
    """Return the pages needed to show held copies, at three per page."""
    return (len(copies) + 2) // 3


def _wrapped_pdf_lines(text: str, width: float, font: str, size: float) -> list[str]:
    """Wrap text at any character so long file paths and hashes remain fully visible."""
    from reportlab.pdfbase import pdfmetrics  # pylint: disable=import-outside-toplevel

    lines: list[str] = []
    current = ""
    for char in text:
        candidate = current + char
        if current and pdfmetrics.stringWidth(candidate, font, size) > width:
            lines.append(current)
            current = char
        else:
            current = candidate
    if current or not lines:
        lines.append(current)
    return lines


def _draw_pdf_lines(pdf, text: str, x: float, y: float, width: float, *, font: str, size: float,
                    leading: float) -> float:
    """Draw fully wrapped text and return the next baseline."""
    pdf.setFont(font, size)
    for line in _wrapped_pdf_lines(text, width, font, size):
        pdf.drawString(x, y, line)
        y -= leading
    return y


def _draw_duplicate_page(pdf, size, label: str, primary: Path, copies: list[HeldCopy], primary_fact: Facts,
                         page: int, pages: int, footer: str) -> None:
    """Draw one page comparing a primary photo with up to three copies in holding."""
    width, height = size
    margin = 36
    text_x = margin + 112
    text_width = width - margin - text_x
    primary_stat = primary.stat()

    pdf.setFillGray(0)
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(margin, height - 40, f"{label} - copies in holding"[:90])
    pdf.setFont("Helvetica-Bold", 10)
    pdf.drawString(margin, height - 62, "PRIMARY FILE")
    primary_image = _thumbnail(primary, (200, 140), primary_fact.sha256)
    if primary_image:
        iw, ih = primary_image.getSize()
        scale = min(94 / iw, 68 / ih)
        pdf.drawImage(primary_image, margin, height - 148, iw * scale, ih * scale)
    else:
        pdf.setFont("Helvetica", 8)
        pdf.drawString(margin, height - 100, "(thumbnail unavailable)")

    text_y = height - 62
    text_y = _draw_pdf_lines(pdf, f"Location: {primary}", text_x, text_y, text_width,
                             font="Helvetica", size=8, leading=10)
    text_y = _draw_pdf_lines(pdf, f"Size: {primary_stat.st_size:,} bytes", text_x, text_y, text_width,
                             font="Helvetica", size=8, leading=10)
    _draw_pdf_lines(pdf, f"SHA-256: {primary_fact.sha256 or 'not recorded'}", text_x, text_y, text_width,
                    font="Helvetica", size=8, leading=10)

    y = height - 170
    for copy in copies:
        pdf.setStrokeGray(0.78)
        pdf.line(margin, y, width - margin, y)
        pdf.setFont("Helvetica-Bold", 9)
        pdf.drawString(margin, y - 14, "HELD DUPLICATE" if copy.kind == "exact copy" else f"HELD {copy.kind.upper()}")
        image = _thumbnail(copy.path, (200, 140), copy.sha256)
        if image:
            iw, ih = image.getSize()
            scale = min(94 / iw, 68 / ih)
            pdf.drawImage(image, margin, y - 98, iw * scale, ih * scale)
        else:
            pdf.setFont("Helvetica", 8)
            pdf.drawString(margin, y - 50, "(thumbnail unavailable)")

        text_y = y - 14
        text_y = _draw_pdf_lines(pdf, f"Location: {copy.path}", text_x, text_y, text_width,
                                 font="Helvetica", size=7.5, leading=9)
        text_y = _draw_pdf_lines(pdf, f"Size: {copy.size_bytes:,} bytes", text_x, text_y, text_width,
                                 font="Helvetica", size=7.5, leading=9)
        _draw_pdf_lines(pdf, f"SHA-256: {copy.sha256}", text_x, text_y, text_width,
                        font="Helvetica", size=7.5, leading=9)
        y -= 142

    _footer(pdf, size, footer, page, pages)
    pdf.showPage()


def _summary_page(pdf, size, label: str, photos: list[Path], facts: dict[Path, Facts],
                  groups, first_page: dict, pages: int, footer: str) -> None:  # pylint: disable=too-many-locals,too-many-arguments
    width, height = size
    margin = 40
    videos = sum(1 for p in photos if p.suffix.lower() in VIDEO_TILE_EXTENSIONS)
    stills = len(photos) - videos
    dates = sorted(d for d in (caption_date(p.name) for p in photos) if d)
    with_gps = sum(1 for p in photos if facts[p].gps)
    places = Counter(facts[p].place for p in photos if facts[p].place)
    schemas = Counter(facts[p].schema for p in photos)

    pdf.setFillColorRGB(0.17, 0.43, 0.57)
    pdf.rect(0, height - 74, width, 74, stroke=0, fill=1)
    pdf.setFillGray(1)
    pdf.setFont("Helvetica-Bold", 20)
    pdf.drawString(margin, height - 40, label)
    pdf.setFont("Helvetica", 10.5)
    counts = f"{stills:,} photo{'s' if stills != 1 else ''}" + (f", {videos:,} video{'s' if videos != 1 else ''}" if videos else "")
    span = (f"{dates[0][:10]} to {dates[-1][:10]}" if dates and dates[0][:10] != dates[-1][:10]
            else (dates[0][:10] if dates else "no dates in the names"))
    pdf.drawString(margin, height - 60, f"Contact sheet   |   {counts}   |   {span}   |   {pages} pages")

    y = height - 104

    def heading(text: str) -> None:
        nonlocal y
        pdf.setFillColorRGB(0.17, 0.43, 0.57)
        pdf.setFont("Helvetica-Bold", 12)
        pdf.drawString(margin, y, text.upper())
        pdf.setStrokeGray(0.8)
        pdf.line(margin, y - 4, width - margin, y - 4)
        y -= 22

    def row(cells: list[tuple[float, str, str]], *, bold: bool = False, gray: float = 0.1) -> None:
        nonlocal y
        pdf.setFillGray(gray)
        pdf.setFont("Helvetica-Bold" if bold else "Helvetica", 10.5)
        for x, text, align in cells:
            if align == "r":
                pdf.drawRightString(x, y, text)
            else:
                pdf.drawString(x, y, text)
        y -= 15

    heading("This month")
    row([(margin, "Pictures with a GPS position", "l"), (width - margin, f"{with_gps:,} of {len(photos):,}", "r")])
    duplicate_photos = sum(1 for photo in photos if facts[photo].duplicates)
    duplicate_copies = sum(len(facts[photo].duplicates) for photo in photos)
    if duplicate_copies:
        row([(margin, "Photos with copies in holding", "l"),
             (width - margin,
              f"{duplicate_photos:,} photo{'s' if duplicate_photos != 1 else ''}, "
              f"{duplicate_copies:,} copies", "r")])
    if places:
        shown = ", ".join(f"{name} ({n:,})" for name, n in places.most_common(6))
        more = f" and {len(places) - 6} more" if len(places) > 6 else ""
        row([(margin, "Places", "l"), (width - margin, shown + more, "r")])
    named = Counter(name for p in photos for name in people(facts[p].faces))
    if named:
        shown = ", ".join(f"{name} ({n:,})" for name, n in named.most_common(5))
        more = f" and {len(named) - 5} more" if len(named) > 5 else ""
        row([(margin, "People", "l"), (width - margin, shown + more, "r")])
    sidecars = ", ".join(f"schema {v} ({n:,})" if v not in ("-", "?") else
                         ("no sidecar" if v == "-" else "no version") + f" ({n:,})"
                         for v, n in sorted(schemas.items(), reverse=True))
    row([(margin, "Sidecars", "l"), (width - margin, sidecars, "r")])
    y -= 10

    heading("Cameras")
    cam_x, own_x, num_x, date_x, page_x = margin, margin + 210, margin + 330, margin + 440, width - margin
    row([(cam_x, "Camera", "l"), (own_x, "Taken by", "l"), (num_x, "Pictures", "r"), (date_x, "Dates", "r"),
         (page_x, "Page", "r")], bold=True, gray=0.35)
    for camera, owner, items in groups[:24]:
        days = sorted(d[:10] for d in (caption_date(p.name) for p in items) if d)
        when = (f"{days[0][5:]} to {days[-1][5:]}" if days and days[0] != days[-1] else (days[0][5:] if days else ""))
        row([(cam_x, camera[:38], "l"), (own_x, (owner or "-")[:20], "l"), (num_x, f"{len(items):,}", "r"),
             (date_x, when, "r"), (page_x, str(first_page[(camera, owner)]), "r")])
    if len(groups) > 24:
        row([(cam_x, f"and {len(groups) - 24} more cameras", "l")], gray=0.4)
    y -= 12
    pdf.setFillGray(0.4)
    pdf.setFont("Helvetica", 9)
    pdf.drawString(margin, y, "On each picture: GPS down the left edge = it has a position; the number in the circle "
                              "= its sidecar's schema version.")
    pdf.drawString(margin, y - 12, "A yellow box = a face, with the person's name above it (from Picasa).")
    _footer(pdf, size, footer, 1, pages)
    pdf.showPage()


def _photo_page(pdf, size, header: str, items: list[Path], facts: dict[Path, Facts], grid: tuple[int, int],
                page: int, pages: int, subheader: str, footer: str) -> None:  # pylint: disable=too-many-locals,too-many-arguments,too-many-statements
    width, height = size
    cols, rows = grid
    margin, head, foot = 36, 40, 20
    big = cols <= 3
    name_size, date_size = (8.5, 8.0) if big else (7.0, 7.0)
    caption = name_size + date_size + 10
    gutter = 13                                              # room for "GPS" down the left of each picture
    cell_w = (width - 2 * margin) / cols
    cell_h = (height - 2 * margin - head - foot) / rows
    box_w = cell_w - gutter - 8

    top = height - margin
    pdf.setFillGray(0)
    pdf.setFont("Helvetica-Bold", 13)
    pdf.drawString(margin, top - 14, header[:90])
    pdf.setFont("Helvetica", 9)
    pdf.setFillGray(0.4)
    pdf.drawString(margin, top - 28, subheader)
    pdf.setStrokeGray(0.7)
    pdf.line(margin, top - head + 4, width - margin, top - head + 4)

    for i, photo in enumerate(items):
        col, row = i % cols, i // cols
        x = margin + col * cell_w
        y = top - head - (row + 1) * cell_h
        fact = facts[photo]
        noted = bool(fact.duplicates or fact.versions)
        tile_caption = caption + (10 if noted else 0)
        area_x, area_y = x + gutter, y + tile_caption
        tile_box_h = cell_h - tile_caption - 8
        image = (_thumbnail(photo, (int(box_w * 2), int(tile_box_h * 2)), fact.sha256)
                 if photo.suffix.lower() in IMAGE_EXTENSIONS else None)
        if image is not None:
            iw, ih = image.getSize()
            scale = min(box_w / iw, tile_box_h / ih)
            dw, dh = iw * scale, ih * scale
            ix, iy = area_x + (box_w - dw) / 2, area_y + (tile_box_h - dh) / 2
            pdf.drawImage(image, ix, iy, dw, dh)
            draw_faces(pdf, fact.faces, ix, iy, dw, dh, size=6.0 if big else 5.0)
        else:
            dw, dh = box_w, tile_box_h * 0.75
            ix, iy = area_x, area_y + (tile_box_h - dh) / 2
            is_video = photo.suffix.lower() in VIDEO_TILE_EXTENSIONS
            pdf.setFillGray(0.18 if is_video else 0.9)
            pdf.rect(ix, iy, dw, dh, stroke=0, fill=1)
            pdf.setFillGray(1 if is_video else 0.4)
            if is_video:
                pdf.setFont("Helvetica-Bold", 13 if big else 11)
                pdf.drawCentredString(ix + dw / 2, iy + dh / 2 + 3, "VIDEO")
                pdf.setFont("Helvetica", 9 if big else 8)
                pdf.drawCentredString(ix + dw / 2, iy + dh / 2 - 11, _length_text(fact.seconds, photo))
            else:
                pdf.setFont("Helvetica", 8)
                pdf.drawCentredString(ix + dw / 2, iy + dh / 2, "(can't show this one)")
        if fact.gps:                                         # GPS, bold, reading up the picture's left edge
            pdf.saveState()
            pdf.setFillColorRGB(0.05, 0.45, 0.2)
            pdf.setFont("Helvetica-Bold", 9 if big else 8)
            pdf.translate(ix - 3, iy + dh / 2)
            pdf.rotate(90)
            pdf.drawCentredString(0, 0, "GPS")
            pdf.restoreState()
        radius = 7.5 if big else 6.5                         # the sidecar's schema version, circled, top right
        cx, cy = ix + dw - radius - 2, iy + dh - radius - 2
        pdf.setFillGray(1)
        pdf.setStrokeColorRGB(0.17, 0.43, 0.57)
        pdf.setLineWidth(1.2)
        pdf.circle(cx, cy, radius, stroke=1, fill=1)
        pdf.setFillColorRGB(0.17, 0.43, 0.57)
        pdf.setFont("Helvetica-Bold", 8.5 if big else 7.5)
        pdf.drawCentredString(cx, cy - 3, fact.schema)
        pdf.setLineWidth(1)

        pdf.setFillGray(0)
        pdf.setFont("Helvetica", name_size)
        limit = 38 if big else 34
        name = photo.name if len(photo.name) <= limit else photo.name[:limit - 3] + "..."
        pdf.drawCentredString(x + cell_w / 2, y + date_size + (14 if noted else 6), name)
        when = caption_date(photo.name)
        if when:
            pdf.setFillGray(0.35)
            pdf.setFont("Helvetica", date_size)
            pdf.drawCentredString(x + cell_w / 2, y + (8 if noted else 3), when)
        if fact.duplicates or fact.versions:
            pdf.setFillColorRGB(0.65, 0.22, 0.08)
            pdf.setFont("Helvetica-Bold", 6.5 if big else 6)
            pdf.drawCentredString(x + cell_w / 2, y + 1, tile_note(fact)[:60])
    _footer(pdf, size, footer, page, pages)
    pdf.showPage()


def tile_note(fact: Facts) -> str:
    """Return a tile's note: '3 copies in holding (1 resized)', '2 duplicates in holding', '+2 versions (cropped)'."""
    parts = []
    if fact.duplicates:
        count = len(fact.duplicates)
        kinds = Counter(c.kind.split()[0] for c in fact.duplicates if c.kind != "exact copy")
        if kinds:
            parts.append(f"{count} cop{'ies' if count != 1 else 'y'} in holding ("
                         + ", ".join(f"{n} {k}" for k, n in sorted(kinds.items())) + ")")
        else:
            parts.append(f"{count} duplicate{'s' if count != 1 else ''} in holding")
    if fact.versions:
        role, others = fact.versions[0], fact.versions[1:]
        if role == "original":
            parts.append(f"+{len(others)} version{'s' if len(others) != 1 else ''} ("
                         + ", ".join(sorted(set(others))) + ")")
        else:
            parts.append(f"{role} version - original filed too")
    return " | ".join(parts)


def _footer(pdf, size, text: str, page: int, pages: int) -> None:
    width, _height = size
    pdf.setFont("Helvetica", 7.5)
    pdf.setFillGray(0.45)
    pdf.drawString(36, 22, text)
    pdf.drawRightString(width - 36, 22, f"page {page} of {pages}")
    pdf.setFillGray(0)


def refresh_sheets(folders: Iterable[Path], *, create: bool, version: str = "", layout: str | None = None,
                   progress: Callable[[str], None] | None = None, holding_root: Path | None = None,
                   held: dict[str, list[HeldCopy]] | None = None) -> SheetResult:
    """Make sheets for folders whose photos changed; create=False only updates sheets that exist.

    held: the holding folder's copies (held_copies()), when the caller refreshes more than once in a row.
    """
    result = SheetResult()
    held_duplicates: dict[str, list[HeldCopy]] | None = held
    for folder in sorted(set(folders)):
        sheet = folder / SHEET_NAME
        if not create and not sheet.exists():
            continue
        if held_duplicates is None:
            holding_root = holding_root or _holding_root()
            held_duplicates = _held_duplicates_by_hash(holding_root)
        if is_current(folder, layout, held_duplicates, holding_root):
            result.current += 1
            continue
        try:
            made = make_sheet(folder, version=version, layout=layout, held_duplicates=held_duplicates,
                              holding_root=holding_root)
        except Exception as exc:  # pylint: disable=broad-except
            result.failed.append((folder, f"{type(exc).__name__}: {exc}"))
            continue
        if made is None:
            result.removed.append(sheet)
        else:
            result.made.append(made)
            if progress:
                progress(f"contact sheet: {made}")
    return result


def folders_with_photos(root: Path) -> list[Path]:
    """Return root and every folder under it that has photos directly in it."""
    found = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d != "_duplicates-holding"]
        if any(Path(f).suffix.lower() in IMAGE_EXTENSIONS | VIDEO_TILE_EXTENSIONS for f in filenames):
            found.append(Path(dirpath))
    return found


def folders_with_sheets(root: Path) -> list[Path]:
    """Return every folder under root (and root) that already has a contact sheet."""
    return [Path(d) for d, _dirs, files in os.walk(root) if any(f.lower() == SHEET_NAME for f in files)]
